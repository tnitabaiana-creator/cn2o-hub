/* ============================================================
   06 · GUIA DE ITBI  ·  v1.33
   ------------------------------------------------------------
   Gerador da guia de ITBI da Prefeitura Municipal de Itabaiana-SE.
   Página interna de composição: o escrevente preenche, aperta o
   botão e sai o PDF pronto para imprimir e assinar.

   NADA VAI AO SERVIDOR — os dados só vivem nesta tela; ao sair ou
   apertar "Limpar", somem. O desenho da guia usa o PDFMini
   (frontend/src/pdf-mini.js), sem nenhuma dependência externa.

   Regras do Tabelião (16/09/2026):
   · A4 retrato (o modelo da Prefeitura é Ofício — as alturas são
     comprimidas até caber em uma página).
   · Só a PROFISSÃO entra a mais na qualificação.
   · Botão "não consta" ao lado de cada campo (menos os nomes, as
     observações e o nº da guia, que é numeração da Prefeitura);
     ligado, a guia imprime "NÃO CONSTA".
   · Valor do negócio: campo em R$ com máscara, ou "Não declarado".
   · Assinatura: nome e cargo de quem está logado (SESSAO).
============================================================ */
(function () {
  'use strict';
  var pag = document.getElementById('paginaItbi');
  if (!pag || typeof PDFMini !== 'function') return;

  var MM = 72 / 25.4;
  /* brasão de Itabaiana/SE — JPEG (fundo branco, q92, 186×210 px) embutido */
  var BRASAO = '/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCADSALoDASIAAhEBAxEB/8QAHgABAAEEAwEBAAAAAAAAAAAAAAgBBgcJAgQFAwr/xABFEAABAwQBAgQDAwcKBgEFAAABAgMEAAUGEQcSIQgTMUEiUWEUMnEVI0JSgZGxCRYXJDM0cnOhsjU3U2KS0cFkgoSi4f/EABsBAQACAwEBAAAAAAAAAAAAAAAEBgEFBwMC/8QAOhEAAQMCAwQHBQYHAQAAAAAAAQACAwQRBSExBhJBURMiYXGBkbEUcqHB8AcjUmLR4RUyNDWy0vFC/9oADAMBAAIRAxEAPwDanSlKIlKUoiUpSiJSlKIlKVTqG9aP7qIq0riVAHWj+6qg7G6Iq0riFAnWj+6q7FEVaUpREpSlESlKURKUpREpSlESlKURKUpREqhIFFHX7wKiV4kfFrlGCZBf+NcUsTcK4x2W/s96ccCktlWjvyz61Drq+DD4ulnNh81JpaSSsk6OIZqWEiXHisLkyXkMtNpK1rcPSEpHqTusG5R4xeILRZXJ1hvCrzM+0piMxUIKfMcKwk/ERrQ71HJzxmY3mXCN/wCOOSb9IRmrDaG2nY7RSm4knewQNJ16VGi45Rf40eK1a7E3OiwZDUjyNBKj0kHW/rVcrtp+jlibTNuHWJJ4A+ORC3FHgL5myGU2LbgDQkjlcZhbLecfEaviF/FIrOIOXd3JwSnToQGdJBOzrv61j/jjxB59nHOtutb0pqLj90YV02oIClsqQO56wO+9VFrlfxB5fzhLgu33Cv5uw7a0lECKlzrUwrWlK6h89VZ2LZPmWE5DEy7GMg+zXK3BSWVODqGldiCD6+ta7FNo5DVMbCfu2uBJGpA1Guh5FS6HAD0T3zA7xBABAsDw4X7D8FLXnjxA8t4fyVlVmxvIWIkCzsNLYjrYBUoqTs9yKz54f84yTOeFLTl2SvF26y47ri3EtdIJBIBA19K1e5zeOReQ8mm5bkOXlU64IDbvQ10ggDQ7VduGc4eI/BsXYxKx8pMot8VBbjoVCBLaSSdb19TWaXHw2tfUSOJYQQG30zvppovt+BF9KIo2/eXzNjpbPhfVSU4M8QXL+Y88MYdkGQtSbOHZKXGUxglRCSenvr2q9OX/ABnr4t5FueB/0dP3EwENrTJD4QHOob1oioIYvkXJeFZUnNMfzpAvCVLUHSyCNr+9sfWu/kmXZRmGSPZdl8n8qXWQEec8lPQFhPoNe1Q4No56aIs3rvL78xu8syvWbAWOc0AG26Bl+Py0+K2QTefFW7g1vmOZijzYUWyu3lelJSpfTveu+vWvq54pOFY6oDUzL0x3riEeU2ppXqr0B7dqgfevFVyBdOMLrxRc+Pky4E9LaIU1LuvyeEkHuP0tkf6msXXjNem3IuN+cLUqOgNJSlnexrXb5Vtajah0Ya2CziW8uPLIqBFs9KGGScbovb6yW5ePKjymUvxnkPNrHUlbaupKh8wRX2qDWL+JbGMP8LlttmD5r5eXsNeZGYlJ6lLIX1LQSr2Kd1KnhLklzljjWzZ29bhBcuTZ8xgL6glaSQdH8RViosVgrXCNp6+6HEcuY7wdVqKiglgYZbdW5F/rmr8pSlbRQUpSlESlKURKUpREpSlEVFDY/A7rXt48+IGbPm7HKz01U0XwpYMbzOkxOgD4gP0t1sKqJP8AKG4H+UuLWeT48p0ysJcDjUNJ+GSHFJSQfw3utZi9LHV0j2PGgJHkpdDUS01Qx8OtwDflcX4hQgxqK1kt2cxjF4KJ09tIU4lxkA/+Zrt51Y86wlNuel4qJBfJS42hzsP216PF2VGHmVtjwYgTHlshcx5KNKQpSdgb9+9Zg5aa6+PpykgqkggsqPfpBPzrh9bX+wVsdI1t2uIGd75m3YuzU1DHUUpqbguH4eYF1Gb7fmUmcE/kUwopKQXyrq6d1nfHeHLY9a0y592XLW7HU4hxKD663UfbhY80dPQ3yG1CbkAdCFpHw/vr2bNd+cLZGTbrVymn7LGSU+YIwWlwH1AVWyraOWVjDDK1liNSRfxtqolLWRxuc18bnXvawvbt7F1Z2OZiqY+hjNw22l1SW0eT3ABr4osOYNSY7bmcpc63UJUjyfYmvqm2ZCyvzpmZx1ySoqWpWk7J+ldl60z1FuQjI4rchJCg55ie5HpoVI35BFk0X52y05rxe6ORw3CQb3scjbks6TuFYDMJEhF3cZcRGDi3fKJ6iU79Kj/cLfmNqmvuw7obs0FkJZDfToA/OriumUc4zGVsp5SREjqQEfHFAATrXqasZFgzwJUpjlmKd9R+6nZNR6Cgnu6UytItoSTnry9F7VmI0xa2IRuDudteGqyPhuL5tk0ZcpGO+SHO21Oen7K8HK7kMHu7tlzmD9nSoAsrS35nVUgeGIU22cZW126z/wApXBRUXX09hrfrWC+WcnypzkK5IjYM3dLanoS3PcVvR99A/KoWE1PtlfNC+1mBxy7CBbNSa2Ho6SKWO53iAd7PIjXuVvNT8MytDcVL7jofWGG1FHlAKV2A37brbF4a8CkcbcNY7h0uF9legtFSmuvr6eok+v7a1iYVglk5vzzH+GDfFY5cLu6m4tzGY++nyPjKO3z1qtwNrifYYEaIXS4YzKGCo+quga3+3VdK2Ro27j6vrAkkAHS2R9VznaeoeJxSgN3QAbt55hdylKVdFVkpSlESlKURKUpREpSlESrezvGLJl+LXGwZDbRPgSGFqdjn9MpGwP3irhritPUNH8awQHCx0RaWlXXLjlkxuNj6cWFruKmkh0/EWQvQ2D8xUpMgiIzDFHoFufQpl6IFh5J31KSnZP768vx+8d43iOdws7nTHVnLx5CorKOlLPlJHxdvnVucacicdWjAoMBy6uxVttONqCwSe9cN2wonRVoJZY74IsOGds/qy7BsdWNfRdHe9hY+9YXyUdZ1lsT4kKye5yJZC1thDe09IHb2qRXB0bEbhgjNmtETzI0M6Lbo2tOz7k9zWC7td7zBuktNjxZi6RFOKUy6tYG9n5VdXG3LOUYWmc3K45YcXKIKQmQkBOq8MQgmqqQGJ1jlle2duXNTqKQQ1Ty9osSeHC6tXmNriSzcjXO3XZy4NvsBBDbSVdPf8KthmTw6uVCOrm6UyGw20Ssdyrts1kTJ8pu2XZJIyKXiEOEH0hKkqCVk6+teP9oldbazjUX8y4HEgJSN6O9VKhmiipWRvkdvAC9nDW1slGe1xrHPDBa/4eF/ipD8oWfEIfH8qffbZuH9laKy32UAQOn0qLMSx8bS1s/YGp3nrXpBKlaAPpWYcy5tvOT4quys4E024+hDa+t8abCffX1rFgyLLW3mvsWDREJDiOp4Op+6D37VFwqCeKGQl98zbrcMvD4qVXSsdMzqgiw4cVLHA4CLRhMS0sudQbjOK61dgnYPrUWLlCyv7RPmjN2JiDIUG4qSN/e9KkBc+V8McxF23x53lSXYyW1R0jv1EaPeo1qiYDispycTMS+VKcCgpSwSe/pUTCGugkll3TvPJ0Gt89f01Xvir/uGRtIAABUkvAdBzDI+bV3OTgTAg402pqXdCsdTKlpPSAPr3rZgkaB7e5NRS8AnGbWP4DN5Nbvzsz+fJS+Yyk9IjeWVJA+tSvrt+CQNgomFotvAE95AXF8SnfPVPLxoSPAE9p1SlKVtlBSlKURKUpREpSlESlKURK8nJ8msuI2WRf8AIJgiwYoBddIJ6d/hXrVjDxH6/ofvxLYWAEfCff4hUuhgbVVUcLtHOA8zZRK+oNJSyTtFy1pPkLrFfiJyvhXmHAXrQzf2nLu2Au2vFkktK2N62PcbqNkLjDAkqYdkXYPAJAU15euogdzXphIDiVgI+NtOtJA6e1NIWoqDQGvWrtVfZthNcWyTFxLT+X5tVBi+0LFaaMtg6t88t4Dxs7VerDwzhFjqTMszrp7fElwjpr2BY/DahSVDBX1nWjt8/vq0ulG9pI18tVyLT/ZbcN935dDJIH7a8WfZjgMQu8HW/W3Lf4rDtu9oKkgiUjLg59/VZJxTGeBsmu8bHrdgay8+dJKnj2q/M34D4gwbH3r7csDL7Deioh7XRWMeFIz73KdkC4Uhj7xUstECpJ+JYLPFNxShhbxJQOhAJJ71X8U2RwWlxKKkjhjLX2ud1uVzbUC3wVhwvaHGp8NmqZJ3h7L26zuAB537lGmXbvDZcdL/AKOnUggb1II3XSkY54bngUxsOfZV7HzjqrW+zuJbaDdplAdI6vzJ+VVLa0ICVx3ED/vb6d/hVjd9nOAyt6NgAH5dz/VV1u2e0LOu6V1+Fy/L4ruTcF4YklZgWoxSr7pJ30/OrancS4NLmR127Im4kdDyC82tkK6kb+Ib+or10EK2AQAfpXENFTa2NgA/pa9a8IfsqwVrSLuyP5P9F6N+0PHZHXmkuALWu75uUvsR5k4Fwyy23FMfyBuLEZCWY7KWlaCj+A9SazK24h1CXEHaVpCgfmDWuKJ5f2q3oTHbbSmW1tJSCT8Xruti8D+5x9f9FH8K0+PYRTYM+OGmva3G1uWVgMlYdnsdmxoymYWLbZ2PG/MnkuzSlK0CsyUpSiJSlKIlKUoiUpSiJWMfEZ/ygv3+FH+4Vk6sY+I464fv3+FH+4VscI/uEPvN9Qtfi39BN7rvQqFTZ2Gif1B/Ci+3UR6n1qjXdDWx36R/CuXZSVdR7+1dx0d4Lh//AI8VRJCR8Xpo/wAKmTwfbccc4wsqpbcBbikqJLvT1E7Pruob9ltBKvUf61yVJmlISbnKCEfcabeKQn91ajHsLmxeBsELt0gg+FiOHetvg+JQYZP0s7N4EWtl2c1sIh27HGZSHIbMAPp9C309Q/Cu/PZhPxlNT0tKZV94O66f9ahDwk/NVypZGmrtL6XOrzELeUof61JHxKuPscVz3I8lxhwFIC0K0R3rmdbg01JWx0j33c7jyzsuj0OK09TQyVMcdmt1GWeXkr4/JWJdiGLXr27oqN/iriwI9zx9NmVFQAV+clrXwj9lYKD8woQn8pTx8IPX9pV61V16XLWn8oTnpSUdkFaidVb8J2ZqsPqG1Uslxyz4qn4rj9JWwmnhh3Xc8uHcvmroKyW1fE76EfSuQJB9e4qqFBCtNtdAR90/OqJSeoJKuoq7g1dhlH4qotJDSV9YmxKh7O/62z3/APurYtb/AO5x/wDIR/CtdEU6mREE9xLZ3/5VsXt/9zj/AOQj+Fcy23/qIvd+a6FsMbxynu+a7NKUqkK/JSlKIlKUoiUpSiJSlKIlYw8R3/J+/f4Uf7hWT6xh4j/+T9+/wo/3Ctjg/wDcIffb6ha/Fs6Cb3XehUKm/utf4B/CqigSptDSl6+4n3+lB3Ov413AmzvBcQAJaQOap312quh2Ou/vQ/D2Pt71xWoBOzvv9KyQ97g6M+KOLAOuNAr74PAHLNhKffq3UkvE1r+iq479OpP8ajZwhpvlewqUdfe3UkfE442nimf1b0VI9B9aoePXGO017cP8ir1gXWwKpIvbP/EKGieny0gfqj+FVB6Rr2qiUn82gfpIBH7qHXSSdgD31V8LH5OcRuqitcxwJaDe9r/XFVO9briVdiR6o9DXJJUvskjRqnTtJAHcnvWXPaGa6lfbmHojZfWIr+swdjuqWz/urYvb/wC5x/8AIR/CtdDQUmdDHbtLZ9Pb4q2L2/8Aucb/ACEfwrmm24tURe7810HYZhEEjudvRdmlKVR1e0pSlESlKURKUpREpSlESsYeI5akcQX5ST3CUf7hWT6xf4kVIRw7f1r9AlB//YVsMJO7Xwk/ib6hQMUbvUMw/K70UKEqaaHnLQQFISAon31XIFLiS26ouqT3KNaIrL3C/A10z0wspydlUayFKVsNqGlPa+Y9qy5yR4c8byG3B7FmharhHT2WB2d0Oya6jUbVUNNUezvzOl7Cw78/Ncupdmq+eF1RHkORvcjsy8uaiOlY8pKOnpQPRPuK4qcd0pBeClHWu33RXevliumL3WRCu0ZUeeweh2Or0WP1gferm4t4rvHJt3EG2lce1R1Azpqk9m/foT+tv0rZyYhBS0/tBfZlr6+mfktZDhs883s7GkuJ4/Ps5r3fDzit2vfI0O8W6Gp222wH7bLV2T1EHpCfnUlObsZvGW8dXKzWKOl+YsBTbROuvR7965XO68dcBcfuTrlKYs9jtTe1KP33FfQeqySawzwp48eO+Vc3kYLd4JxubJe1ZFPubTcGxvaidfAe3oa5JimPiqxBtVkC09UHjnfPPU8bLpVDQ0mGUv8ADZpLOkGYvzFjb99VgB+OYB+yyg4260eh1tSdKbUOx7VwcU6lAcU71MfpnXc/LtUv+ZuDYOasO5HjCG418CdqKQOmSAOw/wD7USp9vlWqc7FusYtSmCUrbX8Oj8wD6103B8bjxaA7psQLEHuztn5Ki4pgk+GSllrsOhH1a66wQkPJZLRW4sbbO9BA+ZrkFpUoHrU4O/SsjQc/D56rI/GHCGScjqRIdWu32lCwozin4nR7oA+vpUgs48P+IX7DWrHYoKbfOt6P6hJA7oV77+e+/wC+vGu2jw6jmjp3XJBF7WsO/t5jks0OzuIVVM+ZmQsbA3u7uy4+qhtEKTNhIZR0lcxrrWo9lfF8/atjVv8A7nH/AMhH8K19ZDilzxi/tY9k1tcjKRLYLscfdV8Q0sL+vrWwS3BIhRgkaAYbA/DVVLbWcVNVHJH/ACFuXn6aWVt2LgdT08sb733uPdou1SlKpiuqUpSiJSlKIlKUoiUpSiJXmZDj9oya1uWe9wxJiPKSpbR9FEHY/wBa9OsQeKvOMi464MybL8WuSYFygto8mQpIPQFKAJ0ffRrBlMA6UGxGeWuSj1cjIoHySi7QCSNclbHiH8VuFcFWpePWMM3LJS0G4tuZUAhrt2USOw166qMXh5/lDMqiZy5jnNE9FysUx0l68Jb8tNpWQehs6HxgnQ37VC6+ZJdctkyLnJuDqkuq8x6c6rqWpSu6tb710SIjsNpqSss2Rg7Devzktf19/Wqy7FJZZTIOF7dveueT4/VyVQljO61psG52tfiAczbK3A9gW7rOeM8N5gtEW6tvM+eUpdhXFg9Q6Do99eux/GvjlmbcX+HLBUuXWWzboMJs+Uwju6+vv2I9Ts+9ayvD14zOTOBd2Z+K5ktnlIKYePuO/FD+S/M/+KsLl3mfPuZ8ufmXu9KekOknqPZmA3/09eiu3bdbabH3vpRDvG40aTkDztyW0mx6mjj6emYBM7Im2nM9ovl22VxeJLxLZTz3lTdxuDL0aBEcUmzWZte22x2HmOEdlb9e9YiiOPKmOR475N1ZIelXFC+gMa7gIPtr6V8ULKxIZsr4hxI46ZUxfc79+jfrv6V82GbY5bfJmFUe1NK6kgH87JX9ffRNVh8kkry97jc8eXd2BVGWWWWQyvJ3ideIzv8A8Hicgp1eEfx9PQEMYNzJIWbOhQj2+/rB6ir0Sgp9SN671NjI+JOPOQ7pCym429uXpIdC2VfA+P0TsetaQRJnOPsPyISXJZSUQYI0Esp1rrPyOu9SS4O8bPJ3EmCyuMEr/L6WkK+x3J5X/CAdkpJP3+5NWDC8ZloxZzyCBqDnbkeZVloMaj6Loa9ocxumQOmXHXvyzyGSn/z94hsJ8OuImLFQxKvrjRTarO0rRcVsDatfdA9e/wAqhfw9/KD8kWDkN1XKD4vVjuTm5Kkp6BbU+wT+tqouZpyNf+Qb5NzLKr0/KW64QuUve3j7BCf0R+FW9LfUWkKnxfjdI8iEk91fJSj/AO6gy4pPNKXtyA0vx71Anx+sfVB0PVjbkG6acxexy1GgW7NbHHHiMweDkWP3JibCfWl+JNQNONlKu4WPUehGjWTI7IYYbZB35aEo3+ArTT4ZfEjm/AeZtNWpKrxa7nJaZvNtW50tbVtKFNk9klO/atycCSZcRiSU9PnNId18uob1W8pK01kQ3ibjK3Lu7FdsHr4cQY6VjbPy3uFzbXu5XzsuxSlKlLcpSlKIlKUoiUpVFHQ9PcCiKtKwzbvEhY0c6XrhHJ7abNMjttvWia4vbNwQUFS9q1psg6ABPesyJWFDtv8Ad60XnFMyYEsOhI8QuVR+8dUJdw8MWZRkQ3pSihpQaaSSpWlpPoKkDXxlxY01hcaUw2804kpW24kKSpJ9QQa+Xt32lvNfNRF08Tor2uCPNfn+T0rTHenN+WXUhLMRB3sgD72vSubceXInl6SlK5CRoI3+bjj2+hqYfjK8Flz43uk3kniS1uOYxclF26soHmLs/wB3qWhO9qCyT2HpUP1NJU0G1JfiWpn+0U6kpeeV8yk9xVNraeWmlNhkuTYhQz0EpjkH/Ozv4DU8bIiO5t6FFOi58Uq4KOvJSPYU823rtxWmStm0MnpS90/nJK/lr17mqSHG5UNpElCm4G/zTSfvydem/cVyU90OtOutpdmIGocIJ+BofrKqKev3qCM7AjP6+uTR2qjzLf2eKLgwUBJ3EtzZ2Ug/pLI/f3olhMieX2m0vSoydjqOm2x/AkVwbL7apAgSx9rf/wCIXFfdLKf1Ug/u7VwdYak2/wCNa4tjjq31D+1lr+nvrdfXRnmvvdLjfeP1+vDidTkubPXIS/KhulxCz0yJivhUv5pSPb9lU8llDH2eUFM2Rk9XkpP5ySv22fXW65vvvksSZUXT2gmHDb9On9ZevT9tcFx3vNTGakB2Xrqkun+zYHyHsTXy0Fpu4rALmu3jp9Z+GgPkF9FylIlIuc6KiRK6emNbk9kR0+yifQn3r5tx32Y633ZgDz+/NlEbKgf0Uj6enaiURfIUXHVM25B7rPdyUr5D3Ar3MWw6+ZbeY0eHa5E2bIUG4ENlJUmPv0KyPTf1r7eHyECLRHEuyb6eQ/X43OSu3w3cQu83csY7x9cXZFtsrbpmuvtIKi6pvagFKHpvXvW7SBFRDisxm99LDSWU7+SRoVHTwZ+G248G4rMn5Kto3vICh6THKAoxCnYCUq+u+9SSq3UFMaeEB38x1XTtn6F9HSgyiznZkcvr9lWlK+UiSxFaL0h9tpAIBW4sJSNnQ7mpq3q+tKtix8jYdkeWX3CrPeUSLzjYaNyigd2A4No3+Iq56LAIdmEpSlFlUJA9fwrEGYeKjhPDMuuWDXvK3herQlDk6LGiOPGOlWikq6QdbrL5SFDR+e6jjy/wxmOH5ZcOdeArZb5eSzwn+clhlsoWnJG0BKW2w4r+yKe52NelF8SOLG3AusX8NWrE/EZzhze/dETbthd8FsXbXno64zrLrKR1+Us6UkdQ9vXXesuQbpy7wXeps7kbIlZfgkhKnTcmmAh2xNoBCGyhOy71bSN+tXlw9yZGya2uWrJcVjYfltvbbVeLOQkIjKc7pCXAAlzY0e3zrJjzLElpTL7SHEKGlIcTtJ/EH1rAJIzK8mQsB6Rupz5ef7q3cJ5FxLkGxw8gxa8NS4s5BW0lR6HtAkHbZ+IenuKxNkPi7xDFubZvEV8s0xlu3sJek3RCCptnqTtIVodq97MfDrYZd9unIHHs9zFc4nMtsN3dslbLSU6BAY30d07Hp71jTgbDZUjmTmXF+QpkfJpL7MFqVOWwlKnkKaIKQP0ex9qyNc193k42Hz/T4qR9hyjFc3tDNxsN2gXSFLQSjocS4FgHvtP7Kjx4jPAthvN98ay+w3EYzeukpmOMs/m5ekgIBR6J0R3NdTPLN4aPC3jM5+0ZdNwOc0ShqdGS5PVCcdP3iz3+E7/1q7eMGuUZWAryW0892zkJL4D0SUGG2G1JPcIUR9wn00dGvKRjZG2eLqPU08dXEWVLN4fXxWuPkHwi+IHiuwz8uyXDg7boCz9puEdwOrQ11aSpLQO++x7Vh96PIiQX7lITNitv6D0yTGLanB7JSFf/ABW4PGuWfEDeLnItuceHT8mWtK+j7Sm4IkpcTv73QB6e9djmm1eHbIrXFTypjiH2ICuttLUJQKCoDYIQO9aqTCIngujJBVYqNl4Zb+zPIcOY+dv1C02K+wuRWostbaIH3kRkuDrUr2Kj6965vPvMON3W4vxnZbaeiJHS6ny46f1j7E1sJuWK/wAnBbZzr83GZyXinatRZRAH0Gq8VNq/kxXY5i/zfuam5it94svZI+uu1Qf4RM0/zjz/AGUMbLVXGQeZ8eHnxPYoFtuqbaWi13HzPtp/r04DrUsn0QhPt8u1ehGx+9yHYmMRccvEh2SrcSN9jWPMPzUutj+E454ArTcINwxnGJCX1KBYLsOQpJI9NhQ1UqbHkeBXvods8KMSjQSTA6CkfTYGqkxYPvZSO8lIh2VkcSaiQAcLfPTTs8LLWLxP4Bebc3ksZBl9oRZonw/ZepwH4PclG62K8IeHjAODbKuDj1raduM3pXPnOI61PrG+4390d/SvlceROaYnJsnFrfwyh/FGktli/m5IQlex8W2/VOq8vnK83aA5Yszhc8wcMx+wrW/fIrEdExdxQBvoSPvAjR9B71s6ajipR1fit/h+DUtCekYLuGVzw7lmJ27W1h9UVyfGDyUlZaLw8zQ/7fWrV4+5j4/5OmXeBht7VOkWJ7yJ7SmVIUwvvoEEfQ1YPGGPcCc2X6D4lMITcbhcHdsMzn1vMb6Ox6mFaA/8axnA425Dv3iV5Om8dchM4ZF6reJzLURLn20dHc6/ROtjfr3qWTyW1JeDopPZNnVgxixzL9MnNPMQtJWmMrzV9ZOkpIT3GzoVYjuL3/m7DbYOTrM/jUNby3rlYWn9reDa+plRcTojulKiP2V7/HfCWAcZSLvMxi2PJfvriXrgqS+p5Lzg/SCVEhPf5VfTrzTDanHXEIQPVS1aSO/uTX0sBrngdJ4jgoM4HzLxdxL4ouZMmzK4XeEjJVQI8DotrriXW2GygkFKT39Kz7gfjE4C5HzmJxziOZPzb/LStSIhhOIKAkbPWSn4Doe9OQckyrKcnTgPEuOwGpKm3mrtlEiGhabI507bUlChp0q0R29PWu/wV4erFxKzOyG6Lh3vN7+oO33IBES0qYtJV09CR/ZgAjsKwHbxzXmI5IyGsOXG/wBeSy8CD3Hz1VaUopKVQjY13/YarSiK08442xjPIiGL3CUXGlBbT7Ky24lYHwqUod1a0Do1gK38p+Ibgm8z7PzHiasswS0IVMez2MoB1LKtENmMn4lFG9bHrUqa+T8ZmS0tl9pDrbg6VNuJ6kKHyIPY16RvDLhwuD9ZFFY3G/NXHXLGHQc4w7IW3LTcHVNx3JwMVbiknuAhwA/6Vhfh/N7DD8XXNVhuDzsF8N251p2UgtR3k+X36HVfCojY9DWVuTfDjxPy09YX8zxxbhxuQZNuTCkLioaWSDspbICvT3rD3iD8GeZ+ILMojN95tkWvj6KGQMcgwwy+sIABCpKT1q3r3r63I36Ot3/t+iL5q41zaycj828sIjWvKYuWR4MHGYaHkS0I2kIcJR36dK0f2VH3KuOsnwzEYfhd4GReDAsMxF75XuyvMbMfzNPNtsKOuodldkb7JH7Jh414W8c4h48vOI+Hu8TcNuNzSkIuUt5c8tKB+8EuKI71XH8a5840wu9TshyeJyteFISmLBEJqCp4ehDix2V2J9fasBgc2+8AeWf18UUYs78S3LXKF3tjfBnLFqwvGMShKTkU24ltTz7rSfhSltfcletdvnXpZj4+smwDgji/NrxhlmyO9ZlOct9zV56D9gKXQlC1oHoVp7jehXfX4bcH5DzpF45I8EDlmQdvyLpDyHpQD6qKmUKAV+FW2ce/k0ELvcVy0XlSbnJbTKZXHlqQ28yr4S2CNJII9R615x088h6ovbksWKkVK8Q2F2zIeSoeSYnaYlp49t0CS5clNoKJT8psKba9O3xEJ39asy/eKF/GfD9I5RuPBtnkZTaZsdF3xmC61IMOI84Qh8uJBB+DpVr61iSBx/4a7nIzmPknO+QX7Hs4XFXc7WbU62fKjkFpsL1vsABuvW41wbwm8ZxM8g4Dybf4Vhz5uIwu2yoL0n7Chn76UqWNnr7636b+lffstT+A+RWc+SyBfvG1gttw/lvPrBgtsuNi42i25UOUgISLjKlJH5nsPh6VHpJ+lZd8OHMy+W+JoGc5LZrXZLw4wuVPtcN9D5iM9ygq6d9ynR1UTcd4l8HWI3bkMvZ7d5nHmfoirlYcbe/0xpDJCvNDgG+6tqHuN632rMfhdsnhvxCJmly8KtgutwlveS3c4U1bqUEoB6Eo80dh6+m6yaeaNu89pA7ksV3OVOZuPfEF4cs2uPGnL12xeJbpTcKZeUW50OsrDgBZQ2QCQvXTsem91EdVpv1w455Jgcb8P3/HsxxORbFWmbLedlNTW1qHmvhKgQeofFrvrdTSjcgc9tW2fHR4Vrc0nrJRHROZCH/kVADW/wAa7Ngw3xLZQWspuHIMHB2prSicZat7b4hq2QNu/pexrz6O+pS/BetwTests9lMbk9/HoziYkUs3Jt9qKZqujbm4415fSe31qz+BsvsuQeIPme+W+a4LaHIDCJMtBZZUsIIV0KV2I37iuF68AnEHIflX/mB275Ply0kyLyzcHoyFL2elSWkKCR0jXbXtV9474dbZL4WicRcq3hWVtR3krcmsI+xuvpbcKmQooIJKRob331QMDcr5BO9djmHxOcZ8M3a24zksyc7fb2gi1Qo0NbolOfopK0ghIJ13JqwsXtfiC56v32nl3Gjx3httcLbuOtSA87ex3U26p1Oi2EqCSU1Io2C0FMVK7ZEdMNCW2VvMpcWhKRoaUe4r0AkDfcnfzNe3Ssazda3M6k5+XJF8IsKPEbDbDKEAAJ2kaJAGhs+/auxSleCJSlKIlKUoiUpSiJVND5VWlESqEAjXp+FVpRFx8tPzJ+hO687+bdiJJNjtmydn+qI7/6V6dKyCQi85Ngsyfu2e3jfyio/9VUWKzgaFot4/wDxk/8AqvQpTeKLzzYrORo2i39//pk/+q+0K2QLf1/YoMWN5h2ryGg31fjr1rtUpcouPQPmr/yNVAAGv41WlYRKUpREpSlESlKURKUpREpSlESlKURKUpREpSlESlKURKUpREpSlESlKURKUpREpSlESlKURKUpRF//2Q==';

  var X0 = 11, LARG = 188, TOPO = 11, BAIXO = 11;
  var UTIL = 297 - TOPO - BAIXO;

  var POLOS = { adq: { pre: 'itbiAdq', rot: 'adquirente', ROT: 'ADQUIRENTE', caixa: 'itbiBlocosAdq', chips: 'itbiQtdAdq' },
                tra: { pre: 'itbiTra', rot: 'transmitente', ROT: 'TRANSMITENTE', caixa: 'itbiBlocosTra', chips: 'itbiQtdTra' } };
  var CAMPOS_PESSOA = [
    { k: 'Nome', rot: 'Nome completo', dica: 'como está no documento', nc: false },
    { k: 'Cpf', rot: 'CPF / CNPJ', dica: '000.000.000-00', nc: true },
    { k: 'Rg', rot: 'RG / CNH', dica: 'número e órgão expedidor', nc: true },
    { k: 'Profissao', rot: 'Profissão', dica: 'ex.: comerciante', nc: true },
    { k: 'Endereco', rot: 'Endereço', dica: 'rua, número, bairro', nc: true },
    { k: 'Municipio', rot: 'Município', dica: '', nc: true, padrao: 'ITABAIANA/SE' },
    { k: 'Cep', rot: 'CEP', dica: '49500-000', nc: true }
  ];
  var ATESTO = 'Atesto que esta Guia foi preenchida neste CARTÓRIO, de acordo com a documentação do imóvel e declarações das partes.';
  var CARTORIO_BOX = ['CARTÓRIO DE NOTAS DO 2º OFÍCIO', 'Avenida Ivo de Carvalho, n. 441', 'Itabaiana-Sergipe', 'César Bravo / Tabelião'];

  function elp(id) { return document.getElementById(id); }
  function escapa(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  /* ---------------- montagem dos blocos por pessoa ---------------- */
  function blocoPessoa(polo, i) {
    var P = POLOS[polo], pre = P.pre + i, html = '';
    html += '<div class="itbi-pessoa" data-pessoa="' + polo + i + '"' + (i > 1 ? ' hidden' : '') + '>';
    html += '<p class="itbi-pessoa-tit">' + escapa(P.ROT.charAt(0) + P.ROT.slice(1).toLowerCase()) + ' ' + i + '</p>';
    html += '<div class="itbi-grade">';
    CAMPOS_PESSOA.forEach(function (c) {
      var id = pre + c.k, largo = (c.k === 'Endereco' || c.k === 'Nome') ? ' itbi-largo' : '';
      html += '<div class="itbi-campo' + largo + '">';
      html += '<label class="min-campo" for="' + id + '"><span>' + escapa(c.rot) + (c.k === 'Nome' ? ' *' : '') + '</span>';
      html += '<input id="' + id + '" type="text" autocomplete="off"' +
        (c.padrao ? ' value="' + escapa(c.padrao) + '"' : '') +
        (c.dica ? ' placeholder="' + escapa(c.dica) + '"' : '') + '></label>';
      if (c.nc) html += '<button type="button" class="itbi-nc" data-nc="' + id + '" aria-pressed="false">não consta</button>';
      html += '</div>';
    });
    html += '</div></div>';
    return html;
  }

  Object.keys(POLOS).forEach(function (polo) {
    var caixa = elp(POLOS[polo].caixa), h = '';
    for (var i = 1; i <= 4; i++) h += blocoPessoa(polo, i);
    caixa.innerHTML = h;
  });

  /* ---------------- quantidade de pessoas ---------------- */
  var QTD = { adq: 1, tra: 1 };
  function aplicarQtd(polo) {
    var n = QTD[polo];
    for (var i = 1; i <= 4; i++) {
      var b = pag.querySelector('[data-pessoa="' + polo + i + '"]');
      if (b) b.hidden = (i > n);
    }
    var g = elp(POLOS[polo].chips);
    g.querySelectorAll('.ed-chip').forEach(function (c) {
      var at = Number(c.dataset.qtd) === n;
      c.classList.toggle('ativo', at);
      c.setAttribute('aria-pressed', at ? 'true' : 'false');
    });
  }
  Object.keys(POLOS).forEach(function (polo) {
    elp(POLOS[polo].chips).addEventListener('click', function (ev) {
      var b = ev.target.closest('.ed-chip'); if (!b) return;
      QTD[polo] = Number(b.dataset.qtd) || 1;
      aplicarQtd(polo);
      var novo = pag.querySelector('[data-pessoa="' + polo + QTD[polo] + '"] input');
      if (novo && QTD[polo] > 1) try { novo.focus(); } catch (e) {}
    });
    aplicarQtd(polo);
  });

  /* ---------------- chips de escolha única (situação, tipo, natureza) ---------------- */
  var GRUPOS = ['itbiSituacao', 'itbiTipo', 'itbiNatureza'];
  GRUPOS.forEach(function (gid) {
    var g = elp(gid), alvo = elp(g.dataset.alvo);
    var pad = g.querySelector('.ed-chip.ativo');
    g.dataset.padrao = pad ? pad.dataset.v : '';
    g.addEventListener('click', function (ev) {
      var b = ev.target.closest('.ed-chip'); if (!b || b.disabled) return;
      g.querySelectorAll('.ed-chip').forEach(function (c) {
        var at = c === b;
        c.classList.toggle('ativo', at);
        c.setAttribute('aria-pressed', at ? 'true' : 'false');
      });
      alvo.hidden = b.dataset.v !== '__outra';
      if (!alvo.hidden) try { alvo.focus(); } catch (e) {}
    });
  });
  function valorGrupo(gid) {
    var g = elp(gid), a = g.querySelector('.ed-chip.ativo');
    if (!a) return '';
    if (a.dataset.v === '__outra') return (elp(g.dataset.alvo).value || '').trim();
    return a.dataset.v;
  }

  /* ---------------- botões "não consta" / "Não declarado" ---------------- */
  function alvoDoBotao(btn) {
    var id = btn.dataset.nc;
    return { id: id, no: elp(id) };
  }
  function pintarNc(btn, ligado) {
    btn.setAttribute('aria-pressed', ligado ? 'true' : 'false');
    btn.classList.toggle('ativo', ligado);
    var a = alvoDoBotao(btn);
    if (!a.no) return;
    if (a.no.classList && a.no.classList.contains('ed-chips')) {
      a.no.querySelectorAll('.ed-chip').forEach(function (c) { c.disabled = ligado; });
      var extra = elp(a.no.dataset.alvo);
      if (extra) extra.disabled = ligado;
      a.no.classList.toggle('desligado', ligado);
    } else {
      if (ligado) {
        a.no.dataset.antes = a.no.value; a.no.dataset.dica = a.no.placeholder || '';
        a.no.value = ''; a.no.placeholder = 'NÃO CONSTA'; a.no.disabled = true;
      } else {
        a.no.disabled = false;
        if (a.no.dataset.dica !== undefined) { a.no.placeholder = a.no.dataset.dica; delete a.no.dataset.dica; }
        if (a.no.dataset.antes !== undefined) { a.no.value = a.no.dataset.antes; delete a.no.dataset.antes; }
      }
      a.no.classList.toggle('nao-consta', ligado);
    }
  }
  pag.addEventListener('click', function (ev) {
    var b = ev.target.closest('.itbi-nc'); if (!b || b.id === 'btnItbiNaoDeclarado') return;
    pintarNc(b, b.getAttribute('aria-pressed') !== 'true');
  });
  function ncLigado(id) {
    var b = pag.querySelector('.itbi-nc[data-nc="' + id + '"]');
    return !!b && b.getAttribute('aria-pressed') === 'true';
  }

  var btnND = elp('btnItbiNaoDeclarado'), campoValor = elp('itbiValor');
  btnND.addEventListener('click', function () {
    var lig = btnND.getAttribute('aria-pressed') !== 'true';
    btnND.setAttribute('aria-pressed', lig ? 'true' : 'false');
    btnND.classList.toggle('ativo', lig);
    if (lig) {
      campoValor.dataset.antes = campoValor.value; campoValor.dataset.dica = campoValor.placeholder || '';
      campoValor.value = ''; campoValor.placeholder = 'NÃO DECLARADO'; campoValor.disabled = true;
    } else {
      campoValor.disabled = false;
      if (campoValor.dataset.dica !== undefined) { campoValor.placeholder = campoValor.dataset.dica; delete campoValor.dataset.dica; }
      if (campoValor.dataset.antes !== undefined) { campoValor.value = campoValor.dataset.antes; delete campoValor.dataset.antes; }
    }
    campoValor.classList.toggle('nao-consta', lig);
  });

  /* ---------------- máscara de moeda pt-BR ---------------- */
  function moeda(digitos) {
    var d = String(digitos).replace(/\D/g, '').replace(/^0+(?=\d{3})/, '');
    while (d.length < 3) d = '0' + d;
    var cent = d.slice(-2), inteiro = d.slice(0, -2).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    return inteiro + ',' + cent;
  }
  campoValor.addEventListener('input', function () {
    var so = campoValor.value.replace(/\D/g, '');
    campoValor.value = so ? moeda(so) : '';
  });

  /* ---------------- leitura do formulário ---------------- */
  function texto(id) {
    if (ncLigado(id)) return 'NÃO CONSTA';
    var no = elp(id);
    if (!no) return '';
    if (no.classList && no.classList.contains('ed-chips')) return valorGrupo(id);
    return (no.value || '').trim();
  }
  function vazio(id) {
    if (ncLigado(id)) return false;
    var no = elp(id);
    if (!no) return true;
    if (no.classList && no.classList.contains('ed-chips')) return !valorGrupo(id);
    return !(no.value || '').trim();
  }
  function pessoas(polo) {
    var out = [], P = POLOS[polo];
    for (var i = 1; i <= QTD[polo]; i++) {
      var pre = P.pre + i, p = { n: i };
      CAMPOS_PESSOA.forEach(function (c) { p[c.k.toLowerCase()] = texto(pre + c.k); });
      out.push(p);
    }
    return out;
  }
  function lerTudo() {
    return {
      adq: pessoas('adq'),
      tra: pessoas('tra'),
      imovel: {
        inscricao: texto('itbiInscricao'), logradouro: texto('itbiLogradouro'),
        complemento: texto('itbiComplemento'), municipio: texto('itbiMunicipio'), cep: texto('itbiCep'),
        areaTerreno: texto('itbiAreaTerreno'), testadas: texto('itbiTestadas'), situacao: texto('itbiSituacao'),
        areaUtil: texto('itbiAreaUtil'), areaTotal: texto('itbiAreaTotal'),
        fracao: texto('itbiFracao'), tipo: texto('itbiTipo')
      },
      operacao: {
        natureza: texto('itbiNatureza'), financiadora: texto('itbiFinanciadora'),
        valor: btnND.getAttribute('aria-pressed') === 'true' ? 'NÃO DECLARADO'
               : ((campoValor.value || '').trim() ? 'R$ ' + campoValor.value.trim() : ''),
        outras: texto('itbiOutras')
      },
      doc: { cartorio: texto('itbiCartorio'), matricula: texto('itbiMatricula'), guia: (elp('itbiGuiaNum').value || '').trim() },
      obs: (elp('itbiObs').value || '').trim(),
      quem: { nome: (typeof SESSAO === 'object' && SESSAO.nome) || '', cargo: (typeof SESSAO === 'object' && SESSAO.cargo) || '' }
    };
  }

  /* ---------------- conferência dos campos em branco ---------------- */
  function emBranco() {
    var faltas = [];
    Object.keys(POLOS).forEach(function (polo) {
      var P = POLOS[polo];
      for (var i = 1; i <= QTD[polo]; i++) {
        CAMPOS_PESSOA.forEach(function (c) {
          var id = P.pre + i + c.k;
          if (vazio(id)) faltas.push({ id: id, txt: c.rot + ' — ' + P.rot + ' ' + i });
        });
      }
    });
    [['itbiInscricao', 'Inscrição cadastral do imóvel'], ['itbiLogradouro', 'Logradouro do imóvel'],
     ['itbiComplemento', 'Complemento do imóvel'], ['itbiMunicipio', 'Município do imóvel'],
     ['itbiCep', 'CEP do imóvel'], ['itbiAreaTerreno', 'Área do terreno'], ['itbiTestadas', 'Testadas'],
     ['itbiSituacao', 'Situação do terreno'], ['itbiAreaUtil', 'Área útil'],
     ['itbiAreaTotal', 'Área total construída'], ['itbiFracao', 'Fração ideal'], ['itbiTipo', 'Tipo do imóvel'],
     ['itbiNatureza', 'Natureza da operação'], ['itbiFinanciadora', 'Entidade financiadora'],
     ['itbiOutras', 'Outras informações'], ['itbiCartorio', 'Cartório do registro'],
     ['itbiMatricula', 'Matrícula']].forEach(function (par) {
      if (vazio(par[0])) faltas.push({ id: par[0], txt: par[1] });
    });
    if (btnND.getAttribute('aria-pressed') !== 'true' && !(campoValor.value || '').trim()) {
      faltas.push({ id: 'itbiValor', txt: 'Valor atribuído pelo contribuinte' });
    }
    if (!(elp('itbiGuiaNum').value || '').trim()) faltas.push({ id: 'itbiGuiaNum', txt: 'Nº da guia (sai a linha para preencher à mão)' });
    return faltas;
  }
  function semNome(polo) {
    var P = POLOS[polo];
    for (var i = 1; i <= QTD[polo]; i++) if ((elp(P.pre + i + 'Nome').value || '').trim()) return false;
    return true;
  }

  /* ============================================================
     DESENHO DA GUIA
  ============================================================ */
  /* "m²" e "m³": o expoente é desenhado à parte, menor e elevado —
     assim a guia sai igual em qualquer leitor de PDF. */
  function fatiarSup(s) {
    var out = [], atual = '', i, c;
    s = String(s == null ? '' : s);
    for (i = 0; i < s.length; i++) {
      c = s.charAt(i);
      if (c === '²' || c === '³') {
        if (atual) { out.push({ t: atual, sup: false }); atual = ''; }
        out.push({ t: c === '²' ? '2' : '3', sup: true });
      } else atual += c;
    }
    if (atual) out.push({ t: atual, sup: false });
    return out;
  }
  function largS(pdf, s, neg, base) {
    var soma = 0;
    fatiarSup(s).forEach(function (p) { soma += pdf.larguraTexto(p.t, neg, p.sup ? base * 0.68 : base); });
    return soma;
  }
  function escS(pdf, x, y, s, neg, base, op) {
    var xx = x;
    if (op && (op.alinhar === 'centro' || op.alinhar === 'dir')) {
      var w = largS(pdf, s, neg, base);
      xx = op.alinhar === 'centro' ? x + (op.larguraMm - w) / 2 : x + op.larguraMm - w;
    }
    fatiarSup(s).forEach(function (p) {
      var tam = p.sup ? base * 0.68 : base;
      pdf.fonte(neg, tam);
      pdf.texto(xx, p.sup ? y - base * 0.32 / MM : y, p.t);
      xx += pdf.larguraTexto(p.t, neg, tam);
    });
    pdf.fonte(neg, base);
  }
  function lh(base) { return base * 1.20 / MM; }
  function padY(base) { return base * 0.26 / MM; }
  function padX(base) { return base * 0.42 / MM; }
  function altCel(n, base) { return n * lh(base) + 2 * padY(base); }

  /* quebra o valor sabendo que a 1ª linha divide espaço com o rótulo */
  function quebrarCom(pdf, txt, larg1, largN, neg, base) {
    var s = String(txt == null ? '' : txt).replace(/\s+/g, ' ').trim();
    if (!s) return [''];
    var palavras = s.split(' '), linhas = [], atual = '', limite = larg1;
    palavras.forEach(function (p) {
      var t = atual ? atual + ' ' + p : p;
      if (largS(pdf, t, neg, base) <= limite) { atual = t; return; }
      if (atual) { linhas.push(atual); atual = ''; limite = largN; }
      if (largS(pdf, p, neg, base) <= limite) { atual = p; return; }
      var pedaco = '';
      for (var i = 0; i < p.length; i++) {
        if (pedaco && largS(pdf, pedaco + p.charAt(i), neg, base) > limite) { linhas.push(pedaco); pedaco = ''; limite = largN; }
        pedaco += p.charAt(i);
      }
      atual = pedaco;
    });
    linhas.push(atual);
    return linhas;
  }

  /* Prepara uma célula "RÓTULO: valor": o rótulo sai em negrito e o valor
     continua na mesma linha; se não couber, o rótulo quebra e o valor desce.
     Devolve a lista de pedaços já posicionados (deslocamento e nº da linha). */
  function prepara(pdf, base, rotulo, valor, util, neg) {
    var linhasRot = rotulo ? quebrarCom(pdf, rotulo, util, util, true, base) : [];
    var ultima = linhasRot.length ? linhasRot[linhasRot.length - 1] : '';
    var lr = ultima ? largS(pdf, ultima, true, base) + base * 0.30 / MM : 0;
    var abaixo = false, larg1 = util - lr;
    if (valor && larg1 < base * 2.4 / MM) { abaixo = true; larg1 = util; }
    var linhasVal = valor ? quebrarCom(pdf, valor, larg1, util, !!neg, base) : [];
    var pecas = [], i = 0;
    linhasRot.forEach(function (l) { pecas.push({ dx: 0, li: i, t: l, neg: true }); i++; });
    if (valor) {
      var inicio = abaixo ? i : Math.max(0, i - 1);
      linhasVal.forEach(function (l, j) {
        pecas.push({ dx: (j === 0 && !abaixo && linhasRot.length) ? lr : 0, li: inicio + j, t: l, neg: !!neg });
      });
      i = inicio + linhasVal.length;
    }
    return { pecas: pecas, n: Math.max(1, i) };
  }
  function pintaPrep(pdf, prep, x, y, base) {
    var yb = y + padY(base) + base * 0.88 / MM, px = x + padX(base);
    prep.pecas.forEach(function (p) {
      if (!p.t) return;
      escS(pdf, px + p.dx, yb + p.li * lh(base), p.t, p.neg, base);
    });
  }

  /* uma linha da tabela, com 1..3 células (frações da largura) */
  function linhaTabela(pdf, base, defs) {
    var preps = [], maxN = 1, x = X0;
    defs.forEach(function (c) {
      var w = LARG * c.fr;
      var pr = prepara(pdf, base, c.rotulo, c.valor, w - 2 * padX(base), c.neg);
      pr.x = x; pr.w = w; preps.push(pr);
      if (pr.n > maxN) maxN = pr.n;
      x += w;
    });
    var h = altCel(maxN, base);
    return { h: h, desenhar: function (pdf, y) {
      pdf.retangulo(X0, y, LARG, h, { espessura: 0.35 });
      preps.forEach(function (pr, i) {
        if (i > 0) pdf.linha(pr.x, y, pr.x, y + h, { espessura: 0.35 });
        pintaPrep(pdf, pr, pr.x, y, base);
      });
    } };
  }
  function banda(pdf, base, titulo) {
    var h = base * 1.45 / MM;
    return { h: h, cola: true, desenhar: function (pdf, y) {
      pdf.retangulo(X0, y, LARG, h, { preencher: '#A6A6A6', borda: true, espessura: 0.35 });
      escS(pdf, X0 + padX(base), y + h - base * 0.40 / MM, titulo, true, base);
    } };
  }
  function subTitulo(pdf, base, titulo) {
    var b = base - 1, h = altCel(1, b);
    return { h: h, cola: true, desenhar: function (pdf, y) {
      pdf.retangulo(X0, y, LARG, h, { espessura: 0.35 });
      escS(pdf, X0 + padX(b), y + padY(b) + b * 0.88 / MM, titulo, true, b);
    } };
  }

  function cabecalho(pdf, base, alt, numeroGuia) {
    var h = alt, wB = 25;
    var tamGuia = base - 0.5, txtGuia = 'GUIA DE ITBI Nº ' + (numeroGuia || '__________');
    var wGuia = largS(pdf, txtGuia, true, tamGuia);
    var xt = X0 + wB + 2.5;
    var espaco = (X0 + LARG - 3 - wGuia - 3) - xt;
    var tamTit = base + 3.5, tit = 'PREFEITURA MUNICIPAL DE ITABAIANA-SE';
    while (tamTit > 6 && largS(pdf, tit, true, tamTit) > espaco) tamTit -= 0.25;
    return { h: h, desenhar: function (pdf, y) {
      pdf.retangulo(X0, y, LARG, h, { espessura: 0.35 });
      pdf.linha(X0 + wB, y, X0 + wB, y + h, { espessura: 0.35 });
      var hi = Math.min(h - 2.4, 19.5), wi = hi * 93 / 105;
      pdf.imagemJpeg(BRASAO, X0 + (wB - wi) / 2, y + (h - hi) / 2, wi, hi);
      escS(pdf, xt, y + h * 0.40, tit, true, tamTit);
      escS(pdf, X0, y + h * 0.38, txtGuia, true, tamGuia, { alinhar: 'dir', larguraMm: LARG - 3 });
      escS(pdf, xt, y + h * 0.645, 'Secretaria Municipal de Finanças', false, base);
      escS(pdf, xt, y + h * 0.875, 'Coordenadoria de Cadastro Imobiliário', false, base);
    } };
  }

  function blocoDocumentacao(pdf, base, alt, d) {
    var h = alt, bs = base - 1.5;
    var xd = X0 + LARG * 0.42;
    var dirX = xd + padX(base), dirW = X0 + LARG - dirX - padX(base);
    var atesto = quebrarCom(pdf, ATESTO, dirW, dirW, false, bs);
    var subLW = dirW * 0.42, caixaX = dirX + dirW * 0.46, caixaW = dirW * 0.54;
    var legenda = quebrarCom(pdf, 'Assinatura do Tabelião ou Escrevente', subLW, subLW, false, bs);
    var tamCx = bs;
    while (tamCx > 4.5 && Math.max.apply(null, CARTORIO_BOX.map(function (l, i) { return largS(pdf, l, i === 0, tamCx); })) > caixaW - 3) tamCx -= 0.2;
    return { h: h, desenhar: function (pdf, y) {
      pdf.retangulo(X0, y, LARG, h, { espessura: 0.35 });
      pdf.linha(xd, y, xd, y + h, { espessura: 0.35 });
      /* esquerda: cartório e matrícula */
      var ye = y + h * 0.20;
      escS(pdf, X0 + padX(base), ye, 'CARTÓRIO:', true, base);
      escS(pdf, X0 + padX(base) + largS(pdf, 'CARTÓRIO:', true, base) + 1.5, ye, d.doc.cartorio, true, base);
      escS(pdf, X0 + padX(base), ye + lh(base) * 1.25, 'MATRÍCULA:', true, base);
      escS(pdf, X0 + padX(base) + largS(pdf, 'MATRÍCULA:', true, base) + 1.5, ye + lh(base) * 1.25, d.doc.matricula, true, base);
      /* direita: atesto */
      var ya = y + padY(bs) + bs * 0.95 / MM;
      atesto.forEach(function (l, i) { escS(pdf, dirX, ya + i * lh(bs), l, false, bs); });
      /* data */
      var yData = ya + atesto.length * lh(bs) + lh(bs) * 0.5;
      escS(pdf, dirX, yData, 'DATA: ' + d.dataHoje, true, base);
      /* assinatura (canto inferior esquerdo da direita) */
      var lhs = bs * 1.15 / MM;
      var yCargo = y + h - padY(bs) - 0.4;
      var yNome = yCargo - lhs;
      var yLeg = yNome - lhs - 0.3;
      var yTraco = yLeg - (legenda.length - 1) * lhs - bs * 0.85 / MM - 0.9;
      pdf.linha(dirX, yTraco, dirX + subLW, yTraco, { espessura: 0.35 });
      legenda.forEach(function (l, i) {
        escS(pdf, dirX, yLeg - (legenda.length - 1 - i) * lhs, l, false, bs, { alinhar: 'centro', larguraMm: subLW });
      });
      if (d.quem.nome) escS(pdf, dirX, yNome, d.quem.nome, true, bs, { alinhar: 'centro', larguraMm: subLW });
      if (d.quem.cargo) escS(pdf, dirX, yCargo, d.quem.cargo, false, bs, { alinhar: 'centro', larguraMm: subLW });
      /* quadro emoldurado do Cartório */
      var lhc = tamCx * 1.30 / MM;
      var hCx = CARTORIO_BOX.length * lhc + 2.4;
      var yCx = y + h - padY(bs) - hCx;
      var minY = yData + lh(base) * 0.4;
      if (yCx < minY) yCx = minY;
      pdf.retangulo(caixaX, yCx, caixaW, Math.min(hCx, y + h - padY(bs) - yCx), { espessura: 0.35 });
      CARTORIO_BOX.forEach(function (l, i) {
        escS(pdf, caixaX, yCx + 1.4 + tamCx * 0.9 / MM + i * lhc, l, i === 0, tamCx, { alinhar: 'centro', larguraMm: caixaW });
      });
    } };
  }

  function blocoAvaliacao(pdf, base, alt) {
    var h = alt, b = base - 1.5, lhv = b * 1.18 / MM;
    var xd = X0 + LARG * 0.76;
    return { h: h, desenhar: function (pdf, y) {
      pdf.retangulo(X0, y, LARG, h, { espessura: 0.35 });
      pdf.linha(xd, y, xd, y + h, { espessura: 0.35 });
      var y1 = y + padY(b) + b * 0.95 / MM, wE = xd - X0;
      escS(pdf, X0, y1, 'USO DA C.C.I.', true, b, { alinhar: 'centro', larguraMm: wE });
      escS(pdf, X0, y1 + lhv, 'CÁLCULO DO IMPOSTO', true, b, { alinhar: 'centro', larguraMm: wE });
      var px = X0 + padX(b);
      escS(pdf, px, y1 + lhv * 2.2, 'ALÍQUOTA:', true, b);
      escS(pdf, px, y1 + lhv * 3.2, 'Imposto a pagar:   R$______________', true, b);
      escS(pdf, px, y1 + lhv * 4.2, 'Valor Tributável   R$______________', true, b);
      escS(pdf, px, y1 + lhv * 5.2, 'Data:        ____/_____/______           Avaliador:', true, b);
      escS(pdf, xd, y1, 'Visto do Chefe:', false, b, { alinhar: 'centro', larguraMm: X0 + LARG - xd });
    } };
  }

  function blocoObservacoes(pdf, base, alt, obs) {
    var b = base - 0.5;
    var rot = 'OBSERVAÇÕES:', lr = largS(pdf, rot, true, b) + 1.5;
    var linhas = obs ? quebrarCom(pdf, obs, LARG - 2 * padX(b) - lr, LARG - 2 * padX(b), false, b) : [];
    var h = Math.max(alt, altCel(Math.max(1, linhas.length), b));
    return { h: h, desenhar: function (pdf, y) {
      pdf.retangulo(X0, y, LARG, h, { espessura: 0.35 });
      var yb = y + padY(b) + b * 0.88 / MM;
      escS(pdf, X0 + padX(b), yb, rot, true, b);
      linhas.forEach(function (l, i) {
        escS(pdf, X0 + padX(b) + (i === 0 ? lr : 0), yb + i * lh(b), l, false, b);
      });
    } };
  }

  /* monta a lista de blocos para um tamanho de corpo */
  function planta(pdf, d, passo) {
    var base = passo.base, f = passo.fixo, b = [];
    b.push(cabecalho(pdf, base, 17 + 5 * f, d.doc.guia));
    [['adq', '1 – ADQUIRENTE'], ['tra', '2 – TRANSMITENTE(ES)']].forEach(function (par) {
      var polo = par[0], lista = d[polo];
      b.push(banda(pdf, base, par[1]));
      lista.forEach(function (p) {
        b.push(linhaTabela(pdf, base, [{ fr: 1, rotulo: lista.length > 1 ? POLOS[polo].ROT + ' ' + p.n + ':' : '', valor: (p.nome || '').toUpperCase(), neg: true }]));
        b.push(linhaTabela(pdf, base, [
          { fr: 0.36, rotulo: 'CPF/CNPJ nº:', valor: p.cpf },
          { fr: 0.30, rotulo: 'RG/CNH:', valor: p.rg },
          { fr: 0.34, rotulo: 'PROFISSÃO:', valor: p.profissao }]));
        b.push(linhaTabela(pdf, base, [{ fr: 1, rotulo: 'ENDEREÇO:', valor: p.endereco }]));
        b.push(linhaTabela(pdf, base, [
          { fr: 0.62, rotulo: 'MUNICÍPIO:', valor: p.municipio },
          { fr: 0.38, rotulo: 'CEP:', valor: p.cep }]));
      });
    });
    var im = d.imovel;
    b.push(banda(pdf, base, '3 – DADOS DO IMÓVEL'));
    b.push(linhaTabela(pdf, base, [{ fr: 1, rotulo: 'INSCRIÇÃO CADASTRAL:', valor: im.inscricao }]));
    b.push(linhaTabela(pdf, base, [{ fr: 1, rotulo: 'LOGRADOURO:', valor: im.logradouro }]));
    b.push(linhaTabela(pdf, base, [{ fr: 1, rotulo: 'COMPLEMENTO:', valor: im.complemento }]));
    b.push(linhaTabela(pdf, base, [
      { fr: 0.62, rotulo: 'MUNICÍPIO:', valor: im.municipio },
      { fr: 0.38, rotulo: 'CEP:', valor: im.cep }]));
    b.push(subTitulo(pdf, base, 'Características do Terreno'));
    b.push(linhaTabela(pdf, base, [
      { fr: 0.38, rotulo: 'ÁREA DO TERRENO (m²):', valor: im.areaTerreno },
      { fr: 0.28, rotulo: 'TESTADAS:', valor: im.testadas },
      { fr: 0.34, rotulo: 'SITUAÇÃO:', valor: im.situacao }]));
    b.push(subTitulo(pdf, base, 'Características da Construção'));
    b.push(linhaTabela(pdf, base, [
      { fr: 0.25, rotulo: 'ÁREA ÚTIL (m²):', valor: im.areaUtil },
      { fr: 0.33, rotulo: 'ÁREA TOTAL CONSTRUÍDA (m²):', valor: im.areaTotal },
      { fr: 0.19, rotulo: 'FRAÇÃO IDEAL:', valor: im.fracao },
      { fr: 0.23, rotulo: 'TIPO:', valor: im.tipo }]));
    var op = d.operacao;
    b.push(banda(pdf, base, '4 – NATUREZA DA OPERAÇÃO'));
    b.push(linhaTabela(pdf, base, [
      { fr: 0.42, rotulo: '', valor: (op.natureza || '').toUpperCase(), neg: false },
      { fr: 0.28, rotulo: 'ENTIDADE FINANCIADORA:', valor: op.financiadora },
      { fr: 0.30, rotulo: 'VALOR ATRIBUÍDO PELO CONTRIBUINTE:', valor: op.valor }]));
    b.push(linhaTabela(pdf, base, [{ fr: 1, rotulo: 'OUTRAS INFORMAÇÕES:', valor: op.outras }]));
    b.push(banda(pdf, base, '5 – DOCUMENTAÇÃO DO IMÓVEL:'));
    b.push(blocoDocumentacao(pdf, base, 26 + 8 * f, d));
    b.push(banda(pdf, base, '6 - AVALIAÇÃO'));
    b.push(blocoAvaliacao(pdf, base, 19 + 5 * f));
    b.push(blocoObservacoes(pdf, base, 11 + 7 * f, d.obs));
    var total = 0;
    b.forEach(function (x) { total += x.h; });
    return { blocos: b, altura: total };
  }

  var PASSOS = [{ base: 10, fixo: 1 }, { base: 9.5, fixo: 0.8 }, { base: 9, fixo: 0.6 },
                { base: 8.5, fixo: 0.4 }, { base: 8, fixo: 0.2 }, { base: 7.5, fixo: 0 }];

  function desenharGuia(d) {
    var escolhido = null, pdf = null, plano = null;
    for (var i = 0; i < PASSOS.length; i++) {
      pdf = new PDFMini({ pagina: 'A4' });
      plano = planta(pdf, d, PASSOS[i]);
      escolhido = PASSOS[i];
      if (plano.altura <= UTIL) break;
    }
    var y = TOPO, limite = 297 - BAIXO + 0.05;
    plano.blocos.forEach(function (bl, i) {
      /* cabeçalho de seção nunca fica órfão no pé da página */
      var junto = bl.cola && plano.blocos[i + 1] ? plano.blocos[i + 1].h : 0;
      if (y + bl.h + junto > limite) { pdf.novaPagina(); y = TOPO; }
      bl.desenhar(pdf, y);
      y += bl.h;
    });
    return { pdf: pdf, base: escolhido.base, altura: plano.altura, paginas: pdf.totalPaginas() };
  }

  /* ---------------- gerar / baixar / limpar ---------------- */
  function hoje() {
    var dt = new Date(), z = function (n) { return (n < 10 ? '0' : '') + n; };
    return { br: z(dt.getDate()) + '.' + z(dt.getMonth() + 1) + '.' + dt.getFullYear(),
             iso: dt.getFullYear() + '-' + z(dt.getMonth() + 1) + '-' + z(dt.getDate()),
             hora: z(dt.getHours()) + 'h' + z(dt.getMinutes()) };
  }
  function primeiroNome(s) {
    var p = String(s || '').trim().split(/\s+/)[0] || 'ITBI';
    return p.normalize ? p.normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^A-Za-z0-9]/g, '') || 'ITBI'
                       : p.replace(/[^A-Za-z0-9]/g, '') || 'ITBI';
  }
  var urlAnterior = null;
  function gerar() {
    var d = lerTudo(), h = hoje();
    d.dataHoje = h.br;
    var r;
    try { r = desenharGuia(d); }
    catch (e) { if (typeof toast === 'function') toast('Não consegui montar a guia (' + (e && e.message ? e.message : 'erro') + ').', true); return; }
    var bytes = r.pdf.bytes();
    var blob = new Blob([bytes], { type: 'application/pdf' });
    if (urlAnterior) { try { URL.revokeObjectURL(urlAnterior); } catch (e) {} }
    var url = URL.createObjectURL(blob);
    urlAnterior = url;
    try { window.open(url, '_blank'); } catch (e) {}
    var nome = 'Guia-ITBI-' + primeiroNome(d.adq[0] && d.adq[0].nome) + '-' + h.iso + '.pdf';
    var a = elp('itbiBaixar');
    a.href = url; a.download = nome; a.hidden = false;
    window.ITBI_ULTIMO_PDF = bytes;
    window.ITBI_ULTIMO_INFO = 'Guia gerada às ' + h.hora + ' · ' + r.paginas + ' página' + (r.paginas > 1 ? 's' : '') +
      ' · corpo ' + String(r.base).replace('.', ',') + ' pt · ' + d.adq.length + ' adquirente(s) · ' + d.tra.length + ' transmitente(s)';
    elp('itbiEstado').textContent = 'Guia gerada às ' + h.hora + ' · ' + r.paginas + ' página' + (r.paginas > 1 ? 's' : '');
    elp('itbiEstado').classList.add('ok');
    elp('itbiConferencia').hidden = true;
    /* v1.34 — trilha de auditoria: só o FATO de a guia ter saído e o tamanho dela.
       Nada das partes (nome, CPF, valor) sai desta tela — nunca saiu e continua assim. */
    if (typeof registrar === 'function') registrar('itbi', 'pdf', r.paginas + ' página(s)');
    if (typeof toast === 'function') toast('Guia de ITBI gerada — abriu numa aba nova.');
  }

  function pedirConferencia(faltas, bloqueio) {
    var cx = elp('itbiConferencia');
    var itens = faltas.slice(0, 40).map(function (f) {
      return '<li><button type="button" class="itbi-ir" data-ir="' + escapa(f.id) + '">' + escapa(f.txt) + '</button></li>';
    }).join('');
    cx.innerHTML =
      '<p class="itbi-conf-cab"><b>' + (bloqueio ? 'Falta o essencial' : 'Antes de gerar, confira') + '</b>' +
        '<span class="itbi-conf-selo">' + faltas.length + ' campo' + (faltas.length === 1 ? '' : 's') + ' em branco</span></p>' +
      (bloqueio ? '<p class="itbi-conf-nota">A guia precisa de <b>ao menos um nome de adquirente e um de transmitente</b>. Os demais campos podem sair em branco.</p>'
                : '<p class="itbi-conf-nota">Campo em branco sai em branco na guia (como no modelo da Prefeitura). Se a informação não existe nos documentos, prefira marcar <b>“não consta”</b>.</p>') +
      '<ul class="itbi-conf-lista">' + itens + '</ul>' +
      (faltas.length > 40 ? '<p class="itbi-conf-nota">… e mais ' + (faltas.length - 40) + '.</p>' : '') +
      '<div class="linha-botoes">' +
        (bloqueio ? '' : '<button type="button" class="btn-vinho" id="btnItbiAssimMesmo">Gerar assim mesmo</button>') +
        '<button type="button" class="btn-fantasma" id="btnItbiVoltarCompletar">Voltar e completar</button>' +
      '</div>';
    cx.hidden = false;
    var assim = elp('btnItbiAssimMesmo');
    if (assim) assim.addEventListener('click', function () { cx.hidden = true; gerar(); });
    elp('btnItbiVoltarCompletar').addEventListener('click', function () {
      cx.hidden = true;
      var alvo = faltas[0] && elp(faltas[0].id);
      if (alvo) { try { (alvo.querySelector ? (alvo.querySelector('.ed-chip') || alvo) : alvo).focus(); } catch (e) {} }
    });
    cx.querySelectorAll('.itbi-ir').forEach(function (b) {
      b.addEventListener('click', function () {
        var alvo = elp(b.dataset.ir);
        if (!alvo) return;
        try { alvo.scrollIntoView({ block: 'center' }); } catch (e) {}
        try { (alvo.querySelector ? (alvo.querySelector('.ed-chip') || alvo) : alvo).focus(); } catch (e) {}
      });
    });
    try { cx.scrollIntoView({ block: 'nearest' }); } catch (e) {}
  }

  elp('btnItbiGerar').addEventListener('click', function () {
    elp('itbiEstado').textContent = ''; elp('itbiEstado').classList.remove('ok');
    if (semNome('adq') || semNome('tra')) {
      var falt = [];
      if (semNome('adq')) falt.push({ id: 'itbiAdq1Nome', txt: 'Nome completo — adquirente 1' });
      if (semNome('tra')) falt.push({ id: 'itbiTra1Nome', txt: 'Nome completo — transmitente 1' });
      pedirConferencia(falt, true);
      return;
    }
    var faltas = emBranco();
    if (faltas.length) { pedirConferencia(faltas, false); return; }
    gerar();
  });

  elp('btnItbiLimpar').addEventListener('click', function () {
    pag.querySelectorAll('input, textarea').forEach(function (c) {
      c.disabled = false; c.classList.remove('nao-consta');
      if (c.dataset.dica !== undefined) { c.placeholder = c.dataset.dica; delete c.dataset.dica; }
      delete c.dataset.antes;
      c.value = (c.id === 'itbiMunicipio' || /Municipio$/.test(c.id)) ? 'ITABAIANA/SE'
              : (c.id === 'itbiCartorio' ? '1º Ofício de Itabaiana' : '');
    });
    pag.querySelectorAll('.itbi-nc').forEach(function (b) { b.setAttribute('aria-pressed', 'false'); b.classList.remove('ativo'); });
    GRUPOS.forEach(function (gid) {
      var g = elp(gid), alvo = elp(g.dataset.alvo);
      g.classList.remove('desligado');
      g.querySelectorAll('.ed-chip').forEach(function (c) {
        c.disabled = false;
        var at = c.dataset.v === g.dataset.padrao;
        c.classList.toggle('ativo', at); c.setAttribute('aria-pressed', at ? 'true' : 'false');
      });
      if (alvo) { alvo.hidden = true; alvo.disabled = false; alvo.value = ''; }
    });
    QTD.adq = 1; QTD.tra = 1; aplicarQtd('adq'); aplicarQtd('tra');
    elp('itbiConferencia').hidden = true;
    elp('itbiEstado').textContent = ''; elp('itbiEstado').classList.remove('ok');
    var a = elp('itbiBaixar'); a.hidden = true; a.removeAttribute('download'); a.href = '#';
    if (urlAnterior) { try { URL.revokeObjectURL(urlAnterior); } catch (e) {} urlAnterior = null; }
    window.ITBI_ULTIMO_PDF = null; window.ITBI_ULTIMO_INFO = '';
    try { elp('itbiAdq1Nome').focus(); } catch (e) {}
    if (typeof toast === 'function') toast('Formulário da guia limpo.');
  });

  /* a nota da assinatura mostra quem vai assinar */
  function pintarAssinatura() {
    var n = elp('itbiAssinaNota');
    if (!n) return;
    var quem = (typeof SESSAO === 'object' && SESSAO.nome) ? SESSAO.nome : '';
    var cargo = (typeof SESSAO === 'object' && SESSAO.cargo) ? SESSAO.cargo : '';
    n.innerHTML = 'Na guia sai a linha <b>“Assinatura do Tabelião ou Escrevente”</b>' +
      (quem ? ' e, sob ela, <b>' + escapa(quem) + '</b>' + (cargo ? ' · ' + escapa(cargo) : '') : '') + '.';
  }
  pag.addEventListener('focusin', pintarAssinatura);
  setTimeout(pintarAssinatura, 400);

  window.ITBI_ULTIMO_PDF = null;
  window.ITBI_ULTIMO_INFO = '';
})();
