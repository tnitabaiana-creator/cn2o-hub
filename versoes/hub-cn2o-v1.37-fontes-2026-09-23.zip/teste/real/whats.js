// MOCK do whats.js (teste local): não dispara WhatsApp.
// Monta, porém, as MESMAS variáveis do recibo pelo módulo REAL (recibo.js), para
// que a suíte confira o que o cliente receberia — não só que o disparo ocorreu.
'use strict';
const fs = require('fs');
const { variaveisDoRecibo } = require('./recibo');
async function dispararRecibos(p, numero) {
  let l = [];
  try { l = JSON.parse(fs.readFileSync('/tmp/whats-chamadas.json', 'utf8')); } catch (e) {}
  // v1.36.1 (teste): registra também os telefones que o disparo recebeu, para a suíte
  // conferir que no CERT o telefone da pessoa do ato (terceiro) nunca chega aqui.
  l.push({ numero, ato: p.ato, dest: p.recibo_destinatarios, vars: variaveisDoRecibo(p, numero),
           tel_apresentante: (p.apresentante && p.apresentante.telefone) || null,
           tel_parte: p.parte_envolvida ? (p.parte_envolvida.telefone === undefined ? null : p.parte_envolvida.telefone) : null });
  fs.writeFileSync('/tmp/whats-chamadas.json', JSON.stringify(l));
}
module.exports = { dispararRecibos, ATO_NOME: {} };
