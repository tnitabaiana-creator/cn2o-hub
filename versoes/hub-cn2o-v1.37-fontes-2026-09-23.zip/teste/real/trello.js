// MOCK do trello.js (teste local): mesmas exportações; grava as chamadas, não toca o Trello real.
'use strict';
const fs = require('fs');
const ARQ = '/tmp/trello-chamadas.json';
function reg(nome, args) { let l = []; try { l = JSON.parse(fs.readFileSync(ARQ, 'utf8')); } catch (e) {} l.push({ nome, args }); fs.writeFileSync(ARQ, JSON.stringify(l)); }
let seq = 0;
module.exports = {
  t: async (method, path) => {
    reg('t', [method, path]);
    if (method === 'GET' && /^\/cards\/[^/]+\?/.test(path)) {
      return {
        name: 'Prot. (CV-Urbano) 1400 - COMPRADOR TESTE DE SOUZA', desc: '',
        url: 'https://trello.com/c/TESTE1/prot-1400', shortUrl: 'https://trello.com/c/TESTE1',
        due: '2026-09-21T23:59:00.000Z', dateLastActivity: '2026-09-12T14:10:00.000Z', closed: false,
        idBoard: 'b-tab', idList: 'l-conf',
        list: { name: 'Aguardando última conferência' },
        board: { name: '02 · TABELIÃO' },
        members: [{ fullName: 'César Bravo' }]
      };
    }
    if (method === 'GET' && /\/actions\?/.test(path)) {
      return [
        { type: 'moveCardToBoard', date: '2026-09-12T14:10:00.000Z', data: { board: { name: '02 · TABELIÃO' }, boardSource: { name: '03 · LARA' } } },
        { type: 'updateCard', date: '2026-09-11T16:40:00.000Z', data: { listAfter: { name: 'Preparação de minuta' }, listBefore: { name: 'Checklist' } } },
        { type: 'updateCard', date: '2026-09-10T09:05:00.000Z', data: { listAfter: { name: 'Curadoria de documentos' }, listBefore: { name: 'Digitalização' } } },
        { type: 'createCard', date: '2026-09-09T08:30:00.000Z', data: { list: { name: 'Protocolo / Entrada' } } }
      ];
    }
    if (method === 'GET' && /\/checklists\?/.test(path)) {
      return [{ name: 'DOSSIÊ', checkItems: [
        { name: 'Certidão de ônus atualizada', state: 'incomplete' },
        { name: 'RG/CPF do comprador', state: 'complete' }
      ] }];
    }
    if (method === 'GET' && /^\/search\?/.test(path)) return { cards: [] };
    throw new Error('mock t sem resposta para: ' + method + ' ' + path);
  },
  camposDoQuadro: async () => ({}),
  labelsDoQuadro: async (b) => { reg('labelsDoQuadro', [b]); return { 'Urgente': 'lbl-urg', 'Doc. pendente': 'lbl-doc', 'Santa Mônica': 'lbl-sm', 'Construtor': 'lbl-con', 'Corretor': 'lbl-cor', 'Advogado': 'lbl-adv', 'Loteador/Incorporador': 'lbl-lot' }; },
  criarCartao: async (x) => { reg('criarCartao', [x]); seq++; return { id: 'card-teste-' + seq, shortUrl: 'https://trello.com/c/TESTE' + seq }; },
  // v1.37 (teste): um campo com o valor 'FORCAR-ERRO-CAMPO' simula o Trello recusando o
  // campo personalizado (ex.: tipo número no quadro) — o /protocolo não pode cair por isso
  aplicarCampos: async (...a) => { reg('aplicarCampos', a); if (Object.values(a[2] || {}).includes('FORCAR-ERRO-CAMPO')) throw new Error('mock: campo personalizado recusado pelo Trello'); },
  criarChecklistDossie: async (...a) => { reg('criarChecklistDossie', a); },
  temPendenciaDossie: async () => false,
  aplicarLabelsPorNome: async (...a) => { reg('aplicarLabelsPorNome', a); },
  aplicarCapa: async (...a) => { reg('aplicarCapa', a); },
  cartoesDaLista: async () => [],
  obterCartao: async () => ({})
};
