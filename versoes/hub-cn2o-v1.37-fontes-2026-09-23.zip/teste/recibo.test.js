// Testes do MÓDULO REAL backend/recibo.js — as variáveis do recibo de WhatsApp.
// O que se guarda aqui é a promessa feita ao cliente no balcão: o recibo tem de
// sair na ORDEM DO TEXTO APROVADO NA META (recibo_protocolo_3, reescrito pelo
// Tabelião em 18/09/2026) e NUNCA pode falhar por causa de um campo vazio ou sujo.
//   {{1}} data e hora do protocolo (fuso America/Maceio) — "dd/mm/aaaa, hh:mm:ss"
//   {{2}} ato por extenso
//   {{3}} parte (parte_envolvida → cessionario → comprador)
//   {{4}} apresentante
//   {{5}} número do protocolo
// Template de UMA variável (recibo_protocolo, _1, _2) devolve só [número].
// O recibo.js é a verdade: esta suíte afere o comportamento dele, não o altera.
'use strict';
const assert = require('assert');
const path = require('path');

process.env.WHATS_TEMPLATE_RECIBO = 'recibo_protocolo_3'; // a suíte afere o template novo
delete process.env.WHATS_VARIAVEIS_QTD;                   // sem override, salvo nos testes dele
const { variaveisDoRecibo, campo, quantasVariaveis, LIMITE_PARAMETRO, VARIAVEIS_POR_TEMPLATE } =
  require(path.join(__dirname, '..', 'backend', 'recibo.js'));
const { NOMES_ATO } = require(path.join(__dirname, '..', 'backend', 'atos.js'));

const testes = [];
function t(nome, fn) { testes.push([nome, fn]); }

// Roda fn com WHATS_VARIAVEIS_QTD = valor e SEMPRE restaura o ambiente.
function comQtd(valor, fn) {
  const antes = process.env.WHATS_VARIAVEIS_QTD;
  if (valor === undefined) delete process.env.WHATS_VARIAVEIS_QTD; else process.env.WHATS_VARIAVEIS_QTD = valor;
  try { return fn(); }
  finally { if (antes === undefined) delete process.env.WHATS_VARIAVEIS_QTD; else process.env.WHATS_VARIAVEIS_QTD = antes; }
}

const RE_DATA_HORA = /^(\d{2})\/(\d{2})\/(\d{4}), (\d{2}):(\d{2}):(\d{2})$/;

// "dd/mm/aaaa, hh:mm:ss" lido como hora de Maceió (UTC-3, sem horário de verão) → epoch ms
function epochDeMaceio(s) {
  const m = RE_DATA_HORA.exec(s);
  assert.ok(m, 'data/hora fora do formato: ' + JSON.stringify(s));
  const [, d, mo, a, h, mi, se] = m.map(Number);
  return Date.UTC(a, mo - 1, d, h + 3, mi, se);
}

const CHEIO = {
  ato: 'CV-Rural',
  apresentante: { nome: 'João Batista de Oliveira', telefone: '79999990000' },
  parte_envolvida: { nome: 'MARIA DE FÁTIMA SANTOS' },
  vendedor: { nome: 'Antônio Carlos Menezes' }
};

// ------------------------------------------------------------ ordem e formato
t('são exatamente 5 variáveis, na ordem aprovada na Meta: data/hora, ato, parte, apresentante, número', () => {
  const v = variaveisDoRecibo(CHEIO, '1369');
  assert.strictEqual(v.length, 5);
  assert.match(v[0], RE_DATA_HORA);
  assert.deepStrictEqual(v.slice(1), [
    'Compra e venda — imóvel rural',
    'MARIA DE FÁTIMA SANTOS',
    'João Batista de Oliveira',
    '1369'
  ]);
});

t('{{1}} é a data e hora no formato "dd/mm/aaaa, hh:mm:ss", com dia/mês/hora válidos', () => {
  const v0 = variaveisDoRecibo(CHEIO, '1')[0];
  const m = RE_DATA_HORA.exec(v0);
  assert.ok(m, v0);
  const [, d, mo, , h, mi, se] = m.map(Number);
  assert.ok(d >= 1 && d <= 31, 'dia ' + d);
  assert.ok(mo >= 1 && mo <= 12, 'mês ' + mo);
  assert.ok(h <= 23 && mi <= 59 && se <= 59, v0);
});

t('{{1}} é a hora de AGORA no fuso America/Maceio (UTC-3), não em UTC da Railway', () => {
  const antes = Date.now();
  const v0 = variaveisDoRecibo(CHEIO, '1')[0];
  const depois = Date.now();
  const lido = epochDeMaceio(v0);
  // precisão de segundo: tolera o truncamento para baixo
  assert.ok(lido >= Math.floor(antes / 1000) * 1000 - 1000 && lido <= depois + 1000,
    'recibo diz ' + v0 + ', mas agora em Maceió é ' + new Date(antes - 3 * 3600e3).toISOString());
});

t('{{1}} continua em UTC-3 mesmo com TZ do processo em UTC ou em outro fuso', () => {
  // toLocaleString com timeZone explícito ignora o TZ do processo; aferimos com o
  // relógio de UTC: a hora do recibo tem de ser a hora UTC − 3.
  const v0 = variaveisDoRecibo(CHEIO, '1')[0];
  const agoraUtc = new Date();
  const hMaceio = (agoraUtc.getUTCHours() + 21) % 24;
  const hRecibo = Number(RE_DATA_HORA.exec(v0)[4]);
  // na virada exata da hora os dois podem diferir por 1
  assert.ok(hRecibo === hMaceio || hRecibo === (hMaceio + 23) % 24 || hRecibo === (hMaceio + 1) % 24,
    'hora do recibo ' + hRecibo + ' ≠ hora de Maceió ' + hMaceio);
});

t('{{5}} o protocolo vai como texto, no fim, e preserva os zeros à esquerda', () => {
  assert.strictEqual(variaveisDoRecibo(CHEIO, '0007')[4], '0007');
  assert.strictEqual(variaveisDoRecibo(CHEIO, 1369)[4], '1369');
  assert.strictEqual(typeof variaveisDoRecibo(CHEIO, 1369)[4], 'string');
});

// ------------------------------------------------------------ {{2}} ato
t('{{2}} o ato vai por extenso — o cliente não recebe o código interno', () => {
  for (const codigo of Object.keys(NOMES_ATO)) {
    const v = variaveisDoRecibo({ ...CHEIO, ato: codigo }, '1');
    assert.strictEqual(v[1], NOMES_ATO[codigo], codigo);
    assert.ok(!/^[A-Z/-]+$/.test(v[1]), 'vazou o código de ' + codigo);
  }
});

t('CERT: pedido de certidão sai como "Certidão ou traslado de ato notarial" no {{2}}', () => {
  const v = variaveisDoRecibo({
    ato: 'CERT',
    apresentante: { nome: 'SOLICITANTE DA CERTIDÃO' },
    parte_envolvida: { nome: 'ANTONIO DOS SANTOS' }
  }, '1450');
  assert.strictEqual(v.length, 5);
  assert.match(v[0], RE_DATA_HORA);
  assert.strictEqual(v[1], 'Certidão ou traslado de ato notarial');
  assert.strictEqual(v[2], 'ANTONIO DOS SANTOS');
  assert.strictEqual(v[3], 'SOLICITANTE DA CERTIDÃO');
  assert.strictEqual(v[4], '1450');
});

t('CERT com template antigo (_2): sai só o número, sem a data nem o ato', () => {
  assert.deepStrictEqual(variaveisDoRecibo({ ato: 'CERT', apresentante: { nome: 'X' } }, '1450', 'recibo_protocolo_2'), ['1450']);
});

t('ato desconhecido não derruba o recibo: vai o próprio código', () => {
  assert.strictEqual(variaveisDoRecibo({ ato: 'XPTO' }, '1')[1], 'XPTO');
});

t('ato ausente vira "não informado", nunca string vazia', () => {
  assert.strictEqual(variaveisDoRecibo({}, '1')[1], 'não informado');
});

t('acento e travessão do nome do ato passam intactos', () => {
  const v = variaveisDoRecibo({ ato: 'CV-Urbano' }, '1');
  assert.ok(v[1].includes('—'), v[1]);
  assert.ok(v[1].includes('imóvel'), v[1]);
});

t('todos os atos do formulário (inclusive CERT) estão no mapa compartilhado', () => {
  const doFormulario = ['CV-Urbano', 'CV-Rural', 'DOA', 'PER', 'INV', 'CDH', 'CDP', 'TEST', 'DUE', 'PACTO', 'RERRAT', 'CERT'];
  for (const a of doFormulario) assert.ok(NOMES_ATO[a], 'faltou ' + a);
});

// ------------------------------------------------------------ {{3}} parte e {{4}} apresentante
t('{{3}} parte: parte_envolvida tem precedência sobre cessionário e comprador', () => {
  const v = variaveisDoRecibo({ ato: 'CDH', parte_envolvida: { nome: 'PARTE' }, cessionario: { nome: 'CESS' }, comprador: { nome: 'COMP' } }, '1');
  assert.strictEqual(v[2], 'PARTE');
});

t('{{3}} parte: sem parte_envolvida, cai para o cessionário (CDH/CDP)', () => {
  for (const ato of ['CDH', 'CDP']) {
    const v = variaveisDoRecibo({ ato, cessionario: { nome: 'CESSIONÁRIO FULANO' }, comprador: { nome: 'COMP' } }, '1');
    assert.strictEqual(v[2], 'CESSIONÁRIO FULANO', ato);
  }
});

t('{{3}} parte: sem parte_envolvida nem cessionário, cai para o comprador', () => {
  const v = variaveisDoRecibo({ ato: 'CV-Urbano', comprador: { nome: 'COMPRADORA BELTRANA' } }, '1');
  assert.strictEqual(v[2], 'COMPRADORA BELTRANA');
});

t('{{3}} parte: parte_envolvida com nome vazio também cai para o cessionário', () => {
  const v = variaveisDoRecibo({ ato: 'CDH', parte_envolvida: { nome: '' }, cessionario: { nome: 'CESS' } }, '1');
  assert.strictEqual(v[2], 'CESS');
});

t('{{3}} parte: ninguém informado → "não informado"; o vendedor NUNCA entra no recibo', () => {
  const v = variaveisDoRecibo({ ato: 'CV-Rural', apresentante: { nome: 'Hellen' }, vendedor: { nome: 'VENDEDOR X' } }, '1');
  assert.strictEqual(v[2], 'não informado');
  assert.ok(!v.includes('VENDEDOR X'), 'o vendedor vazou para o recibo: ' + JSON.stringify(v));
  assert.ok(!variaveisDoRecibo(CHEIO, '1').includes('Antônio Carlos Menezes'), 'vendedor do CHEIO vazou');
});

t('{{4}} apresentante ausente → "não informado"', () => {
  assert.strictEqual(variaveisDoRecibo({ ato: 'DOA', parte_envolvida: { nome: 'A' } }, '1')[3], 'não informado');
  assert.strictEqual(variaveisDoRecibo({ ato: 'DOA', apresentante: {} }, '1')[3], 'não informado');
});

// ------------------------------------------------------------ higiene dos parâmetros (regras da Meta)
t('NENHUMA variável sai vazia — a Meta recusa parâmetro em branco', () => {
  const casos = [{}, { ato: 'DOA' }, { apresentante: {} }, { vendedor: { nome: '   ' } }, { parte_envolvida: { nome: ' \n\t ' } }, null, undefined];
  for (const caso of casos) {
    const v = variaveisDoRecibo(caso, '1');
    assert.strictEqual(v.length, 5, JSON.stringify(caso));
    for (const x of v) assert.ok(typeof x === 'string' && x.trim().length > 0, JSON.stringify(caso));
  }
  // número ausente também não sai vazio
  assert.strictEqual(variaveisDoRecibo(CHEIO, undefined)[4], 'não informado');
  assert.deepStrictEqual(variaveisDoRecibo(CHEIO, '', 'recibo_protocolo_2'), ['não informado']);
});

t('quebra de linha, tabulação e espaços em rajada são achatados', () => {
  const v = variaveisDoRecibo({
    ato: 'DOA',
    apresentante: { nome: '  João \n\t Batista     de   Oliveira  ' },
    parte_envolvida: { nome: 'Ana\nPaula' },
    vendedor: { nome: 'Zé' }
  }, ' 42 ');
  assert.strictEqual(v[4], '42');
  assert.strictEqual(v[3], 'João Batista de Oliveira');
  assert.strictEqual(v[2], 'Ana Paula');
  for (const x of v) {
    assert.ok(!/[\r\n\t]/.test(x), 'sobrou quebra de linha em: ' + x);
    assert.ok(!/ {2}/.test(x), 'sobraram espaços seguidos em: ' + x);
  }
});

t('nome quilométrico é cortado no limite, com reticências', () => {
  const gigante = 'MARIA '.repeat(80).trim();
  const v = variaveisDoRecibo({ ato: 'DOA', parte_envolvida: { nome: gigante } }, '1');
  assert.ok(v[2].length <= LIMITE_PARAMETRO, v[2].length);
  assert.ok(v[2].endsWith('…'));
  assert.ok(v[2].startsWith('MARIA MARIA'));
});

t('campo() normaliza, usa a reserva pedida e nunca devolve string vazia', () => {
  assert.strictEqual(campo('', 'não se aplica'), 'não se aplica');
  assert.strictEqual(campo('   \n\t'), 'não informado');
  assert.strictEqual(campo(null), 'não informado');
  assert.strictEqual(campo(undefined), 'não informado');
  assert.strictEqual(campo(0), '0');
  assert.strictEqual(campo('a\r\nb\tc    d'), 'a b c d');
  assert.strictEqual(campo('x'.repeat(LIMITE_PARAMETRO)), 'x'.repeat(LIMITE_PARAMETRO), 'no limite exato não corta');
  assert.strictEqual(campo('x'.repeat(LIMITE_PARAMETRO + 1)).length, LIMITE_PARAMETRO);
});

// ------------------------------------------------------------ quantidade de variáveis (troca sem parada)
t('a quantidade de variáveis segue o NOME do template configurado', () => {
  assert.strictEqual(quantasVariaveis('recibo_protocolo'), 1);
  assert.strictEqual(quantasVariaveis('recibo_protocolo_1'), 1);
  assert.strictEqual(quantasVariaveis('recibo_protocolo_2'), 1);
  assert.strictEqual(quantasVariaveis('recibo_protocolo_3'), 5);
  assert.strictEqual(quantasVariaveis('  recibo_protocolo_3  '), 5, 'espaços em volta do nome');
  assert.deepStrictEqual(VARIAVEIS_POR_TEMPLATE, { recibo_protocolo: 1, recibo_protocolo_1: 1, recibo_protocolo_2: 1, recibo_protocolo_3: 5 });
});

t('nome desconhecido: com "3" → 5 variáveis; sem "3" → 1 (padrão seguro)', () => {
  assert.strictEqual(quantasVariaveis('recibo_protocolo_v3'), 5);
  assert.strictEqual(quantasVariaveis('recibo_cn2o_3_pt'), 5);
  assert.strictEqual(quantasVariaveis('template_que_ninguem_cadastrou'), 1);
  assert.strictEqual(quantasVariaveis('recibo_protocolo_4'), 1);
});

t('sem nome explícito, vale WHATS_TEMPLATE_RECIBO; sem ela, o padrão é o _2 (1 variável)', () => {
  const antes = process.env.WHATS_TEMPLATE_RECIBO;
  try {
    process.env.WHATS_TEMPLATE_RECIBO = 'recibo_protocolo_3';
    assert.strictEqual(quantasVariaveis(), 5);
    assert.strictEqual(variaveisDoRecibo(CHEIO, '7').length, 5);
    process.env.WHATS_TEMPLATE_RECIBO = 'recibo_protocolo_2';
    assert.strictEqual(quantasVariaveis(), 1);
    assert.deepStrictEqual(variaveisDoRecibo(CHEIO, '7'), ['7']);
    delete process.env.WHATS_TEMPLATE_RECIBO;
    assert.strictEqual(quantasVariaveis(), 1);
    assert.strictEqual(quantasVariaveis(null), 1);
  } finally { process.env.WHATS_TEMPLATE_RECIBO = antes; }
});

t('WHATS_VARIAVEIS_QTD sobrepõe o nome do template', () => {
  comQtd('5', () => {
    assert.strictEqual(quantasVariaveis('recibo_protocolo_2'), 5);
    const v = variaveisDoRecibo(CHEIO, '1369', 'recibo_protocolo_2');
    assert.strictEqual(v.length, 5);
    assert.strictEqual(v[4], '1369');
  });
  comQtd('1', () => {
    assert.strictEqual(quantasVariaveis('recibo_protocolo_3'), 1);
    assert.deepStrictEqual(variaveisDoRecibo(CHEIO, '1369', 'recibo_protocolo_3'), ['1369']);
  });
});

t('WHATS_VARIAVEIS_QTD inválida (texto, zero, negativa, vazia) é ignorada', () => {
  for (const ruim of ['abc', '0', '-2', '']) {
    comQtd(ruim, () => {
      assert.strictEqual(quantasVariaveis('recibo_protocolo_3'), 5, 'QTD=' + JSON.stringify(ruim));
      assert.strictEqual(quantasVariaveis('recibo_protocolo_2'), 1, 'QTD=' + JSON.stringify(ruim));
    });
  }
});

t('com o template antigo ainda ativo, sai SÓ o número — a Meta não recusa (132000)', () => {
  assert.deepStrictEqual(variaveisDoRecibo(CHEIO, '1369', 'recibo_protocolo_2'), ['1369']);
  assert.deepStrictEqual(variaveisDoRecibo(CHEIO, '1369', 'recibo_protocolo'), ['1369']);
  assert.deepStrictEqual(variaveisDoRecibo(CHEIO, '1369', 'recibo_protocolo_1'), ['1369']);
  assert.deepStrictEqual(variaveisDoRecibo(null, ' 0042 ', 'recibo_protocolo_2'), ['0042'], 'p nulo e número sujo');
});

t('a virada é uma linha na Railway: o mesmo protocolo vira 5 variáveis, número no {{5}}', () => {
  const antigo = variaveisDoRecibo(CHEIO, '1369', 'recibo_protocolo_2');
  const novo = variaveisDoRecibo(CHEIO, '1369', 'recibo_protocolo_3');
  assert.strictEqual(antigo.length, 1);
  assert.strictEqual(novo.length, 5);
  assert.strictEqual(antigo[0], novo[4]); // o número é o mesmo nos dois
});

(async () => {
  let ok = 0, falhas = 0;
  for (const [nome, fn] of testes) {
    try { await fn(); console.log('  ✓ ' + nome); ok++; }
    catch (e) { console.log('  ✗ ' + nome + ' → ' + e.message); falhas++; }
  }
  console.log('\n' + ok + ' ok, ' + falhas + ' falha(s)');
  process.exit(falhas ? 1 : 0);
})();
