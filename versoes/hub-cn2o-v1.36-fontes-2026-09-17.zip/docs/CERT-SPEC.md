# CERT — pedido de certidão e traslado no e-Protocolo (v1.36)

Pedido do Tabelião, em 17/09/2026:

> "inclua um botão da imagem anexa para permitir o protocolo de pedido de CERTIDÃO cuja
> sigla será CERT, abrindo campos para nome do solicitante, RG, dados do ato (Livro,
> folhas, data). Sempre inclua botão 'não consta' ao lado de cada campo de dados
> informados pelo solicitante. caso o pedido venha apenas com o nome completo da pessoa
> que participa do ato nesse caso exija filiação. Inclua campo para anexar pdf ou imagem
> com documentos a servir de base para pesquisa nos livros. o Protocolo deve gerar cartão
> trello na área de trabalho do trello específica das Escreventes que acessam as
> certidões."

---

## 1. Onde fica

O botão **CERT · Certidão/Traslado** é o 15º da fila de atos do **e-Protocolo**
(`protocolo.html`), não do painel do Hub. Escolhido o ato, aparece o bloco
**“Pedido de certidão — dados informados pelo solicitante”** e some a triagem por
botões, que não se aplica.

## 2. Os campos

| Campo | Onde | “não consta” | Obrigatório |
|---|---|---|---|
| Nome do solicitante | Identificação (`#apresNome`) | não | sim |
| Telefone do solicitante | Identificação (`#apresTel`) | não | sim |
| Pessoa que participa do ato | Identificação (`#parteNome`) | não | sim |
| RG do solicitante | Pedido (`#certRg`) | sim | não |
| O que o solicitante pede | Pedido (`#certEspecie`) | não | tem padrão |
| Natureza do ato procurado | Pedido (`#certNatureza`) | sim | não |
| Livro | Pedido (`#certLivro`) | sim | não |
| Folhas | Pedido (`#certFolhas`) | sim | não |
| Data do ato | Pedido (`#certData`) | sim | não |
| Filiação — pai | Pedido (`#certPai`) | sim | **condicional** |
| Filiação — mãe | Pedido (`#certMae`) | sim | **condicional** |
| Documentos para a pesquisa | Pedido (`#certArq`) | — | não |

Espécies oferecidas: certidão em breve relatório, certidão de inteiro teor, traslado
(2ª via da escritura), certidão de procuração e certidão negativa de ato.

## 3. “não consta” é resposta, não campo vazio

O botão ao lado de cada dado informado pelo solicitante marca o campo, **trava a
digitação e limpa o que estava escrito**; desmarcar devolve o texto anterior. O payload
leva a palavra `não consta`, e o cartão do Trello imprime
*“não consta (declarado pelo solicitante)”*.

A distinção importa no balcão: **campo em branco** é dado sobre o qual ninguém
perguntou; **“não consta”** é o solicitante dizendo que não sabe. A escrevente não vai
procurar no acervo o que já se sabe que não existe.

## 4. A regra da filiação

Se **livro, folhas e data** estiverem todos ausentes — em branco ou marcados como “não
consta” —, a pesquisa no acervo vai partir do nome, e nome sozinho não distingue
homônimo. Nesse caso:

* aparece o aviso em destaque no fim do bloco;
* **Protocolizar fica travado** até que se informe o pai **ou** a mãe;
* o servidor repete a verificação e devolve **400** com a razão, ainda que alguém tente
  contornar a tela.

Informado qualquer um dos três dados do ato, a filiação volta a ser opcional.

## 5. Anexos

* Tipos aceitos: **PDF, JPEG, PNG e WEBP**. Até **8 MB** por arquivo, no máximo **5**.
* A tela envia os arquivos **antes** de protocolar, para `POST /hub/cert/anexos`
  (o `/protocolo` tem parser de 256 kb). Falhando o envio, **nada é protocolado**.
* O arquivo **não vai para o Trello**: fica na tabela `hub_cert_anexos`, no banco da
  serventia. O cartão recebe um **link** para `anexo.html#<id>`, uma página do próprio
  site que abre o documento **com a sessão do Hub** — não é URL pública.
* Criado o protocolo, o servidor carimba o número em cada anexo
  (`vincularAnexosCert`). Anexo que nunca virou protocolo é pedido abandonado e o
  expurgo o apaga em **12 horas**; anexo vinculado é guardado por
  **`HUB_CERT_ANEXO_DIAS`** (padrão **180 dias**).
* A gravação usa `decode($n,'base64')` e a leitura `encode(conteudo,'base64')`: o
  arquivo vira *bytea* de verdade sem depender de o driver tratar `Buffer` — houve
  driver que gravou o JSON do Buffer, e isso só aparece na hora de abrir o documento.

## 6. O cartão no Trello

Vai para o quadro **04 · Certidões/Traslado**, lista **Triagem Certidões/Traslado**:

* `BOARD_04` — padrão `6a8ca1ddc8f6574231ab8ab0`
* `LISTA_TRIAGEM_CERT` — padrão `6a8cbff5e564123504996c60`
* `HUB_SITE` — endereço do site para o link do anexo (padrão `https://cn2o-hub.netlify.app`)

Título no padrão da casa: `Prot. (CERT) 1450 - NOME DA PESSOA DO ATO`. A descrição traz
o pedido inteiro, o aviso de pesquisa por nome quando for o caso, e os links dos anexos.
Etiquetas e campos personalizados são lidos do quadro 04; campo que não existir lá é
ignorado, e uma falha nessa etapa **não derruba o protocolo**.

## 7. Numeração e prazo

O CERT **consome a mesma série** dos demais atos — a numeração da serventia é uma só, e
é assim que a auditoria fecha. Prazo automático: **3 dias úteis**.

## 8. Recibo e trilha

O recibo do WhatsApp do CERT sai com a espécie pedida, o solicitante e o nome em que o
ato é procurado. Na trilha de auditoria entra `anexar / cert / N arquivo(s)` no envio e
`abrir / cert-anexo / <id>` na leitura — metadados apenas, nunca o nome do arquivo nem o
conteúdo.

## 9. O que os testes cobrem

**API (`teste/api.test.js`)** — cartão na lista de triagem do quadro 04; descrição com
“não consta” declarado e aviso de pesquisa por nome; 400 sem filiação; 200 com filiação
da mãe; tipos e tamanhos recusados; anexo só abre com sessão, com tipo, nome e
`no-store` corretos; link do anexo no cartão; nome do ato no recibo; trilha sem o nome
do arquivo.

**Tela (`teste/e2e.py`)** — o botão e o rótulo; fonte nunca abaixo de 13,5 px; um “não
consta” por campo informado pelo solicitante; travar, limpar e devolver o valor;
exigência e dispensa da filiação; anexo na lista e no dossiê; protocolização real com
recibo, número e cartão no quadro certo.
