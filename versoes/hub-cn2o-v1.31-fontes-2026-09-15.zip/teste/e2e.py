"""E2E do Hub dos Escreventes (Chromium headless) contra o servidor de teste.

Roda o fluxo completo: login e primeiro acesso, mural, modo do Tabelião com o
editor de texto rico, aniversariantes, metas, histórico, Extrator e Analista com
anexos (foto, PDF, print colado), Gerador de Minuta (entrevista dirigida por ato,
cinco estados da decisão do roteador),
erros, sessão expirada, ferramenta embutida.
"""
import json, os, sys, time, urllib.request
from playwright.sync_api import sync_playwright

SITE = os.environ.get('SITE', 'http://127.0.0.1:8088/')
API = os.environ.get('API', 'http://127.0.0.1:3999')
SHOTS = os.environ.get('SHOTS', '/tmp/claude-0/-home-claude/1420be19-29c6-5b17-b90b-a63024aaf784/scratchpad/shots')
ARQ = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'arquivos')
os.makedirs(SHOTS, exist_ok=True)
ok = falhas = 0
erros_console = []

PAGINA = {}
def passo(nome, fn):
    global ok, falhas
    try:
        fn(); ok += 1; print('  ✓', nome)
    except Exception as e:
        falhas += 1; print('  ✗', nome, '→', repr(e)[:400])
        pg = PAGINA.get('pg')
        if pg:
            try:
                pg.screenshot(path=SHOTS + '/falha-' + str(falhas) + '.png')
                pg.evaluate("document.querySelectorAll('.veu.aberto').forEach(v => v.classList.remove('aberto'))")
            except Exception:
                pass

def api(caminho, corpo=None, token=None):
    req = urllib.request.Request(API + caminho, method='POST' if corpo is not None else 'GET')
    if corpo is not None:
        req.add_header('Content-Type', 'application/json'); req.data = json.dumps(corpo).encode()
    if token: req.add_header('X-Auth-Token', token)
    try:
        with urllib.request.urlopen(req) as r: return r.status, json.loads(r.read() or b'null')
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b'null')

import subprocess
def sql(comando):
    return subprocess.run(['psql', '-h', '127.0.0.1', '-p', '54329', '-U', 'postgres', '-d', 'cn2o', '-At', '-c', comando], capture_output=True, text=True, check=True).stdout
def chamadas():
    with open('/tmp/gemini-chamadas.json', encoding='utf-8') as f: return json.load(f)
def garantir_senha(login, senha):
    st, r = api('/login', {'login': login, 'senha': senha})
    if st == 200 and r.get('primeiro_acesso'):
        st, r = api('/definir-senha', {'login': login, 'senha': senha})
    return st

def esperar(cond, seg=8, msg='condição'):
    fim = time.time() + seg
    while time.time() < fim:
        if cond(): return
        time.sleep(0.1)
    raise AssertionError('tempo esgotado: ' + msg)

with sync_playwright() as p:
    nav = p.chromium.launch()
    ctx = nav.new_context(viewport={'width': 1366, 'height': 900}, locale='pt-BR', reduced_motion='reduce')
    # o container não alcança o Google Fonts: corta na hora para não travar o carregamento
    CSV_FRASES_TESTE = ('"frase","autor","fixar"\n'
        '"A frase fixada do teste vale para todos.","Equipe de Teste","HOJE"\n'
        '"Outra frase qualquer para a roleta.","",""\n')
    def rotear(r):
        u = r.request.url
        if 'fonts.googleapis' in u or 'fonts.gstatic' in u or 'calendar.google.com' in u:
            return r.abort()
        if 'docs.google.com/spreadsheets' in u:
            return r.fulfill(status=200, content_type='text/csv; charset=utf-8', body=CSV_FRASES_TESTE)
        r.continue_()
    ctx.route('**/*', rotear)
    ctx.grant_permissions(['clipboard-read', 'clipboard-write'], origin=SITE.rstrip('/'))
    pg = ctx.new_page()
    pg.set_default_timeout(15000)
    PAGINA['pg'] = pg
    pg.on('console', lambda m: erros_console.append(m.text) if m.type == 'error' else None)
    pg.on('pageerror', lambda e: erros_console.append('pageerror: ' + str(e)))

    print('E2E — login e primeiro acesso')
    pg.goto(SITE); pg.wait_for_selector('#telaLogin:not([hidden])')
    def login_errado():
        # a senha da Camily é criada pelo teste de API; aqui usamos um usuário que já tem senha
        garantir_senha('camily.jesus', 'senha-camily-1')
        pg.fill('#campoLogin', 'camily.jesus'); pg.fill('#campoSenha', 'errada'); pg.click('#btnEntrar')
        pg.wait_for_selector('#msgLogin:not([hidden])')
        assert 'não conferem' in pg.inner_text('#msgLogin')
    passo('senha errada → "Usuário ou senha não conferem"', login_errado)

    def primeiro_acesso():
        pg.fill('#campoLogin', 'Josi.Silva '); pg.fill('#campoSenha', ''); pg.click('#btnEntrar')
        pg.wait_for_selector('#formPrimeiro:not([hidden])')
        assert pg.inner_text('#nomePrimeiro') == 'josi.silva'
        pg.fill('#senhaNova', 'curta'); pg.fill('#senhaConf', 'curta'); pg.click('#btnCriarSenha')
        assert '8 caracteres' in pg.inner_text('#msgPrimeiro')
        pg.fill('#senhaNova', 'senha-josi-2026'); pg.fill('#senhaConf', 'senha-josi-2027'); pg.click('#btnCriarSenha')
        assert 'não são iguais' in pg.inner_text('#msgPrimeiro')
        pg.fill('#senhaConf', 'senha-josi-2026'); pg.click('#btnCriarSenha')
        pg.wait_for_selector('#app:not([hidden])')
        assert 'Josilene' in pg.inner_text('#saudacao')
        assert pg.is_hidden('#btnEditarMural')
    passo('primeiro acesso cria senha (valida tamanho e confirmação) e entra', primeiro_acesso)

    def mural_inicial():
        pg.wait_for_selector('#muralAvisos .aviso-row')
        carimbo = pg.evaluate("(s => s && getComputedStyle(s).transform)(document.querySelector('#muralMetas .carimbo-breve span'))")
        assert carimbo and carimbo != 'none', 'carimbo EM BREVE ausente ou sem inclinação'
        assert pg.evaluate("document.querySelector('[data-sub=metas]').hidden"), 'em breve: Ver mais das metas deveria sumir'
        pg.evaluate("abrirSub('metas')")
        assert pg.locator('#veuMural.aberto').count() == 0, 'em breve: metas não podem abrir subpágina'
        assert 'Comunicado Geral' in pg.inner_text('#muralAvisos')
        assert pg.locator('#muralAvisos .aviso-row.novo').count() == 1, 'sem marca de novo'
        assert '1 novo' in pg.text_content('#pillAvisos'), pg.text_content('#pillAvisos')
        pg.click('#muralAvisos .aviso-row')
        pg.wait_for_selector('#veuMural.aberto .sub-texto.rico b')
        assert 'Bem-vindo' in pg.inner_text('.sub-texto.rico b')
        assert 'César Bravo' in pg.inner_text('.sub-assina')
        pg.screenshot(path=SHOTS + '/01-aviso-aberto.png')
        pg.keyboard.press('Escape')
        esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='fechar subpágina')
        assert pg.locator('#muralAvisos .aviso-row.novo').count() == 0, 'continua novo'
        assert 'Em destaque' in pg.text_content('#pillAvisos'), pg.text_content('#pillAvisos')
    passo('mural: aviso "novo", abre subpágina rica, some o "novo" depois de lido', mural_inicial)

    def sessao_persistida():
        pg.reload(); pg.wait_for_selector('#app:not([hidden])')
        assert 'Josilene' in pg.inner_text('#saudacao')
    passo('recarregar a página mantém a sessão', sessao_persistida)

    # v1.31 — o Gerador de Minuta fica "Em breve" para a equipe (só o Tabelião entra)
    def gerador_em_breve_para_equipe():
        card = pg.locator('#cardMinutas')
        assert 'em-breve' in card.get_attribute('class') and 'em-breve-admin' not in card.get_attribute('class'), card.get_attribute('class')
        assert pg.is_visible('#minSeloEmBreve') and pg.inner_text('#minSeloEmBreve').strip().upper() == 'EM BREVE'
        assert 'curadoria' in pg.inner_text('#cardMinutas .card-acao').lower() and card.get_attribute('aria-disabled') == 'true'
        assert pg.evaluate("getComputedStyle(document.getElementById('cardMinutas')).cursor") == 'not-allowed'
        pg.click('#cardMinutas', force=True); pg.wait_for_selector('#toast:not([hidden])')   # force: o aria-disabled faz o Playwright recusar o clique (a pessoa consegue clicar)
        assert 'em breve' in pg.inner_text('#toast').lower() and pg.evaluate("document.getElementById('paginaMinutas').hidden"), 'o cartão não abre o Gerador'
        pg.goto(SITE + '#minutas'); pg.reload(); pg.wait_for_selector('#app:not([hidden])')
        esperar(lambda: pg.evaluate("!document.getElementById('paginaHub').hidden && document.getElementById('paginaMinutas').hidden"), msg='#minutas volta ao hub')
        pg.goto(SITE); pg.wait_for_selector('#app:not([hidden])')
    passo('v1.31: Gerador de Minuta "Em breve" para a equipe — cartão sombreado com selo, clique só avisa, #minutas volta ao hub', gerador_em_breve_para_equipe)

    def sair_e_entrar_cesar():
        pg.click('#btnSair'); pg.wait_for_selector('#telaLogin:not([hidden])')
        garantir_senha('cesar.bravo', 'senha-cesar-123')
        pg.fill('#campoLogin', 'cesar.bravo'); pg.fill('#campoSenha', 'senha-cesar-123'); pg.click('#btnEntrar')
        pg.wait_for_selector('#app:not([hidden])')
        assert pg.is_visible('#btnEditarMural')
        # v1.31 — para o Tabelião o cartão 05 continua aberto (com o selo EM BREVE à vista)
        assert 'em-breve-admin' in pg.get_attribute('#cardMinutas', 'class') and pg.is_visible('#minSeloEmBreve')
        assert 'tabelião' in pg.inner_text('#cardMinutas .card-acao').lower() and pg.get_attribute('#cardMinutas', 'aria-disabled') == 'false', pg.inner_text('#cardMinutas .card-acao')
    passo('sair → entrar como Tabelião → botão "Editar mural" aparece; cartão 05 aberto ao Tabelião', sair_e_entrar_cesar)

    print('E2E — modo do Tabelião e editor de texto rico')
    def novo_aviso_formatado():
        pg.click('#btnEditarMural'); pg.wait_for_selector('#veuMural.aberto .ed-abas')
        pg.click('#edNovoAviso'); pg.wait_for_selector('#edAvEditor .rico-area')
        pg.fill('#edAvTitulo', 'Plantão de sábado')
        pg.click('[data-estilo="importante"]'); pg.check('#edAvFixado')
        area = pg.locator('#edAvEditor .rico-area')
        area.click()
        pg.keyboard.type('Atenção equipe: plantão neste sábado das 8h às 12h.')
        # seleciona "plantão" e aplica negrito
        def selecionar(palavra):
            pg.evaluate('''(p) => { const a = document.querySelector('#edAvEditor .rico-area');
              const w = document.createTreeWalker(a, NodeFilter.SHOW_TEXT); let n;
              while ((n = w.nextNode())) { const i = n.nodeValue.indexOf(p);
                if (i >= 0) { const r = document.createRange(); r.setStart(n, i); r.setEnd(n, i + p.length);
                  const s = getSelection(); s.removeAllRanges(); s.addRange(r); a.dispatchEvent(new Event('mouseup')); return; } } }''', palavra)
        selecionar('plantão'); pg.click('#edAvEditor [data-cmd="bold"]')
        selecionar('8h às 12h'); pg.click('#edAvEditor [data-acao="marca"]')
        selecionar('Atenção equipe'); pg.click('#edAvEditor [data-acao="vinho"]')
        pg.keyboard.press('End'); pg.keyboard.press('Enter')
        pg.click('#edAvEditor [data-cmd="insertUnorderedList"]')
        pg.keyboard.type('Trazer crachá'); pg.keyboard.press('Enter'); pg.keyboard.type('Chegar 7h50')
        pg.click('#edAvEditor [data-acao="emoji"]'); pg.click('#edAvEditor [data-emoji="📌"]')
        pg.screenshot(path=SHOTS + '/02-editor-rico.png')
        pg.click('#edAvSalvar')
        pg.wait_for_selector('.ed-item.fixado')
        assert 'pendente' in pg.get_attribute('#edStatus', 'class')
        pg.click('#edPublicar')
        esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='publicar fecha o editor')
        pg.wait_for_selector('#toast:not([hidden])')
        assert 'publicado' in pg.inner_text('#toast')
    passo('cria aviso Importante + fixado com negrito, destaque, cor vinho, lista e emoji; publica', novo_aviso_formatado)

    def conferir_html_salvo():
        tok = pg.evaluate("localStorage.getItem('cn2o_token')")
        st, r = api('/hub/mural', token=tok)
        av = r['dados']['avisos'][0]
        h = av['html']
        assert av['titulo'] == 'Plantão de sábado' and av['estilo'] == 'importante' and av['fixado'] is True, av
        assert '<b>plantão</b>' in h, h
        assert '<mark>8h às 12h</mark>' in h, h
        assert 't-vinho' in h, h
        assert '<ul><li>Trazer crachá</li><li>Chegar 7h50📌</li></ul>' in h or ('<li>Trazer crachá</li>' in h and '📌' in h), h
        assert 'style=' not in h and 'font' not in h, h
        print('     html salvo:', h[:220])
    passo('HTML gravado no servidor: só tags/classes permitidas (b, mark, t-vinho, ul/li)', conferir_html_salvo)

    def foto_e_imagem_no_mural():
        # jpgs gerados na hora (rosto pequeno e imagem de aviso maior)
        import io as _io
        from PIL import Image as _Img
        def jpg(l, cor):
            b = _io.BytesIO(); _Img.new('RGB', (l, l), cor).save(b, 'JPEG', quality=88); return b.getvalue()
        pg.click('#btnEditarMural'); pg.wait_for_selector('#veuMural.aberto .ed-abas')
        pg.click('.ed-aba[data-aba="aniversariantes"]'); pg.wait_for_selector('#edAnFoto', state='attached')
        # ainda não há ninguém na lista neste ponto do fluxo: cadastra um para receber a foto
        pg.fill('#edAnNome', 'Foto Teste'); pg.fill('#edAnDia', '25')
        pg.select_option('#edAnMes', str(time.localtime().tm_mon))
        pg.click('#edAnAdd')
        pg.wait_for_selector('[data-foto]')
        pg.locator('[data-foto]').first.click()
        pg.set_input_files('#edAnFoto', files=[{'name': 'rosto.jpg', 'mimeType': 'image/jpeg', 'buffer': jpg(400, (180, 90, 60))}])
        esperar(lambda: pg.locator('.ed-item-foto img.aniv-foto').count() >= 1, msg='thumb da foto no editor')
        # aviso com imagem
        pg.click('.ed-aba[data-aba="avisos"]'); pg.wait_for_selector('[data-edita]')
        pg.locator('[data-edita]').first.click(); pg.wait_for_selector('#edAvImg', state='attached')
        pg.set_input_files('#edAvImg', files=[{'name': 'quadro.jpg', 'mimeType': 'image/jpeg', 'buffer': jpg(1600, (40, 70, 120))}])
        esperar(lambda: pg.locator('#edAvImgPrev:visible').count() == 1, msg='prévia da imagem do aviso')
        pg.click('#edAvSalvar'); pg.wait_for_selector('#edPublicar')
        pg.click('#edPublicar')
        esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='publicar fecha o editor')
        pg.wait_for_selector('#toast:not([hidden])')
        # no mural: foto redonda no aniversariante e miniatura no aviso
        esperar(lambda: pg.locator('#muralAniversariantes img.aniv-foto').count() >= 1, msg='foto no cartão Agenda Cn2o')
        assert pg.locator('#muralAvisos .aviso-doc img').count() >= 1, 'miniatura da imagem no aviso'
        pg.click('#muralAvisos .aviso-row')
        pg.wait_for_selector('#veuMural.aberto .sub-imagem')
        assert pg.evaluate("(i => i.naturalWidth > 200)(document.querySelector('.sub-imagem'))"), 'imagem grande na subpágina'
        pg.keyboard.press('Escape')
        esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='fechar subpágina')
        # servidor guardou foto e imagem
        tok = pg.evaluate("localStorage.getItem('cn2o_token')")
        st, r = api('/hub/mural', token=tok)
        assert any(str(a.get('foto', '')).startswith('data:image/jpeg') for a in r['dados']['aniversariantes']), 'foto não persistiu'
        assert any(str(a.get('imagem', '')).startswith('data:image/jpeg') for a in r['dados']['avisos']), 'imagem não persistiu'
    passo('foto do aniversariante + imagem no aviso: editor do Tabelião → publica → aparece no mural e persiste', foto_e_imagem_no_mural)

    def mural_mostra_fixado():
        first = pg.locator('#muralAvisos .aviso-row').first
        assert 'Plantão de sábado' in first.inner_text()
        assert 'fixado' in first.get_attribute('class') and 'importante' in first.get_attribute('class')
        first.click(); pg.wait_for_selector('.sub-selo.importante')
        assert pg.locator('.sub-texto.rico mark').count() == 1
        assert pg.locator('.sub-texto.rico .t-vinho').count() >= 1
        pg.screenshot(path=SHOTS + '/03-aviso-formatado.png')
        pg.keyboard.press('Escape')
    passo('mural: aviso fixado vem primeiro, selo "Importante" e formatação renderizada', mural_mostra_fixado)

    def editar_aviso_existente():
        pg.click('#btnEditarMural'); pg.wait_for_selector('.ed-abas')
        pg.click('[data-edita="0"]'); pg.wait_for_selector('#edAvEditor .rico-area')
        assert pg.input_value('#edAvTitulo') == 'Plantão de sábado', pg.input_value('#edAvTitulo')
        nb = pg.locator('#edAvEditor .rico-area b').count()
        assert nb == 1, 'negritos no editor: %d · %s' % (nb, pg.inner_html('#edAvEditor .rico-area'))
        pg.wait_for_timeout(150)  # o formulário foca o editor 30 ms depois de abrir; deixa assentar
        pg.fill('#edAvTitulo', 'Plantão de sábado (confirmado)')
        pg.click('#edAvSalvar')
        try:
            pg.wait_for_selector('.ed-item:has-text("(confirmado)")', timeout=6000)
        except Exception:
            if pg.locator('#edAvSalvar').count():
                pg.click('#edAvSalvar')
            pg.wait_for_selector('.ed-item:has-text("(confirmado)")', timeout=9000)
        pg.click('#edPublicar')
        esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='publicar')
        assert 'confirmado' in pg.text_content('#muralAvisos'), pg.text_content('#muralAvisos')
    passo('edita aviso existente mantendo a formatação e republica', editar_aviso_existente)

    def aniversariantes_lote():
        pg.click('#btnEditarMural'); pg.click('[data-aba="aniversariantes"]')
        hoje = time.localtime()
        pg.fill('#edAnLote', f'Josilene - {hoje.tm_mday:02d}/{hoje.tm_mon:02d}\nCamily – 28/{hoje.tm_mon:02d}\nLara: 05/{(hoje.tm_mon % 12) + 1:02d}\nlinha ruim')
        pg.click('#edAnLoteAdd')
        assert pg.locator('.ed-item').count() == 4  # 3 do lote + "Foto Teste" (do teste da foto)
        pg.click('#edPublicar'); esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='publicar')
        assert pg.locator('#muralAniversariantes li.hoje').count() == 1
        assert 'Camily' in pg.inner_text('#muralAniversariantes')
        pg.click('[data-sub="aniversariantes"]'); pg.wait_for_selector('#veuMural.aberto')
        assert 'Lara' in pg.inner_text('#subConteudo')
        pg.keyboard.press('Escape')
    passo('aniversariantes colados em lote (linha ruim avisada); "hoje!" destacado; próximo mês na subpágina', aniversariantes_lote)

    def metas_ativas():
        pg.click('#btnEditarMural'); pg.click('[data-aba="metas"]')
        pg.fill('#edMtTitulo', '120 atos lavrados em setembro'); pg.fill('#edMtProg', '65'); pg.fill('#edMtPremio', 'Almoço da equipe')
        pg.click('#edMtAdd'); pg.uncheck('#edMtBreve')
        pg.click('#edPublicar'); esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='publicar')
        assert pg.locator('#muralMetas .meta-item').count() == 1
        assert '65%' in pg.inner_text('#muralMetas')
        w = pg.evaluate("document.querySelector('#muralMetas .meta-barra i').style.width")
        assert w == '65%', w
    passo('metas: cadastra meta com prêmio, tira o "EM BREVE" e a barra aparece no cartão', metas_ativas)

    def historico_e_conflito():
        pg.click('#btnEditarMural'); pg.click('[data-aba="historico"]')
        pg.wait_for_selector('[data-carrega]')
        n = pg.locator('[data-carrega]').count(); assert n >= 4, n
        # alguém publica "por fora" enquanto o editor está aberto → 409 tratado
        tok = pg.evaluate("localStorage.getItem('cn2o_token')")
        st, atual = api('/hub/mural', token=tok)
        st2, _ = api('/hub/mural', {'dados': atual['dados'], 'base': atual['atualizado_em']}, token=tok)
        assert st2 == 200
        pg.click('[data-aba="avisos"]'); pg.click('[data-fixa="0"]'); pg.click('#edPublicar')
        pg.wait_for_function("document.getElementById('edStatus') && /alterado em outro lugar/.test(document.getElementById('edStatus').textContent)")
        pg.keyboard.press('Escape')
        pg.keyboard.press('Escape')
    passo('histórico lista as publicações; conflito de edição avisado e mural recarregado', historico_e_conflito)

    def fechar_com_alteracao_pendente():
        pg.click('#btnEditarMural'); pg.click('[data-fixa="0"]')
        pg.click('#subConteudo [data-fechar-sub]')
        assert pg.locator('#veuMural.aberto').count() == 1
        assert 'descartar' in pg.inner_text('#edStatus')
        pg.click('#subConteudo [data-fechar-sub]')
        esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='descartar')
    passo('fechar o editor com alteração pendente pede um segundo clique', fechar_com_alteracao_pendente)

    def equipe_admin():
        pg.click('#btnEditarMural'); pg.click('[data-aba="equipe"]')
        pg.wait_for_selector('#edEqNome')
        pg.fill('#edEqNome', 'Sérgio Luiz')
        assert pg.input_value('#edEqLogin') == 'sergio.luiz', pg.input_value('#edEqLogin')
        pg.fill('#edEqCargo', 'Cadastro e Protocolo'); pg.click('#edEqAdd')
        pg.wait_for_selector('.ed-item:has-text("Sérgio Luiz")')
        assert 'aguardando o primeiro acesso' in pg.text_content('.ed-item:has-text("Sérgio Luiz")')
        st, r = api('/login', {'login': 'sergio.luiz', 'senha': ''})
        assert r.get('primeiro_acesso') is True, r
        b = pg.locator('[data-zera="josi.silva"]')
        b.click(); assert (b.text_content() or '').strip() == 'Confirmar?'
        b.click()
        pg.wait_for_function("/Senha zerada/.test(document.getElementById('toast').textContent)")
        st, r = api('/login', {'login': 'josi.silva', 'senha': 'senha-josi-2026'})
        assert r.get('primeiro_acesso') is True, r
        pg.screenshot(path=SHOTS + '/09-equipe.png')
        pg.keyboard.press('Escape')
        esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='fechar editor')
    passo('Equipe: cadastra colaborador (usuário sugerido do nome) e zera a senha de outra pessoa', equipe_admin)

    def tema():
        assert pg.get_attribute('html', 'data-theme') == 'light'
        pg.click('#btnTema'); assert pg.get_attribute('html', 'data-theme') == 'dark'
        pg.reload(); pg.wait_for_selector('#app:not([hidden])')
        assert pg.get_attribute('html', 'data-theme') == 'dark', 'tema escuro não persistiu'
        pg.click('#btnTema'); assert pg.get_attribute('html', 'data-theme') == 'light'
    passo('tema claro por padrão; escuro só por escolha e lembrado', tema)

    def xss_nao_renderiza():
        tok = pg.evaluate("localStorage.getItem('cn2o_token')")
        st, atual = api('/hub/mural', token=tok)
        d = atual['dados']
        d['avisos'].insert(0, {'titulo': 'Teste de segurança', 'html': '<p>ok<img src="x"><table><tr><td>célula</td></tr></table><a href="http://exemplo.com">link</a><video src="x"></video><font face="Comic Sans">fonte</font></p>'})
        st2, r = api('/hub/mural', {'dados': d, 'base': atual['atualizado_em']}, token=tok)
        assert st2 == 200, r
        pg.reload(); pg.wait_for_selector('#muralAvisos .aviso-row')
        pg.click('#muralAvisos .aviso-row:has-text("Teste de segurança")')
        pg.wait_for_selector('#veuMural.aberto .sub-texto.rico')
        assert pg.locator('.sub-texto.rico img, .sub-texto.rico table, .sub-texto.rico video, .sub-texto.rico font').count() == 0
        assert 'célula' in pg.text_content('.sub-texto.rico')
        a = pg.locator('.sub-texto.rico a')
        assert a.get_attribute('target') == '_blank' and 'noopener' in a.get_attribute('rel')
        assert pg.is_visible('body')
        pg.keyboard.press('Escape')
    passo('HTML indesejado gravado por fora não é renderizado (img/style/object caem; link seguro)', xss_nao_renderiza)

    print('E2E — ferramentas de IA')
    def extrator_texto():
        pg.click('#cardExtrator'); pg.wait_for_selector('#paginaExtrator:not([hidden])')
        assert pg.evaluate('location.hash') == '#extrator'
        esperar(lambda: 'IA ativa' in (pg.text_content('#paginaExtrator [data-chip-ia]') or ''), msg='chip IA ativa')
        # v1.19: sem campo de texto na interface e sem "Ver exemplo" — só documento
        assert pg.evaluate("document.getElementById('entradaExtrator').hidden"), 'o campo de colar texto deveria estar oculto'
        assert pg.evaluate("document.getElementById('btnExemploExt').hidden"), '"Ver exemplo" deveria estar oculto'
        assert 'cole o texto' not in pg.inner_text('#paginaExtrator'), 'não deveria convidar a colar texto'
        # pisca-pisca verde no selo IA ativa
        # o contexto de teste roda com prefers-reduced-motion, que desliga o pisca de
        # propósito: confere-se o verde do ponto e a existência da animação na folha
        piscando = pg.evaluate('''() => { const c = document.querySelector('#paginaExtrator [data-chip-ia]');
          const e = getComputedStyle(c, '::before');
          return { cor: e.color, temKeyframes: document.documentElement.outerHTML.indexOf('@keyframes pulsoIA') > -1,
                   temRegra: /\.chip-ia\.ok::before\{[^}]*animation:pulsoIA/.test(document.documentElement.outerHTML) }; }''')
        assert piscando['cor'] == 'rgb(34, 161, 92)', piscando
        assert piscando['temKeyframes'] and piscando['temRegra'], piscando
        pg.set_input_files('#paginaExtrator .zona-anexos input[type=file]', os.path.join(ARQ, 'certidao-p1.png'))
        pg.wait_for_selector('#paginaExtrator .anexo-item')
        # v1.20: barra verde de carregamento e campo compactado com arquivo na lista
        carga = pg.evaluate('''() => { const b = document.querySelector('#paginaExtrator .anexo-drop .dc-barra');
          if (!b) return { falta: true };
          const e = getComputedStyle(b);
          return { fundo: e.backgroundImage, temFundoVerde: !!document.querySelector('#paginaExtrator .anexo-drop .dc-fundo'),
                   compacto: document.querySelector('#paginaExtrator .zona-anexos').classList.contains('tem-itens') }; }''')
        assert not carga.get('falta'), 'barra de carregamento não foi montada'
        assert '34, 161, 92' in carga['fundo'], carga['fundo']
        assert carga['temFundoVerde'] and carga['compacto'], carga
        pg.click('#btnGerar')
        pg.wait_for_selector('#saidaExtrator .giro')
        pg.wait_for_function("document.getElementById('saidaExtrator').textContent.startsWith('QUALIFICAÇÃO PRONTA')", timeout=20000)
        assert pg.is_visible('#btnCopiarExt')
        meta = pg.inner_text('#metaExt'); assert 'Gemini Pro (vigente)' in meta and 'César' in meta, meta
    passo('Extrator: documento → Extrair qualificação → resultado, assinatura e Copiar (selo IA piscando)', extrator_texto)

    def leitura_clara():
        fundo = pg.evaluate("getComputedStyle(document.querySelector('#paginaExtrator .painel')).backgroundColor")
        cor = pg.evaluate("getComputedStyle(document.querySelector('#saidaExtrator')).color")
        tam = pg.evaluate("getComputedStyle(document.querySelector('#saidaExtrator')).fontSize")
        fam = pg.evaluate("getComputedStyle(document.querySelector('#saidaExtrator')).fontFamily")
        assert fundo == 'rgb(255, 255, 255)', fundo
        assert cor == 'rgb(26, 34, 48)', cor
        assert tam == '18px', tam
        assert 'Atkinson Hyperlegible' in fam, fam
        ent = pg.evaluate("""() => { const c = getComputedStyle(document.querySelector('#paginaExtrator .col-entrada'));
          return { fundo: c.backgroundColor, tarja: c.borderTopColor }; }""")
        assert ent['fundo'] == 'rgb(246, 239, 231)', ent
        assert ent['tarja'] == 'rgb(32, 42, 58)', ent
    passo('v1.15: leitura Atkinson Hyperlegible 18 px quase-preta em quadro branco; entrada marfim com tarja marinho', leitura_clara)

    def extrator_foto_grande():
        pg.click('#btnLimparExt')
        pg.set_input_files('#paginaExtrator .zona-anexos input[type=file]', os.path.join(ARQ, 'foto-celular.jpg'))
        pg.wait_for_selector('#paginaExtrator .anexo-item')
        tam = pg.inner_text('#paginaExtrator .anexo-tam')
        assert 'MB' in tam or 'KB' in tam
        info = pg.inner_text('#paginaExtrator .cont-anexos'); print('     foto 11 MB comprimida para:', info)
        pg.click('#btnGerar')
        pg.wait_for_function("document.getElementById('saidaExtrator').textContent.startsWith('QUALIFICAÇÃO PRONTA')", timeout=20000)
        ult = chamadas()[-1]
        assert ult['arquivos'][0]['mime'] == 'image/jpeg' and ult['arquivos'][0]['tam'] < 6 * 1024 * 1024, ult['arquivos']
        assert ult['observacoes'].startswith('(Sem texto colado')
        assert 'LEITURA OCR DEDICADA' in ult['observacoes'], 'dupla leitura ausente das observações'
        assert 'Dupla leitura OCR: 1 de 120 palavra(s) com leitura incerta' in pg.inner_text('#metaExt'), pg.inner_text('#metaExt')
        assert 'leitura difícil' not in pg.inner_text('#metaExt'), 'documento bom não pode ser rotulado de difícil'
    passo('Extrator: foto de celular de 11 MB é reduzida (≤ 2400 px) e chega como JPEG ao modelo — com dupla leitura OCR', extrator_foto_grande)

    def extrator_botao_descricao():
        pg.click('#btnLimparExt')
        pg.set_input_files('#paginaExtrator .zona-anexos input[type=file]', os.path.join(ARQ, 'certidao-p1.png'))
        pg.wait_for_selector('#paginaExtrator .anexo-item')
        pg.click('#btnDescricao')
        pg.wait_for_function("/DESCRIÇÃO ATUALIZADA DO IMÓVEL/.test(document.getElementById('saidaExtrator').textContent)", timeout=20000)
        assert pg.inner_text('#rotuloSaidaExt').strip().lower() == 'descrição do imóvel', pg.inner_text('#rotuloSaidaExt')
        assert 'Descrição extraída para' in pg.inner_text('#metaExt'), pg.inner_text('#metaExt')
        ch = chamadas()[-1]
        assert 'extrator de DESCRIÇÃO DE IMÓVEL' in ch['prompt'], ch['prompt'][:120]
        assert 'ipsis litteris' in ch['prompt']
        pg.screenshot(path=SHOTS + '/18-extrator-botoes.png')
        # o outro botão continua funcionando na mesma página
        pg.click('#btnLimparExt')
        assert pg.inner_text('#rotuloSaidaExt').strip().lower() == 'resultado da extração'
    passo('Extrator por botões: "Extrair descrição do imóvel" chama o prompt certo e rotula o painel', extrator_botao_descricao)

    def congestionamento_503():
        # v1.21 — quando o provedor da IA congestiona (503 UNAVAILABLE), o servidor
        # insiste e troca de modelo sozinho; se ainda assim não vier, o balcão recebe
        # um recado em português, nunca o JSON cru do Google.
        antes = len(chamadas())
        pg.set_input_files('#paginaExtrator .zona-anexos input[type=file]', os.path.join(ARQ, 'forcar-503.png'))
        pg.wait_for_selector('#paginaExtrator .anexo-item')
        pg.click('#btnGerar')
        pg.wait_for_function("/congestionado/.test(document.getElementById('saidaExtrator').textContent)", timeout=40000)
        recado = pg.inner_text('#saidaExtrator')
        assert 'UNAVAILABLE' not in recado and '{' not in recado, recado
        assert 'seus anexos continuam aqui' in recado.lower(), recado
        assert pg.evaluate("document.querySelectorAll('#paginaExtrator .anexo-item').length") == 1, 'o anexo não podia sumir'
        usados = [x.get('modelo') for x in chamadas()[antes:]]
        assert len(usados) == 4, usados          # preferido 2x + socorro 2x
        assert len(set(usados)) == 2, usados     # o socorro é outro modelo
        pg.screenshot(path=SHOTS + '/19-extrator-congestionado.png')
        pg.click('#btnLimparExt')
    passo('v1.21: modelo congestionado (503) → retentativa, socorro em outro modelo e recado humano', congestionamento_503)

    def analista_pdf_foto_print():
        pg.locator('[data-voltar]:visible').first.click(); pg.click('#cardAnalisador'); pg.wait_for_selector('#paginaAnalisador:not([hidden])')
        assert pg.evaluate("document.getElementById('entradaAnalisador').hidden"), 'o campo de texto do Analista deveria estar oculto (só upload)'
        assert pg.evaluate("document.getElementById('btnExemploAna').hidden"), 'Ver exemplo deveria estar oculto no Analista'
        assert 'cole o texto' not in pg.inner_text('#paginaAnalisador'), 'não deveria haver convite a colar texto'
        pg.set_input_files('#paginaAnalisador .zona-anexos input[type=file]', [os.path.join(ARQ, 'certidao.pdf'), os.path.join(ARQ, 'certidao-p1.png')])
        esperar(lambda: pg.locator('#paginaAnalisador .anexo-item').count() == 2, msg='2 anexos')
        assert pg.locator('#paginaAnalisador .anexo-thumb.pdf').count() == 1
        # print colado (Ctrl+V) com imagem no clipboard
        pg.evaluate('''async () => {
          const c = document.createElement('canvas'); c.width = 300; c.height = 120;
          const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0,0,300,120); g.fillStyle = '#000'; g.fillText('R.4/8.412 PENHORA', 20, 60);
          const b = await new Promise(r => c.toBlob(r, 'image/png'));
          const dt = new DataTransfer(); dt.items.add(new File([b], 'image.png', { type: 'image/png' }));
          document.body.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
        }''')
        esperar(lambda: pg.locator('#paginaAnalisador .anexo-item').count() == 3, msg='print colado')
        assert 'print colado' in pg.inner_text('#paginaAnalisador .anexo-lista')
        pg.screenshot(path=SHOTS + '/04-analista-anexos.png')
        pg.click('#btnAnalisar')
        pg.wait_for_selector('#descBox:not([hidden])', timeout=20000)
        assert 'Rua Coronel Sebastião' in pg.inner_text('#descTexto')
        assert '===DESCRICAO' not in pg.inner_text('#saidaAnalisador')
        ult = chamadas()[-1]
        assert [a['mime'] for a in ult['arquivos']] == ['application/pdf', 'image/png', 'image/png'], ult['arquivos']
        assert ult['arquivos'][0]['cabeca'] == '%PDF-'
        pg.screenshot(path=SHOTS + '/05-analista-resultado.png')
    passo('Analista: PDF + foto + print colado → extrato e "Descrição do imóvel" destacada', analista_pdf_foto_print)

    def colar_texto_nao_vira_anexo():
        n = pg.locator('#paginaAnalisador .anexo-item').count()
        pg.evaluate('''() => { const dt = new DataTransfer(); dt.setData('text/plain', 'MATRÍCULA 123 texto');
          document.body.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true })); }''')
        time.sleep(0.4)
        assert pg.locator('#paginaAnalisador .anexo-item').count() == n
    passo('colar TEXTO (sem imagem) não cria anexo no Analista', colar_texto_nao_vira_anexo)

    def analista_sem_anexo_avisa():
        pg.click('#btnLimparAna'); pg.click('#btnAnalisar')
        pg.wait_for_selector('#toast:not([hidden])')
        assert 'foto, print ou PDF' in pg.inner_text('#toast'), pg.inner_text('#toast')
    passo('Analista sem anexo: aviso pede a certidão em foto, print ou PDF', analista_sem_anexo_avisa)

    def erro_do_modelo():
        pg.locator('[data-voltar]:visible').first.click(); pg.click('#cardExtrator'); pg.wait_for_selector('#paginaExtrator:not([hidden])')
        pg.click('#btnLimparExt'); pg.evaluate("document.getElementById('entradaExtrator').value = 'FORCAR_ERRO'")
        pg.click('#btnGerar')
        pg.wait_for_function("/A IA não conseguiu concluir/.test(document.getElementById('saidaExtrator').textContent)", timeout=15000)
        assert 'extrair qualificação' in (pg.inner_text('#btnGerar') or '').lower(), pg.inner_text('#btnGerar')
    passo('falha do modelo mostra mensagem clara e libera o botão', erro_do_modelo)

    def interromper():
        pg.evaluate("document.getElementById('entradaExtrator').value = 'qualquer'"); pg.click('#btnGerar')
        pg.wait_for_selector('#saidaExtrator .giro'); pg.click('#btnGerar')
        pg.wait_for_function("document.getElementById('saidaExtrator').textContent === 'Interrompido.'")
    passo('botão Interromper cancela a análise em andamento', interromper)

    print('E2E — ferramentas embutidas, rotas e sessão')
    def protocolo_embutido():
        pg.locator('[data-voltar]:visible').first.click(); pg.click('#cardProtocolo')
        pg.wait_for_selector('#paginaEmbutida:not([hidden]) iframe')
        fr = pg.frame_locator('#molduraEmbutida iframe:not([hidden])')
        txt = fr.locator('#sessaoInfo').inner_text(timeout=8000)
        assert 'César Bravo' in txt and 'Tabelião' in txt and 'Hub dos Escreventes' not in txt, txt
        assert pg.get_attribute('#embutidaNovaAba', 'href') == 'protocolo.html'
        assert pg.evaluate('location.hash') == '#protocolo'
        pg.screenshot(path=SHOTS + '/06-protocolo-embutido.png')
        pg.go_back(); pg.wait_for_selector('#paginaHub:not([hidden])')
    passo('Protocolo abre embutido com a MESMA sessão; Voltar do navegador retorna ao hub', protocolo_embutido)

    def agenda_embutida():
        pg.evaluate("document.querySelector('[data-nav=calendario]').click()")
        pg.wait_for_selector('#paginaEmbutida:not([hidden])')
        assert pg.evaluate('location.hash') == '#agenda'
        assert (pg.text_content('#embutidaTitulo') or '').strip() == 'Agenda do Tabelião'
        src = pg.evaluate("document.querySelector('#molduraEmbutida iframe:not([hidden])').src")
        assert src.startswith('https://calendar.google.com/calendar/embed?src=tnitabaiana%40gmail.com'), src
        assert 'ctz=America%2FMaceio' in src and 'hl=pt_BR' in src, src
        ab = pg.get_attribute('#embutidaNovaAba', 'href')
        assert ab == 'https://calendar.google.com/calendar/u/0?cid=dG5pdGFiYWlhbmFAZ21haWwuY29t', ab
        pg.go_back(); pg.wait_for_selector('#paginaHub:not([hidden])')
    passo('Agenda do Tabelião abre embutida (Google Agenda) e "nova aba" leva ao link do Tabelião', agenda_embutida)

    def home_igual_a_foto():
        est = pg.evaluate("""() => { const c = getComputedStyle(document.querySelector('.login-caixa'));
          const img = document.querySelector('.login-arte img');
          return { fundo: c.backgroundImage, raio: c.borderRadius, sombra: c.boxShadow,
                   arte: img && img.src.slice(0, 22), frase: document.querySelector('.arte-frase').textContent,
                   titulo: document.querySelector('.login-titulo').textContent,
                   sub: document.querySelector('.login-sub').textContent,
                   botao: document.getElementById('btnEntrar').textContent.trim(),
                   nota: document.querySelector('.login-nota-pe').textContent }; }""")
        assert 'gradient' in est['fundo'] and est['raio'] == '16px' and est['sombra'] != 'none', est
        assert est['arte'] == 'data:image/jpeg;base64', est['arte']
        assert 'Boas ferramentas' in est['frase'] and 'transformam.' in est['frase'], est['frase']
        assert est['titulo'] == 'Hub CN2O' and est['sub'] == 'Seu ambiente de trabalho.', est
        assert est['botao'] == 'Entrar no Hub', est['botao']
        assert 'e-Protocolo' in est['nota'] and 'redefinição ao Tabelião' in est['nota'], est['nota']
    passo('home igual à foto: escultura + frase à esquerda, cartão "Hub CN2O" à direita', home_igual_a_foto)

    def olho_da_senha():
        assert pg.evaluate("document.getElementById('campoSenha').type") == 'password'
        pg.evaluate("document.querySelector('[data-olho=campoSenha]').click()")
        assert pg.evaluate("document.getElementById('campoSenha').type") == 'text'
        pg.evaluate("document.querySelector('[data-olho=campoSenha]').click()")
        assert pg.evaluate("document.getElementById('campoSenha').type") == 'password'
    passo('olho da senha mostra e volta a ocultar', olho_da_senha)

    def links_uteis_com_logos():
        dados = pg.evaluate("""() => Array.from(document.querySelectorAll('#linksUteis .link-item')).map(li => ({
          nome: li.querySelector('.link-nome').textContent,
          logo: !!li.querySelector('.link-logo img') && li.querySelector('.link-logo img').src.startsWith('data:image/png'),
          href: (li.querySelector('a') || {}).href || null }))""")
        nomes = [d['nome'] for d in dados]
        assert nomes == ['TJSE — Guia de emolumentos', 'e-Notariado', 'RI Digital', 'Links CNJ',
            'Receita Federal — CND', 'Sefaz/SE — Portal do ITCMD', 'Prefeitura de Itabaiana/SE'], nomes
        assert all(d['logo'] for d in dados), dados
        assert any(d['href'] and 'e-notariado.org.br' in d['href'] for d in dados)
        assert any(d['href'] and 'ridigital.org.br' in d['href'] for d in dados)
        assert any(d['href'] and 'itabaiana.se.gov.br' in d['href'] for d in dados)
        pg.click('#linkCnj')
        pg.wait_for_selector('#veuCnj.aberto')
        cnj = pg.evaluate("""() => Array.from(document.querySelectorAll('#veuCnj a')).map(a => a.href)""")
        assert len(cnj) == 3 and any('179' in u for u in cnj) and any('5243' in u for u in cnj) and any('justicaaberta' in u for u in cnj), cnj
        pg.keyboard.press('Escape')
        pg.wait_for_selector('#veuCnj', state='hidden')
        faixa = pg.evaluate("(f => f && f.textContent.trim())(document.querySelector('#linksUteis .faixa-titulo.faixa-clara .faixa-palavra'))")
        assert faixa == 'Links úteis', faixa
    passo('Links úteis: 7 entradas com mini-logos, faixa clara própria e a sobreposição Links CNJ', links_uteis_com_logos)

    def cartoes_numerados():
        nomes = pg.evaluate("Array.from(document.querySelectorAll('#secFerramentas .card h3')).map(h => h.textContent.trim())")
        assert nomes == ['e-Protocolo', 'Calculadora de Emolumentos', 'Extrator', 'e-Analista', 'Gerador de Minuta', 'Cláusulas CN2O', 'T-Consulta', 'Redator CN2O'], nomes
        nums = pg.evaluate("Array.from(document.querySelectorAll('#secFerramentas .card-num')).map(n => n.textContent)")
        assert nums == ['01', '02', '03', '04', '05', '06', '07', '08'], nums
        chips = pg.evaluate("""Array.from(document.querySelectorAll('#secFerramentas .card')).map(c => {
          const ch = c.querySelector('.chip-ia'); return ch ? ch.textContent.trim() : null })""")
        assert chips == [None, None, 'IA', 'IA', 'IA', 'Guia', 'Trello', 'IA'], chips
        icones = pg.evaluate("document.querySelectorAll('#secFerramentas .card .card-ico svg').length")
        assert icones == 8, icones
        descr = pg.evaluate("document.querySelectorAll('#secFerramentas .card p').length")
        assert descr == 8, descr
        cols = pg.evaluate("getComputedStyle(document.querySelector('#secFerramentas .cards')).gridTemplateColumns.split(' ').length")
        assert cols == 4, 'grade deveria ter 4 colunas na tela larga: %s' % cols
        trello = pg.evaluate("(a => ({href: a.href, gira: !!a.querySelector('.t3d-gira'), cn2o: !!a.querySelector('.t3d-cn2o'), seta: !!a.querySelector('.t3d-seta')}))(document.getElementById('atalhoTrello'))")
        assert trello['href'].startswith('https://trello.com') and trello['gira'] and not trello['cn2o'] and not trello['seta'], trello
        pg.click('#cardMinutas')
        pg.wait_for_selector('#paginaMinutas:not([hidden])')
        # v1.30 — o termo de ciência saiu da tela (ciência colhida por termo escrito): o botão nasce liberado
        assert not pg.evaluate("document.getElementById('btnGerarMinuta').disabled"), 'v1.30: o botão nasce liberado'
        assert pg.locator('#paginaMinutas .termo-check').count() == 0 and pg.locator('#minCiente1').count() == 0, 'v1.30: sem caixas de ciência'
        assert 'responsabilidade disciplinar' not in pg.inner_text('#paginaMinutas'), 'v1.30: o termo disciplinar saiu da tela'
        pg.locator('#paginaMinutas [data-voltar]').click()
        pg.wait_for_selector('#paginaHub:not([hidden])')
    passo('Ferramentas 01–08 com descrições, chips IA/Guia/Trello e o atalho 3D do Trello', cartoes_numerados)

    # ---------------- 05 · Gerador de Minuta (v1.28 — entrevista dirigida por ato sobre o Prompt-Mestre BV 4.0) ----------------
    def abrir_gerador():
        if pg.locator('#paginaMinutas:visible').count() == 0:
            if pg.locator('[data-voltar]:visible').count(): pg.locator('[data-voltar]:visible').first.click()
            pg.wait_for_selector('#paginaHub:not([hidden])')
            pg.click('#cardMinutas')
        pg.wait_for_selector('#paginaMinutas:not([hidden])')
    def ficha_enviada():
        obs = chamadas()[-1]['observacoes']
        return obs[obs.index('=== ENTREVISTA DIRIGIDA'):]
    def entrevistas_visiveis():
        return pg.evaluate("Array.from(document.querySelectorAll('#minEntrevista [data-entrevista]')).filter(d => !d.hidden).map(d => d.dataset.entrevista)")
    def modulo(id_):
        # estado de uma caixa de módulo: {visivel, marcado, travado, fixo, nota}
        return pg.evaluate("""(id) => { const l = document.querySelector('#minPModulos .min-modulo[data-modulo="' + id + '"]');
          if (!l) return null; const c = l.querySelector('input'); const f = l.closest('.min-familia');
          return { visivel: !l.hidden && !f.hidden, marcado: c.checked, travado: c.disabled, fixo: l.classList.contains('fixo'), nota: l.querySelector('.min-modulo-nota').hidden ? '' : l.querySelector('.min-modulo-nota').textContent } }""", id_)
    def estado_rotulo():
        return pg.evaluate("document.getElementById('minDecisaoEstado').textContent")
    def minuta_guardada(link):
        # lê pela API a minuta que o link permanente aponta (título com o sufixo do estado)
        tok = pg.evaluate("localStorage.getItem('cn2o_token')")
        st, m = api('/hub/minutas/' + link.split('#minuta=')[1], token=tok)
        assert st == 200, (st, m)
        return m

    def gerador_cinco_entrevistas():
        abrir_gerador()
        assert pg.evaluate('location.hash') == '#minutas', pg.evaluate('location.hash')
        assert 'DECISÃO DO ROTEADOR' in pg.inner_text('#paginaMinutas .desc'), 'a descrição deve dizer que a saída começa pela decisão do roteador'
        assert pg.locator('#minAtos .min-ato').count() == 5, 'cinco atos'
        assert pg.locator('[data-min-chips="forma"] .ed-chip').count() == 4 and pg.evaluate("document.querySelector('[data-min-chips=\"forma\"] .ed-chip.ativo')") is None, 'FORMA_DO_ATO: quatro chips, nenhum pré-marcado'
        assert pg.locator('[data-min-multi="particularidades"] .ed-chip').count() == 4 and pg.locator('[data-min-multi="particularidades"] .ed-chip.ativo').count() == 0, 'PARTICULARIDADES: quatro chips de multi-seleção, nenhum pré-marcado'
        pg.click('[data-min-multi="particularidades"] [data-v="interprete"]'); pg.click('[data-min-multi="particularidades"] [data-v="gratuidade"]')
        assert pg.locator('[data-min-multi="particularidades"] .ed-chip.ativo').count() == 2, 'multi-seleção acumula'
        pg.click('[data-min-multi="particularidades"] [data-v="interprete"]')
        assert pg.evaluate("Array.from(document.querySelectorAll('[data-min-multi=\"particularidades\"] .ed-chip.ativo')).map(b => b.dataset.v)") == ['gratuidade'], 'clicar de novo desliga o chip'
        assert entrevistas_visiveis() == ['UE'], 'o padrão inicial é a união estável: %s' % entrevistas_visiveis()
        for ato in ['PROC', 'UE', 'DISS_UE', 'DIV', 'EMANC']:
            pg.click('.min-ato[data-ato="%s"]' % ato)
            assert entrevistas_visiveis() == [ato], 'só a entrevista de %s deveria aparecer: %s' % (ato, entrevistas_visiveis())
            assert pg.evaluate("document.querySelector('.min-ato.ativo').dataset.ato") == ato, 'botão do ato ativo'
            if ato == 'PROC':
                assert pg.locator('[data-min-chips="proc.finalidade"] .ed-chip').count() == 16, 'dezesseis finalidades (com tributária, empresarial e saúde)'
                assert not pg.is_visible('#minPModulosBox') and not pg.is_visible('#minPCpcBox'), 'os módulos só aparecem depois da finalidade'
                pg.click('[data-min-chips="proc.finalidade"] [data-v="ad_judicia"]')
                assert pg.is_visible('#minPModulosBox') and pg.is_visible('#minPCpcBox'), 'ad judicia mostra os módulos e o bloco do CPC 105'
                assert pg.locator('#minPCpc .min-poder:visible').count() == 10 and pg.is_visible('.min-poder[data-poder="assinar_declaracao_hipossuficiencia"]'), 'dez poderes do CPC 105'
                assert pg.evaluate("document.querySelectorAll('#minPCpc input:checked').length") == 0, 'todos os poderes do CPC nascem desligados'
                m = modulo('PROC.LEGAL.JUDICIAL')
                assert m['visivel'] and m['fixo'] and m['marcado'] and m['travado'] and 'incluso pela finalidade' in m['nota'], 'PROC.LEGAL.JUDICIAL é o módulo fixo do ad judicia: %s' % m
                assert modulo('PROC.LEGAL.HIRE_LAWYER')['visivel'] and not modulo('PROC.LEGAL.HIRE_LAWYER')['marcado'], 'opcional nasce desmarcado'
                assert not modulo('PROC.LEGAL.SETTLE')['visivel'] and not modulo('PROC.LEGAL.RECEIVE')['visivel'] and not modulo('PROC.LEGAL.QUIT')['visivel'], 'transigir/receber/quitar são poderes do CPC 105 aqui — os módulos só aparecem em "outra"'
                assert modulo('PROC.ADMIN')['visivel'] and modulo('PROC.BASE.ACCOUNTABILITY')['visivel'] and not modulo('PROC.ADMIN')['marcado'], 'PROC.ADMIN e PROC.BASE.ACCOUNTABILITY são transversais, desmarcados'
                assert not modulo('PROC.REAL_ESTATE.SELL')['visivel'] and not modulo('PROC.DISPOSITION.DONATE')['visivel'] and not modulo('PROC.WAIVER')['visivel'], 'vender imóvel, doar e renunciar não cabem no ad judicia'
                assert pg.evaluate("document.querySelectorAll('#minPModulos input:checked:not(:disabled)').length") == 0, 'nenhum opcional nasce marcado'
                assert 'texto livre não vale' in pg.inner_text('#minPModulosBox')
                assert 'PROC.LEGAL.JUDICIAL' in pg.inner_text('#minPModulos'), 'o ID exato da biblioteca aparece ao lado do rótulo'
                pg.click('[data-min-chips="proc.finalidade"] [data-v="imovel_vender"]')
                assert 'Matrícula e CRI' in pg.text_content('#minPObjetoRot'), pg.text_content('#minPObjetoRot')
                assert pg.is_visible('#minPAutoBox') and pg.is_visible('#minPPrecoBox') and pg.is_visible('#minPIrrevBox'), 'venda de imóvel pergunta autocontrato, preço e irrevogabilidade'
                assert not pg.is_visible('#minPCpcBox'), 'sem PROC.LEGAL.JUDICIAL não há bloco do CPC 105'
                assert 'sem cláusula na matriz' in modulo('PROC.SPECIAL.IRREVOCABLE')['nota'] and 'sem cláusula na matriz' in modulo('PROC.SPECIAL.IN_REM_SUAM')['nota'] and modulo('PROC.REAL_ESTATE.QUIT')['nota'] == '', 'os módulos sem cláusula na MATRIX 01 avisam ao lado do rótulo; os demais não'
                assert 'vão ao Tabelião' in pg.inner_text('#minPIrrevBox'), 'a nota da irrevogabilidade diz que o módulo vai ao Tabelião'
                # PROC.LEGAL.JUDICIAL opcional (administrar imóvel) liga o bloco do CPC 105; desmarcar zera e esconde
                pg.click('[data-min-chips="proc.finalidade"] [data-v="imovel_administrar"]')
                assert modulo('PROC.LEGAL.JUDICIAL')['visivel'] and not modulo('PROC.LEGAL.JUDICIAL')['marcado'] and not pg.is_visible('#minPCpcBox'), 'administrar imóvel: LEGAL.JUDICIAL opcional, CPC 105 escondido'
                assert not modulo('PROC.LEGAL.SETTLE')['visivel'] and not modulo('PROC.LEGAL.RECEIVE')['visivel'] and not modulo('PROC.LEGAL.QUIT')['visivel'], 'SETTLE/RECEIVE/QUIT não aparecem fora de "outra"'
                pg.check('#minPModulos .min-modulo[data-modulo="PROC.LEGAL.JUDICIAL"] input')
                assert pg.is_visible('#minPCpcBox'), 'marcar PROC.LEGAL.JUDICIAL abre o bloco do CPC 105'
                pg.check('#minPCpc .min-poder[data-poder="transigir"] input')
                pg.uncheck('#minPModulos .min-modulo[data-modulo="PROC.LEGAL.JUDICIAL"] input')
                assert not pg.is_visible('#minPCpcBox') and pg.evaluate("document.querySelectorAll('#minPCpc input:checked').length") == 0, 'desmarcar PROC.LEGAL.JUDICIAL zera e esconde o CPC 105'
                pg.click('[data-min-chips="proc.finalidade"] [data-v="imovel_vender"]')
                assert modulo('PROC.REAL_ESTATE.SELL')['fixo'] and modulo('PROC.SPECIAL.IRREVOCABLE')['visivel'] and not modulo('PROC.DISPOSITION.DONATE')['visivel'], 'venda: PROC.REAL_ESTATE.SELL fixo, irrevogável opcional, doar proibido'
                assert 'PROC.SPECIAL.IRREVOCABLE' in pg.inner_text('#minPIrrevBox'), 'a nota da irrevogabilidade cita o módulo'
                pg.click('[data-min-chips="proc.finalidade"] [data-v="veiculo_vender"]')
                assert modulo('PROC.VEHICLE.SELF_TRANSFER')['visivel'] and modulo('PROC.VEHICLE.SELF_TRANSFER')['travado'], 'transferir para si só com autocontrato = sim'
                pg.click('[data-min-chips="proc.autocontrato"] [data-v="sim"]')
                assert not modulo('PROC.VEHICLE.SELF_TRANSFER')['travado'], 'autocontrato sim destrava PROC.VEHICLE.SELF_TRANSFER'
                pg.click('[data-min-chips="proc.finalidade"] [data-v="casamento"]')
                assert pg.is_visible('#minPAvisoSemModulo') and 'DECISÃO DO TABELIÃO' in pg.inner_text('#minPAvisoSemModulo'), 'casamento avisa que não há módulo na matriz'
                assert not pg.is_visible('#minPModulosBox') and pg.is_visible('#minPPrazoNota'), 'casamento: sem módulos; nota do prazo legal'
                pg.click('[data-min-chips="proc.finalidade"] [data-v="outra"]')
                assert pg.evaluate("Array.from(document.querySelectorAll('#minPModulos .min-modulo')).filter(l => !l.hidden).length") == 44, 'outra: toda a biblioteca (44 módulos, com PROC.ADMIN e PROC.WAIVER)'
                assert pg.evaluate("Array.from(document.querySelectorAll('#minPModulos .min-familia')).filter(f => !f.hidden).length") == 13, 'treze famílias'
                assert modulo('PROC.WAIVER')['visivel'] and not modulo('PROC.WAIVER')['marcado'] and 'renunciar a direitos' in pg.inner_text('#minPModulos .min-modulo[data-modulo="PROC.WAIVER"]'), 'PROC.WAIVER (renunciar a direitos) só em "outra", desmarcado'
                for sem in ['PROC.SPECIAL.IRREVOCABLE', 'PROC.SPECIAL.IN_REM_SUAM', 'PROC.WAIVER', 'PROC.HEALTH.MEDICAL_CONSENT', 'PROC.LEGAL.SETTLE', 'PROC.LEGAL.RECEIVE', 'PROC.LEGAL.QUIT']:
                    assert modulo(sem)['visivel'] and 'sem cláusula na matriz — vai ao Tabelião' in modulo(sem)['nota'], sem + ' deveria avisar que não tem cláusula na matriz: %s' % modulo(sem)
                assert modulo('PROC.LEGAL.JUDICIAL')['nota'] == '' and modulo('PROC.ADMIN')['nota'] == '', 'módulos com cláusula não levam a nota'
                assert not pg.is_visible('#minPCpcBox')
                pg.check('#minPModulos .min-modulo[data-modulo="PROC.LEGAL.JUDICIAL"] input')
                assert pg.is_visible('#minPCpcBox'), 'em "outra", marcar PROC.LEGAL.JUDICIAL também abre o CPC 105'
                pg.uncheck('#minPModulos .min-modulo[data-modulo="PROC.LEGAL.JUDICIAL"] input')
                assert modulo('PROC.BANK.OPEN_ACCOUNT')['visivel'] and modulo('PROC.BANK.CLOSE_ACCOUNT')['visivel'] and modulo('PROC.BASE.ACCOUNTABILITY')['visivel'], 'IDs exatos da biblioteca (OPEN_ACCOUNT, CLOSE_ACCOUNT, BASE.ACCOUNTABILITY)'
                assert pg.evaluate("Array.from(document.querySelectorAll('#minPModulos .min-modulo')).filter(l => !l.hidden).every(l => l.dataset.modulo.startsWith('PROC.'))"), 'todo ID leva o prefixo PROC.'
                assert pg.locator('[data-min-chips="proc.substab"] .ed-chip').count() == 5 and pg.locator('[data-min-chips="proc.substab"] [data-v="com_ou_sem_reserva"]').count() == 1, 'substabelecimento: vedado, com reserva, sem reserva, com ou sem reserva, não informado'
                assert pg.is_visible('#minPAutoBox') and pg.is_visible('#minPPrecoBox') and pg.is_visible('#minPIrrevBox'), 'outra é finalidade de alienação: autocontrato, preço e irrevogabilidade'
                pg.click('[data-min-chips="proc.finalidade"] [data-v="inventario"]')
                assert not modulo('PROC.WAIVER')['visivel'] and modulo('PROC.ADMIN')['visivel'] and not modulo('PROC.LEGAL.SETTLE')['visivel'], 'PROC.WAIVER e PROC.LEGAL.SETTLE não aparecem fora de "outra"; PROC.ADMIN aparece'
                assert pg.is_visible('#minPAutoBox') and pg.is_visible('#minPPrecoBox') and pg.is_visible('#minPIrrevBox'), 'inventário é alienação: autocontrato, preço e irrevogabilidade'
                pg.click('[data-min-chips="proc.finalidade"] [data-v="imovel_comprar"]')
                assert pg.is_visible('#minPPrecoBox') and not pg.is_visible('#minPAutoBox') and not pg.is_visible('#minPIrrevBox'), 'comprar imóvel: só o preço (spec §2.1)'
                pg.click('[data-min-chips="proc.finalidade"] [data-v="imovel_vender"]')
                pg.click('[data-min-chips="proc.n_outorgados"] [data-v="2"]')
                assert pg.is_visible('#minPAtuacaoBox') and pg.is_visible('#minPDado2'), 'dois outorgados abrem a atuação'
                assert pg.locator('[data-min-chips="proc.atuacao"] .ed-chip').count() == 5, 'atuação: conjunta, separadamente, sucessivamente, por atribuições, não informado'
                pg.click('[data-min-chips="proc.atuacao"] [data-v="por_atribuicoes"]')
                assert pg.is_visible('#minPAtuacaoQuem'), 'por atribuições pede quem faz o quê'
                pg.click('[data-min-chips="proc.out1.civil"] [data-v="casado"]')
                assert pg.is_visible('#minPOutRegime1'), 'outorgante casado pergunta o regime'
            if ato == 'UE':
                pg.click('[data-min-chips="ue.titulo"] [data-v="escritura_anterior"]')
                assert pg.is_visible('#minLivroEBox') and pg.is_visible('#minTituloDados'), 'título anterior abre o Livro E'
                pg.click('[data-min-chips="ue.titulo"] [data-v="contrato_particular"]')
                assert pg.is_visible('#minTituloData') and not pg.is_visible('#minTituloDados'), 'contrato particular pede a data'
                pg.click('[data-min-chips="ue.titulo"] [data-v="decisao_judicial"]')
                assert pg.is_visible('#minTituloDados') and 'juízo' in pg.get_attribute('#minTituloDados', 'placeholder'), 'decisão judicial pede juízo, autos, data'
                pg.click('[data-min-chips="ue.titulo"] [data-v="nenhum"]')
                assert not pg.is_visible('#minLivroEBox')
                assert not pg.is_visible('#minAfastaBox')
                pg.click('[data-min-chips="ue.maior70"] [data-v="sim"]')
                assert pg.is_visible('#minMaior70Quem') and pg.is_visible('#minAfastaBox') and '1236' in pg.inner_text('#minAfastaBox'), 'maior de 70 abre o afastamento da separação obrigatória (STF, Tema 1236)'
                pg.click('[data-min-chips="ue.regime"] [data-v="pacto_anterior"]')
                assert pg.is_visible('#minRegimePacto'), 'pacto anterior pede instrumento, data, serventia'
                assert pg.locator('[data-min-chips="ue.interesse_livro_e"] .ed-chip').count() == 3, 'INTERESSE_LIVRO_E: sim, não, não informado'
                assert not pg.is_visible('#minUeAdvBox')
                pg.click('[data-min-chips="ue.adv"] [data-v="sim"]')
                assert pg.is_visible('#minUeAdvBox') and pg.locator('#minUeAdvBox input').count() == 2, 'advogado facultativo: nome + OAB'
            if ato == 'DISS_UE':
                pg.click('[data-min-chips="dss.filhos"] [data-v="incapazes"]')
                assert pg.is_visible('#minDsDecisaoBox'), 'filho incapaz pergunta a decisão judicial'
                assert 'fora do escopo' in pg.inner_text('[data-entrevista="DISS_UE"]')
                assert pg.evaluate("document.querySelector('[data-min-chips=\"dss.termino_modo\"] .ed-chip.ativo')") is None and not pg.is_visible('#minDsTermino'), 'DATA_TERMINO nasce sem escolha'
                pg.click('[data-min-chips="dss.termino_modo"] [data-v="data"]')
                assert pg.is_visible('#minDsTermino')
                pg.click('[data-min-chips="dss.titulo"] [data-v="decisao_judicial"]')
                assert pg.is_visible('#minDsTituloDados') and pg.is_visible('#minDsLivroEBox')
                assert pg.locator('[data-min-chips="dss.bens"] [data-v="sim_parcialmente_identificados"]').count() == 1 and pg.locator('[data-min-chips="dss.gravidez"] [data-v="nao_se_aplica"]').count() == 1
                pg.click('[data-min-chips="dss.regime"] [data-v="contrato"]')
                assert pg.is_visible('#minDsRegimeDados'), 'regime por contrato pede regime, instrumento, data'
                pg.click('[data-min-chips="dss.regime_alterado"] [data-v="sim"]')
                assert pg.is_visible('#minDsRegAltDados'), 'regime alterado pede novo regime, data, instrumento'
                assert pg.locator('[data-min-chips="dss.nome"] .ed-chip').count() == 4 and not pg.is_visible('#minDsNomeQuem')
                pg.click('[data-min-chips="dss.nome"] [data-v="mantem_nome_atual"]')
                assert pg.is_visible('#minDsNomeQuem'), 'mantém o nome atual pergunta quem'
                pg.click('[data-min-chips="dss.nome"] [data-v="nunca_alterado"]')
                assert not pg.is_visible('#minDsNomeQuem')
                pg.click('[data-min-chips="dss.adv"] [data-v="comum"]')
                assert pg.is_visible('#minDsAdvComumBox') and not pg.is_visible('#minDsAdvSepBox'), 'advogado comum: nome + OAB'
                pg.click('[data-min-chips="dss.adv"] [data-v="separados"]')
                assert pg.is_visible('#minDsAdvSepBox') and pg.locator('#minDsAdvSepBox input').count() == 4, 'separados: dois pares nome + OAB'
            if ato == 'DIV':
                assert pg.locator('[data-min-chips="div.bens"] [data-v="so_bens_particulares"]').count() == 1 and pg.locator('[data-min-chips="div.gravidez"] [data-v="nao_se_aplica"]').count() == 1
                for g in ['div.pacto', 'div.regime_alterado', 'div.separacao', 'div.processo']:
                    assert pg.evaluate("document.querySelector('[data-min-chips=\"%s\"] .ed-chip.ativo')" % g) is None, g + ' nasce sem escolha'
                pg.click('[data-min-chips="div.separacao"] [data-v="de_fato"]')
                assert pg.is_visible('#minDvSepDados') and 'desde' in pg.get_attribute('#minDvSepDados', 'placeholder')
                pg.click('[data-min-chips="div.processo"] [data-v="sim"]')
                assert pg.is_visible('#minDvProcessoDados')
                pg.click('[data-min-chips="div.nome"] [data-v="retoma_nome_de_solteiro"]')
                assert pg.is_visible('#minDvNomeQuem') and not pg.is_visible('#minDvNomeFinal1Box')
                pg.click('[data-min-chips="div.nome_quem"] [data-v="cônjuge 2"]')
                assert pg.is_visible('#minDvNomeFinal2Box') and not pg.is_visible('#minDvNomeFinal1Box'), 'só quem retoma informa o nome final'
                pg.click('[data-min-chips="div.adv"] [data-v="defensor_publico"]')
                assert pg.is_visible('#minDvDefNome') and not pg.is_visible('#minDvAdvComumBox')
                assert pg.is_visible('#minDvSolteiro1') and pg.is_visible('#minDvSolteiro2'), 'nome antes do casamento dos dois'
                pg.click('[data-min-multi="div.solteiro2"] [data-v="igual_ao_atual"]')
                assert not pg.is_visible('#minDvSolteiro2') and pg.is_visible('#minDvSolteiro1'), '"igual ao atual" dispensa o nome de solteiro'
                assert pg.locator('[data-min-chips="div.averbacao"] .ed-chip').count() == 3 and pg.evaluate("document.querySelector('[data-min-chips=\"div.averbacao\"] .ed-chip.ativo')") is None, 'AVERBACAO nasce sem escolha'
            if ato == 'EMANC':
                assert not pg.is_visible('#minEmMotivoBox')
                pg.click('[data-min-chips="em.quem"] [data-v="um_dos_pais"]')
                assert pg.is_visible('#minEmMotivoBox') and pg.is_visible('#minEmQual'), 'um dos pais pergunta o motivo'
                assert pg.is_visible('#minEmDomicilio'), 'domicílio do menor'
                assert pg.locator('[data-min-chips="em.participacao"] .ed-chip').count() == 4
                pg.click('[data-min-chips="em.repr_pais"] [data-v="por_procuracao"]')
                assert pg.is_visible('#minEmReprDados'), 'pais por procuração pedem os dados'
                assert pg.locator('[data-min-chips="em.situacao"] .ed-chip').count() == 6 and pg.evaluate("document.querySelector('[data-min-chips=\"em.situacao\"] .ed-chip.ativo')") is None, 'SITUACAO_DOS_PAIS: seis chips, nenhum pré-marcado'
            pg.screenshot(path=SHOTS + '/27-gerador-' + ato.lower() + '.png', full_page=True)
        pg.click('.min-ato[data-ato="UE"]')
    passo('Gerador de Minuta: cinco atos, cada um só com a sua entrevista; forma do ato e particularidades; módulos por finalidade com os IDs PROC.* (fixo travado, opcionais desmarcados, proibidos ausentes), CPC 105, condicionais novas', gerador_cinco_entrevistas)

    # ---------------- v1.30 · Gerador em fases (linha do tempo lateral) ----------------
    def fase_atual():
        return pg.evaluate("(() => { const b = document.querySelector('#minLtPassos .lt-passo.atual'); return b ? { i: +b.dataset.i, nome: b.querySelector('.lt-nome').textContent, falta: b.querySelector('.lt-falta').hidden ? '' : b.querySelector('.lt-falta').textContent } : null })()")
    def nomes_fases():
        return pg.evaluate("Array.from(document.querySelectorAll('#minLtPassos .lt-passo .lt-nome')).map(n => n.textContent)")
    TRILHO = {}
    def trilho_na_fase_atual():
        TRILHO['ultimo'] = pg.evaluate("(() => { const t = document.getElementById('minTrilho'); const f = t.querySelector('.min-fase.atual'); return { scrollLeft: t.scrollLeft, alvo: f.offsetLeft - parseFloat(getComputedStyle(t).paddingLeft), max: t.scrollWidth - t.clientWidth, fase: f.dataset.fase, scrollTop: t.scrollTop } })()")
        u = TRILHO['ultimo']
        return abs(u['scrollLeft'] - u['alvo']) < 2
    def gerador_fases():
        abrir_gerador()
        pg.click('.min-ato[data-ato="UE"]'); pg.click('#btnLimparMin')
        esperar(lambda: fase_atual() is not None and fase_atual()['i'] == 0, msg='fase 1')
        assert nomes_fases() == ['O ato', 'Documentos', 'Conviventes', 'A união', 'Nome e registro', 'Conferir e gerar'], nomes_fases()
        # só a fase atual fica à vista: a altura do trilho é a da fase atual (a página não cresce com as outras)
        alt = pg.evaluate("(() => { const t = document.getElementById('minTrilho'); const f = t.querySelector('.min-fase.atual'); return [parseFloat(t.style.height), f.offsetHeight] })()")
        assert abs(alt[0] - alt[1]) < 2, alt
        assert pg.evaluate("getComputedStyle(document.getElementById('minLinhaTempo')).position") == 'sticky', 'a linha do tempo fica presa no topo'
        # os botões dos atos maiores, com o nome em 18 px
        assert pg.evaluate("parseFloat(getComputedStyle(document.querySelector('.min-ato .rt-txt b')).fontSize)") >= 18, 'nome do ato em 18 px'
        assert pg.evaluate("document.querySelector('.min-ato').getBoundingClientRect().height") >= 80, 'botão do ato maior'
        # Próxima fase → anda para a direita: a fase 2 (documentos) marca "1" sem resposta (nenhum anexo)
        pg.click('#minTrilho .min-fase.atual .min-nav[data-nav="1"]')
        esperar(lambda: fase_atual()['i'] == 1, msg='fase 2')
        assert fase_atual()['nome'] == 'Documentos' and fase_atual()['falta'] == '1', fase_atual()
        esperar(trilho_na_fase_atual, msg='o trilho rolou até a fase 2: %r' % TRILHO.get('ultimo'))
        assert pg.evaluate("document.querySelector('#minTrilho .min-fase.atual .min-nav[data-nav=\"-1\"]').disabled") is False
        # a linha do tempo é clicável: direto à fase final, que tem o Gerar e não tem "Próxima"; a conferência lista o que ficou sem resposta, por fase, com atalho
        pg.click('#minLtPassos .lt-passo[data-i="5"]')
        esperar(lambda: fase_atual()['i'] == 5, msg='fase final')
        esperar(trilho_na_fase_atual, msg='o trilho rolou até a fase final: %r' % TRILHO.get('ultimo'))
        assert pg.is_visible('#btnGerarMinuta') and pg.locator('#minTrilho .min-fase.atual .min-nav[data-nav="1"]:visible').count() == 0, 'a fase final tem o Gerar e não tem Próxima'
        conf = pg.inner_text('#minConfLista')
        assert '2 · Documentos' in conf and 'nenhum documento anexado' in conf and '3 · Conviventes' in conf and 'Nome completo' in conf and 'Estado civil registral' in conf, conf
        assert '1 · O ato' in conf and 'Forma do ato' in conf, conf
        assert pg.evaluate("parseFloat(getComputedStyle(document.querySelector('#minConfLista li')).fontSize)") >= 18, 'conferência em 18 px'
        assert not pg.is_visible('#minConfOk') and 'sem resposta' in pg.inner_text('#minConfResumo').lower(), pg.inner_text('#minConfResumo')
        pg.locator('#minConfLista li', has_text='3 · Conviventes').locator('.mc-ir').click()
        esperar(lambda: fase_atual()['i'] == 2, msg='"ir à fase" leva à fase 3')
        # respondido some da conferência e da linha do tempo
        pg.fill('#minC1Nome', 'Fulana de Tal'); pg.fill('#minC2Nome', 'Beltrano de Tal')
        pg.click('[data-min-chips="ue.c1civil"] [data-v="solteiro"]'); pg.click('[data-min-chips="ue.c2civil"] [data-v="solteiro"]')
        esperar(lambda: pg.evaluate("document.querySelector(\"#minLtPassos .lt-passo[data-i='2'] .lt-falta\").hidden"), msg='fase 3 sem pendência')
        assert '3 · Conviventes' not in pg.inner_text('#minConfLista')
        # Gerar com um nome faltando: o aviso leva à fase do campo que falta e nada é enviado
        pg.fill('#minC2Nome', '')
        pg.click('#minLtPassos .lt-passo[data-i="5"]'); esperar(lambda: fase_atual()['i'] == 5)
        antes = len(chamadas())
        pg.click('#btnGerarMinuta'); pg.wait_for_selector('#toast:not([hidden])')
        assert 'dois conviventes' in pg.inner_text('#toast')
        esperar(lambda: fase_atual()['i'] == 2, msg='a validação leva à fase dos conviventes')
        esperar(lambda: pg.evaluate("document.activeElement ? document.activeElement.id : ''") == 'minC2Nome', msg='o campo que falta recebe o foco')
        assert len(chamadas()) == antes
        pg.fill('#minC2Nome', 'Beltrano de Tal')
        # trocar de ato refaz a linha do tempo (as fases do ato aberto)
        pg.click('#minLtPassos .lt-passo[data-i="0"]'); esperar(lambda: fase_atual()['i'] == 0)
        pg.click('.min-ato[data-ato="PROC"]')
        assert nomes_fases() == ['O ato', 'Documentos', 'Finalidade', 'Outorgantes', 'Outorgados', 'Objeto e poderes', 'Condições', 'Conferir e gerar'], nomes_fases()
        for ato, n in [('DISS_UE', 7), ('DIV', 8), ('EMANC', 6), ('UE', 6)]:
            pg.click('.min-ato[data-ato="%s"]' % ato)
            assert len(nomes_fases()) == n and fase_atual()['i'] == 0, (ato, nomes_fases(), fase_atual())
        assert pg.evaluate("Array.from(document.querySelectorAll('#minTrilho .min-fase')).filter(f => !f.closest('[hidden]')).length") == 6
        assert pg.evaluate("Array.from(document.querySelectorAll('#minTrilho .min-fase-num')).filter(n => !n.closest('[hidden]')).map(n => n.textContent)") == ['1', '2', '3', '4', '5', '6'], 'numeração das fases'
        # Alt+→ anda uma fase; Limpar volta à primeira
        pg.keyboard.press('Alt+ArrowRight'); esperar(lambda: fase_atual()['i'] == 1, msg='Alt+→ (ativo: %s)' % pg.evaluate("document.activeElement.tagName + '#' + document.activeElement.id + '.' + document.activeElement.className"))
        pg.click('#btnLimparMin'); esperar(lambda: fase_atual()['i'] == 0, msg='Limpar volta à fase 1')
        # a espera da IA (transposição, minuta e as outras ferramentas): relógio que gira + barra + tempo
        html = pg.evaluate("htmlProgresso('Lendo 1 documento', 7)")
        assert '🕗' in html and 'pi-barra' in html and 'class="giro"' in html and '7 s' in html and 'Lendo 1 documento' in html, html
        assert pg.evaluate("htmlProgresso('x', 12)").count('🕐') == 1, 'o relógio dá a volta a cada 12 s'
    passo('Gerador v1.30 — fases lado a lado: linha do tempo por ato (6/8/7/8/6 fases), Próxima/Anterior, atalho da linha, conferência por fase com "ir à fase" (18 px), validação leva ao campo, Alt+→, Limpar volta à fase 1, botões dos atos em 18 px, espera com relógio e barra', gerador_fases)

    def gerador_ue_fluxo_completo():
        import io as _io
        from PIL import Image as _Img
        def jpg(l, cor):
            b = _io.BytesIO(); _Img.new('RGB', (l, l), cor).save(b, 'JPEG', quality=85); return b.getvalue()
        abrir_gerador()
        pg.click('.min-ato[data-ato="UE"]')
        pg.click('[data-min-chips="forma"] [data-v="presencial"]')
        pg.click('#btnLimparMin')   # zera o que o passo anterior mexeu na entrevista da UE (e a forma do ato)
        assert not pg.is_visible('#minMaior70Quem') and pg.evaluate("document.querySelector('[data-min-chips=\"ue.regime\"] .ed-chip.ativo')") is None, 'Limpar volta aos padrões: regime sem escolha (UNKNOWN não é comunhão parcial)'
        assert pg.evaluate("document.querySelector('[data-min-chips=\"forma\"] .ed-chip.ativo')") is None and pg.locator('[data-min-multi="particularidades"] .ed-chip.ativo').count() == 0, 'Limpar zera a forma do ato e as particularidades'
        pg.click('[data-min-chips="forma"] [data-v="presencial"]')
        pg.click('[data-min-multi="particularidades"] [data-v="parte_estrangeira"]'); pg.click('[data-min-multi="particularidades"] [data-v="interprete"]')
        pg.fill('#minC1Nome', 'Fulana de Tal'); pg.fill('#minC1Cpf', '054.318.276-90')
        pg.fill('#minC2Nome', 'Beltrano de Tal')
        pg.click('[data-min-chips="ue.c1civil"] [data-v="solteiro"]')
        pg.click('[data-min-chips="ue.c2civil"] [data-v="divorciado"]')
        pg.fill('#minEndereco', 'Rua Boanerges Pinheiro, 214, Centro, Itabaiana/SE')
        pg.fill('#minInicio', '2021-05-10')
        pg.click('[data-min-chips="ue.regime"] [data-v="legal_comunhao_parcial"]')  # o regime nunca vem pré-marcado: a escrevente escolhe
        pg.click('[data-min-chips="ue.filhos"] [data-v="sim"]')
        assert pg.locator('#minFilhosBox:visible').count() == 1, 'campo de filhos deveria abrir'
        pg.fill('#minFilhos', 'Maria (12/03/2022)')
        pg.click('[data-min-chips="ue.nome"] [data-v="convivente_1_acrescenta"]')
        assert pg.locator('#minNome1Box:visible').count() == 1, 'campo do nome novo deveria abrir'
        assert pg.locator('#minAvisoLivroE:visible').count() == 1, 'aviso do Livro E deveria aparecer'
        assert 'Livro E' in pg.inner_text('#minAvisoLivroE')
        pg.fill('#minNome1', 'Fulana de Tal Silva')
        pg.click('[data-min-chips="ue.interesse_livro_e"] [data-v="sim"]')
        pg.click('[data-min-chips="ue.adv"] [data-v="nao"]')
        pg.set_input_files('#paginaMinutas .zona-anexos input[type=file]', files=[{'name': 'certidao.jpg', 'mimeType': 'image/jpeg', 'buffer': jpg(900, (200, 190, 170))}])
        esperar(lambda: pg.locator('#paginaMinutas .anexo-item').count() == 1, msg='anexo listado')
        pg.click('#btnGerarMinuta')
        pg.wait_for_selector('#saidaMinuta:not(.vazia)')
        esperar(lambda: pg.is_visible('#minDecisao') and 'PRONTA PARA MINUTA' in pg.inner_text('#minDecisao'), seg=20, msg='quadro da decisão do roteador')
        assert 'DECISÃO DO ROTEADOR' in pg.inner_text('#minDecisao')
        assert estado_rotulo() == 'PRONTA PARA MINUTA', 'o rótulo é só o nome em português: ' + estado_rotulo()
        assert not pg.is_visible('#minDevolvida') and not pg.is_visible('#minPendencias') and not pg.is_visible('#minPreliminarFaixa'), 'minuta pronta não devolve a qualificação nem traz pendências'
        assert not pg.evaluate("document.getElementById('minDecisao').classList.contains('preliminar') || document.getElementById('minDecisao').classList.contains('bloqueada')")
        texto = pg.inner_text('#saidaMinuta')
        assert 'UNIÃO ESTÁVEL' in texto and 'Livro E' in texto, 'minuta sem a ressalva do Livro E'
        assert '— MINUTA —' in texto and '===MINUTA_COPIAVEL===' not in texto and '===FIM_MINUTA===' not in texto, 'os marcadores não podem aparecer na tela'
        assert '⚠ CONFERIR' in texto and 'rascunho' in texto, 'o ⚠ CONFERIR e o rodapé seguem visíveis'
        assert 'DECISÃO DO ROTEADOR' not in texto, 'a decisão fica no quadro próprio, não repetida na saída'
        assert '[LAVRATURA: livro]' in texto, 'placeholders de lavratura ficam na minuta (não são pendência)'
        assert pg.is_visible('#btnCopiarMin'), 'o botão Copiar aparece quando há minuta'
        esperar(lambda: pg.locator('#minutaLinkBox:visible').count() == 1, msg='link permanente aparecer')
        link = pg.evaluate("document.getElementById('minutaLinkA').textContent")
        assert '#minuta=' in link, link
        assert minuta_guardada(link)['titulo'] == 'UE — Fulana de Tal e Beltrano de Tal', 'PRONTA não leva sufixo no título guardado'
        # o botão Copiar leva só a minuta (sem decisão e sem ⚠ CONFERIR); ela começa pelo título nu
        pg.click('#btnCopiarMin')
        pg.wait_for_selector('#toast:not([hidden])')
        copiado = pg.evaluate("navigator.clipboard.readText().then(t => t || MINUTA_COPIAVEL).catch(() => MINUTA_COPIAVEL)")
        assert copiado.startswith('ESCRITURA PÚBLICA DE DECLARAÇÃO DE UNIÃO ESTÁVEL') and 'CONFERIR' not in copiado and 'ROTEADOR' not in copiado and '— MINUTA —' not in copiado, copiado[:120]
        # a ficha enviada ao servidor segue o contrato da spec §2.2 (e é a mesma de #minPedido)
        ch = chamadas()[-1]
        obs = ch['observacoes']
        assert 'ENTREVISTA DIRIGIDA — GERADOR DE MINUTA' in obs
        ficha = ficha_enviada()
        # com anexo, o servidor acrescenta a === LEITURA OCR DEDICADA === depois da ficha: a ficha é o prefixo
        assert ficha.startswith(pg.evaluate("document.getElementById('minPedido').value").strip()), '#minPedido guarda exatamente a ficha enviada'
        # v1.29 — QUALIFICACAO_CONVIVENTE_1/2 sempre presentes, logo após a linha da pessoa (spec §2.2), nao_informado quando vazias
        assert ficha.startswith('=== ENTREVISTA DIRIGIDA — GERADOR DE MINUTA ===\nATO: UE\nFORMA_DO_ATO: presencial\nPARTICULARIDADES: parte_estrangeira, interprete\nCONVIVENTE_1: Fulana de Tal · solteiro · CPF 054.318.276-90\nQUALIFICACAO_CONVIVENTE_1: nao_informado\nCONVIVENTE_2: Beltrano de Tal · divorciado\nQUALIFICACAO_CONVIVENTE_2: nao_informado\nINICIO_CONVIVENCIA: 10/05/2021\nREGIME: legal_comunhao_parcial\nMAIOR_70: nao_informado\nAFASTA_SEPARACAO_OBRIGATORIA: nao_se_aplica\nFILHOS: sim: Maria (12/03/2022)\nNOME: convivente_1_acrescenta: Fulana de Tal Silva\nTITULO_ANTERIOR: nao_informado\nLIVRO_E: nao_informado\nINTERESSE_LIVRO_E: sim\nENDERECO_COMUM: Rua Boanerges Pinheiro, 214, Centro, Itabaiana/SE\nADVOGADO_FACULTATIVO: nao\nOBSERVACOES: nao_informado'), 'ficha UE fora da ordem/valores da spec §2.2:\n' + ficha
        assert ch['arquivos'] and ch['arquivos'][0]['mime'] == 'image/jpeg'
        # link permanente abre o resultado guardado, pelo mesmo processar
        # (goto só do #hash não recarrega a página — o reload garante que a minuta venha do servidor, não da tela)
        pg.goto(link); pg.reload(); pg.wait_for_selector('#paginaMinutas:not([hidden])')
        esperar(lambda: 'guardada por' in pg.inner_text('#metaMin'), msg='minuta pelo link (meta "guardada por")')
        assert 'UNIÃO ESTÁVEL' in pg.inner_text('#saidaMinuta'), 'minuta pelo link'
        assert pg.is_visible('#minDecisao') and 'PRONTA PARA MINUTA' in pg.inner_text('#minDecisao'), 'o link reabre com o quadro da decisão'
        assert pg.is_visible('#btnCopiarMin')
        pg.goto(SITE); pg.wait_for_selector('#app:not([hidden])')
    passo('Gerador de Minuta — UE: entrevista + anexo → PRONTA, minuta com Livro E e placeholders de lavratura, Copiar só a minuta (título nu), ficha §2.2 com PARTICULARIDADES, AFASTA_SEPARACAO_OBRIGATORIA, INTERESSE_LIVRO_E e ADVOGADO_FACULTATIVO, link permanente que reabre', gerador_ue_fluxo_completo)

    def gerador_div_partilha_fora_do_escopo():
        abrir_gerador()
        pg.click('.min-ato[data-ato="DIV"]'); pg.click('#btnLimparMin')
        pg.fill('#minDvC1Nome', 'Fulana de Tal'); pg.fill('#minDvC2Nome', 'Beltrano de Tal')
        pg.fill('#minDvCasData', '2010-10-10'); pg.fill('#minDvCasServ', 'RCPN de Itabaiana/SE'); pg.fill('#minDvCasMatr', '1234')
        pg.click('[data-min-chips="div.regime"] [data-v="comunhão parcial de bens"]')
        pg.click('[data-min-chips="div.pacto"] [data-v="sim"]'); pg.fill('#minDvPactoDados', 'CN2O, livro 12, fls. 34, 01/09/2010')
        pg.click('[data-min-chips="div.bens"] [data-v="sim"]')
        pg.click('[data-min-chips="div.partilha"] [data-v="agora"]')
        pg.click('[data-min-chips="div.filhos"] [data-v="nenhum"]')
        pg.click('[data-min-chips="div.nome"] [data-v="retoma_nome_de_solteiro"]')
        pg.click('[data-min-chips="div.nome_quem"] [data-v="ambos"]')
        pg.fill('#minDvNomeFinal1', 'Fulana Souza'); pg.fill('#minDvNomeFinal2', 'Beltrano Lima')
        pg.fill('#minDvSolteiro1', 'Fulana Souza'); pg.click('[data-min-multi="div.solteiro2"] [data-v="igual_ao_atual"]')
        pg.click('[data-min-chips="div.averbacao"] [data-v="pelas_partes"]')
        pg.click('[data-min-chips="div.adv"] [data-v="comum"]'); pg.fill('#minDvAdvNome', 'Sicrana de Tal'); pg.fill('#minDvAdvOab', 'OAB/SE 1234')
        pg.fill('#minObs', 'querem dividir a casa nesta escritura')
        pg.click('#btnGerarMinuta')
        esperar(lambda: pg.is_visible('#minDecisao') and 'FORA DO ESCOPO' in pg.inner_text('#minDecisao'), seg=20, msg='fora do escopo no quadro')
        quadro = pg.inner_text('#minDecisao')
        assert 'QUALIFICAÇÃO DEVOLVIDA' in quadro and 'O que destravaria' in quadro, quadro
        assert estado_rotulo() == 'FORA DO ESCOPO', estado_rotulo()
        assert pg.evaluate("document.getElementById('minDecisao').classList.contains('bloqueada')"), 'quadro em vinho quando fora do escopo'
        assert not pg.is_visible('#btnCopiarMin'), 'sem minuta não há o que copiar'
        saida = pg.inner_text('#saidaMinuta')
        assert '⚠ CONFERIR' in saida and '[PARTITION_EFFECT]' in saida and 'MINUTA_COPIAVEL' not in saida, saida
        ficha = ficha_enviada()
        assert 'ATO: DIV' in ficha and 'PARTILHA: agora' in ficha and 'BENS_COMUNS: sim' in ficha, ficha
        assert 'CASAMENTO: 10/10/2010 · RCPN de Itabaiana/SE · matrícula 1234 · certidão emitida em nao_informado' in ficha, ficha
        assert 'PACTO_ANTENUPCIAL: sim: CN2O, livro 12, fls. 34, 01/09/2010\nREGIME_ALTERADO: nao_informado\nSEPARACAO_ANTERIOR: nao_informado\nBENS_COMUNS: sim' in ficha, ficha
        assert 'DECISAO_JUDICIAL_FILHOS: nao_se_aplica' in ficha, ficha
        assert 'PENSAO_ENTRE_CONJUGES: nao_informado\nNOME_SOLTEIRO_1: Fulana Souza\nNOME_SOLTEIRO_2: igual_ao_atual\nNOME: retoma_nome_de_solteiro: ambos\nNOME_FINAL_1: Fulana Souza\nNOME_FINAL_2: Beltrano Lima\nADVOGADO: comum: Sicrana de Tal · OAB/SE 1234\nPROCESSO_JUDICIAL: nao_informado\nAVERBACAO: pelas_partes\nREPRESENTACAO: nao_informado\nOBSERVACOES: querem dividir a casa nesta escritura' in ficha, ficha
        esperar(lambda: pg.locator('#minutaLinkBox:visible').count() == 1, msg='o resultado bloqueado também ganha link')
        link = pg.evaluate("document.getElementById('minutaLinkA').textContent")
        assert minuta_guardada(link)['titulo'].endswith(' · FORA DO ESCOPO'), 'título guardado com o sufixo do estado'
    passo('Gerador de Minuta — DIV com partilha agora: FORA DO ESCOPO, qualificação devolvida ao Tabelião, sem botão Copiar; ficha §2.4 com pacto, nomes de solteiro, nomes finais, advogado e averbação', gerador_div_partilha_fora_do_escopo)

    def gerador_emanc_bloqueada():
        abrir_gerador()
        pg.click('.min-ato[data-ato="EMANC"]'); pg.click('#btnLimparMin')
        assert not pg.is_visible('#minDecisao') and not pg.is_visible('#minutaLinkBox'), 'Limpar esconde a decisão e o link anteriores'
        pg.fill('#minEmNome', 'Menino de Tal'); pg.fill('#minEmNasc', '2010-03-01'); pg.fill('#minEmDomicilio', 'Itabaiana/SE')
        pg.click('[data-min-chips="em.quem"] [data-v="um_dos_pais"]')
        pg.click('[data-min-chips="em.qual"] [data-v="mãe"]')
        pg.click('[data-min-chips="em.motivo"] [data-v="outro_discorda"]')
        pg.click('[data-min-chips="em.situacao"] [data-v="separados"]')
        pg.click('[data-min-chips="em.guarda"] [data-v="unilateral"]')
        pg.click('[data-min-chips="em.guarda_quem"] [data-v="mãe"]')
        pg.click('[data-min-chips="em.participacao"] [data-v="comparece_e_assina"]')
        pg.click('#btnGerarMinuta')
        esperar(lambda: pg.is_visible('#minDecisao') and 'BLOQUEADA' in pg.inner_text('#minDecisao'), seg=20, msg='bloqueio no quadro')
        tela = pg.inner_text('#paginaMinutas')
        assert '[HARD_BLOCKER]' in tela and 'QUALIFICAÇÃO DEVOLVIDA' in tela, tela[-800:]
        assert estado_rotulo() == 'BLOQUEADA', estado_rotulo()
        assert not pg.is_visible('#btnCopiarMin'), 'bloqueada não tem minuta para copiar'
        ficha = ficha_enviada()
        assert 'ATO: EMANC' in ficha and 'QUEM_OUTORGA: um_dos_pais: mãe' in ficha and 'MOTIVO_UM_SO: outro_discorda' in ficha and 'GUARDA: unilateral: mãe' in ficha, ficha
        assert 'MENOR: Menino de Tal · nascido em 01/03/2010 · domicílio: Itabaiana/SE' in ficha, ficha
        # v1.29 — QUALIFICACAO_MENOR, CERTIDAO_NASCIMENTO, PAI e MAE entre MENOR e QUEM_OUTORGA (spec §2.5)
        assert 'ATO: EMANC\nFORMA_DO_ATO: nao_informado\nPARTICULARIDADES: nenhuma\nMENOR: Menino de Tal · nascido em 01/03/2010 · domicílio: Itabaiana/SE\nQUALIFICACAO_MENOR: nao_informado\nCERTIDAO_NASCIMENTO: nao_informado\nPAI: nao_informado\nMAE: nao_informado\nQUEM_OUTORGA: um_dos_pais: mãe\nMOTIVO_UM_SO: outro_discorda\nSITUACAO_DOS_PAIS: separados\nGUARDA: unilateral: mãe\nPARTICIPACAO_DO_MENOR: comparece_e_assina\nREPRESENTACAO_DOS_PAIS: nao_informado\nEMANCIPACAO_ANTERIOR: nao_informado\nFINALIDADE: nao_informado\nOBSERVACOES: nao_informado' in ficha, 'ficha EMANC fora da ordem/valores da spec §2.5:\n' + ficha
        pg.screenshot(path=SHOTS + '/27-gerador-bloqueada.png', full_page=True)
        # tutor: emancipação judicial ⇒ FORA DO ESCOPO (a tela já avisa antes de gerar)
        esperar(lambda: pg.locator('#minutaLinkBox:visible').count() == 1, msg='link permanente (bloqueada)')
        link_antes = pg.evaluate("document.getElementById('minutaLinkA').textContent")
        pg.click('[data-min-chips="em.quem"] [data-v="tutor"]')
        assert pg.is_visible('#minEmAvisoTutor') and not pg.is_visible('#minEmMotivoBox'), 'tutor: aviso de que a emancipação é judicial'
        pg.click('#btnGerarMinuta')
        esperar(lambda: pg.is_visible('#minDecisao') and 'FORA DO ESCOPO' in pg.inner_text('#minDecisao'), seg=20, msg='fora do escopo no quadro (tutor)')
        assert estado_rotulo() == 'FORA DO ESCOPO', estado_rotulo()
        assert pg.evaluate("document.getElementById('minDecisao').classList.contains('bloqueada')") and not pg.is_visible('#btnCopiarMin'), 'tutor: quadro vinho, sem Copiar'
        assert 'tutela' in pg.inner_text('#minDevolvidaTexto'), pg.inner_text('#minDevolvidaTexto')
        ficha = ficha_enviada()
        assert 'QUEM_OUTORGA: tutor\nMOTIVO_UM_SO: nao_informado\nSITUACAO_DOS_PAIS: separados' in ficha, ficha
        esperar(lambda: pg.locator('#minutaLinkBox:visible').count() == 1 and pg.evaluate("document.getElementById('minutaLinkA').textContent") != link_antes, msg='link permanente (tutor)')
        assert minuta_guardada(pg.evaluate("document.getElementById('minutaLinkA').textContent"))['titulo'].endswith(' · FORA DO ESCOPO')
    passo('Gerador de Minuta — EMANC: um dos pais com o outro discordando → BLOQUEADA com [HARD_BLOCKER]; por tutor → FORA DO ESCOPO; sem botão Copiar; ficha §2.5 com domicílio, situação dos pais e participação', gerador_emanc_bloqueada)

    def gerador_proc_veiculo():
        import re as _re
        abrir_gerador()
        pg.click('.min-ato[data-ato="PROC"]'); pg.click('#btnLimparMin')
        pg.click('[data-min-chips="forma"] [data-v="eletronico"]')
        pg.click('[data-min-chips="proc.finalidade"] [data-v="veiculo_regularizar"]')
        assert 'Placa / RENAVAM' in pg.text_content('#minPObjetoRot'), 'o rótulo do objeto segue a finalidade: ' + pg.text_content('#minPObjetoRot')
        m = modulo('PROC.VEHICLE.REGULARIZE')
        assert m['visivel'] and m['fixo'] and m['marcado'] and m['travado'], 'PROC.VEHICLE.REGULARIZE é o módulo fixo: %s' % m
        assert not modulo('PROC.VEHICLE.TRANSFER')['visivel'] and not modulo('PROC.VEHICLE.SELF_TRANSFER')['visivel'] and not modulo('PROC.VEHICLE.RECEIVE_PRICE')['visivel'], 'regularizar veículo não oferece transferir/vender (proibidos na rota)'
        assert modulo('PROC.ADMIN')['visivel'] and not modulo('PROC.ADMIN')['marcado'], 'PROC.ADMIN é opcional, desmarcado'
        assert not pg.is_visible('#minPIrrevBox') and not pg.is_visible('#minPAutoBox'), 'regularizar não é alienação: sem irrevogabilidade nem autocontrato'
        pg.fill('#minPFinDesc', 'passar o carro para o nome dele')
        pg.fill('#minPOutNome1', 'José Raimundo Santos Bispo')
        pg.click('[data-min-chips="proc.out1.civil"] [data-v="solteiro"]')
        pg.fill('#minPDadoNome1', 'Marcos Bispo Santos'); pg.fill('#minPDadoVinc1', 'filho')
        pg.fill('#minPObjeto', 'placa ABC1D23')
        pg.check('#minPModulos .min-modulo[data-modulo="PROC.TAX.ADMIN"] input')
        pg.click('[data-min-chips="proc.prazo"] [data-v="indeterminado"]')
        pg.click('[data-min-chips="proc.substab"] [data-v="vedado"]')
        assert pg.evaluate("document.querySelectorAll('#minPModulos input:checked:not(:disabled)').length") == 1, 'só PROC.TAX.ADMIN marcado pela escrevente'
        pg.click('#btnGerarMinuta')
        esperar(lambda: pg.is_visible('#minDecisao') and 'PROC.VEICULO.REGULARIZE' in pg.inner_text('#minDecisao'), seg=20, msg='variante no quadro')
        assert 'PROC.VEICULO.REGULARIZE' in pg.inner_text('#paginaMinutas')
        assert estado_rotulo() == 'PRONTA PARA MINUTA' and not pg.is_visible('#minPreliminarFaixa'), estado_rotulo()
        assert 'Módulos autorizados: PROC.VEHICLE.REGULARIZE, PROC.TAX.ADMIN' in pg.inner_text('#minDecisaoTexto'), pg.inner_text('#minDecisaoTexto')
        assert pg.evaluate("Array.from(document.querySelectorAll('#minDecisaoTexto .md-linha b')).map(b => b.textContent)")[:4] == ['Ato:', 'Especialista:', 'Rota:', 'Módulos autorizados:'], 'Rota e Módulos autorizados viram linhas com a chave em negrito'
        assert pg.is_visible('#btnCopiarMin')
        ficha = ficha_enviada()
        assert ficha.strip() == pg.evaluate("document.getElementById('minPedido').value").strip(), '#minPedido guarda exatamente a ficha enviada'
        assert 'ATO: PROC\nFORMA_DO_ATO: eletronico\nPARTICULARIDADES: nenhuma\nFINALIDADE: veiculo_regularizar' in ficha, ficha
        assert not _re.search(r'^PODERES_ALTO_RISCO:', ficha, _re.M), 'PODERES_ALTO_RISCO deixou de existir'
        # v1.29 — QUALIFICACAO_OUTORGANTE_i / QUALIFICACAO_OUTORGADO_i logo após cada pessoa (spec §2.1)
        assert 'OUTORGANTES: 1\nOUTORGANTE_1: José Raimundo Santos Bispo · PF · solteiro · capaz\nQUALIFICACAO_OUTORGANTE_1: nao_informado\nOUTORGADOS: 1\n' in ficha, ficha
        assert 'OUTORGADO_1: Marcos Bispo Santos · filho\nQUALIFICACAO_OUTORGADO_1: nao_informado\nATUACAO: nao_informado\nOBJETO: placa ABC1D23\nMODULOS_AUTORIZADOS: PROC.VEHICLE.REGULARIZE, PROC.TAX.ADMIN\nPODERES_CPC_105: nao_se_aplica\nAUTOCONTRATO: nao_informado\nPRECO: nao_se_aplica\nPRAZO: indeterminado\nSUBSTABELECIMENTO: vedado\nIRREVOGABILIDADE: nao_informado\nOBSERVACOES: nao_informado' in ficha, 'ficha PROC fora da ordem/valores da spec §2.1:\n' + ficha
        assert ficha.rstrip().endswith('OBSERVACOES: nao_informado'), 'OBSERVACOES é a última chave'
        esperar(lambda: pg.locator('#minutaLinkBox:visible').count() == 1, msg='link permanente da PRONTA')
    passo('Gerador de Minuta — PROC regularizar veículo: módulo fixo PROC.VEHICLE.REGULARIZE + opcional PROC.TAX.ADMIN em MODULOS_AUTORIZADOS, FORMA_DO_ATO, PODERES_CPC_105 e IRREVOGABILIDADE na ficha; PRONTA', gerador_proc_veiculo)

    def gerador_proc_preliminar():
        # (a) SUBSTABELECIMENTO não informado ⇒ PRELIMINAR COM PENDÊNCIAS: minuta com [FALTA],
        # faixa "não apta à assinatura", Copiar visível, bloco PENDÊNCIAS no quadro
        abrir_gerador()
        pg.click('.min-ato[data-ato="PROC"]')
        link_antes = pg.evaluate("document.getElementById('minutaLinkA').textContent")
        pg.click('[data-min-chips="proc.substab"] [data-v="nao_informado"]')
        pg.click('#btnGerarMinuta')
        esperar(lambda: pg.is_visible('#minDecisao') and 'PRELIMINAR' in pg.inner_text('#minDecisao'), seg=20, msg='preliminar no quadro')
        assert estado_rotulo() == 'PRELIMINAR COM PENDÊNCIAS', estado_rotulo()
        assert pg.evaluate("document.getElementById('minDecisao').classList.contains('preliminar') && !document.getElementById('minDecisao').classList.contains('bloqueada')"), 'quadro .preliminar (marinho), não .bloqueada'
        assert pg.is_visible('#minPreliminarFaixa'), 'faixa da preliminar'
        faixa = pg.inner_text('#minPreliminarFaixa')
        assert 'não apta à assinatura' in faixa and '1 pendência(s)' in faixa, faixa
        assert pg.is_visible('#btnCopiarMin'), 'a preliminar pode ser copiada (minuta de trabalho)'
        assert pg.is_visible('#minPendencias') and 'PENDÊNCIAS' in pg.inner_text('#minPendencias') and 'SUBSTABELECIMENTO' in pg.inner_text('#minPendenciasTexto'), pg.inner_text('#minPendencias')
        assert pg.evaluate("document.querySelector('#minPendenciasTexto .md-pend b').textContent") == 'B1 · SUBSTABELECIMENTO', 'nível e chave da pendência em negrito'
        assert not pg.is_visible('#minDevolvida'), 'preliminar não devolve a qualificação'
        saida = pg.inner_text('#saidaMinuta')
        assert '— MINUTA PRELIMINAR (não apta à assinatura) —' in saida and '[FALTA: substabelecimento' in saida and '⚠ CONFERIR' in saida, saida[:400]
        assert '\nPENDÊNCIAS\n' not in saida, 'a seção PENDÊNCIAS fica no quadro, não repetida na saída'
        pg.click('#btnCopiarMin'); pg.wait_for_selector('#toast:not([hidden])')
        copiado = pg.evaluate("navigator.clipboard.readText().then(t => t || MINUTA_COPIAVEL).catch(() => MINUTA_COPIAVEL)")
        assert copiado.startswith('PROCURAÇÃO PÚBLICA') and '[FALTA: substabelecimento' in copiado and 'PENDÊNCIAS' not in copiado, copiado[:160]
        assert 'SUBSTABELECIMENTO: nao_informado' in ficha_enviada()
        esperar(lambda: pg.locator('#minutaLinkBox:visible').count() == 1 and pg.evaluate("document.getElementById('minutaLinkA').textContent") != link_antes, msg='link permanente da preliminar')
        link = pg.evaluate("document.getElementById('minutaLinkA').textContent")
        assert minuta_guardada(link)['titulo'].endswith(' · PRELIMINAR'), 'título guardado com o sufixo PRELIMINAR'
        pg.screenshot(path=SHOTS + '/27-gerador-preliminar.png', full_page=True)
        # o link permanente reabre a preliminar com o mesmo quadro (faixa + pendências)
        pg.goto(link); pg.reload(); pg.wait_for_selector('#paginaMinutas:not([hidden])')
        esperar(lambda: 'guardada por' in pg.inner_text('#metaMin'), msg='preliminar pelo link')
        assert pg.evaluate("document.getElementById('minDecisao').classList.contains('preliminar')") and pg.is_visible('#minPendencias') and pg.is_visible('#btnCopiarMin'), 'o link reabre a preliminar com faixa, pendências e Copiar'
        pg.goto(SITE); pg.wait_for_selector('#app:not([hidden])')
    passo('Gerador de Minuta — PROC com SUBSTABELECIMENTO não informado: PRELIMINAR COM PENDÊNCIAS (quadro marinho, faixa "não apta à assinatura", Copiar visível, bloco PENDÊNCIAS), link reabre igual', gerador_proc_preliminar)

    def gerador_proc_casamento_decisao():
        # (b) finalidade sem módulo na MATRIX 01 ⇒ DECISÃO DO TABELIÃO: mesmo visual da bloqueada
        import re as _re
        abrir_gerador()
        pg.click('.min-ato[data-ato="PROC"]'); pg.click('#btnLimparMin')
        assert not pg.is_visible('#minDecisao') and not pg.is_visible('#minPModulosBox'), 'Limpar zera a finalidade e esconde os módulos'
        pg.click('[data-min-chips="proc.finalidade"] [data-v="casamento"]')
        assert pg.is_visible('#minPAvisoSemModulo')
        pg.fill('#minPFinDesc', 'casar por procuração com Sicrana de Tal')
        pg.fill('#minPOutNome1', 'Fulano de Tal'); pg.click('[data-min-chips="proc.out1.civil"] [data-v="solteiro"]')
        pg.fill('#minPDadoNome1', 'Beltrano de Tal'); pg.fill('#minPDadoVinc1', 'irmão')
        pg.fill('#minPObjeto', 'Sicrana de Tal')
        pg.click('[data-min-chips="proc.substab"] [data-v="com_ou_sem_reserva"]')
        pg.click('#btnGerarMinuta')
        esperar(lambda: pg.is_visible('#minDecisao') and 'DECISÃO DO TABELIÃO' in pg.inner_text('#minDecisao'), seg=20, msg='decisão do Tabelião no quadro')
        assert estado_rotulo() == 'DECISÃO DO TABELIÃO', estado_rotulo()
        assert pg.evaluate("document.getElementById('minDecisao').classList.contains('bloqueada') && !document.getElementById('minDecisao').classList.contains('preliminar')"), 'quadro .bloqueada (vinho)'
        assert not pg.is_visible('#btnCopiarMin') and not pg.is_visible('#minPreliminarFaixa'), 'sem minuta não há o que copiar'
        quadro = pg.inner_text('#minDecisao')
        assert 'QUALIFICAÇÃO DEVOLVIDA' in quadro and 'alternativa A' in quadro and 'MATRIX_EXTENSION_REVIEW' in quadro, quadro
        assert 'PROCURAÇÃO PÚBLICA' not in pg.inner_text('#saidaMinuta') and 'MINUTA_COPIAVEL' not in pg.inner_text('#saidaMinuta'), 'sem trecho de minuta'
        ficha = ficha_enviada()
        assert 'FINALIDADE: casamento' in ficha and _re.search(r'^MODULOS_AUTORIZADOS:\s*$', ficha, _re.M), 'casamento viaja sem módulo: ' + ficha
        assert 'PODERES_CPC_105: nao_se_aplica' in ficha and 'PRECO: nao_se_aplica' in ficha and 'SUBSTABELECIMENTO: com_ou_sem_reserva' in ficha and 'IRREVOGABILIDADE: nao_informado' in ficha, ficha
        esperar(lambda: pg.locator('#minutaLinkBox:visible').count() == 1, msg='link permanente da decisão')
        link = pg.evaluate("document.getElementById('minutaLinkA').textContent")
        assert minuta_guardada(link)['titulo'].endswith(' · DECISÃO DO TABELIÃO'), 'título guardado com o sufixo DECISÃO DO TABELIÃO'
        pg.screenshot(path=SHOTS + '/27-gerador-decisao.png', full_page=True)
    passo('Gerador de Minuta — PROC para casamento: DECISÃO DO TABELIÃO (MATRIX_EXTENSION_REVIEW), quadro vinho, sem botão Copiar, MODULOS_AUTORIZADOS vazio', gerador_proc_casamento_decisao)

    def gerador_dissue_gravidez_decisao():
        # (c) nascituro em extinção de união estável ⇒ DECISÃO DO TABELIÃO
        abrir_gerador()
        pg.click('.min-ato[data-ato="DISS_UE"]'); pg.click('#btnLimparMin')
        pg.fill('#minDsC1Nome', 'Fulana de Tal'); pg.fill('#minDsC2Nome', 'Beltrano de Tal')
        pg.click('[data-min-chips="dss.c1civil"] [data-v="solteiro"]'); pg.click('[data-min-chips="dss.c2civil"] [data-v="solteiro"]')
        pg.click('[data-min-chips="dss.titulo"] [data-v="contrato_particular"]'); pg.fill('#minDsTituloData', '2019-05-05')
        pg.click('[data-min-chips="dss.livro_e"] [data-v="nao_registrada"]')
        pg.click('[data-min-chips="dss.termino_modo"] [data-v="nao_sabem_precisar"]')
        pg.click('[data-min-chips="dss.regime"] [data-v="contrato"]'); pg.fill('#minDsRegimeDados', 'separação total, escritura CN2O, 01/02/2020')
        pg.click('[data-min-chips="dss.regime_alterado"] [data-v="nao"]')
        pg.click('[data-min-chips="dss.bens"] [data-v="sim_parcialmente_identificados"]')
        pg.click('[data-min-chips="dss.partilha"] [data-v="diferida"]')
        pg.click('[data-min-chips="dss.filhos"] [data-v="nenhum"]')
        pg.click('[data-min-chips="dss.gravidez"] [data-v="sim"]')
        pg.click('[data-min-chips="dss.alimentos"] [data-v="dispensa_reciproca"]')
        pg.click('[data-min-chips="dss.nome"] [data-v="mantem_nome_atual"]'); pg.click('[data-min-chips="dss.nome_quem"] [data-v="convivente 2"]')
        pg.click('[data-min-chips="dss.adv"] [data-v="comum"]'); pg.fill('#minDsAdvNome', 'Sicrana de Tal'); pg.fill('#minDsAdvOab', 'OAB/SE 1234')
        pg.click('[data-min-chips="dss.repr"] [data-v="pessoal"]')
        pg.click('#btnGerarMinuta')
        esperar(lambda: pg.is_visible('#minDecisao') and 'DECISÃO DO TABELIÃO' in pg.inner_text('#minDecisao'), seg=20, msg='decisão do Tabelião no quadro')
        assert estado_rotulo() == 'DECISÃO DO TABELIÃO', estado_rotulo()
        assert pg.evaluate("document.getElementById('minDecisao').classList.contains('bloqueada')") and not pg.is_visible('#btnCopiarMin')
        assert 'nascituro' in pg.inner_text('#minDevolvidaTexto'), pg.inner_text('#minDevolvidaTexto')
        ficha = ficha_enviada()
        # v1.29 — QUALIFICACAO_CONVIVENTE_1/2 logo após a linha da pessoa (spec §2.3)
        assert 'ATO: DISS_UE\nFORMA_DO_ATO: nao_informado\nPARTICULARIDADES: nenhuma\nCONVIVENTE_1: Fulana de Tal · solteiro\nQUALIFICACAO_CONVIVENTE_1: nao_informado\nCONVIVENTE_2: Beltrano de Tal · solteiro\nQUALIFICACAO_CONVIVENTE_2: nao_informado\nTITULO_ANTERIOR: contrato_particular: 05/05/2019\nLIVRO_E: nao_registrada\nDATA_TERMINO: nao_sabem_precisar\nREGIME: contrato: separação total, escritura CN2O, 01/02/2020\nREGIME_ALTERADO: nao\nBENS_COMUNS: sim_parcialmente_identificados\nPARTILHA: diferida\nFILHOS: nenhum\nDECISAO_JUDICIAL_FILHOS: nao_se_aplica\nGRAVIDEZ: sim\nALIMENTOS_ENTRE_CONVIVENTES: dispensa_reciproca\nNOME: mantem_nome_atual: convivente 2\nADVOGADO: comum: Sicrana de Tal · OAB/SE 1234\nREPRESENTACAO: pessoal\nOBSERVACOES: nao_informado' in ficha, 'ficha DISS_UE fora da ordem/valores da spec §2.3:\n' + ficha
        pg.goto(SITE); pg.wait_for_selector('#app:not([hidden])')
    passo('Gerador de Minuta — DISS_UE com GRAVIDEZ sim: DECISÃO DO TABELIÃO (nascituro), sem botão Copiar; ficha §2.3 com DATA_TERMINO, REGIME, REGIME_ALTERADO, NOME (mantém o nome atual) e advogado comum', gerador_dissue_gravidez_decisao)

    # ---------------- 05 · Gerador de Minuta — v1.29: transposição de dados dos documentos (spec §9) + minuta no Google Docs ----------------
    # O mock da transposição (teste/real/gemini.js) decide a variante pelo NOME do arquivo anexado:
    # padrão (Maria + João, sem certidão de casamento, alertas de estado civil), "casamento",
    # "menor" (Lucas, certidão de nascimento) e "json-quebrado" (502). O fake do Apps Script
    # (docs-falso.js) cria o Doc para toda minuta PRONTA/PRELIMINAR e falha com "FALHA-DOCS" no título.
    def anexo_teste(nome):
        with open(os.path.join(ARQ, 'certidao-p1.png'), 'rb') as f: return {'name': nome, 'mimeType': 'image/png', 'buffer': f.read()}
    def anexar(nome):
        n = pg.locator('#paginaMinutas .anexo-item').count()
        pg.set_input_files('#paginaMinutas .zona-anexos input[type=file]', files=[anexo_teste(nome)])
        esperar(lambda: pg.locator('#paginaMinutas .anexo-item').count() == n + 1, msg='anexo listado')
    def transpor(min_linhas):
        pg.click('#btnTranspor')
        esperar(lambda: pg.text_content('#btnTranspor').strip() == 'Interromper' or pg.locator('#minTranspostoLinhas .mt-linha').count() >= min_linhas, msg='botão vira Interromper')
        esperar(lambda: pg.locator('#minTranspostoLinhas .mt-linha').count() >= min_linhas and pg.text_content('#btnTranspor').strip() == 'Extrair e transpor dados', seg=20, msg='transposição concluída')
    def chip_ativo(chave):
        return pg.evaluate("(k => { const b = document.querySelector('[data-min-chips=\"' + k + '\"] .ed-chip.ativo'); return b ? b.dataset.v : null; })", chave)
    def valor(id_): return pg.evaluate("document.getElementById(%r).value" % id_)
    def destino(k): return pg.evaluate("document.querySelector('#minTranspostoLinhas .mt-linha[data-pessoa=\"%d\"] select').value" % k)
    def ordem_no_dom(a, b):
        return pg.evaluate("!!(document.getElementById(%r).compareDocumentPosition(document.getElementById(%r)) & Node.DOCUMENT_POSITION_FOLLOWING)" % (a, b))

    def gerador_zona_documentos():
        abrir_gerador()
        pg.click('.min-ato[data-ato="UE"]'); pg.click('#btnLimparMin')
        assert ordem_no_dom('minAtos', 'minDocs') and ordem_no_dom('minDocs', 'minEntrevista'), 'a zona "Documentos das partes" fica entre o passo 1 (o ato) e a entrevista'
        assert pg.locator('#paginaMinutas [data-anexos="min"]').count() == 1 and pg.locator('#minDocs [data-anexos="min"]').count() == 1, 'uma única zona de anexos, dentro do bloco Documentos das partes'
        assert pg.locator('#minDocs #btnTranspor').count() == 1 and pg.text_content('#btnTranspor').strip() == 'Extrair e transpor dados', 'o botão Extrair e transpor dados fica na zona'
        bloco = pg.inner_text('#minDocs')
        assert 'DOCUMENTOS DAS PARTES' in bloco.upper() and 'preenche os campos das fases seguintes' in bloco and 'Os mesmos documentos seguem com a minuta' in bloco, bloco[:300]
        assert 'conviventes' in pg.inner_text('#minAnexosRot'), pg.inner_text('#minAnexosRot')
        pg.click('.min-ato[data-ato="EMANC"]')
        assert 'Certidão de nascimento do menor' in pg.inner_text('#minAnexosRot'), 'a ajuda da zona muda com o ato'
        pg.click('.min-ato[data-ato="UE"]')
        assert not pg.is_visible('#minTransposto'), 'o painel "Dados transpostos" nasce escondido'
        for id_ in ['minC1Qual', 'minC2Qual', 'minDsC1Qual', 'minDsC2Qual', 'minDvC1Qual', 'minDvC2Qual', 'minEmMenorQual', 'minEmCertidao', 'minEmPai', 'minEmMae', 'minEmPaiQual', 'minEmMaeQual', 'minPOutQual1', 'minPOutQual4', 'minPDadoQual1', 'minPDadoQual3']:
            assert pg.locator('#' + id_).count() == 1, 'campo novo ausente: ' + id_
        assert pg.get_attribute('#minC1Qual', 'placeholder') == 'Preenchida pela transposição dos documentos; edite se preciso'
        assert 'Google Doc' in pg.inner_text('#minNota'), 'com a ponte ligada (docs_ativo), a nota do Gerador fala do Google Docs: ' + pg.inner_text('#minNota')
        antes = len(chamadas())
        pg.click('#btnTranspor'); pg.wait_for_selector('#toast:not([hidden])')
        assert 'Anexe os documentos das partes' in pg.inner_text('#toast'), pg.inner_text('#toast')
        assert len(chamadas()) == antes and not pg.is_visible('#minTransposto'), 'sem anexo não há chamada nem painel'
    passo('Gerador v1.29 — zona "Documentos das partes" logo após o passo 1 (a mesma zona de anexos da geração), botão Extrair e transpor, ajuda por ato, campos novos de qualificação, nota do Google Docs; sem anexo só avisa', gerador_zona_documentos)

    def gerador_transposicao_ue():
        abrir_gerador()
        pg.click('.min-ato[data-ato="UE"]'); pg.click('#btnLimparMin')
        pg.fill('#minC1Cpf', '000.000.000-00')                              # valor anterior diferente → marca "substituído"
        pg.click('[data-min-chips="ue.c2civil"] [data-v="solteiro"]')       # chip anterior: sem prova, a transposição não mexe
        anexar('rg-e-certidao.png')                                          # variante padrão do mock: sem certidão de casamento
        transpor(2)
        ch = chamadas()[-1]
        assert 'TRANSPOSITOR DE DADOS' in ch['prompt'], 'o prompt da transposição chegou ao modelo'
        assert 'ENTREVISTA DIRIGIDA' not in ch['observacoes'] and '=== HOJE ===' not in ch['observacoes'] and 'QUEM ESTÁ MINUTANDO' not in ch['observacoes'], 'a transposição manda só os documentos (sem ficha): ' + ch['observacoes'][:200]
        assert ch['arquivos'] and ch['arquivos'][0]['mime'] == 'image/png', ch['arquivos']
        assert pg.locator('#minTranspostoLinhas .mt-linha').count() == 2, 'uma linha por pessoa'
        assert destino(0) == 'c1' and destino(1) == 'c2', 'destinos padrão: convivente 1 e 2, na ordem das pessoas'
        assert valor('minC1Nome') == 'MARIA DAS GRAÇAS SANTOS' and valor('minC1Cpf') == '123.456.789-00' and valor('minC1Nasc') == '1958-03-10' and valor('minC1Prof') == 'aposentada', [valor('minC1Nome'), valor('minC1Cpf'), valor('minC1Nasc'), valor('minC1Prof')]
        assert valor('minC1Qual').startswith('MARIA DAS GRAÇAS SANTOS, brasileira, aposentada, nascida em 10/03/1958') and 'CPF/MF sob o nº 123.456.789-00' in valor('minC1Qual'), valor('minC1Qual')
        assert valor('minC2Nome') == 'JOÃO PEDRO SANTOS' and valor('minC2Cpf') == '987.654.321-00' and valor('minC2Nasc') == '1985-07-22' and valor('minC2Prof') == 'comerciante'
        assert valor('minC2Qual').startswith('JOÃO PEDRO SANTOS, comerciante, nascido em 22/07/1985'), valor('minC2Qual')
        assert chip_ativo('ue.c1civil') is None and chip_ativo('ue.c2civil') == 'solteiro', 'estado civil não comprovado ("") não altera os chips'
        painel = pg.inner_text('#minTransposto')
        assert 'estado civil de MARIA DAS GRAÇAS SANTOS não comprovado' in painel and 'estado civil de JOÃO PEDRO SANTOS não comprovado' in painel, 'os alertas do modelo aparecem no painel: ' + painel
        assert pg.locator('#minTranspostoAlertas li').count() == 2
        cor, tam = pg.evaluate("(e => [getComputedStyle(e).color, parseFloat(getComputedStyle(e).fontSize)])(document.getElementById('minTranspostoAlertas'))")
        assert cor == 'rgb(99, 19, 37)' and tam >= 16, 'alertas em vinho, 16 px ou mais: %s %s' % (cor, tam)
        assert pg.evaluate("parseFloat(getComputedStyle(document.querySelector('#minTranspostoLinhas .mt-linha')).fontSize)") >= 18, 'linhas do painel em 18 px'
        marca = pg.inner_text('#minTranspostoLinhas .mt-linha[data-pessoa="0"] .mt-marca')
        assert 'SUBSTITUÍDO' in marca.upper() and 'CPF' in marca, 'o CPF já preenchido com valor diferente vira "substituído": ' + marca
        assert not pg.is_visible('#minTranspostoLinhas .mt-linha[data-pessoa="1"] .mt-marca'), 'sem substituição no convivente 2'
        meta = pg.inner_text('#minTranspostoMeta')
        assert 'Transposição feita para' in meta and 'Gemini Pro' in meta and 'US$ 0,0093' in meta and 'Dupla leitura OCR' in meta, meta
        assert 'PESSOA(S)' in pg.inner_text('#minTranspostoResumo').upper()
        pg.screenshot(path=SHOTS + '/27-gerador-transposicao-ue.png', full_page=True)
        # (c) Desfazer devolve os valores anteriores à transposição
        pg.click('#btnDesfazerTransp')
        assert valor('minC1Nome') == '' and valor('minC1Cpf') == '000.000.000-00' and valor('minC1Prof') == '' and valor('minC1Nasc') == '' and valor('minC1Qual') == '' and valor('minC2Nome') == '' and valor('minC2Qual') == '', 'Desfazer restaura os campos'
        assert chip_ativo('ue.c2civil') == 'solteiro' and chip_ativo('ue.c1civil') is None
        assert 'desfeita' in pg.inner_text('#minTranspostoResumo').lower() and pg.locator('#minTranspostoLinhas .mt-linha').count() == 2, 'o painel continua, marcado como desfeito'
        assert pg.evaluate("document.getElementById('btnDesfazerTransp').disabled")
        # (d) trocar os destinos + Reaplicar troca as pessoas de lugar
        pg.select_option('#minTranspostoLinhas .mt-linha[data-pessoa="0"] select', 'c2')
        pg.select_option('#minTranspostoLinhas .mt-linha[data-pessoa="1"] select', 'c1')
        pg.click('#btnReaplicarTransp')
        assert valor('minC1Nome') == 'JOÃO PEDRO SANTOS' and valor('minC1Cpf') == '987.654.321-00' and valor('minC2Nome') == 'MARIA DAS GRAÇAS SANTOS' and valor('minC2Cpf') == '123.456.789-00', 'Reaplicar com os destinos trocados'
        assert valor('minC2Qual').startswith('MARIA DAS GRAÇAS SANTOS') and valor('minC1Qual').startswith('JOÃO PEDRO SANTOS')
        pg.select_option('#minTranspostoLinhas .mt-linha[data-pessoa="1"] select', 'c2')
        pg.click('#btnReaplicarTransp')
        esperar(lambda: pg.is_visible('#toast') and 'mesmo destino' in pg.inner_text('#toast'), msg='destino repetido é recusado')
        assert valor('minC1Nome') == 'JOÃO PEDRO SANTOS', 'destino repetido não altera os campos'
        # (b) variante com certidão de casamento (sobre os campos originais: CPF digitado e chip solteiro do convivente 2):
        # chips de estado civil marcados, sem alertas, linha da certidão
        pg.click('#btnDesfazerTransp')
        assert valor('minC1Nome') == '' and valor('minC1Cpf') == '000.000.000-00'
        pg.locator('#paginaMinutas .anexo-x').first.click()
        esperar(lambda: pg.locator('#paginaMinutas .anexo-item').count() == 0, msg='anexo removido')
        anexar('certidao-casamento.png')
        transpor(3)
        assert destino(0) == 'c1' and destino(1) == 'c2', 'nova transposição volta aos destinos padrão'
        assert valor('minC1Nome') == 'MARIA DAS GRAÇAS SANTOS' and valor('minC2Nome') == 'JOÃO PEDRO SANTOS'
        assert chip_ativo('ue.c1civil') == 'casado' and chip_ativo('ue.c2civil') == 'casado', 'estado civil comprovado pela certidão marca os chips'
        assert pg.is_visible('#minAvisoCasado'), 'o aviso do convivente casado acompanha o chip'
        assert not pg.is_visible('#minTranspostoAlertas') and pg.locator('#minTranspostoAlertas li').count() == 0, 'sem alertas na variante casamento'
        assert 'Certidão de casamento' in pg.inner_text('#minTranspostoLinhas') and 'MARIA DAS GRAÇAS SILVA' in pg.inner_text('#minTranspostoLinhas'), 'a certidão de casamento aparece como linha informativa'
        assert 'casada sob o regime da comunhão parcial de bens desde 15/06/2010' in valor('minC1Qual')
        marcas = pg.evaluate("Array.from(document.querySelectorAll('#minTranspostoLinhas .mt-marca')).filter(m => !m.hidden).map(m => m.textContent)")
        assert marcas == ['substituído: CPF', 'substituído: estado civil'], 'substituídos: o CPF digitado do convivente 1 e o chip solteiro → casado do convivente 2: %s' % marcas
        # (e) a ficha traz QUALIFICACAO_CONVIVENTE_1 com o parágrafo e QUALIFICACAO_CONVIVENTE_2, logo após cada pessoa (spec §2.2)
        pg.click('[data-min-chips="ue.filhos"] [data-v="nenhum"]')
        pg.fill('#minObs', 'ambos separados de fato dos respectivos cônjuges desde 2015')
        link_antes = pg.evaluate("document.getElementById('minutaLinkA').textContent")
        pg.click('#btnGerarMinuta')
        esperar(lambda: pg.is_visible('#minDecisao') and 'PRONTA PARA MINUTA' in pg.inner_text('#minDecisao'), seg=20, msg='minuta pronta')
        ficha = pg.evaluate("document.getElementById('minPedido').value")
        assert 'CONVIVENTE_1: MARIA DAS GRAÇAS SANTOS · casado · nascido(a) em 10/03/1958 · CPF 123.456.789-00 · profissão: aposentada\nQUALIFICACAO_CONVIVENTE_1: MARIA DAS GRAÇAS SANTOS, brasileira, casada sob o regime da comunhão parcial de bens desde 15/06/2010, aposentada, nascida em 10/03/1958, natural de Itabaiana/SE, filha de JOSÉ SANTOS e de ANA SANTOS, portadora da cédula de identidade RG nº 1.234.567 – SSP/SE, inscrita no CPF/MF sob o nº 123.456.789-00, residente e domiciliada na Rua das Flores, nº 45, Centro, Itabaiana/SE, CEP 49500-000.\nCONVIVENTE_2: JOÃO PEDRO SANTOS · casado · nascido(a) em 22/07/1985 · CPF 987.654.321-00 · profissão: comerciante\nQUALIFICACAO_CONVIVENTE_2: JOÃO PEDRO SANTOS, casado sob o regime da comunhão parcial de bens desde 15/06/2010, comerciante, nascido em 22/07/1985, portador da cédula de identidade RG nº 7.654.321 – SSP/SE, inscrito no CPF/MF sob o nº 987.654.321-00.\nINICIO_CONVIVENCIA:' in ficha, 'ficha UE com as qualificações transpostas:\n' + ficha
        assert ficha_enviada().startswith(ficha.strip()), 'a ficha enviada é a de #minPedido'
        ch = chamadas()[-1]
        assert ch['arquivos'] and ch['arquivos'][0]['mime'] == 'image/png', 'os mesmos documentos seguem na chamada de geração'
        # (i) minuta PRONTA → botão "Abrir no Google Docs" no topo do resultado, com a URL do Doc criado (fake do Apps Script)
        assert pg.is_visible('#minDocBox') and not pg.is_visible('#minDocErro'), 'a caixa do Google Docs aparece na minuta PRONTA'
        href = pg.get_attribute('#minDocLink', 'href')
        assert href.startswith('https://docs.google.com/document/d/doc-teste-') and href.endswith('/edit'), href
        assert pg.get_attribute('#minDocLink', 'target') == '_blank' and 'noopener' in pg.get_attribute('#minDocLink', 'rel')
        assert pg.text_content('#minDocLink').strip() == 'Abrir no Google Docs'
        assert pg.inner_text('#minDocTitulo').startswith('MINUTA — Hub — UE — MARIA DAS GRAÇAS SANTOS e JOÃO PEDRO SANTOS — '), 'o título do Doc vem do titulo_base enviado pela tela: ' + pg.inner_text('#minDocTitulo')
        assert 'pasta do Gerador (Drive)' in pg.inner_text('#minDocBox') and 'Extra Digital' in pg.inner_text('#minDocBox')
        assert ordem_no_dom('minDocBox', 'minDecisao'), 'a caixa do Docs fica antes do quadro da decisão'
        assert pg.is_visible('#btnCopiarMin'), 'o Copiar continua'
        with open('/tmp/docs-chamadas.json', encoding='utf-8') as f: pedido = json.load(f)[-1]
        assert pedido['titulo'].startswith('MINUTA — Hub — UE — MARIA DAS GRAÇAS SANTOS e JOÃO PEDRO SANTOS'), pedido['titulo']
        esperar(lambda: pg.locator('#minutaLinkBox:visible').count() == 1 and pg.evaluate("document.getElementById('minutaLinkA').textContent") != link_antes, msg='link permanente')
        link = pg.evaluate("document.getElementById('minutaLinkA').textContent")
        assert minuta_guardada(link)['doc_url'] == href, 'a minuta guardada leva a doc_url'
        pg.screenshot(path=SHOTS + '/27-gerador-transposicao-docs.png', full_page=True)
        # reabrir por #minuta=<id> mostra o botão de novo
        pg.goto(link); pg.reload(); pg.wait_for_selector('#paginaMinutas:not([hidden])')
        esperar(lambda: 'guardada por' in pg.inner_text('#metaMin'), msg='minuta pelo link')
        assert pg.is_visible('#minDocBox') and pg.get_attribute('#minDocLink', 'href') == href, 'o link permanente reabre com o botão do Google Docs'
        assert not pg.is_visible('#minDocErro')
        pg.goto(SITE); pg.wait_for_selector('#app:not([hidden])')
    passo('Gerador v1.29 — transposição na UE: campos dos conviventes 1 e 2 (nome, CPF, nascimento, profissão, qualificação), alertas em vinho, "substituído", Desfazer, troca de destino + Reaplicar, variante casamento marca os chips; ficha com QUALIFICACAO_CONVIVENTE_1/2; minuta PRONTA com "Abrir no Google Docs" que o link permanente reabre', gerador_transposicao_ue)

    def gerador_transposicao_div():
        abrir_gerador()
        pg.click('.min-ato[data-ato="DIV"]'); pg.click('#btnLimparMin')
        assert not pg.is_visible('#minTransposto'), 'trocar de ato (e Limpar) esconde o painel da transposição anterior'
        pg.click('[data-min-multi="div.solteiro1"] [data-v="igual_ao_atual"]')     # a certidão traz o nome de solteira: o chip cai
        anexar('certidao-casamento.png')
        transpor(3)
        assert valor('minDvC1Nome') == 'MARIA DAS GRAÇAS SANTOS' and valor('minDvC2Nome') == 'JOÃO PEDRO SANTOS'
        assert valor('minDvCasData') == '2010-06-15' and valor('minDvCasServ') == '1º Ofício de Itabaiana/SE' and valor('minDvCasMatr') == '123456 01 55 2010 2 00020 111 0000222 33' and valor('minDvCertData') == '2026-09-02', 'a certidão de casamento preenche data, serventia, matrícula e emissão'
        assert chip_ativo('div.regime') == 'comunhão parcial de bens', 'o regime vira chip'
        assert valor('minDvSolteiro1') == 'MARIA DAS GRAÇAS SILVA' and pg.is_visible('#minDvSolteiro1') and pg.locator('[data-min-multi="div.solteiro1"] .ed-chip.ativo').count() == 0, 'nome de solteiro do cônjuge 1 pelo nome_solteiro da certidão (e o chip "igual ao atual" cai)'
        assert valor('minDvSolteiro2') == '', 'sem nome anterior na certidão, o campo do cônjuge 2 fica como está'
        assert valor('minDvC1Qual').startswith('MARIA DAS GRAÇAS SANTOS, brasileira, casada') and valor('minDvC2Qual').startswith('JOÃO PEDRO SANTOS, casado')
        assert 'dados do casamento e nomes de solteiro' in pg.inner_text('#minTranspostoLinhas'), 'no DIV a linha da certidão diz que foi aplicada'
        pg.screenshot(path=SHOTS + '/27-gerador-transposicao-div.png', full_page=True)
        pg.click('#btnDesfazerTransp')
        assert valor('minDvCasData') == '' and valor('minDvCasMatr') == '' and chip_ativo('div.regime') is None and valor('minDvSolteiro1') == '' and pg.locator('[data-min-multi="div.solteiro1"] .ed-chip.ativo').count() == 1, 'Desfazer devolve também o casamento, o regime e o chip do nome'
        pg.click('#btnReaplicarTransp')
        assert valor('minDvCasMatr') == '123456 01 55 2010 2 00020 111 0000222 33' and chip_ativo('div.regime') == 'comunhão parcial de bens'
        # a ficha (sem gerar): CONJUGE_i, QUALIFICACAO_CONJUGE_i, CASAMENTO, REGIME, NOME_SOLTEIRO
        pg.click('[data-min-chips="div.bens"] [data-v="nao"]'); pg.click('[data-min-chips="div.partilha"] [data-v="nenhuma_a_fazer"]')
        pg.click('[data-min-chips="div.filhos"] [data-v="nenhum"]'); pg.click('[data-min-chips="div.gravidez"] [data-v="nao"]')
        pg.evaluate("document.getElementById('minPedido').value = ''")
        pg.click('#btnGerarMinuta')
        esperar(lambda: pg.evaluate("document.getElementById('minPedido').value") != '', msg='ficha montada')
        ficha = pg.evaluate("document.getElementById('minPedido').value")
        assert 'CONJUGE_1: MARIA DAS GRAÇAS SANTOS\nQUALIFICACAO_CONJUGE_1: MARIA DAS GRAÇAS SANTOS, brasileira, casada sob o regime' in ficha and '\nCONJUGE_2: JOÃO PEDRO SANTOS\nQUALIFICACAO_CONJUGE_2: JOÃO PEDRO SANTOS, casado sob o regime' in ficha, ficha
        assert 'CASAMENTO: 15/06/2010 · 1º Ofício de Itabaiana/SE · matrícula 123456 01 55 2010 2 00020 111 0000222 33 · certidão emitida em 02/09/2026\nREGIME: comunhão parcial de bens\n' in ficha, ficha
        assert 'NOME_SOLTEIRO_1: MARIA DAS GRAÇAS SILVA\nNOME_SOLTEIRO_2: nao_informado\n' in ficha, ficha
        esperar(lambda: pg.is_visible('#minDecisao') and 'PRONTA PARA MINUTA' in pg.inner_text('#minDecisao'), seg=20, msg='divórcio pronto')
        assert pg.is_visible('#minDocBox'), 'a minuta PRONTA do divórcio também nasce no Google Docs'
    passo('Gerador v1.29 — transposição no DIV com "certidao-casamento": cônjuges, qualificações, data/serventia/matrícula/emissão do casamento, regime (chip) e nome de solteira; Desfazer e Reaplicar; ficha §2.4 com QUALIFICACAO_CONJUGE_1/2', gerador_transposicao_div)

    def gerador_transposicao_emanc():
        abrir_gerador()
        pg.click('.min-ato[data-ato="EMANC"]'); pg.click('#btnLimparMin')
        anexar('certidao-nascimento-menor.png')
        transpor(1)
        assert pg.locator('#minTranspostoLinhas .mt-linha').count() == 1 and destino(0) == 'menor', 'a única pessoa vai para o emancipando'
        assert valor('minEmNome') == 'LUCAS ANDRADE COSTA' and valor('minEmNasc') == '2009-05-05'
        assert valor('minEmMenorQual') == 'LUCAS ANDRADE COSTA, brasileiro, nascido em 05/05/2009, natural de Itabaiana/SE, filho de JOÃO COSTA e de MARIA ANDRADE COSTA.'
        assert valor('minEmCertidao') == '1º Ofício de Itabaiana/SE · matrícula 123456 01 55 2009 1 00010 123 0000456 78 · emitida em 01/09/2026', valor('minEmCertidao')
        assert valor('minEmPai') == 'JOÃO COSTA' and valor('minEmMae') == 'MARIA ANDRADE COSTA', 'a filiação "PAI e MÃE" separa em pai e mãe'
        assert valor('minEmPaiQual') == '' and valor('minEmMaeQual') == '', 'sem documento próprio dos pais, a qualificação deles fica vazia'
        assert 'estado civil não comprovado' not in pg.inner_text('#minTranspostoLinhas'), 'o emancipando não leva a nota de estado civil'
        assert pg.evaluate("Array.from(document.querySelectorAll('#minTranspostoLinhas select option')).map(o => o.textContent)") == ['Emancipando', 'Pai', 'Mãe', '(não usar)']
        pg.screenshot(path=SHOTS + '/27-gerador-transposicao-emanc.png', full_page=True)
        # a ficha §2.5: QUALIFICACAO_MENOR, CERTIDAO_NASCIMENTO, PAI, MAE depois de QUALIFICACAO_MENOR e antes de QUEM_OUTORGA
        pg.fill('#minEmDomicilio', 'Itabaiana/SE')
        pg.click('[data-min-chips="em.quem"] [data-v="ambos_os_pais"]'); pg.click('[data-min-chips="em.situacao"] [data-v="casados"]')
        pg.click('[data-min-chips="em.participacao"] [data-v="comparece_e_assina"]')
        pg.evaluate("document.getElementById('minPedido').value = ''")
        pg.click('#btnGerarMinuta')
        esperar(lambda: pg.evaluate("document.getElementById('minPedido').value") != '', msg='ficha montada')
        ficha = pg.evaluate("document.getElementById('minPedido').value")
        assert 'MENOR: LUCAS ANDRADE COSTA · nascido em 05/05/2009 · domicílio: Itabaiana/SE\nQUALIFICACAO_MENOR: LUCAS ANDRADE COSTA, brasileiro, nascido em 05/05/2009, natural de Itabaiana/SE, filho de JOÃO COSTA e de MARIA ANDRADE COSTA.\nCERTIDAO_NASCIMENTO: 1º Ofício de Itabaiana/SE · matrícula 123456 01 55 2009 1 00010 123 0000456 78 · emitida em 01/09/2026\nPAI: JOÃO COSTA\nMAE: MARIA ANDRADE COSTA\nQUEM_OUTORGA: ambos_os_pais\n' in ficha, 'ficha EMANC fora da posição da spec §2.5:\n' + ficha
        esperar(lambda: pg.is_visible('#minDecisao'), seg=20, msg='resposta da emancipação')
        # a qualificação do pai digitada entra na linha PAI ("<nome> · <qualificação>")
        pg.fill('#minEmPaiQual', 'JOÃO COSTA, brasileiro, lavrador, RG 1.111.111 – SSP/SE')
        pg.evaluate("document.getElementById('minPedido').value = ''")
        pg.click('#btnGerarMinuta')
        esperar(lambda: pg.evaluate("document.getElementById('minPedido').value") != '', msg='ficha remontada')
        assert 'PAI: JOÃO COSTA · JOÃO COSTA, brasileiro, lavrador, RG 1.111.111 – SSP/SE\nMAE: MARIA ANDRADE COSTA\n' in pg.evaluate("document.getElementById('minPedido').value")
        esperar(lambda: pg.is_visible('#minDecisao'), seg=20, msg='segunda resposta')
    passo('Gerador v1.29 — transposição no EMANC com "certidao-nascimento-menor": emancipando (nome, nascimento, qualificação), certidão (serventia · matrícula · emitida em), PAI e MAE pela filiação; ficha §2.5 com CERTIDAO_NASCIMENTO/PAI/MAE entre QUALIFICACAO_MENOR e QUEM_OUTORGA', gerador_transposicao_emanc)

    def gerador_transposicao_erros():
        abrir_gerador()
        pg.click('.min-ato[data-ato="DISS_UE"]'); pg.click('#btnLimparMin')
        pg.fill('#minDsC1Nome', 'Nome digitado antes'); pg.click('[data-min-chips="dss.c1civil"] [data-v="viuvo"]')
        anexar('json-quebrado.png')
        pg.click('#btnTranspor')
        esperar(lambda: pg.is_visible('#minTranspostoTexto') and 'estruturados' in pg.inner_text('#minTranspostoTexto'), seg=20, msg='mensagem do 502')
        assert pg.text_content('#btnTranspor').strip() == 'Extrair e transpor dados', 'o botão volta ao rótulo'
        msg = pg.inner_text('#minTranspostoTexto')
        assert 'O modelo não devolveu dados estruturados — tente de novo. Os campos não foram alterados.' in msg, msg
        assert pg.evaluate("getComputedStyle(document.getElementById('minTranspostoTexto')).color") == 'rgb(99, 19, 37)' and pg.evaluate("parseFloat(getComputedStyle(document.getElementById('minTranspostoTexto')).fontSize)") >= 18
        assert 'não concluída' in pg.inner_text('#minTranspostoResumo').lower()
        assert not pg.is_visible('#minTranspostoLinhas') and not pg.is_visible('#minTranspostoBotoes'), 'sem linhas nem botões na falha'
        assert valor('minDsC1Nome') == 'Nome digitado antes' and chip_ativo('dss.c1civil') == 'viuvo', 'a falha não altera os campos'
        pg.screenshot(path=SHOTS + '/27-gerador-transposicao-erro.png', full_page=True)
        # Limpar zera o painel e os campos novos
        pg.click('#btnLimparMin')
        assert not pg.is_visible('#minTransposto') and pg.locator('#paginaMinutas .anexo-item').count() == 0 and valor('minDsC1Qual') == ''
        # doc_erro: título com FALHA-DOCS derruba o fake do Apps Script → nota discreta, minuta segue com o Copiar
        pg.click('.min-ato[data-ato="UE"]'); pg.click('#btnLimparMin')
        pg.fill('#minC1Nome', 'FALHA-DOCS Fulana'); pg.fill('#minC2Nome', 'Beltrano de Tal')
        pg.click('[data-min-chips="ue.filhos"] [data-v="nenhum"]')
        pg.click('#btnGerarMinuta')
        esperar(lambda: pg.is_visible('#minDecisao') and 'PRONTA PARA MINUTA' in pg.inner_text('#minDecisao'), seg=20, msg='minuta pronta (docs em falha)')
        assert not pg.is_visible('#minDocBox') and pg.is_visible('#minDocErro'), 'sem Doc criado, só a nota de falha'
        nota = pg.inner_text('#minDocErro')
        assert nota.startswith('Google Docs: não foi possível criar o documento — use o Copiar. (') and 'HTTP 500' in nota, nota
        assert pg.evaluate("getComputedStyle(document.getElementById('minDocErro')).color") == 'rgb(99, 19, 37)' and pg.evaluate("parseFloat(getComputedStyle(document.getElementById('minDocErro')).fontSize)") >= 16
        assert pg.is_visible('#btnCopiarMin')
        esperar(lambda: pg.locator('#minutaLinkBox:visible').count() == 1, msg='link permanente')
        assert minuta_guardada(pg.evaluate("document.getElementById('minutaLinkA').textContent"))['doc_url'] is None, 'sem Doc, a minuta guardada não leva doc_url'
        pg.click('#btnLimparMin')
        assert not pg.is_visible('#minDocErro') and not pg.is_visible('#minDocBox'), 'Limpar esconde a nota do Docs'
        pg.goto(SITE); pg.wait_for_selector('#app:not([hidden])')   # os passos seguintes (dashboard) partem do hub visível
    passo('Gerador v1.29 — "json-quebrado": mensagem de erro no painel (vinho, 18 px) e campos intactos; Limpar zera o painel; falha do Apps Script vira nota discreta "use o Copiar" e a minuta guardada fica sem doc_url', gerador_transposicao_erros)

    def pacto_no_dossie_do_protocolo():
        pg2 = ctx.new_page()
        pg2.set_default_timeout(12000)
        tok = pg.evaluate("localStorage.getItem('cn2o_token')")
        pg2.add_init_script("localStorage.setItem('cn2o_token','%s');localStorage.setItem('cn2o_nome','César Bravo');localStorage.setItem('cn2o_hub_key','teste');" % tok)
        pg2.goto(SITE + 'protocolo.html'); pg2.wait_for_selector('.chips .chip')
        pg2.evaluate("[...document.querySelectorAll('.chips .chip')].find(c => c.textContent.includes('CV-Urbano')).click()")
        def op(pg_, pergunta_titulo, valor):
            js = ("([t, v]) => { const div = [...document.querySelectorAll('#perguntas .pergunta')]"
                  ".find(d => d.querySelector('.titulo-p') && d.querySelector('.titulo-p').textContent.includes(t));"
                  " const o = [...div.querySelectorAll('.op')].find(x => x.textContent.trim() === v); o.click(); }")
            pg_.evaluate(js, [pergunta_titulo, valor])
        op(pg2, 'pessoa', 'Pessoa física')
        op(pg2, 'estado civil', 'Casado(a)')
        op(pg2, 'regime de bens', 'Comunhão universal')
        doss = pg2.evaluate("[...document.querySelectorAll('#listaDossie li')].map(li => li.dataset.item)")
        assert any('Pacto antenupcial — escritura ou certidão do registro no RI' in d for d in doss), doss
        assert any('Certidão de casamento (transmitente)' in d for d in doss), doss
        op(pg2, 'regime de bens', 'Separação obrigatória (art. 1.641 CC)')
        doss = pg2.evaluate("[...document.querySelectorAll('#listaDossie li')].map(li => li.dataset.item)")
        assert not any('Pacto antenupcial' in d for d in doss), 'separação obrigatória não tem pacto'
        assert any('Súmula 377' in d for d in doss), doss
        pg2.close()
    passo('Protocolo: comunhão universal exige o pacto no dossiê; separação obrigatória não (Súmula 377 por cautela)', pacto_no_dossie_do_protocolo)


    def dashboard_mural():
        assert 'Olá' in pg.inner_text('#saudacao'), pg.inner_text('#saudacao')
        titulo = pg.inner_text('.mural-titulo').upper().strip()
        assert titulo == 'MURAL', titulo
        fonte = pg.evaluate("getComputedStyle(document.querySelector('.mural-titulo')).fontFamily")
        assert 'Caveat' in fonte, fonte
        sem_frases = pg.evaluate("document.querySelectorAll('.mural-citacao, .mural-frase, .mural-script, .mural-linha2, .mural-rodape-frases').length")
        assert sem_frases == 0, 'frases ainda no mural: %s' % sem_frases
        nav = pg.evaluate("Array.from(document.querySelectorAll('.lat-nav .nav-item')).map(b => b.textContent.trim())")
        assert nav == ['Início', 'Ferramentas', 'Links úteis', 'Avisos', 'Metas', 'Agenda do Tabelião', 'Documentos', 'Ajuda'], nav
        assert pg.evaluate("document.getElementById('avatarIni').textContent.trim().length >= 1"), 'avatar vazio'
        marca = pg.evaluate("""() => { const m = document.querySelector('.lat-avatar.avatar-m'), b = document.querySelector('.lat-avatar.avatar-b');
          return m && m.naturalWidth > 50 && m.src.startsWith('data:image/png') &&
                 getComputedStyle(m).display !== 'none' && getComputedStyle(b).display === 'none'; }""")
        assert marca, 'avatar oficial (marinho) deveria aparecer na lateral clara'
        lateral = pg.evaluate("getComputedStyle(document.querySelector('.lateral')).backgroundImage")
        assert '247' in lateral, 'lateral não está clara (marfim): %s' % lateral
        pino = pg.evaluate("() => getComputedStyle(document.querySelector('.mural-cards .ficha-luz'), '::before').backgroundImage.includes('radial-gradient')")
        assert pino, 'alfinete (pin) ausente nos papéis do mural'
        inclinacao = pg.evaluate("getComputedStyle(document.querySelectorAll('.mural-cards .ficha-luz')[0]).transform")
        assert inclinacao not in ('none', ''), 'papel sem inclinação de alfinete'
        assert pg.evaluate("/^\\d\\d$/.test(document.getElementById('seloDia').textContent)"), pg.evaluate("document.getElementById('seloDia').textContent")
        fichas = pg.evaluate("document.querySelectorAll('.mural-cards .ficha-luz').length")
        assert fichas == 3, fichas
        # metas ativas neste ponto do fluxo: o Ver mais aparece; em breve ele some (testado no mural inicial)
        esperar(lambda: 'frase fixada do teste' in pg.inner_text('#fraseTexto'), msg='frase da planilha (fixada) chegar')
        frase = pg.evaluate("""() => ({ texto: document.getElementById('fraseTexto').textContent.trim(),
          autor: document.getElementById('fraseAutor').textContent.trim(),
          fecho: document.querySelector('#fraseDia .fd-fecho').textContent,
          cursiva: getComputedStyle(document.getElementById('saudacao')).fontFamily })""")
        assert frase['texto'] == 'A frase fixada do teste vale para todos.', frase
        assert frase['autor'] == '— Equipe de Teste', frase
        assert 'César Bravo, Tabelião' in frase['fecho'] and 'Dr.' not in frase['fecho'] and 'ótimo dia de trabalho' in frase['fecho'], frase['fecho']
        assert 'Caveat' in frase['cursiva'], frase['cursiva']
        agenda = pg.evaluate("""() => { const t = document.querySelector('.mural-cards .ficha-luz .ficha-titulo');
          return { texto: t.textContent.trim(), transf: getComputedStyle(t).textTransform }; }""")
        assert agenda['texto'] == 'Agenda Cn2o' and agenda['transf'] == 'none', agenda
        pg.evaluate("document.querySelector('[data-nav=avisos]').click()")
        pg.wait_for_selector('#veuMural.aberto')
        pg.keyboard.press('Escape')
        esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='fechar avisos')
        pg.evaluate("document.querySelector('[data-nav=ajuda]').click()")
        pg.wait_for_selector('#veuAjuda.aberto')
        pg.keyboard.press('Escape')
        pg.wait_for_selector('#veuAjuda', state='hidden')
        aberto = pg.evaluate("""() => { let url = null; const velho = window.open; window.open = u => { url = u; return null; };
          document.querySelector('[data-nav=documentos]').click(); window.open = velho; return url; }""")
        assert aberto and '17jiEqA5ufl4L_7fKKvHzvWF23wvDnlWT' in aberto, aberto
        pg.evaluate("document.querySelector('[data-nav=inicio]').click()")
    passo('dashboard: avatar oficial na lateral + Mural CN2O sem frases, com alfinetes e Agenda do Tabelião no menu', dashboard_mural)


    def protocolar_de_verdade():
        pg.locator('[data-voltar]:visible').first.click() if pg.locator('[data-voltar]:visible').count() else None
        pg.click('#cardProtocolo'); pg.wait_for_selector('#paginaEmbutida:not([hidden])')
        fr = pg.frame_locator('#molduraEmbutida iframe:not([hidden])')
        fr.locator('.chip[data-ato="CV-Urbano"]').click()
        fr.locator('#veuCheck.aberto').wait_for()
        itens = fr.locator('#checkLista .ck-it.tick')
        n = itens.count()
        for i in range(min(3, n)): itens.nth(i).click()
        fr.locator('#veuCheck .fechar').click()
        fr.locator('#apresNome').fill('Corretor Teste da Silva')
        fr.locator('#apresTel').fill('(79) 99999-0000')
        fr.locator('#parteNome').fill('Comprador Teste de Souza')
        fr.locator('#enotT .op', has_text='Não').click()
        fr.locator('#enotA .op', has_text='Não').click()
        btn = fr.locator('#btnProt')
        esperar(lambda: btn.is_enabled(), msg='botão Protocolizar habilitar')
        btn.click()
        fr.locator('#veu.aberto').wait_for(timeout=15000)
        recibo = fr.locator('#reciboTxt').inner_text()
        assert 'Nº do protocolo: 1400' in recibo, recibo
        pg.screenshot(path=SHOTS + '/08-protocolo-recibo.png')
        num = sql("SELECT numero || '|' || usuario || '|' || coalesce(card_id,'') FROM protocolos ORDER BY numero DESC LIMIT 1").strip()
        assert num.startswith('1400|cesar.bravo|card-teste-'), num
        with open('/tmp/trello-chamadas.json', encoding='utf-8') as f: tr = json.load(f)
        cartao = [c for c in tr if c['nome'] == 'criarCartao'][-1]['args'][0]
        assert cartao['name'] == 'Prot. (CV-Urbano) 1400 - COMPRADOR TESTE DE SOUZA', cartao['name']
        campos = [c for c in tr if c['nome'] == 'aplicarCampos'][-1]['args'][2]
        assert campos['Escrevente'] == 'César Bravo', campos
        with open('/tmp/whats-chamadas.json', encoding='utf-8') as f: wa = json.load(f)
        v = wa[-1]['vars']
        assert len(v) == 5, v
        assert v[0] == '1400', v
        assert v[1] == 'Compra e venda — imóvel urbano', v            # ato por extenso, nunca o código
        assert v[2] == 'CORRETOR TESTE DA SILVA', v                   # apresentante (o formulário sobe para caixa alta)
        assert v[3] == 'COMPRADOR TESTE DE SOUZA', v                  # parte / comprador(a)
        assert v[4] == 'não se aplica', v                             # sem vendedor no formulário
        assert all(isinstance(x, str) and x.strip() for x in v), v    # a Meta recusa parâmetro vazio
        print('     recibo do WhatsApp:', ' | '.join(v))
        print('     protocolo 1400 registrado; cartão:', cartao['name'], '· escrevente (da sessão):', campos['Escrevente'])
        fr.locator('#veu .fechar').click()
        pg.locator('[data-voltar]:visible').first.click()
    passo('PROTOCOLO de ponta a ponta dentro do Hub: CV-Urbano → nº 1400 no banco, cartão (simulado) e escrevente da sessão', protocolar_de_verdade)

    def consulta_trello_extrato():
        pg.click('#cardConsulta'); pg.wait_for_selector('#paginaConsulta:not([hidden])')
        pg.fill('#conNumero', '1400')
        pg.click('#btnConsultar')
        pg.wait_for_selector('#conResultado:not([hidden])')
        txt = pg.inner_text('#conResultado')
        assert 'COMPRADOR TESTE DE SOUZA' in txt, txt[:400]            # título do cartão (mock)
        assert 'CORRETOR TESTE DA SILVA' in txt, txt[:400]            # apresentante vindo do registro do banco (o e-Protocolo grava em caixa alta)
        assert 'Compra e venda' in txt, txt[:400]                      # tipo de ato traduzido
        assert 'Aguardando última conferência' in txt, txt[:400]       # fase atual
        assert 'César Bravo' in txt, txt[:400]                         # com quem está
        assert 'Protocolo / Entrada' in txt and 'Curadoria de documentos' in txt and 'Preparação de minuta' in txt, txt[:700]
        assert 'Certidão de ônus atualizada' in txt, txt[:700]         # pendência do dossiê
        link = pg.evaluate("(document.querySelector('#conResultado a.con-link') || {}).href || ''")
        assert link.startswith('https://trello.com'), link
        pg.screenshot(path=SHOTS + '/14-t-consulta.png', full_page=True)
        pg.fill('#conNumero', '999444'); pg.click('#btnConsultar')
        esperar(lambda: 'não encontrado' in pg.inner_text('#conNota'), msg='recado de protocolo inexistente')
        pg.locator('#paginaConsulta [data-voltar]').click()
        pg.wait_for_selector('#paginaHub:not([hidden])')
    passo('T-Consulta: protocolo 1400 → extrato com partes, fases, fase atual com o Tabelião e link do cartão', consulta_trello_extrato)

    def redator_oficio_e_aviso():
        pg.locator('[data-voltar]:visible').first.click() if pg.locator('[data-voltar]:visible').count() else None
        pg.click('#cardRedator'); pg.wait_for_selector('#paginaRedator:not([hidden])')
        assert pg.evaluate('location.hash') == '#redator'
        # o tipo padrão é e-mail: cargo/órgão e texto recebido ficam escondidos
        assert not pg.is_visible('#paginaRedator [data-campo="cargo"]'), 'cargo não deveria aparecer no e-mail'
        assert not pg.is_visible('#paginaRedator [data-campo="recebido"]'), 'texto recebido não deveria aparecer no e-mail'
        assert pg.inner_text('#redRotuloBtn').lower() == 'escrever o e-mail', pg.inner_text('#redRotuloBtn')
        # WhatsApp esconde o assunto e o anexo
        pg.click('.red-tipo[data-tipo="whatsapp"]')
        assert not pg.is_visible('#paginaRedator [data-campo="assunto"]'), 'assunto não cabe no WhatsApp'
        assert not pg.is_visible('#paginaRedator [data-campo="anexo"]'), 'anexo não cabe no WhatsApp'
        # ofício exige cargo e órgão
        pg.click('.red-tipo[data-tipo="oficio"]')
        assert pg.is_visible('#paginaRedator [data-campo="cargo"]'), 'ofício precisa do cargo e órgão'
        assert pg.inner_text('#redRotuloBtn').lower() == 'escrever o ofício', pg.inner_text('#redRotuloBtn')
        pg.fill('#redDest', 'Juízo da 2ª Vara Cível da Comarca de Itabaiana/SE')
        pg.click('#btnRedigir')
        esperar(lambda: 'cargo e o órgão' in (pg.inner_text('#toast') if pg.is_visible('#toast') else ''),
                msg='aviso de cargo obrigatório')
        pg.fill('#redCargo', 'Juiz de Direito')
        pg.fill('#redContexto', 'informar que a escritura foi lavrada em 10/09/2026')
        pg.click('#btnRedigir')
        pg.wait_for_selector('#saidaRedator .giro')
        pg.wait_for_function("document.getElementById('saidaRedator').textContent.indexOf('TEXTO PRONTO') > -1", timeout=20000)
        saida = pg.inner_text('#saidaRedator')
        assert '===TEXTO_COPIAVEL===' not in saida, 'os marcadores não podem aparecer na tela'
        assert 'Ofício nº ____/2026' in saida, saida[:200]
        assert '⚠ CONFERIR' in saida
        assert pg.is_visible('#btnCopiarRed')
        assert not pg.is_visible('#btnCopiarZap'), 'ofício não tem versão de WhatsApp'
        # o botão Copiar leva só o texto, sem o bloco de conferência
        assert pg.is_visible('#redAjusteBox'), 'a caixa de ajuste deveria aparecer depois do primeiro texto'
        assert pg.inner_text('#redRotuloBtn').lower() == 'escrever o ofício', 'o botão voltou ao rótulo errado: ' + pg.inner_text('#redRotuloBtn')
        meta = pg.inner_text('#metaRed'); assert 'Redigido por' in meta and 'César' in meta, meta
        # aviso de pendência: sai também a versão curta para WhatsApp
        pg.click('.red-tipo[data-tipo="aviso_pendencia"]')
        pg.fill('#redDest', 'Corretor Teste da Silva')
        pg.fill('#redProtocolo', '1400')
        pg.click('#btnRedigir')
        pg.wait_for_function("document.getElementById('saidaRedator').textContent.indexOf('WHATSAPP') > -1", timeout=20000)
        assert pg.is_visible('#btnCopiarZap'), 'o aviso de pendência precisa do botão da versão curta'
        assert 'VERSÃO CURTA PARA WHATSAPP' in pg.inner_text('#saidaRedator')
        with open('/tmp/gemini-chamadas.json', encoding='utf-8') as f: ch = json.load(f)[-1]
        assert 'REDATOR CN2O' in ch['prompt'], 'prompt do Redator não chegou ao modelo'
        assert 'TIPO: aviso_pendencia' in ch['observacoes'], ch['observacoes'][:300]
        assert 'DADOS DO PROTOCOLO 1400' in ch['observacoes'], 'o Hub deveria ter lido o protocolo 1400'
        assert 'Escrevente que está redigindo: César Bravo' in ch['observacoes'], 'quem assina tem de vir da sessão'
        pg.screenshot(path=SHOTS + '/26-redator.png')
        pg.locator('[data-voltar]:visible').first.click()
    passo('Redator CN2O: tipo muda os campos, ofício exige cargo, aviso de pendência sai com versão de WhatsApp e lê o protocolo', redator_oficio_e_aviso)

    def calculadora_embutida():
        pg.click('#cardCalculadora')
        pg.wait_for_selector('#paginaEmbutida:not([hidden])')
        fr = pg.frame_locator('#molduraEmbutida iframe:not([hidden])')
        assert fr.locator('body').inner_text(timeout=8000).strip() != ''
        pg.click('#paginaEmbutida [data-voltar]')
    passo('Calculadora abre embutida', calculadora_embutida)

    def rota_direta():
        pg.goto(SITE + '#analista'); pg.wait_for_selector('#paginaAnalisador:not([hidden])')
        pg.goto(SITE + '#protocolo'); pg.wait_for_selector('#paginaEmbutida:not([hidden])')
        pg.goto(SITE)
        pg.wait_for_selector('#paginaHub:not([hidden])')
    passo('atalhos diretos (#analista, #protocolo) abrem a ferramenta certa', rota_direta)

    def clausulas():
        pg.click('#cardClausulas'); pg.wait_for_selector('#veuClausulas.aberto')
        pg.click('.tema-cab >> nth=0'); pg.click('.clausula >> nth=0')
        pg.wait_for_selector('#toast:not([hidden])'); assert 'copiada' in pg.inner_text('#toast')
        pg.keyboard.press('Escape')
    passo('Cláusulas do Guia: abre tema e copia', clausulas)

    def sessao_expirada():
        sql('DELETE FROM sessoes')
        pg.click('#cardExtrator'); pg.evaluate("document.getElementById('entradaExtrator').value = 'sessao'"); pg.click('#btnGerar')
        pg.wait_for_selector('#telaLogin:not([hidden])', timeout=10000)
        assert 'expirou' in pg.inner_text('#msgLogin')
        assert pg.evaluate("localStorage.getItem('cn2o_token')") is None
    passo('sessão derrubada no servidor → volta ao login com "Sua sessão expirou"', sessao_expirada)

    def celular():
        m = nav.new_context(viewport={'width': 400, 'height': 860}, locale='pt-BR')
        m.route('**/*', lambda r: r.abort() if 'fonts.g' in r.request.url else r.continue_())
        mp = m.new_page(); mp.goto(SITE); mp.wait_for_selector('#telaLogin:not([hidden])')
        mp.fill('#campoLogin', 'cesar.bravo'); mp.fill('#campoSenha', 'senha-cesar-123'); mp.click('#btnEntrar')
        mp.wait_for_selector('#app:not([hidden])'); mp.wait_for_selector('#muralAvisos .aviso-row')
        larg = mp.evaluate('document.documentElement.scrollWidth')
        assert larg <= 402, larg
        mp.screenshot(path=SHOTS + '/07-celular.png', full_page=True)
        m.close()
    passo('tela de celular (400 px) sem rolagem horizontal', celular)

    pg.goto(SITE); pg.wait_for_selector('#telaLogin:not([hidden])')
    pg.fill('#campoLogin', 'cesar.bravo'); pg.fill('#campoSenha', 'senha-cesar-123'); pg.click('#btnEntrar')
    pg.wait_for_selector('#muralAvisos .aviso-row')
    pg.screenshot(path=SHOTS + '/00-hub-desktop.png', full_page=True)
    nav.close()

relevantes = [e for e in erros_console if 'Failed to load resource' not in e and 'fonts.g' not in e]
print(f'\n{ok} ok, {falhas} falha(s); erros de console relevantes: {len(relevantes)}')
for e in relevantes[:10]: print('   console:', e[:200])
sys.exit(1 if falhas else 0)
