/* ============================================================
   Declaração do ITCMD "causa mortis" (SEFAZ/SE) — Hub CN2O · Calculadora ITCMD
   ------------------------------------------------------------
   Reproduz o formulário oficial "DECLARAÇÃO DO ITCMD 'CAUSA MORTIS' (Inventário/
   Sobrepartilha)" da Coordenadoria do ITCMD (12 quadros), já preenchido com o que a
   Calculadora apurou (inventariado, meação, quinhões, bens, dívidas, cálculo) e com os
   dados complementares do bloco "E · Declaração ITCMD (SEFAZ)" da tela (inventariante,
   tipo de inventário, cessão, renúncia, responsável). O que não consta fica em branco
   para o advogado completar. Usa o PDFMini do Hub (pdf-mini.js); fora do Hub o botão
   avisa que a geração só existe dentro do Hub.

   Layout: A4, margens de 15 mm, grade de 180 mm; rótulos em negrito 7,5 pt, valores em
   8,5 pt, faixas de seção em cinza-claro. Alinhamentos corrigidos em relação ao modelo
   (todas as colunas na mesma grade; valores em R$ à direita; datas alinhadas).
============================================================ */
(function () {
  'use strict';
  const Fr = (window.ITCMD && window.ITCMD.Fr) || function () { };
  const BRASAO_SE = '/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCAB2AGQDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD7LooooAKKKCcUAB4qpe6jY2as11eW8IUZO+QAj8K8g+Onxfm8P6ZqOn+D4DqGp2cscN9Ki7hZ+YQFYD+LGea47X/AVzrNqP7Y1G41XxDYwLcT6mkxSO5DjIQL046UAe7QeOvCk14LVNat/MJwNzYH51vwXVvP/qZ4ZRjPyOG/lXwldaIdXsptPkVoIA5dnWfDKU525960PBmteJNF1NNT0W/fTp9RQiWCWXzF08Rjgc9d/wDWgD7jorzH4GfFa0+IGkbL22Gm61CzJNaM2S2ON4+vWvTqACiiigAooooAKKKKACuE+O/jP/hBPhjq3iER+ZLEnlxLnnLcZ/DrXdmvL/i9o9l4m8VeGvDWrIZtNvBKZos8MQOKAPmf4c6tfabeaXe/2lLcLIJGu5Ps5kFz5nTd/u5716BrS6vZ6FYWuia5/ayWxke5dTgqr84Y+1angPTW8C+INf07UdU03S9B09XUPJtdpw3AAB6YrzbR/iR8OdHs9Z0mTVptLknnLTFUMn2oZ4/3aAK9v4e1CazmvdN0t5dNST9/KZv4ie9UvEFknhyS6kfTrhoXaNZimW37jx9MVs6F8V/hfY6D4q0R/EN0bfWNhgYQH9wy9xXbeBfHHw61OXw5peneLItQaCNzq81zBt80gfuxyOOeKAPLo9et/CfiHU9e0y4mtbnQ3g86QqQGWTtjvX3B4V1e213w/Y6vaSiSG6hV1YepHNfNWgeFZ/iF4u1iLxFpdrFpzxSMRAwbhQdhOOvavY/2dIWtvhRpdsZDIIZJY1Y/3Q5AoA9GooooAKKKKACiiigAryn9pqx15fh1deIPCcjQ69pQ32zqMnYSN4H4V6tUV1DHcQPDKgeORSjqehB4NAH5ayTXPiUW2o6hf3V9LI0jatumKhSOVrLuraBfClzrXkqj3kwjjR1yUAOO9etfHP4R6p4N8e61BYW7p4X1BhOjIcsT1IA68c15ZrN+mpW6cBNNQhVxxvK/yoAi1JLK01rS5Eji8lEBmbyxjJFbJ0+yTVvs5QiDWkLI0fyCNl5HI6c1yGoXaXt19ka42oxUZx0xXVz6lF5UelagrCIhTatGMuzDpjFAFrwV4x8deAr6ztfDmtzx6lfSGC4tXHmHaWwvX2r9GfhZokvh/wADaZptw264WPzZj/ttyf1NfKf7IPwp1DWfHdz478XWm1bHb9ijYZWQkHn8K+1FGBQAtFFFABRRRQAVV1S/ttNsZb26ZlhiGXIXJA+lWqp6xBPcafLBbSLHLINocruAB68UAeA+Iv2nNDs/G8mi6XAL+BWRIyTt80n73XpivetG1ex1S1imtZ45C6BmVGzsyOh9K+Jvjl8JLTTPGV5eabayXK2o828kUFdztyPpzXo37E2l+Lok1XUtYkuLe1kYB0mziUDO3GemBQB7Z8WfDj6tpCalp8CvqlgD5BflfLP+sBHfjNfn7+0X4Wg8OazFf6EhTw7q+XtVPBEi48zjtzX6anbJH1DqwxkcgivjT9rfwNquq+KItE0O0iuklw1nFJIIltT/ABYz1zQB8drK4mEmfmHevpb9m3wP/aqjxTdwCbUpT5eg20gysy8iQnPpzXm4+A/xIQktpFr8vLA3S9B+NfYn7I3hqa18LrJqkSo9i22ztgdwtc53YbvmgD2fwXoNt4c8PW2lWy7UiBJ/3icn9TW1XnnxS+KGneBxHG9lNeTNKiMqjAXceua7yzuo7myhu1IWOWNXBJxwRmgCeimxukihkYMp7g06gAooooAK4T42Sarb+D5LvSvFw8MSREE3Rt/Nz7Yru6ralY2mo2MtlewJPBKpV0YZBFAHxR8U5/inodtp2sWXiJPFdr4kA+1rFCAB5eNoOPu5r0H4S/FjWvGcsfhbU7CXw1HZIFvZDDtVh6BvevfNB8FeG9F0iXSdP01Us5G3NG53c+2elXr7w/pF5p72E9hB9ncAFUQKTj3FAHzb4l+JPiD4f/FKDQdL1611TQNRwLG2LqWhP8W5u3NYnxo0bUfHGt20OtawXvSvmWQtXwLXHPJHWvapvgB8LP7TutWl8OySXU4y7GdjjH93nivOrbR9G0a7naxikhgBZYI3cu0f40AfL+uf8JrDf6hYg6hdR7hG94JmG1RwTivq/wDZel1fTPCM0mm6qus6bCoPkSHbIDj5uvJxWP4esopEvTPaq0czc5T71L4a8G6gniyW40S+eGWYZht0banvkUAdn8QdO8Q/E/TUudIsbe3srS4VlR3G+7weQe6gVi/GD4z22iaPqHhObT5LK+tY4Y5ZYm3JEGxjBFS6Fe6d4H1jXo/Gd+1rPeW7HiXCx8fwj3rgvC/gxfEHwXXxDLqS3ML6kWLON73q+ZwCeox/SgD6P+FOraZL4L06KLV0upFjBdpjsYkjPQ12cbq4yrKw/wBk5rzrxf8ACnw54psbGcCfTr+1gQW89vIVCcd1HWtn4aeErvwnp01pda3Nqm8gq8g5WgDrqKKKACiiigAooooA5/4ha8nhrwjf61IpZLZMt9K+F/E3x4t21y5t9H0wXKOxKSs2Oe9fcnxK0Y6/4J1TSlcK00LY/AV8A2Hwv0fVzIIJzDM8rqkfeQqefpQBc0/40eJYF3XFrEYeSihhz7V6r8BfjPY6/wCO9Ltr2x/s+VyUUKd2/PGfavGdU+HEOkWjvcWT7E4wJM5rp/2T/Cv9ofGuxmtrXyLLTwzXMRO7J/hOe1AHq/xz0S51j4ja9car4XbUdPtIEW3l87bksMdKv/Abwzqmh2eleFtUgMOn3TvOluX3eV3Fb3xYtNU1XxnqFlZMxACMUBwGArS+HmpDV/F+kxxJibT42S6TOfLOMDNAHtEahVCgcAYH4U6kH9aWgAooooAbK+xCRjODgE4ya43SPiLodxdXGnX7tY6nattmtmUnHPBB75rpNf07+1NMltBO0DN92ReqmvOYvBOs6J4jj151TxJMiskasBGY8+vrQB3XinxBBpHh+bU1eOQLtC4boWOAf1rj/E/jrU/Bmkw3OqQQapHMwKTRSgde34V5jrOjeJbTxDqE2sWtxDp1wrf6ErFwSehB9q4Twpp8j+HNdi16C9vLHQZC0RmdgZQx6AHrigD3/R/jX4U1bVJ9FlZoLlY/nC/MBke1fMfjCFdJ8ZX83ha+kvLi3kL7GQqIgxyR+NdB4S1LwakL3mj2Z0y+fOx5uTu7detdH4B+GmtePF1fUb3xKljfMdjyRwg71PTigDzGe58X6navLaeHWFtcD5JWbIQj7xHrXoH7MOo+Dvhm3iDV/EmviO81N1ygQt5IGSQSOnNemH4J6vF4T0zQY/HMkVvpwcq/kDLbupPNeA614Oh8Iardpca4LzQbiUCe5dATevngAfw4NAHovjDx9ptzdat4j8O+JxqCzyRxxxtHsKZOMV6J8NbObwjrUN3e6NFHLryB7q6WcMVOMrhfevKNX8GaZpllYahqWgxTJqQUxNDMAMDocD0FQxPq2maje6uL28MFq8aaZKMybQT8w2+1AH18biFfvTRDvy4rCt/Gnh+41+HRILx5L2bdsRYyV465OMCuYgh0C/tENlZ3Wrak0QLbmaMEkdaq+E/B3jGz1BbpNYh0uEyZmh8kSNMPTd2oA9TFFNAbAG7nHNFADqMUUUAMeNH+8iN/vDNZeqeHtG1E/wCmWET+oC4DfXHWiigDnNY+FngTVJYpLnQ4xJH/AKtozt2/lW14P8Kab4YinjsA374jdn2oooA3nRXRkYcEEGvPtT+EvhvVJUGoK09tExaKE9FJ60UUAalt8PPCdvFBENPd1g/1YeQttrY0zw9oun5+yWESZ/vLkfrRRQBqJFGhykaL/urin0UUAFFFFAH/2Q==';
  const MM = 72 / 25.4;
  const X0 = 15, LARG = 180, Y0 = 12, YMAX = 284;
  const R = 7.5, V = 8.5, S = 8.5;   // rótulo · valor · seção (pt)
  const CINZA = '#D9D9D9', CINZA2 = '#EFEFEF';
  const fmt = v => 'R$ ' + (Math.round((+v || 0) * 100) / 100).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const dataBR = iso => iso && /^\d{4}-\d{2}-\d{2}$/.test(iso) ? iso.split('-').reverse().join('/') : (iso || '');
  const pct = v => (v * 100).toLocaleString('pt-BR', { maximumFractionDigits: 2 }) + '%';
  const arred = v => Math.round((+v || 0) * 100) / 100;
  const lh = pt => pt * 1.25 / MM;          // entrelinha em mm
  const REGIMES = { parcial: 'Comunhão parcial de bens', universal: 'Comunhão universal de bens', separacao_conv: 'Separação convencional de bens', separacao_obrig: 'Separação obrigatória de bens', aquestos: 'Participação final nos aquestos' };
  const ESTADO = { casado: 'Casado(a)', uniao: 'Em união estável', solteiro: '' };
  const ESTADO_OBITO = { solteiro: 'Solteiro(a)', viuvo: 'Viúvo(a)', divorciado: 'Divorciado(a)', separado: 'Separado(a)' };

  /* ---------- dados ---------- */
  // Monta o objeto plano que o formulário imprime (também usado pelos testes).
  // fração do excedente sobre o item arrolado e sobre o bem inteiro (só quando há um único bem e a fração difere da fração "da herança")
  function fracaoBemInteiro(pat, excFr, parenteses) {
    if (!pat || !pat.bens || pat.bens.length !== 1 || !excFr) return '';
    const b0 = pat.bens[0];
    const doItem = b0.herancaFr ? excFr.vezes(b0.herancaFr) : excFr;
    const doBem = doItem.vezes(new Fr(Math.round((+b0.fracao || 100) * 100), 10000));
    const partes = [];
    if (doItem.txt() !== excFr.txt()) partes.push(doItem.txt() + ' do item arrolado');
    if (doBem.txt() !== doItem.txt() || doBem.txt() !== excFr.txt()) partes.push(doBem.txt() + ' do bem inteiro');
    if (!partes.length) return '';
    return parenteses ? ` (${partes.join('; ')})` : ', ' + partes.join(', ');
  }
  function dadosDeclaracao(S, inv, opts) {
    opts = opts || {};
    const f = inv.falecido, d = f.decl || {}, pat = inv.pat, it = inv.itc;
    const hoje = S.hoje || new Date().toISOString().slice(0, 10);
    const temConj = pat.rg.temConjuge;
    const renunciantes = (f.descendentes || []).concat(f.colaterais || []).filter(x => x.condicao === 'renuncia' && (x.nome || '').trim()).map(x => x.nome);
    const bens = pat.bens.map((b, i) => {
      // matrícula/inscrição vêm do próprio bem calculado (motor carrega b.matricula/b.inscricao — inclusive nos bens herdados do cumulativo, M2)
      const matricula = b.matricula || '', inscricao = b.inscricao || '';
      let desc = b.descricao;
      if (matricula) { const m = String(matricula).trim(); if (m && desc.includes(m)) desc = desc.replace(new RegExp('\\s*[—–-]\\s*matr[ií]cula\\s*' + m.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\s*', 'i'), ' ').replace(/\s+/g, ' ').trim(); }
      const imovel = b.tipo === 'imovel_urbano' || b.tipo === 'imovel_rural';
      return { item: i + 1, descricao: (b.fracao !== 100 ? `${b.fracao.toLocaleString('pt-BR', { maximumFractionDigits: 4 })}% de ` : '') + desc + (b.comum ? ' (bem comum)' : ' (bem particular)'),
        matricula, inscricao, valor: b.valor, imovel };
    });
    // partilha: meação + herdeiros — quinhão LEGAL (Código Civil) e REAL (partilha acordada, quando
    // difere: bloco F da tela); excedente = real − legal quando positivo (Manual, item 8)
    const real = inv.real || { ativa: false, rows: [], beneficiarios: [], cedentes: [], totalExcedente: 0, natureza: 'nao_onerosa' };
    const realDe = id => real.rows.find(r => r.id === id);
    const cpfs = (f.partilhaReal && f.partilhaReal.cpfs) || {};
    const nomeCpf = (nome, id) => nome + (cpfs[id] ? ', CPF ' + cpfs[id] : '');
    const partilha = [];
    const unicoItem = pat.bens.length === 1;
    // fração de um quinhão sobre a base que o formulário pede ("Percentual ou Fração do(s) Bem(ns)"): com um só bem,
    // fração do item arrolado; com vários, percentual do monte-mor. Legal e real saem sempre sobre o MESMO denominador (R25).
    const sobreBens = (frHeranca, valor) => {
      if (unicoItem && frHeranca) { const fr = frHeranca.vezes(pat.bens[0].herancaFr); if (fr.zero()) return 'nada'; if (fr.txt() === '1') return '100% do item 1'; return `${fr.txt()} do item 1`; }
      const p = pat.monteMor > 0 ? Math.max(0, Math.min(1, valor / pat.monteMor)) : 0;
      return p <= 0 ? 'nada' : `${pct(p)} do monte-mor`;
    };
    const conjNome = (f.conjuge && f.conjuge.nome) || '';
    if (temConj && pat.meacao > 0) { const rr = realDe('meacao'); partilha.push({ id: 'meacao', nome: nomeCpf(conjNome, 'meacao'), condicao: f.estadoCivil === 'uniao' ? 'Companheiro(a) meeiro(a)' : 'Cônjuge meeiro(a)', fracao: (pat.rg.meacaoSobre === 'todos' ? '1/2 dos bens (meação)' : '1/2 dos bens comuns (meação)') + (rr && rr.real !== rr.legal ? `; real: ${sobreBens(null, rr.real)}` : ''), real: rr ? rr.real : pat.meacao, legal: pat.meacao, excedente: rr ? rr.excedente : 0, meacao: true }); }
    it.linhas.forEach(l => {
      let fr;
      if (pat.herancaPart > 0 && pat.herancaComum > 0 && l.frPart.txt() !== l.frComum.txt()) fr = [l.frPart.zero() ? '' : `${l.frPart.txt()} dos particulares`, l.frComum.zero() ? '' : `${l.frComum.txt()} dos comuns`].filter(Boolean).join('; ');
      else fr = `${(pat.herancaPart > 0 ? l.frPart : l.frComum).txt()} da herança`;
      const rr = realDe(l.id);
      const frUnica = (pat.herancaPart > 0 && pat.herancaComum > 0 && l.frPart.txt() !== l.frComum.txt()) ? null : (pat.herancaPart > 0 ? l.frPart : l.frComum);
      const legalBens = sobreBens(frUnica, l.quinhao);
      // com um só bem que é todo herança (particular), "1/7 da herança" = "1/7 do item 1": não repetir
      const legalTxt = (unicoItem && frUnica && pat.bens[0].herancaFr.txt() === '1') ? legalBens : `${fr} (= ${legalBens})`;
      let fracao;
      if (rr && rr.real !== rr.legal) fracao = `legal: ${legalTxt}; real: ${rr.realFr ? sobreBens(rr.realFr, rr.real) : sobreBens(null, rr.real)}`;
      else fracao = legalTxt;
      partilha.push({ id: l.id, nome: nomeCpf(l.nome, l.id), condicao: condicaoDe(l.papel), fracao, real: rr ? rr.real : l.quinhao, legal: l.quinhao, excedente: rr ? rr.excedente : 0, cede: rr ? rr.cede : 0, situacao: l.situacao, aliq: l.aliq, imposto: l.imposto });
    });
    // cônjuge meeiro(a) E herdeiro(a) concorrente: UMA linha com as duas condições (Manual, item 8)
    const iMe = partilha.findIndex(x => x.id === 'meacao'), iCo = partilha.findIndex(x => x.id === 'conj');
    if (iMe >= 0 && iCo >= 0) {
      const me = partilha[iMe], co = partilha[iCo];
      partilha[iMe] = { id: 'conjuge', nome: nomeCpf(conjNome, cpfs.conj ? 'conj' : 'meacao'), condicao: `${me.condicao} e herdeiro(a) concorrente`, fracao: `meação: ${me.fracao}; quinhão: ${co.fracao}`, real: arred(me.real + co.real), legal: arred(me.legal + co.legal), excedente: arred(me.excedente + co.excedente), cede: co.cede || 0, meacao: true, situacao: co.situacao, aliq: co.aliq, imposto: co.imposto };
      partilha.splice(iCo, 1);
    }
    // texto de ligação com a Inter Vivos I (Manual Causa Mortis, item 8, nota)
    let ligacao = '';
    if (real.ativa && real.totalExcedente > 0) {
      const ben = real.beneficiarios.map(b => `${b.nome}${cpfs[b.id] ? ', CPF ' + cpfs[b.id] : ''} (quinhão legal ${fmt(b.legal)}; quinhão real ${fmt(b.real)}; excedente ${fmt(b.excedente)}${b.excedenteFr ? ' = ' + b.excedenteFr.txt() + ' da herança' + fracaoBemInteiro(pat, b.excedenteFr) : ''})`).join('; ');
      const ced = real.cedentes.map(c => c.nome).join(', ');
      const taxaTxt = real.taxaUniforme != null ? (real.taxaUniforme >= 1 - 1e-9 ? 'todo (100%)' : (real.taxaFr ? `${real.taxaFr.txt()} (${pct(real.taxaUniforme)})` : pct(real.taxaUniforme))) : null;
      if (real.natureza === 'onerosa') ligacao = `CESSÃO ONEROSA NA SUCESSÃO DE ${f.nome || ''}: ${ced} cedem parte do próprio quinhão a ${ben}. O excedente decorre de transmissão onerosa (ITBI municipal sobre imóveis; escritura de cessão e guia de ITBI — relação documental, item 30). Os quinhões legais causa mortis não se alteram.`;
      else ligacao = `TRANSMISSÃO NÃO ONEROSA NA SUCESSÃO DE ${f.nome || ''}: ${ced} ${real.cedentes.length > 1 ? 'transferem' : 'transfere'} gratuitamente a ${ben}${taxaTxt ? `, cada qual ${taxaTxt} do próprio quinhão legal` : ''}. O excedente corresponde à soma das cessões e não integra novamente o quinhão legal causa mortis; o imposto causa mortis é apurado sobre os quinhões legais. Acompanha a DECLARAÇÃO DO ITCMD "INTER VIVOS I" (excedente de meação/quinhão decorrente de inventário), conforme a nota do item 8 do Manual Causa Mortis e o item 33 da relação documental extrajudicial. Frações exatas prevalecem sobre os arredondamentos em reais.`;
    }
    // quadro 6: cessão de direitos hereditários — automática pela partilha acordada quando há herdeiro cedente
    const herdeiroCede = real.ativa && real.cedentes.some(c => !c.meacao) && real.totalExcedente > 0;
    const cessaoAuto = herdeiroCede ? (real.natureza === 'onerosa' ? 'onerosa' : 'nao_onerosa') : 'nao';
    const tributados = it.linhas.filter(l => l.situacao === 'tributado');
    const aliqs = [...new Set(tributados.map(l => (l.aliq * 100).toFixed(0)))];
    const baseCalculo = tributados.reduce((s, l) => s + (l.baseTrib != null ? l.baseTrib : l.quinhao), 0);   // art. 8º, VI: só a parte não isenta
    const isentos = it.linhas.filter(l => l.situacao === 'isento');
    const baseLegal = isentos.length ? (it.unicoImovelOk ? 'Lei 7.724/2013, art. 8º, IV e VI' : 'Lei 7.724/2013, art. 8º, IV (quinhão até 500 UFP/SE)') : '';
    const inventariante = d.inventariante || {};
    const responsavel = d.responsavel || {};
    return {
      tipo: d.tipo || 'extrajudicial', sobrepartilha: !!d.sobrepartilha,
      dataAbertura: dataBR(d.dataAbertura), processo: d.processo || '', vara: d.vara || '', dataDistribuicao: dataBR(d.dataDistribuicao), dataHomologacao: dataBR(d.dataHomologacao), dataTransito: dataBR(d.dataTransito),
      inventariado: { nome: f.nome || '', cpf: d.cpf || '', obito: dataBR(f.obito), estadoCivil: ESTADO[f.estadoCivil] || ESTADO_OBITO[d.estadoCivilObito] || '', regime: temConj ? (REGIMES[f.regime] || '') : '', dataCasamento: temConj ? dataBR(d.dataCasamento) : '' },
      inventariante: { nome: inventariante.nome || '', cpf: inventariante.cpf || '', endereco: inventariante.endereco || '', contato: inventariante.contato || '' },
      bens, monteMor: pat.monteMor,
      dividas: pat.dividas > 0 ? [{ item: 1, descricao: d.dividasDescricao || 'Dívidas do espólio (conforme documentação)', valor: pat.dividas }] : [],
      cessao: (!d.cessao || d.cessao === 'auto') ? cessaoAuto : d.cessao, ligacao, excedente: real.ativa ? real.totalExcedente : 0, natureza: real.natureza,
      renuncia: renunciantes.length ? (d.renuncia && d.renuncia !== 'auto' ? d.renuncia : (d.tipo === 'judicial' ? 'termo' : 'escritura')) : (d.renuncia && d.renuncia !== 'auto' ? d.renuncia : 'nao'),
      renunciantes,
      partilha,
      calculo: { monteMor: pat.monteMor, dividas: pat.dividas, meacao: pat.meacao, montePartivel: pat.heranca, base: baseCalculo, aliquota: aliqs.length === 1 ? aliqs[0] + '%' : aliqs.length ? aliqs.map(a => a + '%').join(' / ') : (tributados.length ? '' : 'isento'), principal: it.total, multa: 0, total: it.total, multaEstimada: it.multaCabivel ? it.totalMulta : 0, baseLegal, ufp: it.ufp },
      cartorio: { nome: 'Cartório de Notas do 2º Ofício de Itabaiana/SE', municipio: 'Itabaiana/SE', comarca: 'Itabaiana/SE' },
      responsavel: { nome: responsavel.nome || inventariante.nome || '', cpf: responsavel.cpf || (responsavel.nome ? '' : inventariante.cpf || '') },
      localData: (d.local || 'Itabaiana/SE') + ', ' + dataBR(hoje),
      geradoEm: new Date().toLocaleString('pt-BR'), quem: opts.quem || ''
    };
  }
  function condicaoDe(papel) {
    const p = String(papel || '');
    if (/neto/.test(p)) return 'Neto(a), por representação' + (p.includes(' de ') ? ' de ' + p.split(' de ').slice(1).join(' de ') : '');
    if (/sobrinho/.test(p)) return 'Sobrinho(a)' + (p.includes('representação') ? ', por representação' : ', por cabeça');
    if (/concorrente/.test(p)) return p.replace(/\s*\(concorrente[^)]*\)/, '') + ' — herdeiro(a) concorrente';
    if (/herdeiro único/.test(p)) return p.replace(/\s*\(.*\)$/, '') + ' — herdeiro(a) único(a)';
    return p.charAt(0).toUpperCase() + p.slice(1);
  }

  /* ---------- desenho ---------- */
  function Desenho(pdf) { this.pdf = pdf; this.y = Y0; this.pagina = 1; }
  Desenho.prototype.garantir = function (h) { if (this.y + h > YMAX) { this.rodape(); this.pdf.novaPagina(); this.pagina++; this.y = Y0; } };
  Desenho.prototype.rodape = function () {
    const p = this.pdf; p.fonte(false, 7);
    p.texto(X0, 290, 'Gerado pelo Hub CN2O — Calculadora ITCMD/SE — em ' + this._gerado + ' · conferir antes de assinar · página ' + this.pagina);
    p.texto(X0, 290, 'Impresso em 3 vias', { alinhar: 'dir', larguraMm: LARG });
  };
  Desenho.prototype.banda = function (titulo, sub) {
    const p = this.pdf; p.fonte(false, 7.5);
    const subs = sub ? p.quebrar(sub, LARG - 4, false, 7.5) : [];
    const h = 5.2 + subs.length * 3.2; this.garantir(h + 6);
    p.retangulo(X0, this.y, LARG, h, { preencher: CINZA, borda: true, espessura: 0.3 });
    p.fonte(true, S); p.texto(X0, this.y + 3.7, titulo, { alinhar: 'centro', larguraMm: LARG });
    p.fonte(false, 7.5); subs.forEach((l, j) => p.texto(X0, this.y + 6.9 + j * 3.2, l, { alinhar: 'centro', larguraMm: LARG }));
    this.y += h;
  };
  Desenho.prototype.subBanda = function (titulo) {
    const h = 4.6; this.garantir(h + 6);
    const p = this.pdf;
    p.retangulo(X0, this.y, LARG, h, { preencher: CINZA2, borda: true, espessura: 0.3 });
    p.fonte(true, R + 0.5); p.texto(X0, this.y + 3.3, titulo, { alinhar: 'centro', larguraMm: LARG });
    this.y += h;
  };
  // Linha de células "Rótulo: valor". cel = { rotulo, valor, fr, alinhar:'dir', minH, valorAbaixo }
  Desenho.prototype.linhaCampos = function (cels, minH) {
    const p = this.pdf;
    const preps = []; let x = X0, maxH = minH || 6.4;
    cels.forEach(c => {
      const w = LARG * c.fr, pad = 1.6, wi = w - 2 * pad;
      p.fonte(true, R); const rot = c.rotulo ? p.quebrar(c.rotulo, wi, true, R) : []; const wr = rot.length === 1 ? p.larguraTexto(rot[0]) : wi;
      let linhas = [], abaixo = !!c.valorAbaixo || rot.length > 1;
      const v = String(c.valor == null ? '' : c.valor);
      if (v) {
        p.fonte(false, V);
        const cabe = wi - wr - 1.5;
        if (!abaixo && c.rotulo && p.larguraTexto(v) <= cabe && cabe > 10) linhas = [v];
        else { abaixo = true; linhas = p.quebrar(v, wi, false, V); }
      }
      const h = abaixo ? 2.2 + rot.length * lh(R) + linhas.length * lh(V) + 0.6 : Math.max(c.minH || 6.4, 2.2 + rot.length * lh(R) + 0.6);
      if (h > maxH) maxH = h;
      preps.push({ x, w, pad, wr, rot, linhas, abaixo, c });
      x += w;
    });
    this.garantir(maxH);
    const y = this.y;
    p.retangulo(X0, y, LARG, maxH, { espessura: 0.3 });
    preps.forEach((pr, i) => {
      if (i > 0) p.linha(pr.x, y, pr.x, y + maxH, { espessura: 0.3 });
      const yb = y + 1.9 + R * 0.9 / MM;
      p.fonte(true, R); pr.rot.forEach((l, j) => p.texto(pr.x + pr.pad, yb + j * lh(R), l));
      p.fonte(false, V);
      if (!pr.abaixo && pr.linhas.length) {
        if (pr.c.alinhar === 'dir') p.texto(pr.x + pr.pad, yb, pr.linhas[0], { alinhar: 'dir', larguraMm: pr.w - 2 * pr.pad });
        else p.texto(pr.x + pr.pad + pr.wr + (pr.wr ? 1.5 : 0), yb, pr.linhas[0]);
      } else pr.linhas.forEach((l, j) => p.texto(pr.x + pr.pad, yb + pr.rot.length * lh(R) + j * lh(V), l, pr.c.alinhar === 'dir' ? { alinhar: 'dir', larguraMm: pr.w - 2 * pr.pad } : undefined));
    });
    this.y += maxH;
  };
  // Tabela com cabeçalho repetido a cada página. cols = [{titulo, fr, alinhar}], linhas = [[texto…]]
  Desenho.prototype.tabela = function (cols, linhas, opts) {
    opts = opts || {};
    const p = this.pdf;
    const cab = () => {
      p.fonte(true, R);
      const lss = cols.map(c => p.quebrar(c.titulo, LARG * c.fr - 3, true, R));
      const h = Math.max(6.2, 1.8 + Math.max.apply(null, lss.map(l => l.length)) * lh(R) + 0.8); this.garantir(h + 7);
      const y = this.y; let x = X0;
      p.retangulo(X0, y, LARG, h, { preencher: CINZA2, borda: true, espessura: 0.3 });
      cols.forEach((c, i) => {
        const w = LARG * c.fr; if (i > 0) p.linha(x, y, x, y + h, { espessura: 0.3 });
        p.fonte(true, R); const ls = lss[i];
        ls.forEach((l, j) => p.texto(x + 1.5, y + (h - ls.length * lh(R)) / 2 + R * 0.9 / MM + j * lh(R), l, { alinhar: 'centro', larguraMm: w - 3 }));
        x += w;
      });
      this.y += h;
    };
    cab();
    const corpo = linhas.length ? linhas : [cols.map(() => '')];
    corpo.forEach(row => {
      const preps = []; let maxN = 1;
      cols.forEach((c, i) => { const w = LARG * c.fr; p.fonte(row.negrito ? true : false, V); const ls = p.quebrar(String(row[i] == null ? '' : row[i]), w - 3, !!row.negrito, V); if (ls.length > maxN) maxN = ls.length; preps.push({ w, ls }); });
      const h = Math.max(6.2, 2.2 + maxN * lh(V));
      if (this.y + h > YMAX) { this.rodape(); p.novaPagina(); this.pagina++; this.y = Y0; cab(); }
      const y = this.y; let x = X0;
      p.retangulo(X0, y, LARG, h, { espessura: 0.3 });
      preps.forEach((pr, i) => {
        if (i > 0) p.linha(x, y, x, y + h, { espessura: 0.3 });
        p.fonte(!!row.negrito, V);
        pr.ls.forEach((l, j) => p.texto(x + 1.5, y + 1.6 + V * 0.9 / MM + j * lh(V), l, cols[i].alinhar === 'dir' ? { alinhar: 'dir', larguraMm: pr.w - 3 } : cols[i].alinhar === 'centro' ? { alinhar: 'centro', larguraMm: pr.w - 3 } : undefined));
        x += pr.w;
      });
      this.y += h;
    });
  };
  Desenho.prototype.marcadores = function (itens) {   // [{marcado, texto, linhas:[…]}] em duas colunas
    const p = this.pdf;
    const preps = itens.map(it => { p.fonte(true, R + 0.5); const tit = p.quebrar(it.texto, LARG / 2 - 12, true, R + 0.5); p.fonte(false, V); const extra = (it.linhas || []).map(l => p.quebrar(l, LARG / 2 - 12, false, V)).flat(); return { it, tit, extra }; });
    const n = Math.max.apply(null, preps.map(pr => pr.tit.length + pr.extra.length));
    const h = 2.4 + n * lh(V) + 0.8;
    this.garantir(h);
    const y = this.y;
    p.retangulo(X0, y, LARG, h, { espessura: 0.3 });
    p.linha(X0 + LARG / 2, y, X0 + LARG / 2, y + h, { espessura: 0.3 });
    preps.forEach((pr, i) => {
      const x = X0 + i * LARG / 2;
      p.linha(x + 9, y, x + 9, y + h, { espessura: 0.3 });
      const yb = y + 1.9 + V * 0.9 / MM;
      p.fonte(true, V + 1); p.texto(x + 1.5, yb + 0.2, '('); p.texto(x + 6.8, yb + 0.2, ')'); if (pr.it.marcado) p.texto(x + 1.5, yb + 0.2, 'X', { alinhar: 'centro', larguraMm: 6.8 });
      p.fonte(true, R + 0.5); pr.tit.forEach((l, j) => p.texto(x + 10.5, yb + j * lh(V), l));
      p.fonte(false, V); pr.extra.forEach((l, j) => p.texto(x + 10.5, yb + (pr.tit.length + j) * lh(V), l));
    });
    this.y += h;
  };
  Desenho.prototype.nota = function (texto, negritoInicio) {
    const p = this.pdf; p.fonte(false, R);
    const ls = p.quebrar(texto, LARG - 3, false, R);
    const h = 2 + ls.length * lh(R) + 0.8; this.garantir(h);
    p.retangulo(X0, this.y, LARG, h, { espessura: 0.3 });
    ls.forEach((l, j) => p.texto(X0 + 1.5, this.y + 1.5 + R * 0.9 / MM + j * lh(R), l));
    this.y += h;
  };
  Desenho.prototype.cabecalho = function () {
    const p = this.pdf, h = 24, wDir = LARG * 0.30;
    this.garantir(h);
    const y = this.y;
    p.retangulo(X0, y, LARG, h, { espessura: 0.3 });
    p.linha(X0 + LARG - wDir, y, X0 + LARG - wDir, y + h, { espessura: 0.3 });
    try { p.imagemJpeg(BRASAO_SE, X0 + 2, y + 2, 13, 15.3); } catch (e) { }
    p.fonte(true, 8); p.texto(X0 + 18, y + 4.6, 'Governo de Sergipe'); p.texto(X0 + 18, y + 8.0, 'Secretaria de Estado da Fazenda'); p.texto(X0 + 18, y + 11.4, 'Coordenadoria do ITCMD');
    p.fonte(true, 11.5); p.texto(X0, y + 17.6, 'DECLARAÇÃO DO ITCMD “CAUSA MORTIS”', { alinhar: 'centro', larguraMm: LARG - wDir });
    p.fonte(false, 9); p.texto(X0, y + 21.6, '(Inventário/ Sobrepartilha)', { alinhar: 'centro', larguraMm: LARG - wDir });
    p.fonte(true, R); p.texto(X0 + LARG - wDir + 1.5, y + 4.4, '1. Nº da Declaração do ITCMD');
    p.fonte(false, R); p.texto(X0 + LARG - wDir + 1.5, y + 7.6, '(Uso da SEFAZ)');
    this.y += h;
  };

  function desenhar(pdf, D, des) {
    des._gerado = D.geradoEm;
    des.cabecalho();
    // 2
    des.banda('2. DADOS DO INVENTÁRIO/ SOBREPARTILHA - TIPO');
    const ext = D.tipo !== 'judicial', sob = D.sobrepartilha;
    des.marcadores([{ marcado: ext && !sob, texto: 'Inventário Extrajudicial', linhas: ['Data de Abertura do Inventário: ' + (ext && !sob ? D.dataAbertura : '')] },
      { marcado: ext && sob, texto: 'Sobrepartilha Extrajudicial', linhas: ['Data de Abertura da Sobrepartilha: ' + (ext && sob ? D.dataAbertura : '')] }]);
    const jud = !ext;
    des.marcadores([{ marcado: jud && !sob, texto: 'Inventário Judicial', linhas: ['Data de Distribuição: ' + (jud && !sob ? D.dataDistribuicao : ''), 'Processo nº: ' + (jud && !sob ? D.processo : ''), 'Vara/ Comarca: ' + (jud && !sob ? D.vara : ''), 'Data Homologação da Partilha: ' + (jud && !sob ? D.dataHomologacao : ''), 'Data do Trânsito em Julgado: ' + (jud && !sob ? D.dataTransito : '')] },
      { marcado: jud && sob, texto: 'Sobrepartilha Judicial', linhas: ['Processo de Sobrepartilha nº: ' + (jud && sob ? D.processo : ''), 'Vara/ Comarca: ' + (jud && sob ? D.vara : ''), 'Data Homologação da Sobrepartilha: ' + (jud && sob ? D.dataHomologacao : ''), 'Data do Trânsito em Julgado: ' + (jud && sob ? D.dataTransito : '')] }]);
    // 3
    des.banda('3. IDENTIFICAÇÃO DAS PARTES');
    des.subBanda('3.1. INVENTARIADO(A)');
    des.linhaCampos([{ rotulo: 'Nome:', valor: D.inventariado.nome, fr: 0.70 }, { rotulo: 'CPF:', valor: D.inventariado.cpf, fr: 0.30 }]);
    des.linhaCampos([{ rotulo: 'Data do óbito:', valor: D.inventariado.obito, fr: 0.20 }, { rotulo: 'Estado Civil:', valor: D.inventariado.estadoCivil, fr: 0.22 }, { rotulo: 'Regime de bens:', valor: D.inventariado.regime, fr: 0.30, valorAbaixo: !!D.inventariado.regime }, { rotulo: 'Data do Casamento/ União estável:', valor: D.inventariado.dataCasamento, fr: 0.28, valorAbaixo: !!D.inventariado.dataCasamento }]);
    des.subBanda('3.2. INVENTARIANTE');
    des.linhaCampos([{ rotulo: 'Nome:', valor: D.inventariante.nome, fr: 0.70 }, { rotulo: 'CPF:', valor: D.inventariante.cpf, fr: 0.30 }]);
    des.linhaCampos([{ rotulo: 'Endereço completo:', valor: D.inventariante.endereco, fr: 0.70, valorAbaixo: !!D.inventariante.endereco }, { rotulo: 'Telefone/ E-mail:', valor: D.inventariante.contato, fr: 0.30, valorAbaixo: !!D.inventariante.contato }]);
    // 4
    des.banda('4. BEM(NS)/ DIREITO(S)');
    const bens = D.bens.map(b => [String(b.item), b.descricao, b.matricula, b.inscricao, fmt(b.valor)]);
    if (D.bens.length) { const tot = ['', 'Total dos bens (monte-mor)', '', '', fmt(D.monteMor)]; tot.negrito = true; bens.push(tot); }
    des.tabela([{ titulo: 'Item', fr: 0.06, alinhar: 'centro' }, { titulo: 'Descrição Detalhada', fr: 0.46 }, { titulo: 'Matrícula de Registro (Bem Imóvel)', fr: 0.16, alinhar: 'centro' }, { titulo: 'Inscrição Municipal/ INCRA (Bem Imóvel)', fr: 0.16, alinhar: 'centro' }, { titulo: 'Valor (R$)', fr: 0.16, alinhar: 'dir' }], bens);
    // 5
    des.banda('5. DÍVIDA(S) DO ESPÓLIO');
    des.tabela([{ titulo: 'Item', fr: 0.06, alinhar: 'centro' }, { titulo: 'Descrição Detalhada', fr: 0.78 }, { titulo: 'Valor (R$)', fr: 0.16, alinhar: 'dir' }], D.dividas.map(x => [String(x.item), x.descricao, fmt(x.valor)]));
    // 6
    des.banda('6. CESSÃO DE DIREITOS HEREDITÁRIOS (Se houver) - TIPO');
    des.marcadores([{ marcado: D.cessao === 'onerosa', texto: 'Onerosa' }, { marcado: D.cessao === 'nao_onerosa', texto: 'Não Onerosa' }]);
    // 7
    des.banda('7. RENÚNCIA ABDICATIVA EM FAVOR DO MONTE MOR (Se houver) - TIPO');
    des.marcadores([{ marcado: D.renuncia === 'termo', texto: 'Por Termo Judicial', linhas: D.renuncia === 'termo' && D.renunciantes.length ? ['Renunciante(s): ' + D.renunciantes.join('; ')] : [] }, { marcado: D.renuncia === 'escritura', texto: 'Por Escritura Pública', linhas: D.renuncia === 'escritura' && D.renunciantes.length ? ['Renunciante(s): ' + D.renunciantes.join('; ')] : [] }]);
    // 8
    des.banda('8. PARTILHA');
    const part = D.partilha.map(x => [x.nome + (x.condicao ? ' — ' + x.condicao : ''), x.fracao, fmt(x.real), fmt(x.legal), fmt(x.excedente)]);
    if (D.partilha.length) { const tot = ['Total', '', fmt(D.partilha.reduce((s, x) => s + x.real, 0)), fmt(D.partilha.reduce((s, x) => s + x.legal, 0)), fmt(D.partilha.reduce((s, x) => s + x.excedente, 0))]; tot.negrito = true; part.push(tot); }
    des.tabela([{ titulo: 'Meeiro(a)/ Herdeiro(a) (Nome e Condição)', fr: 0.36 }, { titulo: 'Percentual ou Fração do(s) Bem(ns)/ Direito(s)', fr: 0.22 }, { titulo: 'Meação/ Quinhão Real (R$)', fr: 0.14, alinhar: 'dir' }, { titulo: 'Meação/ Quinhão Legal (R$)', fr: 0.14, alinhar: 'dir' }, { titulo: 'Excedente de Meação/ Quinhão (R$)', fr: 0.14, alinhar: 'dir' }], part);
    if (D.ligacao) des.nota(D.ligacao);
    des.nota('Nota: Havendo divisão do acervo patrimonial, que resulte em “excedente” de meação ou de quinhão, decorrente de transmissão “não onerosa”, providenciar o recolhimento do imposto “inter vivos” e preencher a DECLARAÇÃO DO ITCMD “INTER VIVOS I”.');
    // 9
    des.banda('9. USO DO CARTÓRIO', '(Campo de preenchimento obrigatório em se tratando de Inventário/ Sobrepartilha extrajudiciais)');
    des.linhaCampos([{ rotulo: 'Cartório:', valor: D.cartorio.nome, fr: 0.50 }, { rotulo: 'Município:', valor: D.cartorio.municipio, fr: 0.25 }, { rotulo: 'Comarca:', valor: D.cartorio.comarca, fr: 0.25 }]);
    des.linhaCampos([{ rotulo: 'Assinatura e Carimbo do(a) Funcionário(a):', valor: '', fr: 0.70 }, { rotulo: 'Data:', valor: '', fr: 0.30 }], 11);
    // 10
    des.banda('10. CÁLCULO DO IMPOSTO');
    des.linhaCampos([{ rotulo: 'Data de Vencimento:', valor: '', fr: 0.20 }, { rotulo: 'Monte Mor', valor: fmt(D.calculo.monteMor), fr: 0.20, valorAbaixo: true, alinhar: 'dir' }, { rotulo: 'Dívida do Espólio', valor: fmt(D.calculo.dividas), fr: 0.20, valorAbaixo: true, alinhar: 'dir' }, { rotulo: 'Meação Conjugal Legal', valor: fmt(D.calculo.meacao), fr: 0.20, valorAbaixo: true, alinhar: 'dir' }, { rotulo: 'Monte Partível', valor: fmt(D.calculo.montePartivel), fr: 0.20, valorAbaixo: true, alinhar: 'dir' }]);
    des.linhaCampos([{ rotulo: 'Base de Cálculo (total do Estado de SE)', valor: fmt(D.calculo.base), fr: 0.25, valorAbaixo: true, alinhar: 'dir' }, { rotulo: 'Alíquota (%)', valor: D.calculo.aliquota, fr: 0.13, valorAbaixo: true, alinhar: 'dir' }, { rotulo: 'Principal', valor: fmt(D.calculo.principal), fr: 0.155, valorAbaixo: true, alinhar: 'dir' }, { rotulo: 'Atualização', valor: '', fr: 0.155, valorAbaixo: true }, { rotulo: 'Multa', valor: D.calculo.multa ? fmt(D.calculo.multa) : '', fr: 0.155, valorAbaixo: true, alinhar: 'dir' }, { rotulo: 'Juros', valor: '', fr: 0.155, valorAbaixo: true }]);
    des.linhaCampos([{ rotulo: 'Desconto', valor: '', fr: 0.20, valorAbaixo: true }, { rotulo: 'Total a Pagar', valor: fmt(D.calculo.total), fr: 0.25, valorAbaixo: true, alinhar: 'dir' }, { rotulo: 'Data de Pagamento do DAE:', valor: '', fr: 0.30 }, { rotulo: 'Nº do DAE:', valor: '', fr: 0.25 }]);
    des.linhaCampos([{ rotulo: 'Nº do Parcelamento:', valor: '', fr: 0.35 }, { rotulo: 'Base Legal se houver isenção ou imunidade:', valor: D.calculo.baseLegal, fr: 0.65, valorAbaixo: !!D.calculo.baseLegal }]);
    des.nota(`Estimativa da Calculadora ITCMD do Hub CN2O (UFP/SE ${fmt(D.calculo.ufp)}): principal ${fmt(D.calculo.principal)} sobre os quinhões legais tributados (DAE por herdeiro — o quinhão legal de cada um é a base do seu DAE).${D.calculo.multaEstimada ? ' Se o inventário não foi requerido em 120 dias do óbito, multa de 20% (Lei 7.724/2013, art. 27, I) estimada em ' + fmt(D.calculo.multaEstimada) + ', a confirmar no DAE.' : ''} Atualização, multa e juros de mora são os do DAE emitido pela SEFAZ.`);
    // 11
    des.banda('11. RESPONSÁVEL');
    des.linhaCampos([{ rotulo: 'Local/ Data:', valor: D.localData, fr: 0.26, valorAbaixo: true }, { rotulo: 'Nome completo:', valor: D.responsavel.nome, fr: 0.32, valorAbaixo: true }, { rotulo: 'CPF:', valor: D.responsavel.cpf, fr: 0.17, valorAbaixo: true }, { rotulo: 'Assinatura:', valor: '', fr: 0.25 }], 13);
    // 12
    des.banda('12. RECEPÇÃO DA DECLARAÇÃO (Uso da SEFAZ)');
    des.nota('Documentação recepcionada para posterior análise e fiscalização. A Secretaria de Estado da Fazenda reserva-se o Direito de exigir eventuais diferenças do imposto em relação ao período declarado, no prazo decadencial para a constituição do crédito tributário, nos termos do art. 173 da Lei nº 5.172, de 25/10/1966 (Código Tributário Nacional).');
    des.linhaCampos([{ rotulo: 'Assinatura do(a) Funcionário(a):', valor: '', fr: 0.70 }, { rotulo: 'Data:', valor: '', fr: 0.30 }], 11);
    des.rodape();
  }

  /* ---------- Declaração do ITCMD "INTER VIVOS I" — excedente de meação/quinhão ----------
     Uma declaração por beneficiário do excedente (o contribuinte é o cessionário/donatário —
     portal SEFAZ, "Quem deve pagar"; Lei 7.724/2013, art. 17). Quadro 2: "Excedente de Meação/
     Quinhão, decorrente de Inventário ou Sobrepartilha" + nome/CPF do inventariado. 3.1 Doador(es):
     os cedentes (nome e CPF, quando informados); 3.2 Donatário: o beneficiário. Quadro 4: o
     excedente como direito transmitido (fração exata quando houver), com matrícula/inscrição do
     imóvel quando o espólio tem um só imóvel. Quadro 6: base = excedente; alíquota e principal
     estimados pela Calculadora (a apuração definitiva é da SEFAZ). */
  function dadosInterVivos(S, inv, benef, opts) {
    opts = opts || {};
    const f = inv.falecido, d = f.decl || {}, pat = inv.pat, real = inv.real;
    const cpfs = (f.partilhaReal && f.partilhaReal.cpfs) || {};
    const hoje = S.hoje || new Date().toISOString().slice(0, 10);
    const ex = inv.exced && inv.exced.porBeneficiario.find(x => x.id === benef.id);
    const imoveis = pat.bens.filter(x => x.tipo === 'imovel_urbano' || x.tipo === 'imovel_rural');
    const origImovel = imoveis.length === 1 ? { matricula: imoveis[0].matricula || '', inscricao: imoveis[0].inscricao || '' } : {};
    const taxaTxt = real.taxaUniforme != null ? (real.taxaUniforme >= 1 - 1e-9 ? 'todo (100%)' : (real.taxaFr ? `${real.taxaFr.txt()} (${pct(real.taxaUniforme)})` : pct(real.taxaUniforme))) : null;
    const semMatricula = (desc, mat) => { const m = String(mat || '').trim(); if (!m) return desc; return desc.replace(new RegExp('\\s*[—–-]\\s*matr[ií]cula\\s*' + m.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\s*', 'i'), ' ').replace(/\s+/g, ' ').trim(); };
    // fração do excedente sobre o monte-mor (do bem, quando é um só)
    let fracaoTxt = '';
    if (benef.excedenteFr) fracaoTxt = `${benef.excedenteFr.txt()} da herança` + fracaoBemInteiro(pat, benef.excedenteFr, true);
    else if (pat.heranca > 0) fracaoTxt = pct(benef.excedente / pat.heranca) + ' da herança';
    const descricao = `Excedente de ${benef.meacao ? 'meação' : 'quinhão'} na sucessão de ${f.nome || ''}${f.obito ? ' (óbito em ' + dataBR(f.obito) + ')' : ''}: ${real.cedentes.map(c => c.nome).join(', ')} ${real.cedentes.length > 1 ? 'transferem' : 'transfere'} gratuitamente a ${benef.nome}${taxaTxt ? ', cada qual ' + taxaTxt + ' do próprio quinhão legal' : ''} (valores cedidos por cada um no quadro 3.1). ${benef.meacao ? 'Meação legal' : 'Quinhão legal'} do(a) beneficiário(a) ${fmt(benef.legal)}; recebe de fato ${fmt(benef.real)}; excedente ${fmt(benef.excedente)}${fracaoTxt ? ' = ' + fracaoTxt : ''}. Bens: ${pat.bens.map(b => semMatricula(b.descricao, b.matricula)).join('; ')}.`;
    const aliqs = ex && ex.situacao === 'tributado' ? (ex.aliq * 100).toFixed(0) + '%' : (ex && ex.situacao === 'isento' ? 'isento' : '');
    return {
      inventariado: { nome: f.nome || '', cpf: d.cpf || '', obito: dataBR(f.obito) },
      doadores: real.cedentes.map(c => ({ nome: c.nome, cpf: cpfs[c.id] || '', cede: c.cede })),
      donatario: { nome: benef.nome, cpf: cpfs[benef.id] || '', endereco: '', contato: '' },
      bens: [{ item: 1, descricao, matricula: origImovel.matricula || '', inscricao: origImovel.inscricao || '', valor: benef.excedente, imovel: imoveis.length > 0 }],
      calculo: { base: benef.excedente, aliquota: aliqs, principal: ex ? ex.imposto : 0, total: ex ? ex.imposto : 0, baseLegal: ex && ex.situacao === 'isento' ? 'Lei 7.724/2013, art. 8º, IV' : '', detalhe: ex ? ex.detalhe : '' },
      cartorio: { nome: 'Cartório de Notas do 2º Ofício de Itabaiana/SE', municipio: 'Itabaiana/SE', comarca: 'Itabaiana/SE' },
      responsavel: { nome: benef.nome, cpf: cpfs[benef.id] || '' },
      localData: (d.local || 'Itabaiana/SE') + ', ' + dataBR(hoje),
      geradoEm: new Date().toLocaleString('pt-BR'), quem: opts.quem || ''
    };
  }
  Desenho.prototype.cabecalhoIV = function () {
    const p = this.pdf, h = 26, wDir = LARG * 0.30;
    this.garantir(h);
    const y = this.y;
    p.retangulo(X0, y, LARG, h, { espessura: 0.3 });
    p.linha(X0 + LARG - wDir, y, X0 + LARG - wDir, y + h, { espessura: 0.3 });
    try { p.imagemJpeg(BRASAO_SE, X0 + 2, y + 2, 13, 15.3); } catch (e) { }
    p.fonte(true, 8); p.texto(X0 + 18, y + 4.6, 'Governo de Sergipe'); p.texto(X0 + 18, y + 8.0, 'Secretaria de Estado da Fazenda'); p.texto(X0 + 18, y + 11.4, 'Coordenadoria do ITCMD');
    p.fonte(true, 11.5); p.texto(X0, y + 17.6, 'DECLARAÇÃO DO ITCMD “INTER VIVOS I”', { alinhar: 'centro', larguraMm: LARG - wDir });
    p.fonte(false, 8); p.texto(X0, y + 21.4, '(Excedente de Meação/ Quinhão decorrente de Inventário ou Sobrepartilha)', { alinhar: 'centro', larguraMm: LARG - wDir });
    p.fonte(true, R); p.texto(X0 + LARG - wDir + 1.5, y + 4.4, '1. Nº da Declaração do ITCMD');
    p.fonte(false, R); p.texto(X0 + LARG - wDir + 1.5, y + 7.6, '(Uso da SEFAZ)');
    this.y += h;
  };
  function desenharIV(pdf, D, des) {
    des._gerado = D.geradoEm;
    des.cabecalhoIV();
    des.banda('2. DADOS DA TRANSMISSÃO INTER VIVOS - TIPO');
    des.marcadores([{ marcado: true, texto: 'Excedente de Meação/ Quinhão, decorrente de Inventário ou Sobrepartilha', linhas: ['Nome do(a) Inventariado(a): ' + D.inventariado.nome, 'CPF do(a) Inventariado(a): ' + D.inventariado.cpf, 'Data do óbito: ' + (D.inventariado.obito || '')] },
      { marcado: false, texto: 'Instituição de Usufruto / Doação Pura e Simples e outras', linhas: ['(não se aplica a esta declaração)'] }]);
    des.banda('3. IDENTIFICAÇÃO DAS PARTES');
    des.subBanda('3.1. DOADOR(A) — CEDENTE(S) DO EXCEDENTE' + (D.doadores.length > 1 ? ' (' + D.doadores.length + ' pessoas)' : ''));
    D.doadores.forEach(dd => des.linhaCampos([{ rotulo: 'Nome:', valor: dd.nome, fr: 0.50 }, { rotulo: 'CPF:', valor: dd.cpf, fr: 0.25 }, { rotulo: 'Cede (R$):', valor: fmt(dd.cede), fr: 0.25, alinhar: 'dir' }]));
    des.linhaCampos([{ rotulo: 'Endereço completo:', valor: '', fr: 0.70 }, { rotulo: 'Telefone/ E-mail:', valor: '', fr: 0.30 }]);
    des.subBanda('3.2. DONATÁRIO(A) — BENEFICIÁRIO(A) DO EXCEDENTE');
    des.linhaCampos([{ rotulo: 'Nome:', valor: D.donatario.nome, fr: 0.70 }, { rotulo: 'CPF:', valor: D.donatario.cpf, fr: 0.30 }]);
    des.linhaCampos([{ rotulo: 'Endereço completo:', valor: D.donatario.endereco, fr: 0.70 }, { rotulo: 'Telefone/ E-mail:', valor: D.donatario.contato, fr: 0.30 }]);
    des.banda('4. BEM(NS)/ DIREITO(S)');
    des.tabela([{ titulo: 'Item', fr: 0.06, alinhar: 'centro' }, { titulo: 'Descrição Detalhada', fr: 0.46 }, { titulo: 'Matrícula de Registro (Bem Imóvel)', fr: 0.16, alinhar: 'centro' }, { titulo: 'Inscrição Municipal/ INCRA (Bem Imóvel)', fr: 0.16, alinhar: 'centro' }, { titulo: 'Valor (R$)', fr: 0.16, alinhar: 'dir' }], D.bens.map(b => [String(b.item), b.descricao, b.matricula, b.inscricao, fmt(b.valor)]));
    des.banda('5. USO DO CARTÓRIO', '(Campo obrigatório em se tratando de excedente de meação/ quinhão decorrente de Inventário ou Sobrepartilha extrajudiciais e doações que exijam escritura pública)');
    des.linhaCampos([{ rotulo: 'Cartório:', valor: D.cartorio.nome, fr: 0.50 }, { rotulo: 'Município:', valor: D.cartorio.municipio, fr: 0.25 }, { rotulo: 'Comarca:', valor: D.cartorio.comarca, fr: 0.25 }]);
    des.linhaCampos([{ rotulo: 'Assinatura e Carimbo do(a) Funcionário(a):', valor: '', fr: 0.70 }, { rotulo: 'Data:', valor: '', fr: 0.30 }], 11);
    des.banda('6. CÁLCULO DO IMPOSTO');
    des.linhaCampos([{ rotulo: 'Data de Vencimento:', valor: '', fr: 0.20 }, { rotulo: 'Base de Cálculo', valor: fmt(D.calculo.base), fr: 0.20, valorAbaixo: true, alinhar: 'dir' }, { rotulo: 'Alíquota (%)', valor: D.calculo.aliquota, fr: 0.14, valorAbaixo: true, alinhar: 'dir' }, { rotulo: 'Principal', valor: fmt(D.calculo.principal), fr: 0.16, valorAbaixo: true, alinhar: 'dir' }, { rotulo: 'Atualização', valor: '', fr: 0.15, valorAbaixo: true }, { rotulo: 'Multa', valor: '', fr: 0.15, valorAbaixo: true }]);
    des.linhaCampos([{ rotulo: 'Juros', valor: '', fr: 0.16, valorAbaixo: true }, { rotulo: 'Desconto', valor: '', fr: 0.16, valorAbaixo: true }, { rotulo: 'Total a Pagar', valor: fmt(D.calculo.total), fr: 0.18, valorAbaixo: true, alinhar: 'dir' }, { rotulo: 'Data de Pagamento do DAE:', valor: '', fr: 0.25 }, { rotulo: 'Nº do DAE:', valor: '', fr: 0.25 }]);
    des.linhaCampos([{ rotulo: 'Nº do Parcelamento:', valor: '', fr: 0.35 }, { rotulo: 'Base Legal se houver isenção ou imunidade:', valor: D.calculo.baseLegal, fr: 0.65, valorAbaixo: !!D.calculo.baseLegal }]);
    if (D.calculo.detalhe) des.nota('Estimativa da Calculadora ITCMD do Hub CN2O: ' + D.calculo.detalhe + '. A base de cálculo definitiva é apurada pela SEFAZ pelo valor venal na data do ato (Lei 7.724/2013, art. 10); o excesso extrajudicial vincula-se à escritura de partilha e admite recolhimento antecipado (art. 4º, V e §§ 1º–2º).');
    des.banda('7. RESPONSÁVEL');
    des.linhaCampos([{ rotulo: 'Local/ Data:', valor: D.localData, fr: 0.26, valorAbaixo: true }, { rotulo: 'Nome:', valor: D.responsavel.nome, fr: 0.32, valorAbaixo: true }, { rotulo: 'CPF:', valor: D.responsavel.cpf, fr: 0.17, valorAbaixo: true }, { rotulo: 'Assinatura:', valor: '', fr: 0.25 }], 13);
    des.banda('8. RECEPÇÃO DA DECLARAÇÃO (Uso da SEFAZ)');
    des.nota('Documentação recepcionada para posterior análise e fiscalização. A Secretaria de Estado da Fazenda reserva-se o Direito de exigir eventuais diferenças do imposto em relação ao período declarado, no prazo decadencial para a constituição do crédito tributário, nos termos do art. 173 da Lei nº 5.172, de 25/10/1966 (Código Tributário Nacional).');
    des.linhaCampos([{ rotulo: 'Assinatura do(a) Funcionário(a):', valor: '', fr: 0.70 }, { rotulo: 'Data:', valor: '', fr: 0.30 }], 11);
    des.rodape();
  }
  // Uma Inter Vivos I por beneficiário com excedente (natureza não onerosa), em todos os inventários.
  function gerarInterVivos(S, invs, opts) {
    if (typeof PDFMini !== 'function') throw new Error('PDFMini indisponível fora do Hub');
    const alvo = [];
    invs.forEach(inv => { if (inv.real && inv.real.ativa && inv.real.natureza !== 'onerosa' && inv.real.totalExcedente > 0 && Math.abs(inv.real.diferenca) < 0.01) inv.real.beneficiarios.forEach(b => alvo.push({ inv, b })); });
    if (!alvo.length) return null;
    const pdf = new PDFMini({ pagina: 'A4' });
    const des = new Desenho(pdf);
    const dados = [];
    alvo.forEach((a, k) => { if (k > 0) { pdf.novaPagina(); des.pagina++; des.y = Y0; } const D = dadosInterVivos(S, a.inv, a.b, opts); dados.push(D); desenharIV(pdf, D, des); });
    return { blob: pdf.blob(), bytes: pdf.bytes(), dados, paginas: pdf.totalPaginas() };
  }
  function pendenciasIV(D) {
    const p = [];
    if (!D.inventariado.cpf) p.push('CPF do(a) inventariado(a)');
    if (!D.donatario.cpf) p.push(`CPF de ${D.donatario.nome} (beneficiário)`);
    D.doadores.forEach(dd => { if (!dd.cpf) p.push(`CPF de ${dd.nome} (cedente)`); });
    D.bens.forEach(b => { if (b.imovel && !b.matricula) p.push('matrícula do imóvel (quadro 4)'); });
    p.push('endereço e contato das partes (quadro 3)');
    return p;
  }

  // Gera o PDF com uma declaração por inventário (no cumulativo, duas — cada uma começa em página nova).
  function gerarPdf(S, invs, opts) {
    if (typeof PDFMini !== 'function') throw new Error('PDFMini indisponível fora do Hub');
    const pdf = new PDFMini({ pagina: 'A4' });
    const des = new Desenho(pdf);
    const dados = [];
    invs.forEach((inv, k) => {
      if (k > 0) { pdf.novaPagina(); des.pagina++; des.y = Y0; }
      const D = dadosDeclaracao(S, inv, opts); dados.push(D);
      des._maisPaginas = invs.length > 1;
      desenhar(pdf, D, des);
    });
    return { blob: pdf.blob(), bytes: pdf.bytes(), dados, paginas: pdf.totalPaginas() };
  }
  // Campos em branco que o advogado terá de completar (para a conferência antes de gerar).
  function pendencias(D) {
    const p = [];
    if (!D.inventariado.nome) p.push('nome do(a) inventariado(a)');
    if (!D.inventariado.cpf) p.push('CPF do(a) inventariado(a)');
    if (!D.inventariado.obito) p.push('data do óbito');
    if (D.inventariado.regime && !D.inventariado.dataCasamento) p.push('data do casamento/união estável');
    if (!D.inventariante.nome) p.push('nome do(a) inventariante');
    if (!D.inventariante.cpf) p.push('CPF do(a) inventariante');
    if (!D.inventariante.endereco) p.push('endereço do(a) inventariante');
    if (D.tipo !== 'judicial' && !D.dataAbertura) p.push('data de abertura do inventário (data da escritura de abertura/nomeação de inventariante)');
    if (D.tipo === 'judicial' && !D.processo) p.push('número do processo');
    D.bens.forEach(b => { if (!b.descricao) p.push(`descrição do bem ${b.item}`); if (!(+b.valor > 0)) p.push(`valor do bem ${b.item}`); if (b.imovel && !b.matricula) p.push(`matrícula do imóvel (bem ${b.item})`); if (b.imovel && !b.inscricao) p.push(`inscrição municipal/INCRA do imóvel (bem ${b.item})`); });
    if (!D.inventariado.regime && !D.inventariado.estadoCivil) p.push('estado civil no óbito (quadro 3.1)');
    if (!D.responsavel.nome) p.push('nome do responsável pela declaração');
    return p;
  }
  window.ITCMD_DECL = { dadosDeclaracao, gerarPdf, pendencias, dadosInterVivos, gerarInterVivos, pendenciasIV };
})();
