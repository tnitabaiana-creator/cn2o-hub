# Auditoria independente — Calculadora ITCMD/SE (piloto Hub CN2O)

Data: 25/09/2026 · Escopo: `motor.js`, `ui.js`, `corpo.html`, `estilo.css`, `piloto.html`, `teste-motor.js`, `checar.py`.
Nenhum arquivo do projeto foi alterado. Scripts auxiliares ficaram fora do projeto (`cenarios.js`, `ui_check.py`, `ui_foco.py` no scratchpad).
Base legal usada: a fornecida pelo solicitante (Lei 7.724/2013, Decreto 29.994/2015, CC, jurisprudência, Tabela TJSE 2026). Valores de UFP/SE (R$ 86,25 set/2026; R$ 87,19 out/2026) e as Portarias/Leis citadas no cabeçalho do `motor.js` **não foram conferidos** por esta auditoria (sem acesso às fontes).

---

## 1. Execução das verificações existentes

| Comando | Resultado |
|---|---|
| `node teste-motor.js` | **92 ok, 0 falhas** |
| `timeout 180 python3 checar.py` | Todas as asserções passam (cumulativo, inventário, doação, edição ao vivo, adicionar herdeiro, orçamento, mobile 400 px, fontes ≥ 14 px). **Sai com código 1** porque captura como "erro de console" a falha de rede ao baixar Google Fonts (`ERR_TUNNEL_CONNECTION_FAILED`) — falso negativo neste sandbox. Captura em `capturas/`. |

Confirmado que `piloto.html` embute exatamente os `motor.js`, `ui.js`, `corpo.html` e `estilo.css` atuais (build em dia).

Limitações do `checar.py` (importam para o que ele **não** pegou): só testa mobile no modo cumulativo; usa `fill` + `dispatch_event('change')` e por isso não detecta perda de foco durante a digitação; não testa remoção de donatário nem "Limpar tudo".

---

## 2. Tabela de achados

Severidade: **crítico** = resultado errado em fluxo normal, sem aviso · **grave** = resultado errado em cenário plausível ou funcionalidade inutilizável · **menor** = imprecisão, texto ou ergonomia.

| # | Sev. | Arquivo · trecho | Achado | Como reproduzir | Correção sugerida |
|---|---|---|---|---|---|
| 1 | **crítico** | `motor.js:136` `desc = descendentes.filter(d => nome.trim() !== '' \|\| d.condicao)` | A UI sempre grava `condicao:'vivo'`, então um descendente **em branco** é contado como herdeiro ("Herdeiro 1"). Após **Limpar tudo**, o estado padrão tem 1 descendente em branco: toda a herança vai a "Herdeiro 1". A UI, por sua vez, considera que **não há** descendentes (`ui.js:70 temDesc`) e exibe "Ascendentes — herdam quando não há descendentes"; marcando "Mãe viva", o resultado continua dando tudo a "Herdeiro 1" (cenário l e teste UI #2). Mesmo bug se a escrevente clicar "+ Filho(a)" e deixar em branco: cria uma estirpe a mais e altera todos os quinhões. | Limpar tudo → bem 100.000 → abrir Ascendentes → marcar Mãe viva. Resultado: "Herdeiro 1 = R$ 100.000"; mãe não aparece. | Usar o mesmo critério dos colaterais: `filter(d => (d.nome\|\|'').trim() !== '' \|\| (d.condicao === 'premorto' && (d.representantes\|\|[]).some(r => r.nome.trim())))` e alinhar `temDesc` da UI ao motor. |
| 2 | **crítico** | `motor.js:340,348-349` (`donatarios` filtrado por nome; `destino` é índice) · `ui.js:146,316` | O destino do bem é um **índice posicional**. (a) Remover um donatário deixa o índice órfão: o `select` passa a mostrar "Todos" (não há `option` para o valor) enquanto o estado guarda `'1'` → o bem **não é atribuído a ninguém**, ITCMD = R$ 0,00, barra viva mostra R$ 0,00, mas os emolumentos seguem calculados sobre o valor. (b) Donatário com nome em branco à frente na lista desloca os índices e o bem vai para ninguém. | Exemplo → Doação → "Para quem" = Carla → remover Bruno. Resultado: Carla R$ 0, ITCMD R$ 0,00 (teste UI #10; cenário m). | Dar `id` estável a cada donatário e referenciar por id; ao remover donatário, reatribuir bens dele para `'todos'`; no motor, não filtrar donatários por nome (ou filtrar mantendo o índice original); na UI, garantir que o `select` só mostre valor existente. |
| 3 | **crítico** | `ui.js:18,25` (`novoFalecido` → `estadoCivil:'casado'` para os dois falecidos) · `motor.js:85` (`temConjuge` aceita cônjuge sem nome) | No cumulativo, o 2º falecido nasce "Casado(a)" com cônjuge sem nome. Qualquer bem próprio lançado para ele gera **meação fantasma de 50% para "Meeiro(a)"** e reduz a herança/ITCMD do 2º inventário pela metade. O exemplo mascara isso porque força `'solteiro'`. | Limpar tudo → Inventário cumulativo → bem próprio do 2º falecido 100.000. Resultado: "Meeiro(a) — meação R$ 50.000" (teste UI #14). | `estadoInicial()` deve criar o 2º falecido como `'solteiro'` (viúvo). Adicionalmente, emitir aviso quando `estadoCivil ≠ solteiro` e `conjuge.nome` vazio. |
| 4 | **grave** | `ui.js:292-296` (evento `input` → `agendar()` → `calcular()` → `orcamento()` refaz `#orcCorpo` por `innerHTML`) · `ui.js:261` | Os campos do orçamento (Honorários, Certidões, Registro, Outros) **perdem o foco 250 ms após cada tecla**. Digitando "5000" com pausa, fica só "5"; o resto vai para o `body`. Inutilizável para digitação normal. | Clicar em Honorários, digitar "5", esperar 0,4 s, digitar "000" → campo fica "5", `activeElement = BODY` (script `ui_foco.py`). | Não re-renderizar os inputs do orçamento: renderizá-los uma vez fora do bloco recalculado, ou atualizar só as células de total via `textContent`; no mínimo, pular o re-render quando `document.activeElement` está dentro de `#orcCorpo`. |
| 5 | **grave** | `motor.js:224-235` (irmãos premortos → sobrinhos sempre por estirpe) | Quando **todos** os irmãos são premortos e só concorrem sobrinhos, o CC manda partilha **por cabeça** (art. 1.843, §1º); o motor divide por estirpe. Ex.: I1† (1 sobrinho) e I2† (3 sobrinhos), herança 400k → motor: S1 200k, S2–S4 66,7k; lei: 100k cada. Muda faixa/isenção. | Cenário (j). | Se nenhum irmão válido está vivo: distribuir entre os sobrinhos por cabeça (mantendo o dobro para filhos de bilaterais, art. 1.843, §2º). |
| 6 | **grave** | `motor.js:239-243` ("outros" colaterais em partes iguais) | Sobrinhos (3º), tios (3º) e primos (4º) são misturados **por cabeça em partes iguais**. Pela lei, sobrinhos preferem tios (art. 1.843, caput) e 3º grau exclui 4º (art. 1.840). O aviso "confira se há colateral de grau mais próximo" não impede o número errado. | Cenário (k): 1 sobrinho + 1 primo, 100k → motor 50k/50k; correto 100k ao sobrinho. | Ordenar por grau (sobrinhos → tios → 4º grau) e partilhar só dentro do primeiro grau presente. |
| 7 | **grave** | `motor.js:259-260, 275-276` (`propQuotas` uniforme sobre todos os quinhões) | Quotas de sociedade (2%) são rateadas na **mesma proporção** para todo beneficiário, mas na comunhão parcial o cônjuge só recebe dos particulares e os filhos recebem parcelas diferentes de comuns/particulares. Cenário (o): quotas comuns 400k + imóvel particular 200k, cônjuge + 1 filho → cônjuge recebe só imóvel (100k) mas paga "3% de 50k + 2% de 50k" = 2.500 (correto 3.000); filho paga 12.000 (correto 10.000 pela faixa do quinhão, ou 7.000 se a faixa for aferida só na parte geral). | Cenário (o). | Calcular, por beneficiário, o valor de quotas efetivamente recebido: Σ (valor do bem-quota × fração do bem para aquele beneficiário — já disponível em `partilha`). Definir e documentar se a faixa do art. 14, I é aferida pelo quinhão total ou só pela parcela não-quotas. |
| 8 | **grave** | `ui.js:147` (`style="grid-template-columns:…6 colunas"` inline na linha de bens da doação) · `ui.js:106` (colaterais, 4 colunas inline) | O estilo inline **vence a media query** de `estilo.css` (`@media (max-width:760px) .item .linha.bem{…1fr 1fr}`). A 400 px a linha de bens da doação fica com 6 colunas: campo Valor com 45 px mostrando "**42**" (de 420.000,00), "Para quem" 41 px (vazio), Fração "10" (de 100). Valor truncado é enganoso. Não há rolagem horizontal (por isso o `checar.py` não pegou; ele só testa mobile no cumulativo). | Doação a 400 px de largura (captura `u4-mobile-doacao.png`, teste UI #16). | Trocar os estilos inline por classes (`.linha.bem-doacao`, `.linha.colateral`) com regra correspondente dentro da media query. |
| 9 | **grave** | `ui.js:130` (`isentosVI.${x.id}`) · `motor.js:265` (ids posicionais `d0`, `d1`, `conj`) | A marcação da isenção do art. 8º, VI é gravada por **id posicional**. Remover/reordenar herdeiro faz a isenção **migrar ou sumir** em silêncio (teste UI #9: marcado em Carlos = `d1`; após remover Ana, a marcação some). | Exemplo → Inventário → marcar "Único imóvel" → marcar Carlos → remover Ana. | Chavear por id estável do herdeiro (ver #2) ou pelo nome; ou limpar `isentosVI` a cada alteração estrutural com aviso. |
| 10 | **grave** | `motor.js:352` (`d.usufrutoSobreMoveis`, que **nenhum campo da UI define**) | Com "Base da nua-propriedade = 50%", os imóveis vão a 50% e os **móveis continuam a 100%**, sem aviso e sem opção. Cenário (n): imóvel 200k + veículo 100k → base imóveis 100k, móveis 100k. | Exemplo → Doação → base 50% → + Bem veículo 100.000 (teste UI #11). | Ou expor a opção na UI, ou aplicar a mesma base a todos os bens gravados com usufruto, ou avisar explicitamente. |
| 11 | menor | `motor.js:106, 341` (`+b.fracao \|\| 100`) | Fração **0 %** é tratada como 100 %. | Fração = 0 no bem → monte-mor inalterado (teste `ui_foco.py`). | `b.fracao === '' \|\| b.fracao == null ? 100 : +b.fracao`. |
| 12 | menor | `ui.js:161-164` (selo/dica só em `renderForm`) vs `ui.js:300-303` | Editar o campo UFP/SE não atualiza o selo do cabeçalho (fica "R$ 86,25" com UFP 90 no estado) nem a dica. O `#orcData` atualiza. | Digitar 90 em UFP/SE → selo continua 86,25 (teste UI #13). | Atualizar `#seloUfp`/`#ufpDica` em `calcular()`; indicar "UFP informada manualmente". |
| 13 | menor | `motor.js:356, 364` · `corpo.html:82` (premissa 4) | A **faixa** de alíquota da doação é aferida sobre `quinhão + doações anteriores`, mas a premissa diz que a soma serve "para a isenção". O imposto é aplicado só sobre a doação atual (correto), mas a alíquota pode subir de faixa pelas anteriores sem que isso esteja declarado. | Donatário com 500.000 anteriores + doação 200.000 → 4 % sobre 200.000. | Decidir com a SEFAZ (faixa pela doação ou pelo acumulado) e alinhar código e premissa. |
| 14 | menor | `ui.js:206` (`hoje: S.doa.data`, mas `ufp: S.ufp`) | A data prevista da escritura de doação não muda a UFP usada (usa a da "Data de referência"). Escritura em outubro/2026 com referência em setembro usa 86,25 em vez de 87,19. | Doação com data 05/10/2026, referência 25/09/2026. | Usar `M.ufpVigente(S.doa.data)` na doação, ou avisar. |
| 15 | menor | `ui.js:174` (coluna "Fração": "1/3 dos comuns") | "1/3 dos comuns" na verdade é 1/3 **da herança nos comuns** (metade dos bens comuns, após a meação) — o filho recebe 1/6 de cada bem comum. Texto ambíguo para quem lê a tabela sem a "Partilha por bem". | Cenário (a) na UI (teste #15). | "1/3 da herança comum" ou mostrar a fração do bem (1/6). |
| 16 | menor | `ui.js:102` | "Avós maternos vivos" continua exibido com **pai vivo**; o motor (corretamente, art. 1.836, §1º) ignora o valor. Campo sem efeito confunde. | Limpar → Ascendentes → marcar Pai vivo. | Ocultar avós quando qualquer genitor está vivo, com a nota legal. |
| 17 | menor | `motor.js:140` | Art. 1.811 CC: se **todos** os filhos renunciam e há netos, os netos herdam por cabeça. O motor manda a herança aos ascendentes/cônjuge (cenário q) e a UI não permite cadastrar netos de renunciante. | Único filho "renuncia" + representantes + mãe viva. | Ao menos um aviso; idealmente permitir representantes no renunciante quando toda a classe renuncia. |
| 18 | menor | `ui.js:248` (`pessoas = linhas + meeiro`) | Renunciantes e o premorto sem representantes não entram na contagem de pessoas do adicional de R$ 4,77 (a guia conta herdeiros/outorgantes). Só afeta atos com > 10 pessoas. | 11 herdeiros, 1 renunciante → sem adicional. | Contar também os renunciantes que comparecem. |
| 19 | menor | `motor.js:309-317` | "Partilha ideal por bem" usa valores **brutos** (ignora dívidas): com dívidas, a soma dos valores da partilha ≠ meação + quinhões exibidos acima. | Cenário (e) com dívidas 50k. | Nota "valores antes das dívidas" ou aplicar a dedução proporcionalmente. |
| 20 | menor | `motor.js:265-269` · `ui.js:127` | Isenção do art. 8º, VI zera o **quinhão inteiro** (inclusive móveis) e não valida "único imóvel ≤ 2.600 UFP". Depende 100 % da escrevente. | Espólio com casa + carro, sucessor marcado → carro também isento. | Limitar a isenção à parcela do imóvel; validar o teto de 2.600 UFP e a existência de um só imóvel, com aviso. |
| 21 | menor | `corpo.html:83, 84` (premissas 5 e 6) | Premissa 5 cita "art. 2º, §2º" (excesso de meação) — dispositivo **não constava da base fornecida**; conferir. Premissa 6 estende o REsp 1.382.170 (separação convencional) à **participação final nos aquestos** ("concorre sobre tudo"), que é opção doutrinária, não jurisprudência pacificada. | — | Conferir o §; reescrever a premissa 6 separando a hipótese da participação final como "entendimento adotado". |
| 22 | menor | `checar.py:14, 78-79` | Falha por erro de rede das fontes (falso negativo). Não cobre: mobile em doação, digitação real (perda de foco), remoção de donatário, "Limpar tudo". | `python3 checar.py; echo $?` → 1. | Abortar rotas `fonts.g*` no Playwright e ignorar `ERR_*` de rede; adicionar os casos acima. |
| 23 | menor | `estilo.css:79` (`input::placeholder{color:#6b7280}`) | Placeholder cinza médio: contraste ≈ 4,8:1 no claro (aceitável), ≈ 3:1 no escuro sobre `#202a3a` (baixo). | Tema escuro, campo vazio. | Usar `var(--texto-2)` com opacidade, ou `#556070`/`#b8c0cc` por tema. |
| 24 | menor | `ui.js:331, 105` | Restaurar rascunho gravado por versão anterior sem `colaterais`/`isentosVI` quebra o render (`f.colaterais.forEach`). Sem migração de esquema. | Gravar rascunho, mudar esquema, restaurar. | Mesclar rascunho sobre `novoFalecido()` (defaults) antes de usar. |

**Conformidades verificadas (sem achado):** meação por regime (universal/parcial/aquestos/separação conv./obrigatória c/ e s/ Súmula 377); concorrência do cônjuge só nos particulares na parcial (REsp 1.368.123) e sobre tudo na separação convencional (REsp 1.382.170); reserva de 1/4 (art. 1.832) e sua exclusão na filiação híbrida (REsp 1.617.650); quota do cônjuge = 1/(estirpes+1); separado de fato > 2 anos (art. 1.830) mantém meação e não herda em nenhuma classe; ascendentes (1/3 com pai e mãe, 1/2 nos demais; grau mais próximo exclui; metade por linha); irmãos bilaterais dobro dos unilaterais e sobrinhos por estirpe quando há irmão vivo; renúncia acresce e não é tributada; dívidas abatidas antes da meação (premissa declarada); isenção ≤ 500 UFP por beneficiário com limite inclusivo; faixas causa mortis e doação com limites inclusivos e alíquota **não escalonada** sobre o quinhão inteiro; quotas 2 % (quando não há concorrência mista, ver #7); multa 20 % só após 120 dias e desligável; frações exatas somam 1 em cada bem; cumulativo leva meação + quinhão como particulares do 2º; emolumentos TJSE 2026 em todos os limiares testados, FERD 20 % só sobre o emolumento da faixa (bate com a guia real 300.000/12 herdeiros = 3.965,65), adicional a partir do 11º, ato acessório = metade; parse de moeda "1.234,56", "1234.56", "300.000", "R$ 2.500,00"; foco preservado nos campos do **formulário** durante a digitação; adicionar/remover herdeiros, bens, representantes; premorto sem representante gera aviso; Copiar resumo funciona (clipboard e toast); Carregar exemplo/Limpar; tema escuro sem texto ilegível; sem rolagem horizontal a 400 px; nenhum texto visível < 14 px; no tema claro só há texto branco sobre o vinho da marca (botões/pílulas), com contraste ≈ 10:1.

---

## 3. Cenários calculados à mão × motor

UFP/SE 86,25; referência 25/09/2026. Script: `cenarios.js` (scratchpad). **92 verificações OK, 5 falhas** (todas em cenários adicionais j, k, l, m).

### (a) Comunhão parcial — casa comum 300.000 + terreno particular 150.000, 3 filhos comuns, cônjuge concorre
| Item | Esperado | Obtido |
|---|---|---|
| Meação | 150.000 | 150.000 ✓ |
| Herança | 300.000 (150k comuns + 150k particulares) | 300.000 ✓ |
| Cônjuge | 1/4 dos particulares = 37.500; 0 nos comuns | 37.500; frComum 0 ✓ |
| Cada filho | 50.000 + 37.500 = 87.500 | 87.500 ✓ |
| Frações da casa | meação 1/2 + 3 × 1/6 = 1; viúva não herda na casa | 1 ✓; ausente ✓ |
| Frações do terreno | 1/4 + 3 × 1/4 = 1 | 1 ✓ |
| ITCMD | cônjuge 434,8 UFP isento; filhos 1.014,5 UFP → 3 % = 2.625; total 7.875 | ✓ |

### (b) Neto por representação isento, tios pagam — solteiro, 3 filhos (1 premorto com 4 netos), 500.000
| Item | Esperado | Obtido |
|---|---|---|
| Tio | 1/3 = 166.666,67 → 1.932 UFP → 3 % = 5.000 | ✓ |
| Neto | 1/12 = 41.666,67 → 483 UFP → isento | ✓ |
| Total | 10.000 | 10.000 ✓ |

### (c) Cumulativo — Pai (†2020, parcial): casa comum 400k + terreno particular 120k, 3 filhos; Mãe (†07/2026, viúva): poupança 60k; C renuncia só no 2º
| Item | Esperado | Obtido |
|---|---|---|
| Inv1 meação / Mãe / filho | 200.000 / 30.000 (1/4 do terreno) / 96.666,67 | ✓ |
| Inv1 ITCMD | Mãe isenta; filhos 2.900 cada; multa 20 % (óbito 2020); total 10.440 | ✓ |
| Inv2 monte-mor | 200k (1/2 casa) + 30k (1/4 terreno) + 60k = 290.000; sem meação | ✓ |
| Inv2 herdeiros | A e B (C renunciou) 145.000 cada → 1.681 UFP → 3 % = 4.350; sem multa (86 dias); total 8.700 | ✓ |

### (d) Doação de casal a 3 filhos — casa 300k→A, sítio 100k→B, apto 700k→C, quotas 90k→todos
| Item | Esperado | Obtido |
|---|---|---|
| A | 2 % × 300k + 2 % × 30k = 6.600 | ✓ |
| B | 2 % × 100k + 2 % × 30k = 2.600 | ✓ |
| C | 8.464 UFP → 4 % × 700k + 2 % × 30k = 28.600 | ✓ |
| Total / valor | 37.800 / 1.190.000 | ✓ |
| Emolumentos (5 pessoas) | 10.685,18 + 21 × 18,70 = 11.077,88; FERD 2.215,58; total 13.293,46 | ✓ |

### (e) Separação obrigatória + Súmula 377 — comum 250k, particular 400k, dívidas 50k, 2 filhos
| Item | Esperado | Obtido |
|---|---|---|
| Meação | (250k − 50k)/2 = 100.000 | ✓ |
| Herança / cônjuge | 500.000 / não concorre | ✓ |
| Filho | 250.000 → 2.898 UFP → 6 % = 15.000 | ✓ |
| Sem Súmula 377 | meação 0 mesmo com bem "comum" | ✓ |

### (f) Limiares — 500 UFP e 500,01 UFP; limites de faixa
| Item | Esperado | Obtido |
|---|---|---|
| Quinhão 43.125 (= 500 UFP) | isento | ✓ |
| Quinhão 43.126 (500,01 UFP) | tributado, 3 % sobre o total = 1.293,78 | ✓ |
| 2.417 UFP / +R$1 | 3 % / 6 % | ✓ |
| 12.086 UFP / +R$1 | 6 % / 8 % | ✓ |
| Doação 500 UFP / +R$1 anterior | isento / tributado (2 % só sobre a atual = 862,50) | ✓ |
| Doação 6.900 UFP / +R$1; 27.248 +R$1 | 2 % / 4 %; 8 % | ✓ |

### (g) Emolumentos nos limiares
| Base | Esperado | Obtido |
|---|---|---|
| 25.000,01 | 755,52 | ✓ |
| 1.085.000,01 | 10.703,88 | ✓ |
| 1.200.000,01 | 11.133,98 | ✓ |
| 2.000.000,01 | 11.264,88 (teto) | ✓ |
| 5.999,99 / 12.999,99 / 35.000 / 35.000,01 / 1.095.000 / 1.900.000 | 303,09 / 513,01 / 802,58 / 849,64 / 10.722,58 / 11.246,18 | ✓ |
| 11 pessoas / 10 pessoas | adicional 4,77 / 0 | ✓ |
| Acessório 1.190.000, 12 pessoas | 5.538,94 + 9,54 + FERD 1.107,79 = 6.656,27 | ✓ |

### (h) Cônjuge separado de fato > 2 anos com descendentes — parcial, comum 200k + particular 100k, 2 filhos
| Item | Esperado | Obtido |
|---|---|---|
| Meação | 100.000 (mantida) | ✓ |
| Herdeiros | só os 2 filhos, 100.000 cada; cônjuge ausente do particular | ✓ |
| Separação convencional + separado de fato | não concorre | ✓ |

### Adicionais
| Cenário | Esperado | Obtido |
|---|---|---|
| (i) Pai vivo + 2 avós maternos + companheira, 300k particular | companheira 1/2, pai 1/2, avós excluídos | ✓ |
| (j) Só sobrinhos: I1† (1) e I2† (3), 400k | **100.000 cada (por cabeça, art. 1.843 §1º)** | **S1 200.000; S2–S4 66.666,67 ✗** (#5) |
| (k) 1 sobrinho + 1 primo, 100k | **sobrinho 100.000** | **50.000 / 50.000 ✗** (#6) |
| (l) Descendente em branco (`condicao:'vivo'`) + mãe viva, 100k | **classe ascendentes, mãe 100.000** | **"Herdeiro 1" 100.000 ✗** (#1) |
| (m) Donatários ['', 'X'], bem destino '1' 200k | **X 200.000** | **X 0; ITCMD 0; valorTotal 200.000 ✗** (#2) |
| (n) Usufruto 50 % + imóvel 200k + veículo 100k | base uniforme (ou aviso) | imóveis 100k (50 %), móveis 100k (100 %) — #10 |
| (o) Quotas comuns 400k + imóvel particular 200k, cônjuge + 1 filho | cônjuge 3 % × 100k = 3.000 | 2.500 — #7 |
| (p) Fração 0 % | bem excluído | bem a 100 % — #11 |
| (q) Todos os filhos renunciam, há netos | netos por cabeça (art. 1.811) | vai à mãe — #17 |

---

## 4. Verificação da interface (Playwright, chromium, `file://`)

| Teste | Resultado |
|---|---|
| Troca de modo (inventário / cumulativo / doação) | OK |
| Adicionar/remover herdeiros e bens; foco vai para o novo campo | OK |
| Premorto → bloco de representantes; representante em branco → aviso "estirpe desconsiderada" | OK |
| Renúncia → sai da tabela, aviso do art. 7º, II / 1.810 | OK |
| Moeda "1.234,56" / "1234.56" / "300.000" / "1.234" / "12,5" / "R$ 2.500,00" | todos interpretados corretamente e reformatados no `change` |
| Digitação em campo do formulário com pausas > 250 ms | foco mantido |
| Digitação em campo do orçamento | **foco perdido após 250 ms** (#4) |
| Copiar resumo | clipboard preenchido, toast "Resumo copiado" |
| Carregar exemplo / Limpar tudo | OK (mas ver #1 e #3 para o estado após Limpar) |
| UFP vazio → volta ao padrão; data 05/10/2026 → 87,19 | OK; selo desatualizado ao editar manualmente (#12) |
| Isenção VI por id posicional | marcação some ao remover herdeiro (#9) |
| Remover donatário com bem destinado | ITCMD zera (#2) |
| Tema escuro (`emulate_media`) | legível; placeholder de baixo contraste (#23) |
| 400 px | sem rolagem horizontal nos 3 modos; **doação com campos de 41–45 px e valor truncado "42"** (#8) |
| Fontes < 14 px em texto visível | nenhuma (nos 3 modos) |
| Texto claro sobre fundo escuro no tema claro | só branco sobre vinho da marca (`.num`, `.opcoes[aria-pressed]`, `.btn.primario`) — conforme |
| Erros de console | só o carregamento das fontes (rede) |

---

## 5. Conclusão

O núcleo do motor (meação, concorrência, representação, ascendentes, renúncia, faixas, isenção, multa, emolumentos, frações exatas) está correto em todos os cenários obrigatórios (a)–(h) e coincide com os cálculos à mão. Porém, três defeitos produzem **números errados sem aviso em fluxos comuns** — descendente em branco após "Limpar tudo" (#1), bem doado que some do imposto ao remover donatário (#2) e meação fantasma do 2º falecido no cumulativo (#3) — e os campos do orçamento não permitem digitação normal (#4). Para uma ferramenta que gera orçamento ao cliente, isso impede a liberação da versão atual. Todas as correções críticas/graves são localizadas (poucas linhas cada); após corrigi-las e acrescentar os cenários (j), (k), (l), (m), (n), (o) ao `teste-motor.js` e os testes de foco/remoção/mobile-doação ao `checar.py`, recomendo nova rodada.

VEREDITO: reprovado

---

# Segunda rodada — 25/09/2026 (após as correções #1–#24)

Reexecução completa sobre os arquivos atuais (`piloto.html` confere byte a byte com `motor.js`, `ui.js`, `corpo.html`, `estilo.css`).

| Verificação | Resultado |
|---|---|
| `node teste-motor.js` | **121 ok, 0 falhas** |
| `timeout 240 python3 checar.py` | **passa, exit 0** (erros de rede ignorados; agora cobre foco no orçamento, remoção de donatário, Limpar tudo, herdeiro em branco + mãe, doação a 400 px) |
| `cenarios.js` (meus cenários a–q) | **96 ok, 1 "falha" esperada** — (f) doação 43.125 + R$ 1 anterior passou de 862,50 para 862,52 porque a nova regra do art. 10, §7º cobra 2 % sobre o acumulado (43.126). Consistente com a premissa 4 reescrita. |
| Testes de UI #2, #9, #10, #11, #13, #14, #16 + regressões (`ui_check2.py`, `ui_check3.py`) | detalhados abaixo |

## Status dos achados da 1ª rodada

| # | Sev. original | Status | Evidência na 2ª rodada |
|---|---|---|---|
| 1 | crítico | **corrigido** | `motor.js:137-138`. Limpar → mãe viva com herdeiro em branco → classe `ascendentes` (cônjuge sem nome 1/2 + mãe 1/2, com aviso vermelho); estado civil solteiro → mãe 100 %. "+ Filho(a)" em branco não altera os quinhões. |
| 2 | crítico | **corrigido, com ressalva menor** | Destino por `uid` (`motor.js:368-380`, `ui.js:149-151`). Remover Bruno mantém o bem com Carla (420.000, ITCMD 8.400); donatário em branco à frente não desloca mais. Ressalva: ao remover a própria destinatária, `ui.js:150` reatribui o bem a "todos" **antes** de calcular, então o aviso "Bem sem donatário válido" do motor nunca chega à tela — a mudança é silenciosa (o `select` passa a mostrar "Todos", o que é visível, mas sem alerta). |
| 3 | crítico | **corrigido** | 2º falecido nasce `solteiro` (`ui.js:27`); cumulativo limpo → meação inv2 = 0. Cônjuge sem nome em casado/união → aviso vermelho (`motor.js:156`, `ui.js:202-203`). |
| 4 | grave | **corrigido** | Inputs do orçamento criados uma vez (`ui.js:243-249`); digitação "5", pausa, ".000,00" → campo "5.000,00", foco mantido, total recalculado; valor sobrevive à troca de modo e é limpo por "Limpar tudo". |
| 5 | grave | **corrigido** | `motor.js:230-239`. (j) só sobrinhos: 100.000 cada, aviso do art. 1.843, §1º; testado também pela UI (2 irmãos premortos, 1 + 3 sobrinhos → 4 × 100.000). |
| 6 | grave | **corrigido** | `motor.js:254-262`. (k) sobrinho 100.000, primo excluído com aviso nominal. |
| 7 | grave | **corrigido** | Parcela de quotas por beneficiário via frações da partilha (`motor.js:277, 287, 301`). (o) cônjuge: 3 % de 100.000 = 3.000; filho: 6 % de 100.000 + 2 % de 200.000 = 10.000 (faixa pelo quinhão total — opção agora documentada na premissa 15). |
| 8 | grave | **corrigido** | Classes `.bem-doacao`, `.colateral`, `.donatario` na media query (`estilo.css:97-100`). A 400 px, nos 3 modos: nenhum campo < 100 px, scrollWidth 400, nenhum texto < 14 px. |
| 9 | grave | **corrigido** | `uid` em herdeiros/representantes/colaterais (`ui.js:18-19`, `migrar`). Marcação VI em Carlos permanece após remover Ana. |
| 10 | grave | **corrigido** | `motor.js:383`: móveis também a 50 % (veículo 100k → base 25.000 por donatário). Premissa 14 atualizada. |
| 11 | menor | **corrigido** | Fração 0 → valor 0; `''` → 100 (`motor.js:106, 370`). |
| 12 | menor | **corrigido** | Selo e dica mostram "R$ 90,00 · MANUAL"; vazio volta ao vigente (`ui.js:169-173, 309`). |
| 13 | menor | **corrigido com nova regra — ver N1 e N5** | Premissa 4 reescrita; motor aplica art. 10, §7º (recalcula sobre o acumulado e deduz o já recolhido). Dispositivo **não constava da base fornecida** e não foi conferido por esta auditoria. |
| 14 | menor | **corrigido, com ressalva menor** | Doação em 05/10/2026 → cálculo com 87,19 e aviso na tela; UFP manual prevalece. Ressalva (N3): `#orcData` ("Referência … UFP/SE R$ 86,25") e o cabeçalho do resumo copiado continuam mostrando a UFP da data de referência, não a usada no cálculo. |
| 15 | menor | **corrigido** | "1/4 da herança nos bens particulares / 1/3 da herança nos bens comuns" (`ui.js:182`). |
| 16 | menor | **corrigido** | Avós ocultos com genitor vivo + nota do art. 1.836, §1º (`ui.js:105`). |
| 17 | menor | **parcialmente (por decisão)** | Só aviso do art. 1.811 (`motor.js:139-140`); a herança ainda vai à classe seguinte se a escrevente não recadastrar os netos como herdeiros vivos. Aceitável, está explicado no aviso. |
| 18 | menor | **corrigido** | Renunciantes nomeados contam no adicional (`ui.js:268`). |
| 19 | menor | **corrigido** | Nota "valores brutos, antes das dívidas" (`ui.js:207`). |
| 20 | menor | **corrigido** | VI só com um imóvel ≤ 2.600 UFP, só sobre a parcela do imóvel, faixa pelo restante (`motor.js:278-300`). Exemplo (2 imóveis) → aviso; casa única 200k, Carlos marcado → "imóvel isento e restante ≤ 500 UFP". |
| 21 | menor | **parcialmente** | Premissa 6 reescrita (participação final como entendimento adotado). Premissa 5 mantém a citação "art. 2º, §2º" — segue **não conferida**. |
| 22 | menor | **corrigido** | `checar.py` exit 0; novos casos cobrem os fluxos apontados. |
| 23 | menor | **corrigido** | Placeholder `#5a6272` (claro) / `#b8c0cc` (escuro). |
| 24 | menor | **corrigido** | `migrar()` mescla o rascunho sobre os defaults e gera `uid` faltantes. |

## Achados novos (regressões ou introduzidos pelas correções)

| # | Sev. | Arquivo · trecho | Achado | Como reproduzir | Correção sugerida |
|---|---|---|---|---|---|
| N1 | **grave** | `ui.js:147` (campo "ITCMD já recolhido" renderizado só se `+x.doacoesAnteriores`), `ui.js:311-322` (campo `doacoesAnteriores` é `moeda`, não estrutural → não há `renderForm`) | Ao preencher "Doações anteriores no ano", o campo **"ITCMD já recolhido" não aparece** (só surge após outro re-render estrutural, ex.: trocar de modo e voltar). Com `impostoAnterior = 0`, o motor cobra a alíquota sobre **todo o acumulado**: Bruno com 100.000 anteriores e 210.000 doados → 2 % de 310.000 = 6.200 em vez de 6.200 − o já pago. Resultado errado sem aviso na hipótese que a regra do §7º quis tratar. | Exemplo → Doação → "Doações anteriores" = 100.000 (input + change) → campo "ITCMD já recolhido" ausente; `ui_check3.py`. | Marcar o campo `doacoesAnteriores` como estrutural (re-render no `change`) **ou** exibir "ITCMD já recolhido" sempre (desabilitado quando anteriores = 0). |
| N2 | menor | `ui.js:282-283` (`#orcOpcoes` só re-renderiza quando muda o modo) | Com "Cobrar o 2º inventário como ato acessório" marcado, **Carregar exemplo** zera o estado (`emol.inv2Acessorio = false`) mas a caixa continua **marcada** na tela; o total volta a ser calculado sem o acessório (38.814,63 → 40.820,92) enquanto a caixa diz o contrário. | Cumulativo → marcar acessório → Carregar exemplo. | Re-renderizar `#orcOpcoes` também quando `S` é substituído (exemplo/limpar/restaurar), ou sincronizar `checked` com o estado a cada `orcamento()`. |
| N3 | menor | `ui.js:286, 293` | Em doação com data em outro mês, "Referência: … UFP/SE R$ 86,25" (rodapé do orçamento) e a 2ª linha do resumo copiado mostram a UFP da data de referência, não a de 87,19 efetivamente usada. | Doação com data 05/10/2026. | Usar `ULT.d.ufp` no rodapé/resumo quando o modo é doação. |
| N4 | menor | `ui.js:150` | Reatribuição silenciosa do bem para "todos" ao remover a destinatária (ver #2). | Doação → bem para Carla → remover Carla. | Emitir toast/aviso ("Bem X passou a todos os donatários") em vez de só trocar o valor. |
| N5 | menor (nota) | `motor.js:394-401` | A regra do art. 10, §7º (a) assume que as doações anteriores têm a **mesma composição imóvel/móvel** da atual (`propIm`), e (b) cobra sobre o acumulado mesmo quando a anterior era isenta (≤ 500 UFP) — o que só é correto se o dispositivo de fato manda somar. Ambos dependem de conferência do texto legal, que não estava na base fornecida. | Doação anterior de 40.000 (isenta) + atual 40.000 → 2 % de 80.000. | Conferir o §7º com a SEFAZ/SE; se a composição importar, pedir "anteriores em imóveis" e "anteriores em móveis" separadamente. |

## Regressões procuradas e não encontradas

Cenários (a)–(i) inalterados (todos OK); emolumentos idênticos; foco mantido nos campos do formulário; adicionar/remover herdeiros, bens, representantes e colaterais; renúncia; premorto sem representante; Copiar resumo (inclui as linhas editáveis do orçamento); UFP manual sobrevive à troca da data de referência; tema escuro legível; sem erros de console além da rede.

## Conclusão da 2ª rodada

Dos 24 achados, 21 estão corrigidos, 2 parcialmente por decisão documentada (#17, #21) e 1 corrigido mas com regra nova que trouxe um defeito de interface (#13 → N1). O motor passa em todos os cenários obrigatórios e nos adicionais; os três críticos da 1ª rodada não se reproduzem mais. Resta um defeito grave novo, localizado e de correção trivial (N1: o campo "ITCMD já recolhido" não aparece quando deveria, o que leva a cobrança sobre o acumulado sem dedução), mais três itens menores de sincronização de tela (N2–N4) e uma conferência legal pendente (N5, art. 10, §7º; e art. 2º, §2º da premissa 5).

VEREDITO: aprovado com ressalvas — corrigir N1 antes de liberar às escreventes; N2–N4 podem entrar na próxima manutenção; N5 e a premissa 5 dependem de conferência do texto legal.
