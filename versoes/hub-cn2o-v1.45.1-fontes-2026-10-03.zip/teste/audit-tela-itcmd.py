"""AUDITORIA v1.42 — testes adversariais de TELA da importação do dossiê (Calculadora ITCMD/SE).

O servidor real fica no ar (mock do Gemini responde pelo nome do arquivo), mas aqui a resposta de
POST /hub/ia/itcmd é INTERCEPTADA no navegador (page.route) para injetar respostas que o mock não
produz: XSS nos textos, cônjuge pré-morto, "separado", estado civil vazio com cônjuge, multa dentro
e fora dos 120 dias, datas inválidas, doação com destino desconhecido, erro 502/429/413, demora
(estado "carregando"). O JSON injetado passa ANTES pelas funções REAIS de normalização do backend
(audit-normalizar-cli.js), ou seja, a tela recebe exatamente o que o servidor devolveria.

Uso: (harness no ar — ver e2e-v1.42.py)  python3 teste/audit-tela-itcmd.py
Capturas: docs/auditoria-v1.42/*.jpg (640 px, qualidade 45).
"""
import base64, json, os, subprocess, sys, time, io
from playwright.sync_api import sync_playwright
from PIL import Image

SITE = os.environ.get('SITE', 'http://127.0.0.1:8088/')
SENHA = 'Escrituras#2026xy'
AQUI = os.path.dirname(os.path.abspath(__file__))
ARQ = os.path.join(AQUI, 'arquivos')
PDF = os.path.join(ARQ, 'dossie-inventario-silva.pdf')
SHOTS = os.path.join(AQUI, '..', 'docs', 'auditoria-v1.42'); os.makedirs(SHOTS, exist_ok=True)
ok = 0; falhas = []; achados = []

def passo(nome, fn):
    global ok
    try:
        fn(); ok += 1; print('  ✓', nome)
    except Exception as e:
        import traceback; tb = traceback.extract_tb(e.__traceback__)[-1]
        falhas.append(nome); print('  ✗', nome, '→', repr(e)[:600], '(linha %d)' % tb.lineno)

def achado(txt):
    achados.append(txt); print('  ! ACHADO:', txt)

def esperar(cond, tempo=10.0, msg=''):
    fim = time.time() + tempo
    while time.time() < fim:
        try:
            if cond(): return True
        except Exception: pass
        time.sleep(0.15)
    raise AssertionError('esperando: ' + msg)

def normalizar(cru):
    r = subprocess.run(['node', os.path.join(AQUI, 'audit-normalizar-cli.js')], input=json.dumps(cru).encode(), capture_output=True, check=True)
    return json.loads(r.stdout)

def foto(pg, nome, full=True):
    png = pg.screenshot(full_page=full)
    im = Image.open(io.BytesIO(png)).convert('RGB')
    w, h = im.size; nh = max(1, int(h * 640 / w))
    im = im.resize((640, min(nh, 6000)), Image.LANCZOS) if w != 640 else im
    im.save(os.path.join(SHOTS, nome + '.jpg'), 'JPEG', quality=45, optimize=True)

def pequenos(pg, sel):
    return pg.evaluate("""(sel) => [...document.querySelectorAll(sel)].filter(e => e.offsetParent && [...e.childNodes].some(n => n.nodeType === 3 && n.textContent.trim()) && parseFloat(getComputedStyle(e).fontSize) < 14).map(e => (e.tagName + '.' + e.className + ':' + getComputedStyle(e).fontSize + ' "' + e.textContent.trim().slice(0, 30) + '"'))""", sel)

# ---------------------------------------------------------------- JSONs crus (como se viessem do modelo)
def base_inv(**kw):
    j = {'operacao': 'inventario', 'advogado': {'nome': 'DRA. HELENA', 'oab': '5.678'}, 'requerimento': {'data': '15/09/2026', 'resumo': 'Inventário.'},
         'falecidos': [{'nome': 'JOSÉ DA SILVA', 'data_obito': '12/04/2019', 'estado_civil_no_obito': 'casado',
                        'conjuge': {'nome': 'MARIA DA SILVA', 'regime': 'parcial', 'sobrevivente': True, 'separado_de_fato': None},
                        'filhos': [{'nome': 'ANA', 'situacao': 'vivo', 'filho_do_conjuge_sobrevivente': None, 'representantes': []}],
                        'ascendentes': {'pai': {'nome': '', 'vivo': None}, 'mae': {'nome': '', 'vivo': None}, 'avos_paternos_vivos': None, 'avos_maternos_vivos': None},
                        'colaterais': [], 'bens': [{'descricao': 'Casa', 'tipo': 'imovel_urbano', 'matricula': '12.345', 'natureza': 'comum', 'fracao_do_falecido': '100', 'valor_referencia': '180000', 'fonte_valor': 'IPTU'}],
                        'dividas': '', 'inventario_requerido_em': ''}],
         'doacao': {'doadores': [], 'donatarios': [], 'bens': [], 'reserva_usufruto': None, 'data_prevista': ''}, 'alertas': []}
    f = j['falecidos'][0]
    for k, v in kw.items():
        if k in f: f[k] = v
        else: j[k] = v
    return j

with sync_playwright() as p:
    nav = p.chromium.launch()
    ctx = nav.new_context(viewport={'width': 1366, 'height': 900}, locale='pt-BR', reduced_motion='reduce')
    pg = ctx.new_page()
    erros = []; dialogos = []
    pg.on('pageerror', lambda e: erros.append(str(e)))
    pg.on('dialog', lambda d: (dialogos.append(d.message), d.dismiss()))
    pg.on('console', lambda m: erros.append(m.text) if m.type == 'error' and 'ERR_' not in m.text and 'Failed to load' not in m.text else None)

    ROTA = {'resposta': None}   # {status, corpo, segurar}
    PENDENTES = []
    def tratar(route, request):
        r = ROTA['resposta']
        if not r: return route.continue_()
        if r.get('segurar'): PENDENTES.append(route); return
        route.fulfill(status=r.get('status', 200), content_type='application/json', headers={'Access-Control-Allow-Origin': 'http://127.0.0.1:8088'}, body=json.dumps(r['corpo']))
    pg.route('**/hub/ia/itcmd', tratar)

    def entrar():
        pg.goto(SITE); pg.wait_for_selector('#campoLogin')
        pg.fill('#campoLogin', 'cesar.bravo'); pg.fill('#campoSenha', SENHA); pg.click('#btnEntrar')
        pg.wait_for_selector('#muralRodizio li', timeout=20000); pg.wait_for_timeout(500)
        pg.click('#cardItcmd'); pg.wait_for_selector('#paginaItcmd:not([hidden])'); pg.wait_for_timeout(400)
        assert pg.is_visible('#btExtrairDossie')
    passo('login e abrir 08', entrar)

    def anexar():
        while pg.locator('#itcmdImportar .anexo-x').count(): pg.click('#itcmdImportar .anexo-x >> nth=0'); pg.wait_for_timeout(80)
        pg.set_input_files('#itcmdImportar input[type=file]', PDF); pg.wait_for_timeout(300)

    def importar(cru, alertas_srv=None, esperar_painel=True):
        dados = normalizar(cru)
        ROTA['resposta'] = {'status': 200, 'corpo': {'dados': dados, 'modelo': 'audit-mock', 'ms': 1234, 'custo_usd': 0.01, 'tokens_entrada': 1, 'tokens_saida': 1, 'ocr': None, 'alertas': alertas_srv or []}}
        anexar()
        pg.evaluate("document.getElementById('itcmdImportado').classList.add('oculto')")
        pg.click('#btExtrairDossie')
        if esperar_painel:
            esperar(lambda: not pg.evaluate("document.getElementById('itcmdImportado').classList.contains('oculto')"), 15, 'painel')
            pg.wait_for_timeout(300)
        return dados

    S = lambda: pg.evaluate('window.ITCMD_UI.estado')

    # ---------------------------------------------------------------- 1. XSS por todos os campos de texto
    def xss():
        X = '<img src=x onerror="window.__xss=1">'
        cru = base_inv(nome='JOSÉ ' + X, alertas=['alerta ' + X, {'texto': 'obj'}])
        f = cru['falecidos'][0]
        f['conjuge']['nome'] = 'MARIA ' + X; f['conjuge']['regime_como_consta'] = X
        f['filhos'] = [{'nome': 'ANA ' + X, 'situacao': 'falecido', 'representantes': [{'nome': 'NETO ' + X}]}, {'nome': "' onfocus=alert(1) autofocus x='", 'situacao': 'vivo'}]
        f['bens'] = [{'descricao': 'Casa ' + X, 'tipo': 'imovel_urbano', 'matricula': '"><b>m</b>', 'natureza': '', 'fracao_do_falecido': '', 'valor_referencia': '1000', 'fonte_valor': '"><i>f</i>' + X}]
        cru['requerimento'] = {'data': X, 'resumo': 'Resumo ' + X}; cru['advogado'] = {'nome': 'ADV ' + X, 'oab': X}
        importar(cru, alertas_srv=[{'tipo': 'instrucao', 'texto': 'srv ' + X}])
        pg.wait_for_timeout(300)
        assert pg.evaluate('window.__xss') is None, 'onerror executou'
        assert pg.locator('#itcmdRaiz img[src="x"]').count() == 0, 'img injetada no DOM'
        assert pg.evaluate("[...document.querySelectorAll('#itcmdRaiz b, #itcmdRaiz i')].filter(e => e.textContent === 'm' || e.textContent === 'f').length") == 0, 'tag injetada pela matrícula/fonte'
        assert not dialogos
        # o texto chega inteiro (escapado) — nome, dica de referência, painel
        assert pg.input_value('[data-path="inv.0.nome"]') == 'JOSÉ ' + X
        assert X in pg.inner_text('[data-path="inv.0.bens.0.valor"] >> xpath=..')
        assert X in pg.inner_text('#itcmdImportado')
        # resultado (memória de cálculo) e orçamento também escapam
        assert pg.locator('#resCorpo img, #orcCorpo img').count() == 0
        # impressão: a janela nova reaproveita o innerHTML já escapado
        with ctx.expect_page() as nova:
            pg.click('#btImprimir')
        w = nova.value; w.wait_for_timeout(600)
        assert w.locator('img[src="x"]').count() == 0 and w.evaluate('window.__xss') is None
        w.close()
        foto(pg, '01-xss-escapado')
    passo('XSS: nomes, alertas (modelo e servidor), requerimento, advogado, matrícula, fonte do valor, impressão', xss)

    # ---------------------------------------------------------------- 2. mapeamento estado civil / cônjuge
    def conjuge_premorto():
        cru = base_inv(estado_civil_no_obito='casado'); cru['falecidos'][0]['conjuge']['sobrevivente'] = False
        importar(cru); s = S()['inv'][0]
        assert s['estadoCivil'] == 'solteiro' and s['conjuge']['nome'] == ''
        assert 'já havia falecido' in pg.inner_text('#itcmdImportado')
        assert pg.evaluate("window.ITCMD_UI.ultimo.inv.pat.meacao") == 0
    passo('cônjuge pré-morto (casado + sobrevivente=false) → sem viúvo, sem meação, aviso', conjuge_premorto)

    def viuvo_nunca_filho():
        cru = base_inv(); cru['falecidos'][0]['filhos'].append({'nome': 'MARIA DA SILVA', 'situacao': 'vivo'})   # modelo pôs a viúva na lista
        importar(cru); s = S()['inv'][0]
        nomes = [d['nome'] for d in s['descendentes']]
        assert 'MARIA DA SILVA' not in nomes and nomes == ['ANA'], nomes
        assert 'cônjuge sobrevivente e veio também como filho' in pg.inner_text('#itcmdImportado')
        assert pg.evaluate("window.ITCMD_UI.ultimo.inv.itc.linhas.map(l => l.nome)") == ['ANA']
        # variação: acento/caixa diferentes ("Maria da Silva" × "MARIA DA SÍLVA")
        cru = base_inv(); cru['falecidos'][0]['conjuge']['nome'] = 'Maria da Silva'; cru['falecidos'][0]['filhos'].append({'nome': 'MARIA DA SÍLVA', 'situacao': 'vivo'})
        importar(cru); assert [d['nome'] for d in S()['inv'][0]['descendentes']] == ['ANA']
    passo('G2 corrigido: viúva devolvida em "filhos" é retirada com aviso (também com acento/caixa diferentes)', viuvo_nunca_filho)

    def separado():
        cru = base_inv(estado_civil_no_obito='separado'); cru['falecidos'][0]['conjuge']['sobrevivente'] = True
        importar(cru); s = S()['inv'][0]; txt = pg.inner_text('#itcmdImportado')
        assert s['estadoCivil'] == 'casado' and s['conjuge']['separadoFato'] is True and 'consta "separado(a)"' in txt
        assert pg.evaluate("window.ITCMD_UI.ultimo.inv.pat.meacao") > 0 or True   # meação depende do valor lançado (0) — confere as regras
        assert pg.evaluate("window.ITCMD_UI.ultimo.inv.pat.rg.temConjuge") is True
        assert pg.is_checked('[data-path="inv.0.conjuge.separadoFato"]') and pg.evaluate("document.querySelector('[data-path=\"inv.0.conjuge.separadoFato\"]').closest('label').classList.contains('importado')")
        # separado + cônjuge pré-morto → sem viúvo com aviso próprio
        cru = base_inv(estado_civil_no_obito='separado'); cru['falecidos'][0]['conjuge']['sobrevivente'] = False
        importar(cru); assert S()['inv'][0]['estadoCivil'] == 'solteiro' and 'sem meação' in pg.inner_text('#itcmdImportado')
        # divorciado continua sem viúvo
        cru = base_inv(estado_civil_no_obito='divorciado'); importar(cru); assert S()['inv'][0]['estadoCivil'] == 'solteiro'
    passo('M1 corrigido: "separado" + sobrevivente → casado com "separados de fato" marcado e aviso; divorciado sem viúvo', separado)

    def ec_vazio_com_conjuge():
        cru = base_inv(estado_civil_no_obito='casada')   # feminino → enum descarta → ''
        importar(cru); s = S()['inv'][0]
        assert s['estadoCivil'] == 'casado' and s['conjuge']['nome'] == 'MARIA DA SILVA', 'servidor normaliza "casada"'
        # plano B da tela: estado civil vazio de fato, mas cônjuge vivo
        cru = base_inv(estado_civil_no_obito=''); importar(cru); s = S()['inv'][0]; txt = pg.inner_text('#itcmdImportado')
        assert s['estadoCivil'] == 'casado' and s['conjuge']['nome'] == 'MARIA DA SILVA' and 'tratado como casado(a)' in txt
        # estado civil vazio E sem cônjuge → sem viúvo com aviso genérico
        cru = base_inv(estado_civil_no_obito=''); cru['falecidos'][0]['conjuge'] = {}; importar(cru); assert S()['inv'][0]['estadoCivil'] == 'solteiro' and 'não identificado' in pg.inner_text('#itcmdImportado')
    passo('M2 corrigido: "casada" → casado no servidor; estado civil vazio + cônjuge vivo → casado com aviso (plano B)', ec_vazio_com_conjuge)

    def filhos_comuns_null():
        cru = base_inv(); cru['falecidos'][0]['filhos'] = [{'nome': 'ANA', 'situacao': 'vivo', 'filho_do_conjuge_sobrevivente': None}, {'nome': 'BETO', 'situacao': 'vivo', 'filho_do_conjuge_sobrevivente': None}]
        cru['falecidos'][0]['bens'][0]['natureza'] = 'particular'   # parcial: cônjuge concorre nos particulares → reserva de 1/4 depende de filhosComuns
        importar(cru); s = S()['inv'][0]; txt = pg.inner_text('#itcmdImportado')
        assert s['filhosComuns'] == 'sim' and '1/4' in txt and 'não ficou claro se todos os filhos' in txt
        assert not pg.evaluate("document.querySelector('[data-opcao=\"inv.0.filhosComuns\"]').closest('.opcoes').classList.contains('importado')"), 'filhosComuns não confirmado não leva a marca'
        # todos true → marca, sem aviso; universal (não concorre) → sem aviso
        for h in cru['falecidos'][0]['filhos']: h['filho_do_conjuge_sobrevivente'] = True
        importar(cru); txt = pg.inner_text('#itcmdImportado'); assert '1/4' not in txt and pg.evaluate("document.querySelector('[data-opcao=\"inv.0.filhosComuns\"]').closest('.opcoes').classList.contains('importado')")
        for h in cru['falecidos'][0]['filhos']: h['filho_do_conjuge_sobrevivente'] = None
        cru['falecidos'][0]['conjuge']['regime'] = 'universal'; importar(cru); assert '1/4' not in pg.inner_text('#itcmdImportado')
    passo('M3 corrigido: filiação null com cônjuge que concorre → aviso da reserva de 1/4 e sem marca; true → marca; universal → sem aviso', filhos_comuns_null)

    # ---------------------------------------------------------------- 3. multa dos 120 dias / datas
    def multa():
        for req, esperado, rot in [('10/08/2019', False, '120 dias exatos'), ('11/08/2019', True, '121 dias'), ('01/04/2019', True, 'antes do óbito'), ('2019-05-01', True, 'ISO'), ('15/09/2026', True, 'anos depois'), ('', True, 'sem data')]:
            cru = base_inv(inventario_requerido_em=req); importar(cru); s = S()['inv'][0]
            assert s['multaAtraso'] is esperado, (rot, req, s['multaAtraso'])
        # data de óbito inexistente
        cru = base_inv(data_obito='31/02/2020', inventario_requerido_em='05/03/2020'); importar(cru); s = S()['inv'][0]
        assert s['obito'] == '' and s['multaAtraso'] is True and 'data do óbito não identificada' in pg.inner_text('#itcmdImportado'), (s['obito'], s['multaAtraso'])
        assert 'inv.0.obito' not in S()['origem']['paths']
        cru = base_inv(data_obito='29/02/2020', inventario_requerido_em='1/3/2020'); importar(cru); s = S()['inv'][0]
        assert s['obito'] == '2020-02-29' and s['multaAtraso'] is False, 'bissexto válido; dia/mês sem zero'
    passo('multa: só desliga com pedido em ≤ 120 dias; ISO/antes/vazio mantêm; M9 corrigido: 31/02 cai, 29/02/2020 passa', multa)

    # ---------------------------------------------------------------- 4. bens / valores
    def valores():
        cru = base_inv(); cru['falecidos'][0]['bens'] = [
            {'descricao': 'Casa', 'tipo': 'imovel_urbano', 'natureza': 'comum', 'fracao_do_falecido': '100', 'valor_referencia': '180000', 'fonte_valor': 'IPTU'},
            {'descricao': 'Terreno', 'tipo': 'terreno', 'natureza': '', 'fracao_do_falecido': '150', 'valor_referencia': '-5000', 'fonte_valor': 'x'},
            {'descricao': 'Poupança', 'tipo': 'dinheiro', 'natureza': 'particular', 'fracao_do_falecido': '0', 'valor_referencia': '1e308', 'fonte_valor': ''}]
        cru['falecidos'][0]['dividas'] = '-1000'
        importar(cru); s = S()['inv'][0]
        assert all(b['valor'] == 0 for b in s['bens']), 'valor declarado sempre 0'
        assert s['bens'][0]['valorRef'] == 180000 and s['bens'][1]['fracao'] == 100 and s['bens'][2]['fracao'] == 100
        assert s['dividas'] == 0
        assert pg.evaluate("window.ITCMD_UI.ultimo.inv.pat.monteMor") == 0
        assert pg.locator('#itcmdRaiz .campo.pendente').count() == 3
        dica = pg.inner_text('[data-path="inv.0.bens.1.valor"] >> xpath=..')
        assert 'ref.' not in dica and s['bens'][1]['valorRef'] == 0, dica
        assert s['bens'][1]['tipo'] == 'imovel_urbano' and not pg.evaluate("!!window.ITCMD_UI.estado.origem.paths['inv.0.bens.1.tipo']") and 'tipo não identificado' in pg.inner_text('#itcmdImportado')
        assert not pg.evaluate("!!window.ITCMD_UI.estado.origem.paths['inv.0.bens.1.natureza']") and pg.evaluate("!!window.ITCMD_UI.estado.origem.paths['inv.0.bens.0.natureza']"), 'natureza defaultada sem marca; informada com marca'
        assert 'ref.' not in pg.inner_text('[data-path="inv.0.bens.2.valor"] >> xpath=..'), '1e308 não vira referência'
        # lançar valor: some o realce e o rascunho preserva origem
        pg.click('#btLancarValores'); pg.keyboard.type('200000'); pg.keyboard.press('Tab'); pg.wait_for_timeout(500)
        assert pg.locator('#itcmdRaiz .campo.pendente').count() == 2 and S()['inv'][0]['bens'][0]['valor'] == 200000
        assert '2 valor(es) a lançar' in pg.inner_text('#itcmdImportado')
        foto(pg, '02-valores-a-lancar')
    passo('bens: valor sempre 0, ref. como dica, fração inválida → 100, dívida negativa → 0, tipo inválido', valores)

    # ---------------------------------------------------------------- 5. marcas "do dossiê"
    def marcas():
        cru = base_inv(); cru['falecidos'][0]['conjuge']['separado_de_fato'] = True; cru['falecidos'][0]['inventario_requerido_em'] = '01/05/2019'
        cru['falecidos'][0]['filhos'][0]['filho_do_conjuge_sobrevivente'] = False
        importar(cru); s = S()
        paths = list(s['origem']['paths'].keys())
        vis = pg.evaluate("[...document.querySelectorAll('#itcmdRaiz .campo.importado')].map(c => c.querySelector('[data-path]').dataset.path)")
        invisiveis = [p for p in paths if p not in vis]
        vis += pg.evaluate("[...document.querySelectorAll('#itcmdRaiz .opcoes.importado button')].map(b => b.dataset.opcao).concat([...document.querySelectorAll('#itcmdRaiz label.marcar.importado input')].map(i => i.dataset.path))")
        # controle que a tela nem renderiza (filhosComuns quando o cônjuge não concorre — aqui separado de fato) não conta
        renderizados = pg.evaluate("[...document.querySelectorAll('#itcmdRaiz [data-path], #itcmdRaiz [data-opcao]')].map(e => e.dataset.path || e.dataset.opcao)")
        invisiveis = [p for p in paths if p not in vis and p in renderizados]
        assert not invisiveis, invisiveis
        print('     caminhos de origem sem controle na tela (ocultos por regra):', [p for p in paths if p not in renderizados])
        ps = pg.evaluate("[...document.querySelectorAll('#itcmdRaiz .opcoes.importado')].map(e => getComputedStyle(e, '::after').content + ' ' + getComputedStyle(e, '::after').fontSize).concat([...document.querySelectorAll('#itcmdRaiz label.marcar.importado > span')].map(e => getComputedStyle(e, '::after').content + ' ' + getComputedStyle(e, '::after').fontSize))")
        assert ps and all('do dossiê' in x and '14px' in x for x in ps), ps
        # digitar por cima tira a marca (input + change)
        pg.fill('[data-path="inv.0.conjuge.nome"]', 'MARIA X'); pg.dispatch_event('[data-path="inv.0.conjuge.nome"]', 'input'); pg.wait_for_timeout(400)
        assert not pg.evaluate("document.querySelector('[data-path=\"inv.0.conjuge.nome\"]').closest('.campo').classList.contains('importado')")
        assert 'inv.0.conjuge.nome' not in S()['origem']['paths']
        # select estrutural (regime) por cima
        pg.select_option('[data-path="inv.0.regime"]', 'universal'); pg.wait_for_timeout(400)
        assert 'inv.0.regime' not in S()['origem']['paths'] and not pg.evaluate("document.querySelector('[data-path=\"inv.0.regime\"]').closest('.campo').classList.contains('importado')")
        # opção (botão) por cima: a origem permanece?
        pg.click('[data-opcao="inv.0.estadoCivil"][data-valor="uniao"]'); pg.wait_for_timeout(400)
        assert 'inv.0.estadoCivil' not in S()['origem']['paths'] and not pg.evaluate("document.querySelector('[data-opcao=\"inv.0.estadoCivil\"]').closest('.opcoes').classList.contains('importado')")
        # caixa por cima (multaAtraso) tira a marca
        pg.evaluate("document.querySelector('[data-path=\"inv.0.multaAtraso\"]').closest('details').open = true"); pg.click('[data-path="inv.0.multaAtraso"]'); pg.wait_for_timeout(400)
        assert 'inv.0.multaAtraso' not in S()['origem']['paths'], 'origem apagada ao clicar na caixa'
        if pg.evaluate("document.querySelector('[data-path=\"inv.0.multaAtraso\"]').closest('label').classList.contains('importado')"):
            achado('M4 (resíduo menor): clicar numa caixa (marcar) apaga S.origem.paths mas a marca "· do dossiê" fica na tela até a próxima re-renderização — aplicarEntrada só remove a classe de el.closest(".campo"), e nas caixas a classe está no label.marcar (ui.js aplicarEntrada)')
        # o rascunho guarda origem
        r = json.loads(pg.evaluate("localStorage.getItem('itcmd-rascunho')"))
        assert r['S']['origem'] and r['S']['inv'][0]['bens'][0]['doDossie'] is True
    passo('M4 corrigido: marcas em campo/opções/caixas; somem ao digitar, select, opção e caixa; rascunho', marcas)

    # ---------------------------------------------------------------- 6. Desfazer / importar 2× / Limpar / Exemplo / trocar modo
    def desfazer_fluxos():
        pg.click('#btLimpar'); pg.wait_for_timeout(300)
        assert S().get('origem') is None and pg.evaluate("document.getElementById('itcmdImportado').classList.contains('oculto')")
        # 1ª importação
        importar(base_inv(nome='PRIMEIRO')); assert S()['inv'][0]['nome'] == 'PRIMEIRO'
        # 2ª importação por cima
        importar(base_inv(nome='SEGUNDO')); assert S()['inv'][0]['nome'] == 'SEGUNDO'
        pg.click('#btDesfazerImportacao'); pg.wait_for_timeout(400)
        s = S(); assert s['inv'][0]['nome'] == 'PRIMEIRO' and s['origem'] and 'PRIMEIRO' in pg.inner_text('#itcmdImportado'), 'Desfazer volta à 1ª importação (com marcas)'
        assert pg.locator('#itcmdRaiz .campo.importado').count() >= 5
        pg.click('#btDesfazerImportacao'); pg.wait_for_timeout(400)
        s = S(); assert s['inv'][0]['nome'] == '' and s.get('origem') is None, '2º Desfazer (sem "antes") limpa'
        # importar → Limpar → painel some; Desfazer inexistente; nova importação → Desfazer volta ao limpo
        importar(base_inv(nome='TERCEIRO')); pg.click('#btLimpar'); pg.wait_for_timeout(300)
        assert pg.locator('#btDesfazerImportacao').count() == 0 and S().get('origem') is None
        importar(base_inv(nome='QUARTO')); pg.click('#btDesfazerImportacao'); pg.wait_for_timeout(400)
        assert S()['inv'][0]['nome'] == '' and S().get('origem') is None
        # importar → Exemplo → o painel some e as marcas também
        importar(base_inv(nome='QUINTO')); pg.click('#btExemplo'); pg.wait_for_timeout(300)
        assert S().get('origem') is None and pg.locator('#itcmdRaiz .campo.importado').count() == 0
        # Desfazer depois do Exemplo? (o painel está oculto — não há botão) → estado do exemplo permanece
        assert S()['inv'][0]['nome'] == 'José da Silva'
        # trocar de modo depois de importar
        importar(base_inv(nome='SEXTO')); pg.click('#segModo button[data-modo="doacao"]'); pg.wait_for_timeout(400)
        txt = pg.inner_text('#itcmdImportado')
        assert 'são de um inventário' in txt and 'valores lançados' not in txt and pg.locator('#btDesfazerImportacao').count() == 0
        pg.click('#btVoltarModoImportado'); pg.wait_for_timeout(300)
        assert S()['modo'] == 'inventario' and 'Dados importados' in pg.inner_text('#itcmdImportado')
        pg.click('#segModo button[data-modo="cumulativo"]'); pg.wait_for_timeout(300); assert 'são de um inventário' in pg.inner_text('#itcmdImportado')
        pg.click('#segModo button[data-modo="inventario"]'); pg.wait_for_timeout(300)
        assert S()['inv'][0]['nome'] == 'SEXTO' and pg.locator('#itcmdRaiz .campo.importado').count() >= 5, 'voltar ao modo devolve os campos importados'
        foto(pg, '03-desfazer-fluxos')
    passo('Desfazer: 2ª importação → 1ª → limpo; Limpar; Exemplo; M7 corrigido: trocar de modo mostra aviso + "Voltar"', desfazer_fluxos)

    # ---------------------------------------------------------------- 7. doação
    def doacao():
        cru = {'operacao': 'doacao', 'advogado': {'nome': '', 'oab': ''}, 'requerimento': {'data': '', 'resumo': 'Doação.'}, 'falecidos': [],
               'doacao': {'doadores': [{'nome': 'ANTÔNIO'}], 'donatarios': [{'nome': 'Carla Pereira'}, {'nome': 'CARLA PEREIRA'}, {'nome': 'BRUNO'}],
                          'bens': [{'descricao': 'Lote', 'tipo': 'imovel_urbano', 'destino': 'carla pereira ', 'fracao': '100', 'valor_referencia': '', 'fonte_valor': ''},
                                   {'descricao': 'Carro', 'tipo': 'veiculo', 'destino': 'ZÉ', 'fracao': '100', 'valor_referencia': '30000', 'fonte_valor': 'FIPE'},
                                   {'descricao': 'Apto', 'tipo': 'imovel_urbano', 'destino': '', 'fracao': '', 'valor_referencia': '', 'fonte_valor': ''}],
                          'reserva_usufruto': 'sim', 'data_prevista': '10/10/2026'}, 'alertas': []}
        importar(cru); s = S()
        assert s['modo'] == 'doacao' and s['doa']['bens'][0]['destino'] == s['doa']['donatarios'][0]['uid'], 'destino por nome, sem distinguir caixa/espaços → primeiro homônimo'
        assert s['doa']['bens'][1]['destino'] == 'todos' and 'ZÉ' in pg.inner_text('#itcmdImportado')
        assert s['doa']['bens'][2]['destino'] == 'todos' and s['doa']['reservaUsufruto'] is False and s['doa']['data'] == '2026-10-10'
        assert 'Não ficou claro se há reserva de usufruto' in pg.inner_text('#itcmdImportado'), 'nota: reserva_usufruto "sim" → null → aviso'
        assert all(b['valor'] == 0 for b in s['doa']['bens']) and pg.locator('#itcmdRaiz .campo.pendente').count() == 3
        # M11: doações anteriores no exercício
        cru['doacao']['donatarios'] = [{'nome': 'CARLA', 'doacoes_anteriores_no_ano': '40.000,00', 'itcmd_recolhido_anteriores': '800', 'fonte': 'DIT 2026'}, {'nome': 'BRUNO'}]
        cru['doacao']['bens'] = [{'descricao': 'Lote', 'tipo': 'imovel_urbano', 'destino': 'todos', 'fracao': '100'}]
        importar(cru); s = S(); txt = pg.inner_text('#itcmdImportado')
        assert s['doa']['donatarios'][0]['doacoesAnteriores'] == 40000 and s['doa']['donatarios'][0]['impostoAnterior'] == 800 and s['doa']['donatarios'][1]['doacoesAnteriores'] == 0
        assert 'doações anteriores no exercício lançadas' in txt
        assert pg.evaluate("document.querySelector('[data-path=\"doa.donatarios.0.doacoesAnteriores\"]').closest('.campo').classList.contains('importado')")
        assert pg.evaluate("document.querySelector('[data-path=\"doa.donatarios.0.impostoAnterior\"]').closest('.campo').classList.contains('importado')")
        assert pg.input_value('[data-path="doa.donatarios.0.doacoesAnteriores"]') == '40.000,00'
        assert all(b['valor'] == 0 for b in s['doa']['bens']) and pg.locator('#itcmdRaiz .campo.pendente').count() == 1
        # doação com falecidos também (modelo confuso): operacao inventario mas só doacao preenchida → doacao
        cru2 = dict(cru); cru2['operacao'] = ''; importar(cru2); assert S()['modo'] == 'doacao'
        # operacao "doacao" mas com falecidos e sem doação → doação vazia
        cru3 = base_inv(); cru3['operacao'] = 'doacao'; importar(cru3); s = S()
        print('     operacao=doacao com 1 falecido e doação vazia → modo =', s['modo'], '| aviso:', 'Nenhum donatário' in pg.inner_text('#itcmdImportado'))
        foto(pg, '04-doacao-destino')
    passo('doação: destino por nome, destino desconhecido, usufruto "sim" (aviso), operação ambígua; M11: doações anteriores com marca', doacao)

    # ---------------------------------------------------------------- 8. cumulativo: bens repetidos nos dois falecidos
    def cumulativo_repetido():
        cru = base_inv(); cru['operacao'] = 'cumulativo'
        maria = json.loads(json.dumps(cru['falecidos'][0])); maria.update({'nome': 'MARIA DA SILVA', 'data_obito': '03/02/2026', 'estado_civil_no_obito': 'viuvo'}); maria['conjuge'] = {'nome': 'JOSÉ DA SILVA', 'sobrevivente': False}
        cru['falecidos'].append(maria)   # o modelo repetiu a casa nos dois falecidos
        importar(cru); s = S()
        assert s['modo'] == 'cumulativo' and s['inv'][1]['estadoCivil'] == 'solteiro'
        txt = pg.inner_text('#itcmdImportado')
        assert s['inv'][1]['bens'][0]['descricao'] == '' and 'constava nos dois falecidos — retirado do 2º inventário' in txt, (s['inv'][1]['bens'], txt[:400])
        assert len(s['inv'][0]['bens']) == 1 and '12.345' in s['inv'][0]['bens'][0]['descricao']
        # bem próprio legítimo do 2º (matrícula diferente) fica
        maria['bens'] = [dict(cru['falecidos'][0]['bens'][0]), {'descricao': 'Poupança Banese', 'tipo': 'dinheiro', 'matricula': '', 'natureza': 'particular', 'fracao_do_falecido': '100', 'valor_referencia': '18500', 'fonte_valor': 'extrato'}]
        importar(cru); s = S(); assert [b['descricao'] for b in s['inv'][1]['bens']] == ['Poupança Banese']
        # chave: matrícula em um e só descrição no outro NÃO casa (limite do critério)
        maria['bens'] = [{'descricao': 'Casa', 'tipo': 'imovel_urbano', 'matricula': '', 'natureza': 'comum', 'fracao_do_falecido': '100'}]
        importar(cru); s = S(); print('     repetido só pela descrição (sem matrícula no 2º):', 'retirado' in pg.inner_text('#itcmdImportado'), '→', [b['descricao'] for b in s['inv'][1]['bens']])
        if 'retirado' not in pg.inner_text('#itcmdImportado'): achado('G1 (resíduo menor): a chave do bem é `matricula || descricao`; se o 2º falecido vier sem matrícula e o 1º com, o mesmo bem não é reconhecido como repetido')
        # ordem: modelo devolveu o mais recente primeiro → reordenado com aviso
        maria['bens'] = []; cru['falecidos'].reverse(); importar(cru); s = S()
        assert s['inv'][0]['nome'] == 'JOSÉ DA SILVA' and s['inv'][1]['nome'] == 'MARIA DA SILVA' and 'fora da ordem cronológica — reordenados' in pg.inner_text('#itcmdImportado')
        foto(pg, '05-cumulativo-repetido')
    passo('G1 corrigido: bem repetido sai do 2º com aviso; M10 corrigido: ordem invertida reordenada', cumulativo_repetido)

    # ---------------------------------------------------------------- 9. estados da zona: vazia, carregando, erro; fontes < 14; escuro; 400 px
    def estados_visuais():
        for tema in ('light', 'dark'):
            pg.evaluate("document.documentElement.setAttribute('data-theme','%s')" % tema); pg.wait_for_timeout(200)
            # vazio
            while pg.locator('#itcmdImportar .anexo-x').count(): pg.click('#itcmdImportar .anexo-x >> nth=0'); pg.wait_for_timeout(80)
            peq = pequenos(pg, '#itcmdImportar *'); assert not peq, ('vazio', tema, peq)
            # carregando (resposta demorada)
            ROTA['resposta'] = {'status': 200, 'segurar': True, 'corpo': {}}
            anexar(); pg.click('#btExtrairDossie'); pg.wait_for_timeout(900)
            assert 'Interromper' in pg.inner_text('#btExtrairDossie')
            peq = pequenos(pg, '#itcmdImportar *'); assert not peq, ('carregando', tema, peq)
            cores = pg.evaluate("(() => { const m = document.querySelector('#itcmdImportarStatus .pi-msg, #itcmdImportarStatus .importar-progresso'); const t = document.querySelector('#itcmdImportarStatus .pi-tempo'); const cs = e => e ? getComputedStyle(e).color + ' sobre ' + getComputedStyle(e.closest('.cartao')).backgroundColor : null; return { msg: cs(m), tempo: cs(t) }; })()")
            print('     carregando (%s): %s' % (tema, cores))
            foto(pg, '06-carregando-' + tema, full=False)
            pg.click('#btExtrairDossie'); pg.wait_for_timeout(400)   # Interromper
            assert 'interrompida' in pg.inner_text('#itcmdImportarStatus').lower()
            for rt in PENDENTES:
                try: rt.abort()
                except Exception: pass
            PENDENTES.clear()
            # erro 502 json, 429 teto, 413
            for st, corpo, trecho in [(502, {'erro': 'o modelo não devolveu dados estruturados — tente de novo', 'motivo': 'json'}, 'não devolveu dados'), (429, {'erro': 'limite', 'motivo': 'teto'}, 'limite diário'), (413, {'erro': 'arquivos grandes demais para uma análise só (máx. ≈ 13 MB somados) — envie só as páginas necessárias'}, 'grandes demais')]:
                ROTA['resposta'] = {'status': st, 'corpo': corpo}; anexar(); antes = pg.evaluate('JSON.stringify(window.ITCMD_UI.estado)')
                pg.click('#btExtrairDossie'); esperar(lambda: trecho in pg.inner_text('#itcmdImportarStatus').lower(), 10, trecho)
                assert pg.evaluate('JSON.stringify(window.ITCMD_UI.estado)') == antes
                peq = pequenos(pg, '#itcmdImportar *'); assert not peq, ('erro', tema, peq)
                cor = pg.evaluate("(() => { const e = document.querySelector('#itcmdImportarStatus .importar-erro'); return getComputedStyle(e).color + ' sobre ' + getComputedStyle(e).backgroundColor; })()")
            print('     erro (%s): %s' % (tema, cor))
            foto(pg, '07-erro-' + tema, full=False)
            # importado
            importar(base_inv()); peq = pequenos(pg, '#itcmdImportar *, #itcmdRaiz .campo.importado *, #itcmdRaiz .campo.pendente *'); assert not peq, ('importado', tema, peq)
            # pseudo-elementos ::after das marcas
            ps = pg.evaluate("[...document.querySelectorAll('#itcmdRaiz .campo.importado > label, #itcmdRaiz .campo.pendente > label')].map(l => { const a = getComputedStyle(l, '::after'); return a.content + ' ' + a.fontSize + ' ' + a.color; })")
            assert all('14px' in x for x in ps), ps
            cores = pg.evaluate("""(() => { const q = s => document.querySelector(s); const cs = (e, bg) => e ? getComputedStyle(e).color + ' sobre ' + getComputedStyle(bg || e).backgroundColor : null;
                return { h3: cs(q('#itcmdImportado h3'), q('#itcmdImportado')), chip: cs(q('#itcmdImportado .chip')), meta: cs(q('#itcmdImportado .meta'), q('#itcmdImportado')), importadoInput: cs(q('.campo.importado input')), pendenteInput: cs(q('.campo.pendente input')), marcaImportado: getComputedStyle(q('.campo.importado > label'), '::after').color, marcaPendente: getComputedStyle(q('.campo.pendente > label'), '::after').color, fantasma: cs(q('#itcmdImportar .btn-fantasma')) + ' borda ' + getComputedStyle(q('#itcmdImportar .btn-fantasma')).border, dica: cs(q('#itcmdImportar .anexo-dica'), q('.importar-zona')), obs: cs(q('#itcmdObs')) }; })()""")
            print('     importado (%s): %s' % (tema, json.dumps(cores, ensure_ascii=False)))
            assert 'solid' in cores['fantasma'] and 'rgb(99, 19, 37)' in cores['fantasma'], ('M6', cores['fantasma'])
            if tema == 'dark': assert cores['h3'].startswith('rgb(207, 233, 216)'), ('h3 verde no escuro', cores['h3'])
            else: assert cores['h3'].startswith('rgb(36, 92, 58)'), cores['h3']
            foto(pg, '08-importado-' + tema)
            # 400 px
            pg.set_viewport_size({'width': 400, 'height': 860}); pg.wait_for_timeout(400)
            sw = pg.evaluate('document.documentElement.scrollWidth'); assert sw <= 400, sw
            larg = pg.evaluate("[...document.querySelectorAll('#itcmdImportar *')].filter(e => e.getBoundingClientRect().right > 400.5).map(e => e.tagName + '.' + e.className + ':' + Math.round(e.getBoundingClientRect().right))")
            assert not larg, larg
            foto(pg, '09-importado-400-' + tema)
            pg.set_viewport_size({'width': 1366, 'height': 900}); pg.wait_for_timeout(300)
        pg.evaluate("document.documentElement.setAttribute('data-theme','light')")
    passo('estados: vazio / carregando / interrompido / erro 502-429-413 / importado — fontes ≥ 14 px, cores, 400 px, claro e escuro', estados_visuais)

    # ---------------------------------------------------------------- 9b. G3 na tela: separação obrigatória + Súmula 377
    def sumula377():
        cru = base_inv(); cru['falecidos'][0]['conjuge'].update({'regime': 'separação obrigatória de bens (art. 1.641, II), com comunicação dos aquestos (Súmula 377/STF)', 'regime_como_consta': 'separação obrigatória — Súmula 377'})
        importar(cru); s = S()['inv'][0]; txt = pg.inner_text('#itcmdImportado')
        assert s['regime'] == 'separacao_obrig' and s['conjuge']['sumula377'] is True and 'Súmula 377' in txt
        assert pg.is_checked('[data-path="inv.0.conjuge.sumula377"]') and pg.evaluate("document.querySelector('[data-path=\"inv.0.conjuge.sumula377\"]').closest('label').classList.contains('importado')")
        rg = pg.evaluate("window.ITCMD_UI.ultimo.inv.pat.rg"); assert rg['meacaoSobre'] == 'comuns' and rg['concorreDesc'] == 'nada', rg
        # "377" solto em pacto com regime parcial: flag vem true mas a caixa só existe na separação obrigatória — o motor ignora
        cru = base_inv(); cru['falecidos'][0]['conjuge'].update({'regime': 'parcial', 'pacto': 'livro 377'}); importar(cru)
        assert pg.locator('[data-path="inv.0.conjuge.sumula377"]').count() == 0 and pg.evaluate("window.ITCMD_UI.ultimo.inv.pat.rg.concorreDesc") == 'particulares'
        if 'caixa "Aplicar a Súmula 377" marcada' in pg.inner_text('#itcmdImportado'): achado('G3 (resíduo menor): "377" no pacto/regime_como_consta com regime que não é separação obrigatória gera o aviso "caixa Aplicar a Súmula 377 marcada", mas a caixa não existe nesse regime (motor ignora) — aviso enganoso; condicionar a f.regime === "separacao_obrig"')
    passo('G3 corrigido na tela: separação obrigatória + Súmula 377 → regime certo, caixa marcada, sem concorrência', sumula377)

    def sticky():
        importar(base_inv())
        m = pg.evaluate("""(() => { const h = document.querySelector('#itcmdImportado h3').getBoundingClientRect(), b = document.getElementById('barraViva').getBoundingClientRect(); return { coberto: h.top < b.bottom && h.bottom > b.top, folga: Math.round(h.top - b.bottom) }; })()""")
        assert not m['coberto'] and m['folga'] >= 8, m
        pg.set_viewport_size({'width': 400, 'height': 860}); pg.wait_for_timeout(300); importar(base_inv())
        m = pg.evaluate("""(() => { const h = document.querySelector('#itcmdImportado h3').getBoundingClientRect(), b = document.getElementById('barraViva').getBoundingClientRect(); return { coberto: h.top < b.bottom && h.bottom > b.top, folga: Math.round(h.top - b.bottom) }; })()""")
        assert not m['coberto'], m
        pg.set_viewport_size({'width': 1366, 'height': 900}); pg.wait_for_timeout(300)
    passo('M5 corrigido: barra viva não cobre o título do painel após a importação (1366 e 400 px)', sticky)

    # ---------------------------------------------------------------- 10. imprimir com valores lançados
    def imprimir():
        importar(base_inv())
        pg.click('#btLancarValores'); pg.keyboard.type('300000'); pg.keyboard.press('Tab'); pg.wait_for_timeout(500)
        assert 'valores lançados' in pg.inner_text('#itcmdImportado')
        with ctx.expect_page() as nova:
            pg.click('#btImprimir')
        w = nova.value; w.wait_for_timeout(700); t = w.content()
        assert 'R$ 300.000,00' in t and 'Elaborado por' in t and 'Memória de cálculo' in t
        assert 'ADICIONAR' not in t.upper() or 'btn-fantasma' not in t
        assert 'do dossiê' not in t and 'lançar o valor' not in t and 'Dados importados' not in t, 'marcas de importação não vão para o orçamento impresso'
        print('     impressão: "ref. R$" aparece?', 'ref. R$' in t)
        w.close()
    passo('imprimir orçamento com valores lançados: sem marcas de importação', imprimir)

    # ---------------------------------------------------------------- 11. ouvintes presos a #itcmdRaiz
    def ouvintes():
        importar(base_inv()); antes = pg.evaluate('JSON.stringify(window.ITCMD_UI.estado)')
        pg.evaluate("""(() => { const b = document.createElement('button'); b.id = 'btDesfazerImportacao'; b.dataset.modo = 'doacao'; document.body.appendChild(b); b.click(); b.remove(); })()""")
        pg.wait_for_timeout(300)
        assert pg.evaluate('JSON.stringify(window.ITCMD_UI.estado)') == antes, 'botão homônimo fora de #itcmdRaiz não mexe no estado'
    passo('ouvintes: botões homônimos fora de #itcmdRaiz não afetam a importação', ouvintes)

    # ---------------------------------------------------------------- 12. rascunho: recarregar e restaurar com origem
    def rascunho():
        importar(base_inv(nome='RASCUNHO')); pg.click('#btLancarValores'); pg.keyboard.type('1000'); pg.keyboard.press('Tab'); pg.wait_for_timeout(400)
        pg.reload(); pg.wait_for_selector('#paginaItcmd:not([hidden])', timeout=20000); pg.wait_for_timeout(800)
        pg.click('#btRestaurar'); pg.wait_for_timeout(500)
        s = S(); assert s['inv'][0]['nome'] == 'RASCUNHO' and s['origem'] and s['inv'][0]['bens'][0]['valor'] == 1000
        assert 'valores lançados' in pg.inner_text('#itcmdImportado')
        # Desfazer depois de recarregar (sem "antes") → limpa, como documentado no e2e
        pg.click('#btDesfazerImportacao'); pg.wait_for_timeout(300); assert S()['inv'][0]['nome'] == ''
    passo('rascunho preserva origem, valores lançados e marcas; Desfazer pós-reload limpa', rascunho)

    nav.close()

print('\n%d ok, %d falha(s); erros de console: %d; achados: %d' % (ok, len(falhas), len(erros), len(achados)))
for e in erros[:8]: print('   console:', e[:200])
for a in achados: print('   ACHADO:', a)
sys.exit(1 if falhas else 0)
