// AUDITORIA v1.42 — testes adversariais da normalização do Leitor de dossiê (hub.js:
// normalizarDossieItcmd e auxiliares) carregadas direto do fonte, sem servidor.
// Uso: node teste/audit-normalizar-itcmd.js   (sai 1 se algum achado se confirmar)
'use strict';
const fs = require('fs'), path = require('path'), assert = require('assert');
const s = fs.readFileSync(path.join(__dirname, '..', 'backend', 'hub.js'), 'utf8');
const a = s.indexOf('const CHAVES_PESSOA'), b = s.indexOf('function extrairJson');
const c = s.indexOf('// ---------------------------------------------------------------- Leitor de dossiê'), d = s.indexOf('// ---------------------------------------------------------------- Minuta → Google Docs');
assert(a > 0 && b > a && c > b && d > c, 'âncoras do hub.js não encontradas');
const m = { exports: {} };
new Function('module', 'require', s.slice(a, b) + s.slice(c, d) + ';module.exports={normalizarDossieItcmd,enumItcmd,regimeItcmd,numeroItcmd,boolItcmd,avosItcmd,ITCMD_ENUM,LIM_ITCMD}')(m, require);
const { normalizarDossieItcmd: N, enumItcmd, regimeItcmd, numeroItcmd, boolItcmd, avosItcmd, ITCMD_ENUM } = m.exports;
// extrairJson vem separado (está antes da âncora c)
const m2 = { exports: {} };
new Function('module', 'require', s.slice(a, s.indexOf('// ---------------------------------------------------------------- Leitor de dossiê')) + ';module.exports={extrairJson}')(m2, require);
const { extrairJson } = m2.exports;

let ok = 0; const falhas = [], notas = [];
function t(nome, fn) { try { fn(); ok++; console.log('  ✓', nome); } catch (e) { falhas.push(nome + ' → ' + e.message); console.log('  ✗', nome, '→', e.message); } }
function nota(txt) { notas.push(txt); console.log('  ·', txt); }
const CHAVES_TOPO = ['operacao', 'advogado', 'requerimento', 'falecidos', 'doacao', 'alertas'];
const CHAVES_FAL = ['nome', 'data_obito', 'local_obito', 'certidao_obito', 'estado_civil_no_obito', 'conjuge', 'filhos', 'ascendentes', 'colaterais', 'bens', 'dividas', 'inventario_requerido_em'];
const CHAVES_BEM = ['descricao', 'tipo', 'matricula', 'valor_referencia', 'fonte_valor', 'fonte', 'natureza', 'fracao_do_falecido'];

t('forma fixa com objeto vazio: todas as chaves presentes', () => {
  const r = N({});
  assert.deepStrictEqual(Object.keys(r).sort(), CHAVES_TOPO.slice().sort());
  assert.deepStrictEqual(r.falecidos, []); assert.strictEqual(r.operacao, '');
  assert.deepStrictEqual(r.doacao, { doadores: [], donatarios: [], bens: [], reserva_usufruto: null, data_prevista: '' });
});
t('forma fixa do falecido com objeto vazio (nome vazio some; com data_obito fica)', () => {
  const r = N({ falecidos: [{}, { data_obito: '01/01/2020' }] });
  assert.strictEqual(r.falecidos.length, 1);
  assert.deepStrictEqual(Object.keys(r.falecidos[0]).sort(), CHAVES_FAL.slice().sort());
  assert.deepStrictEqual(r.falecidos[0].conjuge, { nome: '', regime: '', regime_como_consta: '', data_casamento: '', pacto: '', sobrevivente: null, separado_de_fato: null, sumula_377: false });
});
t('chaves fora do contrato não passam (nível topo, falecido, bem, filho)', () => {
  const r = N({ valor: 1, falecidos: [{ nome: 'X', valor: 99, bens: [{ descricao: 'casa', valor: 500000, valor_declarado: 1 }], filhos: [{ nome: 'F', cpf: '000' }] }] });
  assert(!('valor' in r)); assert(!('valor' in r.falecidos[0]));
  assert.deepStrictEqual(Object.keys(r.falecidos[0].bens[0]).sort(), CHAVES_BEM.slice().sort());
  assert(!('valor' in r.falecidos[0].bens[0]), 'o VALOR DECLARADO nunca sai do servidor');
  assert(!('cpf' in r.falecidos[0].filhos[0]));
});
t('prototype pollution: __proto__/constructor no JSON não alteram Object.prototype nem vazam', () => {
  const j = JSON.parse('{"__proto__":{"polu":1},"constructor":{"prototype":{"polu2":1}},"falecidos":[{"__proto__":{"x":1},"nome":"A","conjuge":{"__proto__":{"y":1}},"ascendentes":{"pai":{"__proto__":{"z":1},"nome":"P","vivo":true}}}],"doacao":{"__proto__":{"w":1}}}');
  const r = N(j);
  assert.strictEqual(({}).polu, undefined); assert.strictEqual(({}).polu2, undefined); assert.strictEqual(({}).x, undefined);
  assert(!Object.prototype.hasOwnProperty.call(r, '__proto__'));
  assert.strictEqual(r.falecidos[0].ascendentes.pai.nome, 'P');
  assert.strictEqual(JSON.stringify(r).includes('polu'), false);
});
t('enumerações: valor fora da lista vira ""; maiúsculas e espaços tolerados', () => {
  assert.strictEqual(enumItcmd('CASADO', ITCMD_ENUM.estado_civil), 'casado');
  assert.strictEqual(enumItcmd('uniao estavel', ITCMD_ENUM.estado_civil), 'uniao_estavel');
  assert.strictEqual(enumItcmd('bigamo', ITCMD_ENUM.estado_civil), '');
  assert.strictEqual(enumItcmd(['casado'], ITCMD_ENUM.estado_civil), '');
  assert.strictEqual(enumItcmd({ toString: () => 'casado' }, ITCMD_ENUM.estado_civil), '');
  assert.strictEqual(enumItcmd('__proto__', ITCMD_ENUM.estado_civil), '');
  assert.strictEqual(enumItcmd('constructor', ITCMD_ENUM.situacao), '');
});
t('M2 corrigido: enumerações toleram feminino e acento', () => {
  assert.strictEqual(enumItcmd('casada', ITCMD_ENUM.estado_civil), 'casado'); assert.strictEqual(enumItcmd('viúva', ITCMD_ENUM.estado_civil), 'viuvo');
  assert.strictEqual(enumItcmd('união estável', ITCMD_ENUM.estado_civil), 'uniao_estavel'); assert.strictEqual(enumItcmd('união-estável', ITCMD_ENUM.estado_civil), 'uniao_estavel');
  assert.strictEqual(enumItcmd('divorciada', ITCMD_ENUM.estado_civil), 'divorciado'); assert.strictEqual(enumItcmd('separada', ITCMD_ENUM.estado_civil), 'separado');
  assert.strictEqual(enumItcmd('Irmã', ITCMD_ENUM.parentesco), 'irmao'); assert.strictEqual(enumItcmd('sobrinha', ITCMD_ENUM.parentesco), 'sobrinho'); assert.strictEqual(enumItcmd('tia', ITCMD_ENUM.parentesco), 'tio');
  assert.strictEqual(enumItcmd('falecida', ITCMD_ENUM.situacao), 'falecido'); assert.strictEqual(enumItcmd('imóvel urbano', ITCMD_ENUM.tipo_bem), 'imovel_urbano'); assert.strictEqual(enumItcmd('Imóvel Rural', ITCMD_ENUM.tipo_bem), 'imovel_rural');
  assert.strictEqual(enumItcmd('casadas', ITCMD_ENUM.estado_civil), ''); assert.strictEqual(enumItcmd('bigamo', ITCMD_ENUM.estado_civil), '');
});
t('regime por extenso e códigos', () => {
  assert.strictEqual(regimeItcmd('Comunhão Parcial de Bens'), 'parcial');
  assert.strictEqual(regimeItcmd('comunhao universal'), 'universal');
  assert.strictEqual(regimeItcmd('separação obrigatória de bens'), 'separacao_obrig');
  assert.strictEqual(regimeItcmd('separação legal (art. 1.641 CC)'), 'separacao_obrig');
  assert.strictEqual(regimeItcmd('separação total de bens'), 'separacao_conv');
  assert.strictEqual(regimeItcmd('separação convencional'), 'separacao_conv');
  assert.strictEqual(regimeItcmd('participação final nos aquestos'), 'aquestos');
  assert.strictEqual(regimeItcmd('separacao_obrig'), 'separacao_obrig');
  assert.strictEqual(regimeItcmd('comunhão'), '');   // ambíguo — não chuta
  assert.strictEqual(regimeItcmd(42), '');
  assert.strictEqual(regimeItcmd({}), '');
});
t('G3 corrigido: separação decide antes dos aquestos; "aquestos" só com participação final', () => {
  assert.strictEqual(regimeItcmd('regime da separação obrigatória — aplicando-se a Súmula 377 (comunhão dos aquestos)'), 'separacao_obrig');
  assert.strictEqual(regimeItcmd('separação de bens, com comunhão parcial dos aquestos (Súmula 377)'), 'separacao_obrig');
  assert.strictEqual(regimeItcmd('separação convencional de bens (pacto)'), 'separacao_conv');
  assert.strictEqual(regimeItcmd('participação final nos aquestos'), 'aquestos');
  assert.strictEqual(regimeItcmd('aquestos'), 'aquestos');   // código
  assert.strictEqual(regimeItcmd('regime de aquestos'), '', 'sem "participação final" não chuta');
  assert.strictEqual(regimeItcmd('comunhão parcial de bens'), 'parcial');
  assert.strictEqual(regimeItcmd('comunhão universal de bens'), 'universal');
});
t('G3: sinal sumula_377 no cônjuge (regime_como_consta / pacto / regime)', () => {
  const r = N({ falecidos: [{ nome: 'A', conjuge: { regime: 'separacao_obrig', regime_como_consta: 'separação obrigatória de bens, Súmula 377/STF' } }, { nome: 'B', conjuge: { regime: 'parcial' } }] });
  assert.strictEqual(r.falecidos[0].conjuge.sumula_377, true); assert.strictEqual(r.falecidos[1].conjuge.sumula_377, false);
  const r2 = N({ falecidos: [{ nome: 'C', conjuge: { regime: 'parcial', pacto: 'escritura de pacto lavrada no livro 377, fls. 12' } }] });
  nota('sumula_377 dispara com "377" em qualquer lugar do pacto/regime_como_consta (ex.: "livro 377") → ' + r2.falecidos[0].conjuge.sumula_377 + ' — na tela vira caixa marcada só se o regime for separação obrigatória (motor ignora nos demais)');
});
t('booleanos só true/false/null', () => {
  assert.strictEqual(boolItcmd('true'), true); assert.strictEqual(boolItcmd('false'), false);
  assert.strictEqual(boolItcmd('sim'), null); assert.strictEqual(boolItcmd(1), null); assert.strictEqual(boolItcmd(0), null); assert.strictEqual(boolItcmd('TRUE'), null);
});
t('números: formatos BR/US, lixo, negativo, notação científica, Infinity/NaN', () => {
  assert.strictEqual(numeroItcmd('R$ 180.000,00'), '180000'); assert.strictEqual(numeroItcmd('180000.00'), '180000'); assert.strictEqual(numeroItcmd('12.000'), '12000');
  assert.strictEqual(numeroItcmd('50'), '50'); assert.strictEqual(numeroItcmd('50%'), '50'); assert.strictEqual(numeroItcmd(''), ''); assert.strictEqual(numeroItcmd('não consta'), '');
  assert.strictEqual(numeroItcmd(NaN), ''); assert.strictEqual(numeroItcmd(Infinity), ''); assert.strictEqual(numeroItcmd([]), ''); assert.strictEqual(numeroItcmd({}), '');
  assert.strictEqual(numeroItcmd('-5000'), '', 'M8: negativo em texto'); assert.strictEqual(numeroItcmd('1e308'), '', 'M8: notação científica');
  const negN = numeroItcmd(-5000), huge = numeroItcmd(1e21);
  nota('numeroItcmd(-5000) [número JSON] = ' + JSON.stringify(negN) + ' ; numeroItcmd(1e21) = ' + JSON.stringify(huge) + (negN !== '' ? '  ← RESTA: número JSON negativo ainda passa (o caminho typeof number não confere sinal); a tela zera com Math.max' : ''));
  assert.strictEqual(numeroItcmd('1.234.567,89'), '1234567.89');
  const anot = numeroItcmd('180.000,00 (valor venal)'), anot2 = numeroItcmd('R$ 12.000,00 aprox.');
  nota('numeroItcmd("180.000,00 (valor venal)") = ' + JSON.stringify(anot) + ' ; ("R$ 12.000,00 aprox.") = ' + JSON.stringify(anot2) + ' — o filtro /[eE]/ de M8 também derruba anotação com "e" (antes: 180000). Sugestão: /\\d[eE][+-]?\\d/');
});
t('avós: 0..2 inteiros; resto null', () => {
  assert.strictEqual(avosItcmd(2), 2); assert.strictEqual(avosItcmd('1'), 1); assert.strictEqual(avosItcmd(3), null); assert.strictEqual(avosItcmd(-1), null); assert.strictEqual(avosItcmd('dois'), null); assert.strictEqual(avosItcmd(true), null); assert.strictEqual(avosItcmd(1.7), 1);
});
t('tetos: falecidos ≤ 2, filhos ≤ 30, representantes ≤ 20, bens ≤ 40, alertas ≤ 40, texto ≤ 400/600', () => {
  const muitos = n => Array.from({ length: n }, (_, i) => ({ nome: 'P' + i, representantes: Array.from({ length: 50 }, (_, j) => ({ nome: 'R' + j })) }));
  const r = N({ falecidos: Array.from({ length: 5 }, (_, i) => ({ nome: 'F' + i, filhos: muitos(60), colaterais: muitos(60), bens: Array.from({ length: 80 }, (_, i) => ({ descricao: 'B' + i })) })), alertas: Array.from({ length: 100 }, (_, i) => 'a' + i), requerimento: { resumo: 'x'.repeat(5000) }, advogado: { nome: 'y'.repeat(5000) } });
  assert.strictEqual(r.falecidos.length, 2); assert.strictEqual(r.falecidos[0].filhos.length, 30); assert.strictEqual(r.falecidos[0].filhos[0].representantes.length, 20);
  assert.strictEqual(r.falecidos[0].colaterais.length, 30); assert.strictEqual(r.falecidos[0].bens.length, 40); assert.strictEqual(r.alertas.length, 40);
  assert.strictEqual(r.requerimento.resumo.length, 600); assert.strictEqual(r.advogado.nome.length, 160);
});
t('teto dos falecidos: corte em 6 antes do map, 2 depois do filtro', () => {
  const t0 = Date.now(); const r = N({ falecidos: Array.from({ length: 20000 }, (_, i) => ({ nome: i < 4 ? '' : 'F' + i })) }); const ms = Date.now() - t0;
  assert.strictEqual(r.falecidos.length, 2); assert.strictEqual(r.falecidos[0].nome, 'F4'); assert(ms < 200, ms + ' ms');
});
t('caracteres de controle e tamanho em textos; objeto/lista onde se espera texto vira ""', () => {
  const r = N({ falecidos: [{ nome: 'JO\u0000SÉ\u001f DA​ SILVA', data_obito: { d: 1 }, local_obito: ['x'], bens: [{ descricao: 'x'.repeat(1000) }] }] });
  assert.strictEqual(r.falecidos[0].nome, 'JOSÉ DA​ SILVA');   // zero-width passa (não é controle)
  assert.strictEqual(r.falecidos[0].data_obito, ''); assert.strictEqual(r.falecidos[0].local_obito, '');
  assert.strictEqual(r.falecidos[0].bens[0].descricao.length, 300);
});
t('HTML/JS em textos NÃO é escapado no servidor (fica para o esc() da tela) — confirmado, é a divisão de responsabilidade', () => {
  const r = N({ requerimento: { resumo: '<img src=x onerror=alert(1)>' }, falecidos: [{ nome: '<b>X</b>', bens: [{ descricao: '"><script>1</script>', fonte_valor: "' onmouseover='1" }] }] });
  assert(r.requerimento.resumo.includes('<img')); assert(r.falecidos[0].bens[0].fonte_valor.includes("'"));
});
t('bens da doação: destino vazio vira "todos"; fracao normalizada; sem natureza', () => {
  const r = N({ doacao: { bens: [{ descricao: 'lote', destino: '', fracao: '50%' }, { descricao: 'casa', destino: '  CARLA  ', fracao: 'metade' }] } });
  assert.strictEqual(r.doacao.bens[0].destino, 'todos'); assert.strictEqual(r.doacao.bens[0].fracao, '50');
  assert.strictEqual(r.doacao.bens[1].destino, 'CARLA'); assert.strictEqual(r.doacao.bens[1].fracao, '');
  assert(!('natureza' in r.doacao.bens[0]) && !('fracao_do_falecido' in r.doacao.bens[0]));
});
t('falecidos: ordem preservada (não reordena por data) — o prompt exige cronológica, o servidor confia', () => {
  const r = N({ falecidos: [{ nome: 'B', data_obito: '03/02/2026' }, { nome: 'A', data_obito: '12/04/2019' }] });
  assert.strictEqual(r.falecidos[0].nome, 'B');
  nota('ordem dos falecidos vem do modelo; a tela põe o 1º como "1º falecido" sem conferir as datas');
});
t('datas: qualquer texto ≤ 20 passa (formato conferido só na tela)', () => {
  const r = N({ falecidos: [{ nome: 'A', data_obito: '31/02/2020', inventario_requerido_em: '2026-09-15' }] });
  assert.strictEqual(r.falecidos[0].data_obito, '31/02/2020'); assert.strictEqual(r.falecidos[0].inventario_requerido_em, '2026-09-15');
  nota('data "31/02/2020" (inexistente) e "2026-09-15" (ISO) passam pelo servidor — ver teste de tela');
});
t('extrairJson: cerca, texto antes/depois, sem chaves, JSON de lista, JSON quebrado, "{" solto no fim', () => {
  assert.deepStrictEqual(extrairJson('Segue:\n```json\n{"operacao":"doacao"}\n```\nfim'), { operacao: 'doacao' });
  assert.strictEqual(extrairJson('nada'), null); assert.strictEqual(extrairJson('[1,2]'), null); assert.strictEqual(extrairJson('{"a":'), null);
  assert.deepStrictEqual(extrairJson('{"operacao":"doacao"} depois {'), { operacao: 'doacao' });   // "{" solto depois do último "}" é ignorado
  assert.strictEqual(extrairJson(null), null); assert.strictEqual(extrairJson(12), null);
});
t('extrairJson: resposta com DOIS objetos (modelo repetiu) → null (502), e não o primeiro', () => {
  const r = extrairJson('{"operacao":"doacao"}\n{"operacao":"inventario"}');
  assert.strictEqual(r, null);
});
t('extrairJson: objeto cujo valor contém "```"', () => {
  const r = extrairJson('{"alertas":["texto com ```json dentro```"]}');
  nota('extrairJson com "```" dentro de uma string: ' + JSON.stringify(r) + ' (a cerca interna é removida do dado — cosmético)');
});
t('doação: reserva_usufruto "sim" → null (não true) e o data_prevista longo cai', () => {
  const r = N({ doacao: { reserva_usufruto: 'sim', data_prevista: '10/10/2026 (previsão do advogado)' } });
  assert.strictEqual(r.doacao.reserva_usufruto, null); assert.strictEqual(r.doacao.data_prevista, '10/10/2026 (previsão');
});
t('M12 corrigido: filho sem nome mas com representantes fica (netos preservados); sem nome e sem netos some', () => {
  const r = N({ falecidos: [{ nome: 'A', filhos: [{ nome: '', situacao: 'falecido', representantes: [{ nome: 'NETO 1' }] }, { nome: '', situacao: 'vivo' }, { representantes: [{ nome: '' }] }] }] });
  assert.strictEqual(r.falecidos[0].filhos.length, 1); assert.strictEqual(r.falecidos[0].filhos[0].nome, ''); assert.deepStrictEqual(r.falecidos[0].filhos[0].representantes, [{ nome: 'NETO 1' }]);
});
t('M11: donatários com doações anteriores no exercício (forma fixa, números, nome obrigatório)', () => {
  const r = N({ doacao: { donatarios: [{ nome: 'CARLA', doacoes_anteriores_no_ano: 'R$ 40.000,00', itcmd_recolhido_anteriores: '800,00', fonte: 'DIT 2026', cpf: 'x' }, { nome: '', doacoes_anteriores_no_ano: '1' }, { nome: 'B' }] } });
  assert.deepStrictEqual(r.doacao.donatarios, [{ nome: 'CARLA', doacoes_anteriores_no_ano: '40000', itcmd_recolhido_anteriores: '800', fonte: 'DIT 2026' }, { nome: 'B', doacoes_anteriores_no_ano: '', itcmd_recolhido_anteriores: '', fonte: '' }]);
});

console.log('\n%d ok, %d falha(s), %d nota(s)', ok, falhas.length, notas.length);
falhas.forEach(f => console.log('  FALHA:', f));
process.exit(falhas.length ? 1 : 0);
