import test from 'node:test';
import assert from 'node:assert/strict';
import {receiveDocument} from '../frontend/src/despesas/document-intake.mjs';
import {automaticRead} from '../frontend/src/despesas/automatic-reading.mjs';
test('reenvio recupera a identidade, leitura e vínculos do original sem salvar outro documento',async()=>{
 const old={id:'original',hash:'hash',period:'2026-09',ocr:{status:'complete',fields:{amount:{value:'10.00'}}}};
 let saved=0;
 const result=await receiveDocument({id:'novo',hash:'hash',period:'2026-10',blob:new Blob(['fictício'])},{getDocuments:()=>[old],save:async()=>{saved++;},refresh:async()=>assert.fail('não precisa atualizar')});
 assert.equal(result.document,old);assert(result.reused);assert.equal(saved,0);assert.equal(result.document.period,'2026-09');assert.equal(result.document.ocr.fields.amount.value,'10.00');assert(old.blob);
});
test('reenvio simultâneo entre usuários recupera o original confirmado pelo servidor',async()=>{
 let documents=[],saved=0;const original={id:'original-no-servidor',hash:'hash',version:3};
 const result=await receiveDocument({id:'novo',hash:'hash'},{getDocuments:()=>documents,save:async()=>{saved++;throw Object.assign(new Error('já recebido'),{code:'DOCUMENT_EXISTS',documentId:original.id});},refresh:async()=>{documents=[original];}});
 assert.equal(saved,1);assert(result.reused);assert.equal(result.document.id,original.id);assert.equal(result.document.version,3);
});
test('arquivo novo é salvo uma vez e erro de recebimento continua visível',async()=>{
 let count=0;const doc={id:'novo',hash:'novo'};const deps={getDocuments:()=>[],save:async saved=>{assert.equal(saved,doc);count++;},refresh:async()=>{}};
 assert(!(await receiveDocument(doc,deps)).reused);assert.equal(count,1);
 await assert.rejects(()=>receiveDocument(doc,{...deps,save:async()=>{throw new Error('falha de armazenamento');}}),/falha de armazenamento/);
});
test('leitura automática prefere o serviço do servidor sem pedir opção ao usuário',async()=>{
 let localCalls=0;const first={text:'Valor pago: R$ 10,00',confidence:98,method:'google-vision'};
 const result=await automaticRead({primary:async()=>first,secondary:async()=>{localCalls++;}});
 assert.equal(result,first);assert.equal(localCalls,0);
});
test('indisponibilidade, limite e tempo esgotado acionam a recuperação automática',async()=>{
 for(const status of [429,502,503,undefined]){
  const result=await automaticRead({primary:async()=>{throw Object.assign(new Error('indisponível'),{status});},secondary:async()=>({text:'Valor pago: R$ 10,00',confidence:96,method:'tesseract-local'})});
  assert.equal(result.text,'Valor pago: R$ 10,00');assert(result.fallbackUsed);
 }
});
test('leitura vazia ou de baixa confiança tenta a alternativa; não troca por texto vazio',async()=>{
 const weak={text:'Valor pago: R$ 10,00',confidence:25};const better={text:'Valor pago: R$ 100,00',confidence:90};
 assert.equal((await automaticRead({primary:async()=>weak,secondary:async()=>better})).text,better.text);
 assert.equal(await automaticRead({primary:async()=>weak,secondary:async()=>({text:'',confidence:0})}),weak);
 assert.equal((await automaticRead({primary:async()=>({text:'',confidence:99}),secondary:async()=>better})).text,better.text);
});
test('sessão expirada ou acesso proibido não é escondido pela recuperação local',async()=>{
 for(const status of [401,403]){
  let called=false;
  await assert.rejects(()=>automaticRead({primary:async()=>{throw Object.assign(new Error('sessão inválida'),{status});},secondary:async()=>{called=true;}}),/sessão inválida/);
  assert(!called);
 }
});
test('quando o serviço não está configurado usa a alternativa automaticamente; falha total é explícita',async()=>{
 const result=await automaticRead({primaryEnabled:false,primary:async()=>assert.fail('serviço desativado'),secondary:async()=>({text:'Texto do documento',confidence:80})});assert.equal(result.text,'Texto do documento');
 await assert.rejects(()=>automaticRead({primary:async()=>{throw new Error('serviço');},secondary:async()=>{throw new Error('alternativa');}}),/original está guardado/);
});
