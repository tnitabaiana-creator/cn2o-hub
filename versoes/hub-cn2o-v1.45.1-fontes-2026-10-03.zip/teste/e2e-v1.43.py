"""E2E focado na v1.43 — Calculadora ITCMD/SE: Declaração do ITCMD "causa mortis" (SEFAZ/SE) +
partilha acordada diferente da legal (bloco F: excedente de meação/quinhão) + Declaração Inter Vivos I.

Caso de referência: pacote "José/Josefa" (6 filhos + 1 pré-morto com 2 netos; os demais cedem 1570/2997 do
próprio quinhão a Alysson; imóvel de R$ 499.500,00) — os valores conferem com o pacote ao centavo:
legal 71.357,14 / 35.678,57; cessões 37.380,95 × 5 + 18.690,48 × 2 = 224.285,71; Alysson real 295.642,85;
excedente 3140/6993 da herança; ITCMD inter vivos 2% = 4.485,71.

Uso: EXTRA_ENV="HUB_CODIGO_ADMIN=codigo-emergencia-teste-2026 CORS_ORIGENS=http://127.0.0.1:8088 HUB_IA_LIMITE=200" RESET_DB=1 ./reiniciar-real.sh
     python3 e2e-v1.43.py
"""
import base64, json, os, subprocess, sys, time, urllib.request
from playwright.sync_api import sync_playwright

SITE = os.environ.get('SITE', 'http://127.0.0.1:8088/')
API = os.environ.get('API', 'http://127.0.0.1:3999')
CODIGO = os.environ.get('HUB_CODIGO_ADMIN', 'codigo-emergencia-teste-2026')
SENHA = 'Escrituras#2026xy'
AQUI = os.path.dirname(os.path.abspath(__file__))
ARQ = os.path.join(AQUI, 'arquivos')
SHOTS = os.path.join(AQUI, '..', 'docs', 'itcmd-declaracao-v1.43'); os.makedirs(SHOTS, exist_ok=True)
ok = 0; falhas = []

def api(caminho, corpo=None, token=None):
    req = urllib.request.Request(API + caminho, method='POST' if corpo is not None else 'GET')
    if corpo is not None:
        req.add_header('Content-Type', 'application/json'); req.data = json.dumps(corpo).encode()
    if token: req.add_header('X-Auth-Token', token)
    try:
        with urllib.request.urlopen(req) as r: return r.status, json.loads(r.read() or b'null')
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b'null')

def passo(nome, fn):
    global ok
    try:
        fn(); ok += 1; print('  ✓', nome)
    except Exception as e:
        import traceback; tb = traceback.extract_tb(e.__traceback__)[-1]
        falhas.append(nome); print('  ✗', nome, '→', repr(e)[:600], '(linha %d)' % tb.lineno)

def esperar(cond, tempo=10.0, msg=''):
    fim = time.time() + tempo
    while time.time() < fim:
        try:
            if cond(): return True
        except Exception: pass
        time.sleep(0.15)
    raise AssertionError('esperando: ' + msg)

def b64(nome):
    with open(os.path.join(ARQ, nome), 'rb') as f: return base64.b64encode(f.read()).decode()

def texto_pdf(caminho):
    t = subprocess.run(['pdftotext', '-layout', caminho, '-'], capture_output=True, text=True).stdout
    return ' '.join(t.split())   # espaços normalizados (quebras de linha do PDF não atrapalham a busca)

st, r = api('/login', {'login': 'cesar.bravo', 'senha': SENHA})
if st != 200:
    st, r = api('/definir-senha', {'login': 'cesar.bravo', 'codigo': CODIGO, 'senha': SENHA})
    assert st == 200 and r.get('token'), ('não deu para criar a senha do Tabelião', st, r)
TOKEN = r['token']

# ---------------------------------------------------------------- API: forma fixa com "partilha" e CPFs
def api_partilha():
    st, r = api('/hub/ia/itcmd', {'arquivos': [{'nome': 'dossie-inventario-cessao-lima.pdf', 'mime': 'application/pdf', 'base64': b64('dossie-inventario-cessao-lima.pdf')}]}, token=TOKEN)
    assert st == 200, (st, r)
    f = r['dados']['falecidos'][0]
    assert f['partilha']['desigual'] is True and len(f['partilha']['cessoes']) == 7
    c0 = f['partilha']['cessoes'][0]
    assert c0 == {'cedente': 'ADRIANA DE LIMA SANTOS', 'beneficiario': 'ALYSSON DE LIMA SANTOS', 'fracao_do_quinhao': '1570/2997', 'natureza': 'nao_onerosa', 'fonte': 'plano de partilha'}, c0
    assert f['filhos'][0]['cpf'] == '000.000.000-10' and f['filhos'][6]['representantes'][1]['cpf'] == '000.000.000-18'
    assert 'cpf' in f['conjuge'] and f['conjuge']['cpf'] == ''
    # dossiê antigo (sem "partilha") continua com a forma fixa: partilha vazia
    st, r = api('/hub/ia/itcmd', {'arquivos': [{'nome': 'dossie-inventario-silva.pdf', 'mime': 'application/pdf', 'base64': b64('dossie-inventario-silva.pdf')}]}, token=TOKEN)
    assert st == 200 and r['dados']['falecidos'][0]['partilha'] == {'desigual': None, 'cessoes': [], 'descricao': ''}, r['dados']['falecidos'][0].get('partilha')
    assert r['dados']['falecidos'][0]['filhos'][0]['cpf'] == ''
passo('API /hub/ia/itcmd: "partilha" (desigual, cessões com fração exata e natureza) e CPFs dos herdeiros na forma fixa', api_partilha)

# ---------------------------------------------------------------- Tela
with sync_playwright() as p:
    nav = p.chromium.launch()
    ctx = nav.new_context(viewport={'width': 1366, 'height': 900}, locale='pt-BR', reduced_motion='reduce', accept_downloads=True)
    pg = ctx.new_page()
    erros = []
    pg.on('pageerror', lambda e: erros.append(str(e)))
    pg.on('console', lambda m: erros.append(m.text) if m.type == 'error' and 'ERR_' not in m.text and 'Failed to load' not in m.text else None)

    def entrar():
        pg.goto(SITE); pg.wait_for_selector('#campoLogin')
        pg.fill('#campoLogin', 'cesar.bravo'); pg.fill('#campoSenha', SENHA); pg.click('#btnEntrar')
        pg.wait_for_selector('#muralRodizio li', timeout=20000); pg.wait_for_timeout(500)
        pg.click('#cardItcmd'); pg.wait_for_selector('#paginaItcmd:not([hidden])'); pg.wait_for_timeout(400)
        assert pg.is_visible('#btDeclaracao'), 'botão da declaração no orçamento'
        assert 'Inter Vivos I' in pg.inner_text('#declCaixa')
    passo('login, abrir 08 · Calculadora: botão "Gerar Declaração ITCMD (PDF)" no orçamento', entrar)

    def clicar(sel):
        pg.locator(sel).first.evaluate("e => e.scrollIntoView({ block: 'center' })"); pg.wait_for_timeout(100); pg.click(sel)

    def importar(nome):
        while pg.locator('#itcmdImportar .anexo-x').count(): pg.click('#itcmdImportar .anexo-x >> nth=0'); pg.wait_for_timeout(100)
        pg.set_input_files('#itcmdImportar input[type=file]', os.path.join(ARQ, nome)); pg.wait_for_timeout(400)
        pg.evaluate("document.getElementById('itcmdImportado').classList.add('oculto')")
        pg.click('#btExtrairDossie')
        esperar(lambda: not pg.evaluate("document.getElementById('itcmdImportado').classList.contains('oculto')"), 15, 'painel de importação')
        pg.wait_for_timeout(400)

    def sem_valor_bloqueia():
        importar('dossie-inventario-cessao-lima.pdf')
        S = pg.evaluate('window.ITCMD_UI.estado')
        f = S['inv'][0]; pr = f['partilhaReal']
        assert f['nome'] == 'JOSEFA MARIA DE LIMA' and f['estadoCivil'] == 'solteiro' and f['decl']['estadoCivilObito'] == 'viuvo'
        assert pr['ativa'] is True and pr['natureza'] == 'nao_onerosa' and pr['taxaTxt'] == '1570/2997' and pr['atalhoVivo'] is True
        assert pr['beneficiario'] == f['descendentes'][0]['uid'] and pr['incluirMeacao'] is False
        assert pr['cpfs'][f['descendentes'][0]['uid']] == '000.000.000-10' and pr['cpfs'][f['descendentes'][6]['representantes'][0]['uid']] == '000.000.000-17'
        assert f['decl']['dataAbertura'] == '', 'R14: a data de abertura NÃO vem do requerimento'
        assert f['decl']['inventariante']['nome'] == 'ALYSSON DE LIMA SANTOS'
        txt = pg.inner_text('#itcmdImportado')
        assert 'Bloco F preenchido' in txt and 'escritura de abertura' in txt, txt[:800]
        # sem valor lançado: bloco F aberto, quinhões 0; a declaração não sai
        pg.click('#btDeclaracao'); pg.wait_for_timeout(300)
        assert 'sem o valor declarado' in pg.inner_text('#declAviso')
        pg.evaluate("document.querySelectorAll('#itcmdRaiz details').forEach(d => d.open = true)")
        pg.locator('.bloco-real').screenshot(path=os.path.join(SHOTS, 'bloco-f-importado-sem-valor.jpg'))
    passo('importar dossiê com cessão: bloco F preenchido pelo requerimento (beneficiário, 1570/2997, não onerosa), CPFs, R14, declaração bloqueada sem valor', sem_valor_bloqueia)

    def lancar_valor_fecha():
        pg.fill('#itcmdRaiz input[data-path="inv.0.bens.0.valor"]', '499500,00'); pg.press('#itcmdRaiz input[data-path="inv.0.bens.0.valor"]', 'Tab'); pg.wait_for_timeout(600)
        u = pg.evaluate("(() => { const inv = window.ITCMD_UI.ultimo.inv; return { rows: inv.real.rows.map(r => [r.nome, r.legal, r.real, r.excedente, r.cede, r.realFr && r.realFr.txt(), r.excedenteFr && r.excedenteFr.txt()]), dif: inv.real.diferenca, tot: inv.real.totalExcedente, exc: inv.exced && inv.exced.porBeneficiario.map(b => [b.nome, b.base, b.imposto, b.situacao]) }; })()")
        rows = {r[0]: r for r in u['rows']}
        assert u['dif'] == 0 and u['tot'] == 224285.71, u
        a = rows['ALYSSON DE LIMA SANTOS']; assert a[1:] == [71357.14, 295642.85, 224285.71, 0, '4139/6993', '3140/6993'], a
        assert rows['ADRIANA DE LIMA SANTOS'][1:5] == [71357.14, 33976.19, 0, 37380.95] and rows['ADRIANA DE LIMA SANTOS'][5] == '1427/20979'
        assert rows['ANDRÉ DE LIMA SANTOS'][1:5] == [71357.15, 33976.2, 0, 37380.95], 'os últimos quinhões absorvem o centavo'
        assert rows['BRUNO DE LIMA SOUZA'][1:5] == [35678.57, 16988.09, 0, 18690.48] and rows['BRUNO DE LIMA SOUZA'][5] == '1427/41958'
        assert u['exc'] == [['ALYSSON DE LIMA SANTOS', 224285.71, 4485.71, 'tributado']], u['exc']
        t = pg.inner_text('#resCorpo')
        assert 'Partilha acordada' in t and 'inter vivos' in t.lower()
        o = pg.inner_text('#orcCorpo'); assert 'Inter Vivos I' in o and '4.485,71' in o, o[:600]
        pg.locator('.bloco-real').screenshot(path=os.path.join(SHOTS, 'bloco-f-aplicado.jpg'))
    passo('lançar o valor do bem: o atalho vivo refaz a cessão — quinhões, frações exatas e ITCMD inter vivos batem com o pacote ao centavo', lancar_valor_fecha)

    def editar_a_mao_desliga_atalho():
        S0 = pg.evaluate('window.ITCMD_UI.estado')
        uid_adriana = S0['inv'][0]['descendentes'][1]['uid']
        sel = '#itcmdRaiz input[data-path="inv.0.partilhaReal.reais.%s"]' % uid_adriana
        pg.fill(sel, '33976,20'); pg.press(sel, 'Tab'); pg.wait_for_timeout(600)
        S = pg.evaluate('window.ITCMD_UI.estado'); pr = S['inv'][0]['partilhaReal']
        assert pr['atalhoVivo'] is False and pr['taxaFr'] is None
        assert 'não fecha' in pg.inner_text('#resCorpo') or 'difere' in pg.inner_text('.bloco-real')
        # reaplicar pelo botão volta a fechar
        pg.click('button[data-acao="aplicar-cessao"]'); pg.wait_for_timeout(600)
        u = pg.evaluate("(() => { const inv = window.ITCMD_UI.ultimo.inv; return [inv.real.diferenca, inv.real.totalExcedente]; })()")
        assert u == [0, 224285.71], u
    passo('editar um quinhão real à mão desliga o atalho (partilha deixa de fechar); "Aplicar a cessão" refaz', editar_a_mao_desliga_atalho)

    def desmarcar_cedente():
        S0 = pg.evaluate('window.ITCMD_UI.estado')
        uid_bruno = S0['inv'][0]['descendentes'][6]['representantes'][0]['uid']
        pg.click('#itcmdRaiz input[data-path="inv.0.partilhaReal.cedentes.%s"]' % uid_bruno); pg.wait_for_timeout(300)
        pg.click('button[data-acao="aplicar-cessao"]'); pg.wait_for_timeout(600)
        u = pg.evaluate("(() => { const inv = window.ITCMD_UI.ultimo.inv; const b = inv.real.rows.find(r => r.nome.startsWith('BRUNO')); return [inv.real.diferenca, inv.real.totalExcedente, b.cede, b.real]; })()")
        assert u == [0, 205595.23, 0, 35678.57], u
        pg.click('#itcmdRaiz input[data-path="inv.0.partilhaReal.cedentes.%s"]' % uid_bruno); pg.wait_for_timeout(300)
        pg.click('button[data-acao="aplicar-cessao"]'); pg.wait_for_timeout(600)
        assert pg.evaluate("window.ITCMD_UI.ultimo.inv.real.totalExcedente") == 224285.71
    passo('"Quem cede": desmarcar um cedente tira-o da cessão (excedente cai) e remarcar volta', desmarcar_cedente)

    def desmarcar_ativa_desliga():
        # auditoria G2: desmarcar "partilha acordada" com atalho vivo tem de desligar tudo
        clicar('#itcmdRaiz input[data-path="inv.0.partilhaReal.ativa"]'); pg.wait_for_timeout(500)
        assert pg.locator('.bloco-real').evaluate('d => d.open'), 'o bloco F continua aberto depois de desmarcar (a escrevente mexeu nele)'
        S = pg.evaluate('window.ITCMD_UI.estado'); pr = S['inv'][0]['partilhaReal']
        assert pr['ativa'] is False and pr['atalhoVivo'] is False and pr['reais'] == {}, pr
        assert pg.evaluate("window.ITCMD_UI.ultimo.inv.real.totalExcedente") == 0
        assert 'Inter Vivos I' not in pg.inner_text('#orcCorpo')
        # religa e reaplica pelo botão
        clicar('#itcmdRaiz input[data-path="inv.0.partilhaReal.ativa"]'); pg.wait_for_timeout(400)
        pg.click('button[data-acao="aplicar-cessao"]'); pg.wait_for_timeout(600)
        assert pg.evaluate("window.ITCMD_UI.ultimo.inv.real.totalExcedente") == 224285.71
        assert pg.locator('#itcmdRaiz input[data-path="inv.0.partilhaReal.ativa"]').is_checked()
    passo('G2: desmarcar "partilha acordada" desliga o atalho (excedente 0, sem Inter Vivos I); religar + Aplicar refaz', desmarcar_ativa_desliga)

    def taxa_percentual_e_alvo():
        # M7: "1" = 1%; "52.3857" com ponto = 52,3857%; valor-alvo exato; erro visível em vez de silêncio
        sel = '#itcmdRaiz input[data-path="inv.0.partilhaReal.taxaTxt"]'
        pg.fill(sel, '1'); pg.press(sel, 'Tab'); pg.wait_for_timeout(400)
        assert pg.evaluate("window.ITCMD_UI.ultimo.inv.real.totalExcedente") == 224285.71, 'digitar não reaplica: só o botão'
        pg.click('button[data-acao="aplicar-cessao"]'); pg.wait_for_timeout(600)
        assert pg.evaluate("window.ITCMD_UI.ultimo.inv.real.totalExcedente") == 4281.43, pg.evaluate("window.ITCMD_UI.ultimo.inv.real.totalExcedente")
        pg.fill(sel, '52.3857'); pg.press(sel, 'Tab'); pg.click('button[data-acao="aplicar-cessao"]'); pg.wait_for_timeout(600)
        assert abs(pg.evaluate("window.ITCMD_UI.ultimo.inv.real.totalExcedente") - 224285.71) <= 0.10
        pg.fill(sel, '1570/0'); pg.press(sel, 'Tab'); pg.click('button[data-acao="aplicar-cessao"]'); pg.wait_for_timeout(600)
        assert 'denominador zero' in pg.inner_text('.bloco-real'), 'erro do atalho visível no bloco F'
        pg.click('#btDeclaracao'); pg.wait_for_timeout(300)
        assert 'não pôde ser aplicada' in pg.inner_text('#declAviso'), 'declaração bloqueada com o atalho em erro'
        pg.fill(sel, ''); pg.press(sel, 'Tab')
        alvo = '#itcmdRaiz input[data-path="inv.0.partilhaReal.alvoTxt"]'
        pg.fill(alvo, '300.000,00'); pg.press(alvo, 'Tab'); pg.click('button[data-acao="aplicar-cessao"]'); pg.wait_for_timeout(600)
        u = pg.evaluate("(() => { const inv = window.ITCMD_UI.ultimo.inv; const a = inv.real.rows.find(r => r.nome.startsWith('ALYSSON')); return [inv.real.diferenca, a.real]; })()")
        assert u == [0, 300000], u
        pg.fill(alvo, '50.000,00'); pg.press(alvo, 'Tab'); pg.click('button[data-acao="aplicar-cessao"]'); pg.wait_for_timeout(600)
        assert 'menor que o quinhão legal' in pg.inner_text('.bloco-real')
        # volta ao caso de referência
        pg.fill(alvo, ''); pg.press(alvo, 'Tab'); pg.fill(sel, '1570/2997'); pg.press(sel, 'Tab'); pg.click('button[data-acao="aplicar-cessao"]'); pg.wait_for_timeout(600)
        assert pg.evaluate("window.ITCMD_UI.ultimo.inv.real.totalExcedente") == 224285.71
    passo('M7/M4/G1: "1" = 1%, ponto decimal aceito, erro do atalho visível e bloqueia a declaração, valor-alvo exato, alvo inatingível avisa', taxa_percentual_e_alvo)

    def gerar_declaracoes():
        pg.fill('#itcmdRaiz input[data-path="inv.0.decl.dataAbertura"]', '2026-09-20'); pg.press('#itcmdRaiz input[data-path="inv.0.decl.dataAbertura"]', 'Tab'); pg.wait_for_timeout(400)
        pg.click('#btDeclaracao'); pg.wait_for_timeout(600)
        av = pg.inner_text('#declAviso')
        if 'Gerar assim mesmo' in av:
            assert 'endereço' in av.lower(), av
            pg.click('#btDeclMesmoAssim'); pg.wait_for_timeout(1500)
            av = pg.inner_text('#declAviso')
        assert 'Declaração gerada' in av and 'Inter Vivos I' in av and '2 página' in av, av[:600]
        assert pg.is_visible('#declBaixar') and pg.is_visible('#declBaixarIV')
        for var, nome in (('ITCMD_ULTIMO_PDF', 'josefa-causa-mortis.pdf'), ('ITCMD_ULTIMO_PDF_IV', 'josefa-inter-vivos-i.pdf')):
            b = pg.evaluate("(() => { const u = window.%s; let s=''; for (let i=0;i<u.length;i+=8192) s += String.fromCharCode.apply(null, u.subarray(i, i+8192)); return btoa(s); })()" % var)
            open(os.path.join(SHOTS, nome), 'wb').write(base64.b64decode(b))
        cm = texto_pdf(os.path.join(SHOTS, 'josefa-causa-mortis.pdf'))
        for trecho in ['DECLARAÇÃO DO ITCMD “CAUSA MORTIS”', '( X ) Inventário Extrajudicial', 'Data de Abertura do Inventário: 20/09/2026', 'Nome: JOSEFA MARIA DE LIMA', 'CPF: 111.222.333-44', 'Estado Civil: Viúvo(a)',
                       'Nome: ALYSSON DE LIMA SANTOS', '( X ) Não Onerosa', '4139/6993', 'do item 1', 'R$ 295.642,85', 'R$ 224.285,71', 'R$ 71.357,14', 'R$ 35.678,57', '1427/41958',
                       'TRANSMISSÃO NÃO ONEROSA', '3140/6993 da herança', 'INTER VIVOS I', 'R$ 428.142,86', 'R$ 12.844,26', 'art. 8º, IV', 'multa de 20%', 'Impresso em 3 vias', 'página 2']:
            assert trecho in cm, 'faltou na causa mortis: ' + trecho
        assert 'R$ 499.500,00' in cm and 'página 2' in cm
        iv = texto_pdf(os.path.join(SHOTS, 'josefa-inter-vivos-i.pdf'))
        for trecho in ['DECLARAÇÃO DO ITCMD “INTER VIVOS I”', '( X ) Excedente de Meação/ Quinhão', 'JOSEFA MARIA DE LIMA', '(7 pessoas)', 'ADRIANA DE LIMA SANTOS', 'R$ 37.380,95', 'BIANCA DE LIMA SOUZA', 'R$ 18.690,48',
                       'DONATÁRIO(A)', 'ALYSSON DE LIMA SANTOS', '000.000.000-10', '1570/2997', '3140/6993 da herança', 'R$ 224.285,71', '2%', 'R$ 4.485,71', '5.512', '01.02.003.0004', 'art. 4º, V']:
            assert trecho in iv, 'faltou na inter vivos: ' + trecho
        pg.locator('#declCaixa').screenshot(path=os.path.join(SHOTS, 'declaracao-gerada.jpg'))
    passo('gerar: causa mortis (quadros 1–12, frações exatas, base = quinhões tributados, nota da multa) + Inter Vivos I (7 cedentes, donatário, 2% = 4.485,71)', gerar_declaracoes)

    def viuva_beneficiaria():
        # auditoria G1/M1: filhos cedem tudo à viúva meeira (excesso de meação) — importado do requerimento
        importar('dossie-inventario-cessao-viuva.pdf')
        S = pg.evaluate('window.ITCMD_UI.estado'); f = S['inv'][0]; pr = f['partilhaReal']
        assert f['estadoCivil'] == 'casado' and f['regime'] == 'universal' and pr['beneficiario'] == 'conjuge' and pr['taxaTxt'] == '100' and pr['atalhoVivo'] is True, pr
        assert pr['cpfs']['conj'] == '222.333.444-55' and pr['cpfs']['meacao'] == '222.333.444-55'
        pg.fill('#itcmdRaiz input[data-path="inv.0.bens.0.valor"]', '400000,00'); pg.press('#itcmdRaiz input[data-path="inv.0.bens.0.valor"]', 'Tab'); pg.wait_for_timeout(600)
        u = pg.evaluate("(() => { const inv = window.ITCMD_UI.ultimo.inv; return { ids: inv.real.rows.map(r => r.id), rows: inv.real.rows.map(r => [r.nome, r.legal, r.real, r.excedente]), dif: inv.real.diferenca, exc: inv.exced && inv.exced.total }; })()")
        assert u['ids'] == ['meacao'] + [d['uid'] for d in f['descendentes']], u
        assert u['rows'][0][1:] == [200000, 400000, 200000] and u['rows'][1][2] == 0 and u['dif'] == 0 and u['exc'] == 4000, u
        pg.evaluate("document.querySelectorAll('#itcmdRaiz details').forEach(d => d.open = true)")
        assert 'meeiro' in pg.inner_text('#itcmdRaiz select[data-path="inv.0.partilhaReal.beneficiario"] option:checked').lower()
        assert pg.locator('#itcmdRaiz input[data-path="inv.0.partilhaReal.incluirMeacao"]').count() == 0, 'meeira beneficiária: sem a caixa "meeiro também cede"'
        pg.click('#btDeclaracao'); pg.wait_for_timeout(800)
        if pg.query_selector('#btDeclMesmoAssim'): pg.click('#btDeclMesmoAssim'); pg.wait_for_timeout(1500)
        assert 'Inter Vivos I' in pg.inner_text('#declAviso')
        cm = pg.evaluate("(() => { const u = window.ITCMD_ULTIMO_PDF; let s=''; for (let i=0;i<u.length;i+=8192) s += String.fromCharCode.apply(null, u.subarray(i, i+8192)); return btoa(s); })()")
        open(os.path.join(SHOTS, 'viuva-causa-mortis.pdf'), 'wb').write(base64.b64decode(cm)); t = texto_pdf(os.path.join(SHOTS, 'viuva-causa-mortis.pdf'))
        for trecho in ['MARIA VIUVA, CPF 222.333.444-55', 'Cônjuge meeiro(a)', 'R$ 400.000,00 R$ 200.000,00 R$ 200.000,00', '( X ) Não Onerosa', 'FILHO UM', 'todo (100%) do próprio quinhão']:
            assert trecho in t, 'faltou: ' + trecho
        iv = pg.evaluate("(() => { const u = window.ITCMD_ULTIMO_PDF_IV; let s=''; for (let i=0;i<u.length;i+=8192) s += String.fromCharCode.apply(null, u.subarray(i, i+8192)); return btoa(s); })()")
        open(os.path.join(SHOTS, 'viuva-inter-vivos-i.pdf'), 'wb').write(base64.b64decode(iv)); t2 = texto_pdf(os.path.join(SHOTS, 'viuva-inter-vivos-i.pdf'))
        assert 'Nome: MARIA VIUVA' in t2 and 'R$ 200.000,00' in t2 and 'R$ 4.000,00' in t2, t2[:1500]
    passo('G1/M1: viúva meeira como beneficiária (excesso de meação) importada do requerimento — quinhões, IV e declaração com uma linha só para o cônjuge', viuva_beneficiaria)

    def rascunho_antigo_migra():
        pg.evaluate("""(() => { const S = JSON.parse(JSON.stringify(window.ITCMD_UI.estado)); delete S.inv[0].partilhaReal.cedentes; delete S.inv[0].partilhaReal.atalhoVivo; delete S.inv[0].partilhaReal.atalho; delete S.inv[0].partilhaReal.erroAtalho; S.inv[0].partilhaReal.taxaFr = { n: 1, d: 1 }; localStorage.setItem('itcmd-rascunho', JSON.stringify({ S, quando: Date.now() })); })()""")
        pg.reload(); pg.wait_for_timeout(1500)
        if not pg.is_visible('#paginaItcmd'): pg.click('#cardItcmd')
        pg.wait_for_selector('#paginaItcmd:not([hidden])'); pg.wait_for_timeout(600)
        clicar('#btRestaurar'); pg.wait_for_timeout(600)
        S = pg.evaluate('window.ITCMD_UI.estado'); pr = S['inv'][0]['partilhaReal']
        assert pr['cedentes'] == {} or isinstance(pr['cedentes'], dict)
        assert pr['atalhoVivo'] is False and pr['erroAtalho'] == '' and 'atalho' in pr
        assert pg.evaluate("window.ITCMD_UI.ultimo.inv.real.diferenca") == 0
    passo('rascunho salvo por versão anterior (sem cedentes/atalhoVivo) migra sem erro', rascunho_antigo_migra)

    def doacao_nao_gera():
        pg.click('#segModo button[data-modo="doacao"]'); pg.wait_for_timeout(400)
        pg.click('#btDeclaracao'); pg.wait_for_timeout(300)
        assert 'inter vivos' in pg.inner_text('#declAviso').lower()
        pg.click('#segModo button[data-modo="inventario"]'); pg.wait_for_timeout(400)
    passo('modo doação: a declaração causa mortis não sai (aviso)', doacao_nao_gera)

    def sem_erros_js():
        assert not erros, erros[:5]
    passo('sem erros de JavaScript na tela', sem_erros_js)
    nav.close()

print('\n%d ok, %d falha(s)' % (ok, len(falhas)))
for f in falhas: print('  -', f)
sys.exit(1 if falhas else 0)
