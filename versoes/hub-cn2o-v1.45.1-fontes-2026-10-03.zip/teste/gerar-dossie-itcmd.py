"""v1.42 — Gera um DOSSIÊ FICTÍCIO de inventário (PDF de texto, 4 páginas) para testar o botão
"Extrair dados do dossiê" da Calculadora ITCMD/SE: requerimento do advogado + certidão de
óbito + certidão de casamento + certidão de matrícula. Tudo inventado (nomes, números, datas).

Uso: python3 gerar-dossie-itcmd.py  →  arquivos/dossie-inventario-silva.pdf (e -cumulativo, -doacao)
Os nomes dos arquivos carregam a palavra que o mock do Gemini (real/gemini.js) usa para escolher a
resposta; na aferição real (Gemini de verdade) o conteúdo é o que vale."""
import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak

AQUI = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'arquivos'); os.makedirs(AQUI, exist_ok=True)
ss = getSampleStyleSheet()
T = ParagraphStyle('t', parent=ss['Title'], fontSize=14, spaceAfter=10)
H = ParagraphStyle('h', parent=ss['Heading3'], fontSize=11.5, spaceBefore=8, spaceAfter=4)
P = ParagraphStyle('p', parent=ss['BodyText'], fontSize=10.5, leading=14, spaceAfter=6)

def pdf(nome, paginas):
    doc = SimpleDocTemplate(os.path.join(AQUI, nome), pagesize=A4, leftMargin=2.2*cm, rightMargin=2.2*cm, topMargin=2*cm, bottomMargin=2*cm)
    fl = []
    for i, blocos in enumerate(paginas):
        if i: fl.append(PageBreak())
        for b in blocos:
            fl.append(Paragraph(b[1], {'T': T, 'H': H, 'P': P}[b[0]]) if b[0] != 'S' else Spacer(1, 8))
    doc.build(fl)
    return os.path.join(AQUI, nome)

REQ_INV = [
    ('T', 'REQUERIMENTO DE LAVRATURA DE ESCRITURA PÚBLICA DE INVENTÁRIO E PARTILHA'),
    ('P', 'AO CARTÓRIO DE NOTAS DO 2º OFÍCIO DE ITABAIANA/SE — Ilmo. Sr. Tabelião César Bravo'),
    ('P', 'HELENA COSTA MENEZES, advogada, OAB/SE 5.678, com escritório na Rua Coronel Sebastião, 210, Centro, Itabaiana/SE, na qualidade de procuradora dos herdeiros e da meeira abaixo qualificados, vem requerer a lavratura de ESCRITURA PÚBLICA DE INVENTÁRIO E PARTILHA dos bens deixados por <b>JOSÉ RAIMUNDO DA SILVA</b>, falecido em 12/04/2019, nesta cidade, conforme certidão de óbito anexa, nos termos do art. 610, §1º, do CPC e da Resolução CNJ nº 35/2007.'),
    ('H', '1. Do falecido e da meeira'),
    ('P', 'O de cujus era casado com <b>MARIA APARECIDA MENEZES DA SILVA</b>, brasileira, aposentada, sob o regime da <b>comunhão parcial de bens</b>, desde 10/05/1980, conforme certidão de casamento anexa, sem pacto antenupcial. A viúva, ora meeira, sobreviveu ao falecido e com ele convivia até o óbito. Não deixou testamento (certidão negativa CENSEC anexa).'),
    ('H', '2. Dos herdeiros'),
    ('P', 'O falecido deixou três filhos, todos também filhos da meeira: (a) <b>ANA PAULA MENEZES DA SILVA</b>, viva; (b) <b>CARLOS EDUARDO MENEZES DA SILVA</b>, vivo, que <b>RENUNCIA</b> pura e simplesmente à herança em favor do monte, conforme declarará no ato; (c) <b>PEDRO HENRIQUE MENEZES DA SILVA</b>, <b>pré-morto</b> (falecido em 03/08/2015), representado por seus filhos <b>LUCAS MENEZES DA SILVA</b> e <b>JÚLIA MENEZES DA SILVA</b>, ambos maiores e capazes, que herdam por estirpe.'),
    ('H', '3. Dos bens'),
    ('P', 'Compõem o espólio: <b>Bem 1</b> — Casa residencial na Rua Quintino Bocaiúva, nº 120, Centro, Itabaiana/SE, matrícula nº 12.345 do Registro de Imóveis de Itabaiana/SE, adquirida pelo casal em 22/03/1995 (bem comum). Valor venal constante do carnê de IPTU 2026: R$ 180.000,00. <b>Bem 2</b> — Fração de 50% do Sítio Boa Vista, com 12 hectares, no Povoado Flecheiras, Itabaiana/SE, matrícula nº 9.876 do mesmo Registro, recebida pelo falecido por herança de seus pais em 1978 (bem particular), em condomínio com seu irmão Manoel da Silva. <b>Bem 3</b> — Veículo Fiat Strada Working 1.4, ano 2018, placa QKN-1D23, adquirido em 2018 (bem comum).'),
    ('H', '4. Das dívidas'),
    ('P', 'O espólio não possui dívidas conhecidas.'),
    ('H', '5. Do pedido'),
    ('P', 'Requer a lavratura da escritura com a partilha na forma da lei (meação da viúva sobre os bens comuns e quinhões iguais aos herdeiros, observada a representação), com o recolhimento do ITCMD devido ao Estado de Sergipe. Junta os documentos abaixo. Itabaiana/SE, 15 de setembro de 2026. HELENA COSTA MENEZES — OAB/SE 5.678.'),
    ('P', 'Documentos: certidão de óbito; certidão de casamento; certidões de nascimento dos herdeiros; certidão de óbito de Pedro Henrique; certidões de matrícula 12.345 e 9.876; carnê de IPTU 2026; CRLV; procurações.'),
]
OBITO_JOSE = [
    ('T', 'REPÚBLICA FEDERATIVA DO BRASIL — REGISTRO CIVIL DAS PESSOAS NATURAIS'),
    ('P', 'CERTIDÃO DE ÓBITO — Ofício do Registro Civil de Itabaiana/SE — Matrícula 095232 01 55 2019 4 00021 011 0007890 55'),
    ('P', 'Nome: <b>JOSÉ RAIMUNDO DA SILVA</b>. Sexo: masculino. Cor: parda. Estado civil: <b>casado com MARIA APARECIDA MENEZES DA SILVA</b>. Idade: 71 anos. Naturalidade: Itabaiana/SE. Filiação: Raimundo da Silva e Josefa Maria da Silva. Data e hora do falecimento: <b>12 de abril de 2019</b>, às 04h20. Local: Hospital Regional de Itabaiana/SE. Causa: insuficiência cardíaca. Deixou filhos: sim — Ana Paula, Carlos Eduardo e Pedro Henrique (falecido). Deixou bens: sim. Testamento: ignorado. Eleitor: sim. Declarante: Ana Paula Menezes da Silva. Sepultamento: Cemitério Municipal de Itabaiana/SE.'),
    ('P', 'Registro lavrado em 13/04/2019, livro C-58, folha 112, termo 21.011. Certidão emitida em 02/09/2026.'),
]
CASAMENTO = [
    ('T', 'CERTIDÃO DE CASAMENTO — Ofício do Registro Civil de Itabaiana/SE'),
    ('P', 'Matrícula 095232 01 55 1980 2 00012 088 0004321 09. Certifico que, em <b>10 de maio de 1980</b>, perante o Juiz de Paz, receberam-se em matrimônio <b>JOSÉ RAIMUNDO DA SILVA</b>, nascido em 03/02/1948, filho de Raimundo da Silva e Josefa Maria da Silva, e <b>MARIA APARECIDA MENEZES</b>, nascida em 15/07/1952, filha de Antônio Menezes e Rita Menezes, passando a cônjuge virago a assinar-se MARIA APARECIDA MENEZES DA SILVA. Regime de bens: <b>comunhão parcial de bens</b>. Sem pacto antenupcial. Averbações: nenhuma. Certidão emitida em 02/09/2026.'),
]
MATRICULA = [
    ('T', 'REGISTRO DE IMÓVEIS DE ITABAIANA/SE — CERTIDÃO DE INTEIRO TEOR'),
    ('H', 'MATRÍCULA Nº 12.345 — Livro 2 — Ficha 01 — aberta em 22/03/1995'),
    ('P', 'IMÓVEL: Uma casa residencial situada na Rua Quintino Bocaiúva, nº 120, Centro, Itabaiana/SE, com 120,00 m² de área construída em terreno de 300,00 m². Inscrição municipal 01.03.045.0120.001.'),
    ('P', 'R.1/12.345 — 22/03/1995 — COMPRA E VENDA: JOSÉ RAIMUNDO DA SILVA, comerciante, CPF 123.456.789-09, e sua esposa MARIA APARECIDA MENEZES DA SILVA, casados sob o regime da comunhão parcial de bens, adquiriram de Manoel Vieira Sobrinho pelo valor de R$ 25.000,00.'),
    ('P', 'AV.2/12.345 — 20/05/2019 — ÓBITO de JOSÉ RAIMUNDO DA SILVA em 12/04/2019 (certidão de óbito matrícula 095232 01 55 2019 4 00021 011 0007890 55). Certidão emitida em 05/09/2026.'),
    ('H', 'MATRÍCULA Nº 9.876 — Livro 2 — Ficha 01 — aberta em 14/11/1978'),
    ('P', 'IMÓVEL: Sítio Boa Vista, Povoado Flecheiras, Itabaiana/SE, com 12,00 hectares (área rural), INCRA 265.039.006.297-5.'),
    ('P', 'R.1/9.876 — 14/11/1978 — FORMAL DE PARTILHA: adjudicado a JOSÉ RAIMUNDO DA SILVA (50%) e MANOEL DA SILVA (50%), por herança de Raimundo da Silva. Certidão emitida em 05/09/2026.'),
    ('H', 'CARNÊ DE IPTU 2026 — Prefeitura Municipal de Itabaiana'),
    ('P', 'Contribuinte: JOSÉ RAIMUNDO DA SILVA. Inscrição 01.03.045.0120.001. Rua Quintino Bocaiúva, 120. <b>Valor venal do imóvel: R$ 180.000,00</b>.'),
]
inv = pdf('dossie-inventario-silva.pdf', [REQ_INV, OBITO_JOSE, CASAMENTO, MATRICULA])

REQ_CUM = [('T', 'REQUERIMENTO DE INVENTÁRIO CUMULATIVO — ESPÓLIOS DE JOSÉ RAIMUNDO DA SILVA E MARIA APARECIDA MENEZES DA SILVA'),
    ('P', 'HELENA COSTA MENEZES, OAB/SE 5.678, procuradora dos herdeiros, requer ao Cartório de Notas do 2º Ofício de Itabaiana/SE a lavratura de escritura de INVENTÁRIO CUMULATIVO (art. 672 do CPC) dos espólios de <b>JOSÉ RAIMUNDO DA SILVA</b>, falecido em 12/04/2019, e de sua viúva <b>MARIA APARECIDA MENEZES DA SILVA</b>, falecida em 03/02/2026, casados sob o regime da comunhão parcial de bens desde 10/05/1980. Herdeiros de ambos: ANA PAULA MENEZES DA SILVA (viva), CARLOS EDUARDO MENEZES DA SILVA (vivo) e os netos LUCAS e JÚLIA MENEZES DA SILVA, em representação de PEDRO HENRIQUE MENEZES DA SILVA (pré-morto em 03/08/2015). Bens de José: casa na Rua Quintino Bocaiúva, 120, matrícula 12.345 (bem comum, IPTU 2026 R$ 180.000,00) e 50% do Sítio Boa Vista, matrícula 9.876 (bem particular). Bem próprio de Maria além da meação e do quinhão: saldo de poupança Banese de R$ 18.500,00 (extrato de 10/03/2026). Sem dívidas. Itabaiana/SE, 15/09/2026.')]
OBITO_MARIA = [('T', 'CERTIDÃO DE ÓBITO — Ofício do Registro Civil de Itabaiana/SE'),
    ('P', 'Matrícula 095232 01 55 2026 4 00030 015 0009911 20. Nome: <b>MARIA APARECIDA MENEZES DA SILVA</b>. Estado civil: <b>viúva de JOSÉ RAIMUNDO DA SILVA</b>. Idade: 73 anos. Falecimento: <b>03 de fevereiro de 2026</b>, em Itabaiana/SE. Deixou filhos: Ana Paula, Carlos Eduardo e Pedro Henrique (falecido). Deixou bens: sim. Certidão emitida em 02/09/2026.')]
pdf('dossie-cumulativo-silva.pdf', [REQ_CUM, OBITO_JOSE, OBITO_MARIA, CASAMENTO, MATRICULA])

REQ_DOA = [('T', 'REQUERIMENTO DE LAVRATURA DE ESCRITURA PÚBLICA DE DOAÇÃO COM RESERVA DE USUFRUTO'),
    ('P', 'PAULO MENEZES, OAB/SE 1.234, procurador dos doadores <b>ANTÔNIO PEREIRA</b> e <b>RITA PEREIRA</b>, casados sob o regime da comunhão universal de bens, requer ao Cartório de Notas do 2º Ofício de Itabaiana/SE a lavratura de escritura de DOAÇÃO, com reserva de usufruto vitalício em favor dos doadores, aos filhos <b>BRUNO PEREIRA</b> e <b>CARLA PEREIRA</b>, em partes iguais, do apartamento 301 do Edifício Serra, Av. Ivo de Carvalho, 500, Itabaiana/SE, matrícula 4.321 do RI de Itabaiana/SE (valor venal IPTU 2026: R$ 250.000,00); e, somente a CARLA PEREIRA, do lote 12 da quadra C do Loteamento Sol Nascente, matrícula 9.001. Escritura prevista para 10/10/2026. Itabaiana/SE, 20/09/2026.')]
pdf('dossie-doacao-pereira.pdf', [REQ_DOA])
print('dossiês gerados em', AQUI)
