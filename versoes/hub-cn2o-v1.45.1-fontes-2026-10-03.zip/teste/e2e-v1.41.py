"""E2E focado na v1.41 (mural em três quadros + Calculadora ITCMD/SE) contra o servidor v1.40 real.

O harness completo (e2e.py / api.test.js) ficou para trás desde a v1.39 (primeiro acesso por código,
senha sem o nome de usuário) — este roteiro usa a emergência HUB_CODIGO_ADMIN para criar a senha do
Tabelião e confere só o que a v1.41 mudou, mais a regressão visual do mural e dos quadros.

Uso: EXTRA_ENV="HUB_CODIGO_ADMIN=codigo-emergencia-teste-2026" RESET_DB=1 ./reiniciar-real.sh
     python3 e2e-v1.41.py
"""
import json, os, sys, time, urllib.request
from playwright.sync_api import sync_playwright

SITE = os.environ.get('SITE', 'http://127.0.0.1:8088/')
API = os.environ.get('API', 'http://127.0.0.1:3999')
CODIGO = os.environ.get('HUB_CODIGO_ADMIN', 'codigo-emergencia-teste-2026')
SENHA = 'Escrituras#2026xy'
SHOTS = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'docs', 'mural-rodizio-v1.41')
os.makedirs(SHOTS, exist_ok=True)
ok = 0; falhas = []

def api(caminho, corpo=None, token=None):
    req = urllib.request.Request(API + caminho, method='POST' if corpo is not None else 'GET')
    if corpo is not None:
        req.add_header('Content-Type', 'application/json'); req.data = json.dumps(corpo).encode()
    if token: req.add_header('X-Auth-Token', token)
    try:
        with urllib.request.urlopen(req) as r: return r.status, json.loads(r.read() or b'null')
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b'null')

def passo(nome, fn):
    global ok
    try:
        fn(); ok += 1; print('  ✓', nome)
    except Exception as e:
        falhas.append(nome); print('  ✗', nome, '→', repr(e)[:400])

def esperar(cond, tempo=8.0, msg=''):
    fim = time.time() + tempo
    while time.time() < fim:
        try:
            if cond(): return True
        except Exception: pass
        time.sleep(0.15)
    raise AssertionError('esperando: ' + msg)

# senha do Tabelião pela emergência (idempotente: se já existe, o login abaixo resolve)
st, r = api('/login', {'login': 'cesar.bravo', 'senha': SENHA})
if st != 200:
    st, r = api('/definir-senha', {'login': 'cesar.bravo', 'codigo': CODIGO, 'senha': SENHA})
    assert st == 200 and r.get('token'), ('não deu para criar a senha do Tabelião', st, r)
TOKEN = r['token']

with sync_playwright() as p:
    nav = p.chromium.launch()
    ctx = nav.new_context(viewport={'width': 1366, 'height': 900}, locale='pt-BR', reduced_motion='reduce')
    pg = ctx.new_page()
    erros = []
    pg.on('pageerror', lambda e: erros.append(str(e)))
    pg.on('console', lambda m: erros.append(m.text) if m.type == 'error' and 'ERR_' not in m.text and 'Failed to load' not in m.text else None)

    def entrar():
        pg.goto(SITE); pg.wait_for_selector('#campoLogin')
        pg.fill('#campoLogin', 'cesar.bravo'); pg.fill('#campoSenha', SENHA); pg.click('#btnEntrar')
        pg.wait_for_selector('#muralRodizio li', timeout=20000); pg.wait_for_timeout(500)
    passo('login do Tabelião (senha nova da v1.39) e mural carregado', entrar)

    def mural_tres():
        assert pg.evaluate("document.querySelectorAll('.mural-cards .ficha-luz').length") == 3
        titulos = pg.evaluate("Array.from(document.querySelectorAll('.mural-cards .ficha-titulo.titulo-script')).map(t => t.textContent.trim())")
        assert titulos == ['Avisos', 'Minha Agenda', 'Rodízio de Atendimento'], titulos
        fundos = pg.evaluate("Array.from(document.querySelectorAll('.mural-cards .ficha-luz')).map(f => getComputedStyle(f).backgroundColor)")
        assert fundos == ['rgb(253, 245, 246)', 'rgb(243, 245, 249)', 'rgb(250, 246, 236)'], fundos
        assert pg.locator('#muralRodizio li').count() == 5
        txt = pg.inner_text('#muralRodizio')
        assert 'JONAS' in txt and 'LARA' in txt and 'JOSILENE' in txt and 'ROMÊNIA' in txt and 'Todos no atendimento' in txt, txt
        dia = time.localtime().tm_wday
        assert pg.locator('#muralRodizio li.hoje').count() == (1 if dia <= 4 else 0)
        assert 'Escala válida desde 28/09/2026' in pg.inner_text('#rodizioDesde')
        assert 'fica livre do atendimento' in pg.inner_text('#rodizioObs')
        peq = pg.evaluate("[...document.querySelectorAll('.ficha-rodizio *')].filter(e => e.offsetParent && [...e.childNodes].some(n => n.nodeType === 3 && n.textContent.trim()) && parseFloat(getComputedStyle(e).fontSize) < 14).map(e => e.className)")
        assert not peq, peq
        t = pg.evaluate("Array.from(document.querySelectorAll('.mural-cards > article')).map(a => Math.round(a.getBoundingClientRect().top))")
        assert abs(t[0] - t[2]) < 30 and t[1] > t[0] + 200, t
        # Bloco de Notas continua ao lado da agenda (v1.33)
        med = pg.evaluate("""() => { const a = document.querySelector('.ma-painel-agenda').getBoundingClientRect(), n = document.querySelector('.ma-painel-notas').getBoundingClientRect(); return { ladeia: n.left >= a.right - 1, la: Math.round(a.width), ln: Math.round(n.width) }; }""")
        assert med['ladeia'], med
        pg.evaluate("document.querySelector('.mural-cards').scrollIntoView({block:'start'})"); pg.wait_for_timeout(200)
        pg.screenshot(path=SHOTS + '/01-mural-tres-quadros-1366.png')
    passo('mural em três quadros: Avisos · Minha Agenda · Rodízio (tons, escala, hoje, ≥14 px, arranjo, Bloco de Notas ao lado)', mural_tres)

    def editor_rodizio():
        pg.click('#btnEditarMural'); pg.wait_for_selector('#veuMural.aberto .ed-abas')
        pg.click('.ed-aba[data-aba="rodizio"]'); pg.wait_for_selector('#edRz_qua')
        assert pg.input_value('#edRz_seg') == 'JONAS'
        pg.screenshot(path=SHOTS + '/02-editor-aba-rodizio.png')
        pg.fill('#edRz_qua', 'camily'); pg.dispatch_event('#edRz_qua', 'change'); pg.fill('#edRzDesde', '05/10/2026')
        assert pg.input_value('#edRz_qua') == 'CAMILY'
        pg.click('#edPublicar'); esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='publicar rodízio')
        pg.wait_for_selector('#muralRodizio li')
        assert 'CAMILY' in pg.inner_text('#muralRodizio') and 'Todos no atendimento' not in pg.inner_text('#muralRodizio')
        assert '05/10/2026' in pg.inner_text('#rodizioDesde')
        st, m = api('/hub/mural', token=TOKEN)
        assert m['dados']['rodizio']['dias']['qua'] == 'CAMILY', m['dados']['rodizio']
        # normalização no servidor: nome com HTML e data inválida
        st, r = api('/hub/mural', {'dados': dict(m['dados'], rodizio={'dias': {'seg': '<b>Lara</b>', 'qua': 'x' * 80}, 'obs': 'o<i>k</i>', 'desde': '31/02/2026'}), 'base': m['atualizado_em']}, token=TOKEN)
        assert st == 200, (st, r)
        rz = r['dados']['rodizio']
        assert rz['dias']['seg'] == 'Lara' and len(rz['dias']['qua']) == 60 and rz['desde'] == '' and rz['obs'] == 'ok', rz
        # restaura a escala inicial
        st, m2 = api('/hub/mural', token=TOKEN)
        st, r = api('/hub/mural', {'dados': dict(m2['dados'], rodizio={'dias': {'seg': 'JONAS', 'ter': 'LARA', 'qua': '', 'qui': 'JOSILENE', 'sex': 'ROMÊNIA'}, 'obs': 'No dia do rodízio, o escrevente fica livre do atendimento ao público para se dedicar às escrituras.', 'desde': '28/09/2026'}), 'base': m2['atualizado_em']}, token=TOKEN)
        assert st == 200, (st, r)
    passo('editor: aba Rodízio publica a escala; servidor normaliza (sem HTML, 60 caracteres, data válida)', editor_rodizio)

    def cartoes():
        pg.goto(SITE); pg.wait_for_selector('#cardItcmd'); pg.wait_for_timeout(400)
        nomes = pg.evaluate("Array.from(document.querySelectorAll('#secFerramentas .card h3')).map(h => h.textContent.trim())")
        assert nomes[-1] == 'Calculadora ITCMD' and len(nomes) == 8, nomes
        nums = pg.evaluate("Array.from(document.querySelectorAll('#secFerramentas .card-num')).map(n => n.textContent)")
        assert nums == ['01', '02', '03', '04', '05', '06', '07', '08'], nums
        assert pg.is_hidden('#secFerramentas .card-arte')
        pg.set_viewport_size({'width': 1300, 'height': 900}); pg.wait_for_timeout(300)
        assert pg.is_visible('#secFerramentas .card-arte')
        pg.evaluate("document.getElementById('secFerramentas').scrollIntoView()"); pg.screenshot(path=SHOTS + '/03-ferramentas-1300-nicho.png')
        pg.set_viewport_size({'width': 1366, 'height': 900}); pg.wait_for_timeout(300)
        pg.evaluate("document.getElementById('secFerramentas').scrollIntoView()"); pg.screenshot(path=SHOTS + '/04-ferramentas-1366-8-quadros.png')
    passo('dashboard com 8 quadros (08 · Calculadora ITCMD); nicho de galeria só na grade de 3 colunas', cartoes)

    def calculadora_itcmd():
        pg.click('#cardItcmd'); pg.wait_for_selector('#paginaItcmd:not([hidden])'); pg.wait_for_timeout(400)
        assert pg.evaluate('location.hash') == '#itcmd'
        assert pg.evaluate("window.ITCMD_UI.ultimo.modo") == 'cumulativo'
        assert pg.inner_text('#bvTotal').startswith('R$ 40.820,92'), pg.inner_text('#bvTotal')
        peq = pg.evaluate("[...document.querySelectorAll('#itcmdRaiz *')].filter(e => e.offsetParent && [...e.childNodes].some(n => n.nodeType === 3 && n.textContent.trim()) && parseFloat(getComputedStyle(e).fontSize) < 14).map(e => e.className)")
        assert not peq, peq
        vazou = pg.evaluate("""() => { let n = 0; for (const s of document.styleSheets) { try { for (const r of s.cssRules) { const t = r.selectorText || ''; if (/(^|[ ,>])\\.(cartao|barra-viva|orcamento|segmento|kpis|tabela-wrap)(?![\\w-])/.test(t) && !t.includes('#itcmdRaiz')) n++; } } catch (e) {} } return n; }""")
        assert vazou == 0, 'regras da calculadora sem escopo: %d' % vazou
        pg.screenshot(path=SHOTS + '/05-calculadora-itcmd-no-hub.png')
        pg.click('#segModo button[data-modo=inventario]'); pg.wait_for_timeout(300)
        assert pg.evaluate("window.ITCMD_UI.ultimo.inv.pat.heranca") == 481000
        pg.fill('[data-path="inv.0.bens.0.valor"]', '1.000.000,00'); pg.dispatch_event('[data-path="inv.0.bens.0.valor"]', 'change'); pg.wait_for_timeout(400)
        assert pg.evaluate("window.ITCMD_UI.ultimo.inv.pat.monteMor") == 1322000
        pg.click('#segModo button[data-modo=doacao]'); pg.wait_for_timeout(300)
        assert pg.evaluate("window.ITCMD_UI.ultimo.d.total") == 8400
        pg.click('#orc_honorarios'); pg.keyboard.type('5'); pg.wait_for_timeout(400); pg.keyboard.type('000'); pg.keyboard.press('Tab'); pg.wait_for_timeout(400)
        assert pg.input_value('#orc_honorarios') == '5000' and '21.367,16' in pg.inner_text('#orcTotal'), pg.inner_text('#orcTotal')
        # "Ver orçamento" rola sem mexer na rota (antes derrubava para a home)
        pg.click('#btVerOrcamento'); pg.wait_for_timeout(500)
        assert pg.evaluate('location.hash') == '#itcmd' and not pg.evaluate("document.getElementById('paginaItcmd').hidden")
        with pg.context.expect_page() as nova:
            pg.click('#btImprimir')
        w = nova.value; w.wait_for_load_state(); w.wait_for_timeout(500)
        html = w.content()
        assert 'Orçamento do ato' in html and 'Memória de cálculo' in html and 'Elaborado por César Bravo' in html
        w.close()
        # clique em botão data-modo de OUTRA página não mexe na calculadora (ouvintes presos a #itcmdRaiz)
        modo_antes = pg.evaluate("window.ITCMD_UI.estado.modo")
        pg.evaluate("(() => { const b = document.createElement('button'); b.dataset.modo = 'varios'; b.id = 'botaoDeFora'; document.body.appendChild(b); b.click(); b.remove(); })()")
        assert pg.evaluate("window.ITCMD_UI.estado.modo") == modo_antes
        pg.evaluate("document.documentElement.setAttribute('data-theme','dark')"); pg.wait_for_timeout(200)
        cor = pg.evaluate("getComputedStyle(document.querySelector('#bvItcmd')).color")
        assert cor != 'rgb(99, 19, 37)', cor
        pg.screenshot(path=SHOTS + '/06-calculadora-tema-escuro.png')
        pg.evaluate("document.documentElement.setAttribute('data-theme','light')")
        pg.set_viewport_size({'width': 400, 'height': 860}); pg.wait_for_timeout(300)
        assert pg.evaluate('document.documentElement.scrollWidth') <= 400
        pg.screenshot(path=SHOTS + '/07-calculadora-400px.png')
        pg.set_viewport_size({'width': 1366, 'height': 900}); pg.wait_for_timeout(300)
        st, r = api('/hub/registro', {'acao': 'abrir', 'ferramenta': 'itcmd'}, token=TOKEN)
        assert st in (200, 204), (st, r)
        pg.click('#paginaItcmd [data-voltar]'); pg.wait_for_timeout(300)
        assert not pg.evaluate("document.getElementById('paginaHub').hidden")
        pg.goto(SITE + '#itcmd'); pg.wait_for_timeout(1500)
        assert not pg.evaluate("document.getElementById('paginaItcmd').hidden")
    passo('08 · Calculadora ITCMD/SE: rota, exemplo, três modos ao vivo, orçamento, Ver orçamento, impressão, isolamento dos ouvintes, tema escuro, 400 px, trilha', calculadora_itcmd)

    def mobile_mural():
        pg.goto(SITE); pg.wait_for_selector('#muralRodizio li')
        pg.set_viewport_size({'width': 400, 'height': 860}); pg.wait_for_timeout(400)
        assert pg.evaluate('document.documentElement.scrollWidth') <= 401
        pg.evaluate("document.querySelector('.ficha-rodizio').scrollIntoView()"); pg.screenshot(path=SHOTS + '/08-mural-rodizio-400px.png')
        pg.set_viewport_size({'width': 1366, 'height': 900})
    passo('celular: mural sem rolagem horizontal, rodízio empilhado', mobile_mural)

    nav.close()

print('\n%d ok, %d falha(s); erros de console relevantes: %d' % (ok, len(falhas), len(erros)))
for e in erros[:5]: print('   console:', e[:200])
sys.exit(1 if falhas or erros else 0)
