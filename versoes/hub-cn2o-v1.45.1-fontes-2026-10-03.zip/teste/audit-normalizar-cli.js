// AUDITORIA v1.42 — normaliza um JSON "cru do modelo" (stdin) com as funções REAIS do backend/hub.js
// e imprime o objeto de forma fixa (o que a rota /hub/ia/itcmd devolveria em "dados").
// Uso: echo '{"operacao":"doacao"}' | node teste/audit-normalizar-cli.js
'use strict';
const fs = require('fs'), path = require('path');
const s = fs.readFileSync(path.join(__dirname, '..', 'backend', 'hub.js'), 'utf8');
const a = s.indexOf('const CHAVES_PESSOA'), b = s.indexOf('function extrairJson');
const c = s.indexOf('// ---------------------------------------------------------------- Leitor de dossiê'), d = s.indexOf('// ---------------------------------------------------------------- Minuta → Google Docs');
const m = { exports: {} };
new Function('module', 'require', s.slice(a, b) + s.slice(c, d) + ';module.exports={normalizarDossieItcmd}')(m, require);
const entrada = JSON.parse(fs.readFileSync(0, 'utf8'));
process.stdout.write(JSON.stringify(m.exports.normalizarDossieItcmd(entrada)));
