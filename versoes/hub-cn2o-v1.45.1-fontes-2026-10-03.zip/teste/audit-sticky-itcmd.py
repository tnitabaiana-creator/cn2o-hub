"""AUDITORIA v1.42 — depois de importar, o painel "Dados importados" rola para o topo: a barra viva
(sticky) cobre o título? Mede no viewport real (1366×900 e 400×860)."""
import os, sys, time, io
from playwright.sync_api import sync_playwright
from PIL import Image
SITE = 'http://127.0.0.1:8088/'; SENHA = 'Escrituras#2026xy'
AQUI = os.path.dirname(os.path.abspath(__file__)); PDF = os.path.join(AQUI, 'arquivos', 'dossie-inventario-silva.pdf')
SHOTS = os.path.join(AQUI, '..', 'docs', 'auditoria-v1.42')
with sync_playwright() as p:
    nav = p.chromium.launch(); ctx = nav.new_context(viewport={'width': 1366, 'height': 900}, locale='pt-BR', reduced_motion='reduce'); pg = ctx.new_page()
    pg.goto(SITE); pg.wait_for_selector('#campoLogin'); pg.fill('#campoLogin', 'cesar.bravo'); pg.fill('#campoSenha', SENHA); pg.click('#btnEntrar')
    pg.wait_for_selector('#muralRodizio li', timeout=20000); pg.click('#cardItcmd'); pg.wait_for_selector('#paginaItcmd:not([hidden])'); pg.wait_for_timeout(400)
    for (w, h) in [(1366, 900), (400, 860)]:
        pg.set_viewport_size({'width': w, 'height': h}); pg.wait_for_timeout(300)
        pg.set_input_files('#itcmdImportar input[type=file]', PDF); pg.wait_for_timeout(300)
        pg.evaluate("document.getElementById('itcmdImportado').classList.add('oculto')")
        pg.click('#btExtrairDossie')
        fim = time.time() + 15
        while time.time() < fim and pg.evaluate("document.getElementById('itcmdImportado').classList.contains('oculto')"): time.sleep(0.2)
        pg.wait_for_timeout(800)
        m = pg.evaluate("""(() => { const h = document.querySelector('#itcmdImportado h3').getBoundingClientRect(), b = document.getElementById('barraViva').getBoundingClientRect(); return { tituloTop: Math.round(h.top), tituloBottom: Math.round(h.bottom), barraTop: Math.round(b.top), barraBottom: Math.round(b.bottom), coberto: h.top < b.bottom && h.bottom > b.top, elementoNoPonto: (document.elementFromPoint(h.left + 5, h.top + 5) || {}).id }; })()""")
        print(w, 'px →', m); assert not m['coberto'], m
        png = pg.screenshot(); im = Image.open(io.BytesIO(png)).convert('RGB'); im = im.resize((640, int(im.size[1] * 640 / im.size[0])), Image.LANCZOS); im.save(os.path.join(SHOTS, '10-sticky-apos-correcao-%d.jpg' % w), 'JPEG', quality=45)
        while pg.locator('#itcmdImportar .anexo-x').count(): pg.click('#itcmdImportar .anexo-x >> nth=0'); pg.wait_for_timeout(80)
    nav.close()
