#!/usr/bin/env python3
"""Monta o index.html do Hub CN2O (Netlify).

Uso:  python3 build.py [--endpoint URL] [--saida pasta]
Chaves de sessão: ajustadas ao protocolo.html (mesmo site, mesmo login).
"""
import argparse, json, os, re, sys

AQUI = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(AQUI, 'src')
CLAUSULAS = os.path.join(SRC, 'clausulas.html')   # Cláusulas Especiais do Guia CN2O v10

ap = argparse.ArgumentParser()
ap.add_argument('--endpoint', default='https://cn2o-hub-backend-production.up.railway.app')
ap.add_argument('--saida', default=os.path.join(AQUI, 'dist'))
ap.add_argument('--calculadora', default='calculadora.html')
a = ap.parse_args()

def ler(p):
    with open(p, encoding='utf-8') as f:
        return f.read()

def logo(nome):
    b = ler(os.path.join(SRC, nome)).strip()
    return b if b.startswith('data:') else 'data:image/png;base64,' + b

css = ler(os.path.join(SRC, 'estilo-base.css')) + ler(os.path.join(SRC, 'estilo-extra.css'))
corpo = ler(os.path.join(SRC, 'corpo.html'))
clausulas = ler(CLAUSULAS)
app = ler(os.path.join(SRC, 'app.js'))
# v1.33 — 09 · Guia de ITBI: escritor de PDF sem dependência + a ferramenta (mesmo <script> do app.js)
pdf_mini = ler(os.path.join(SRC, 'pdf-mini.js'))
itbi = ler(os.path.join(SRC, 'itbi.js'))
# v1.40 — Relatórios · Produtividade em reais (leitor de .xls/.csv + a tela)
produtividade = ler(os.path.join(SRC, 'produtividade.js'))
for nome, texto in (('pdf-mini.js', pdf_mini), ('itbi.js', itbi), ('produtividade.js', produtividade)):
    if '</script>' in texto:
        sys.exit('</script> dentro de ' + nome + ' quebraria o index.html')

app = app.replace('__ENDPOINT__', a.endpoint.rstrip('/')).replace('__CALCULADORA__', a.calculadora)
corpo = corpo.replace('__LOGO_CLARO__', logo('logo-claro.b64')).replace('__LOGO_ESCURO__', logo('logo-escuro.b64'))
corpo = corpo.replace('__ARTE_LOGIN__', ler(os.path.join(SRC, 'arte-login.b64')).strip())
corpo = corpo.replace('__AVATAR_BRANCO__', ler(os.path.join(SRC, 'avatar-branco.b64')).strip())
corpo = corpo.replace('__AVATAR_MARINHO__', ler(os.path.join(SRC, 'avatar-marinho.b64')).strip())
css = css.replace('__LATERAL_FOTO__', ler(os.path.join(SRC, 'lateral-foto.b64')).strip())
css = css.replace('__MARMORE__', ler(os.path.join(SRC, 'marmore.b64')).strip())
css = css.replace('__NICHO__', ler(os.path.join(SRC, 'nicho-galeria.b64')).strip())   # v1.35: peça de galeria no nicho da grade

html = f'''<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Hub CN2O · Cartório de Notas do 2º Ofício</title>
<meta name="description" content="Hub CN2O — ferramentas, mural e IA do Time CN2O (Cartório de Notas do 2º Ofício de Itabaiana/SE). Uso interno.">
<meta name="robots" content="noindex, nofollow">
<meta name="theme-color" content="#631325">
<script>try{{document.documentElement.setAttribute('data-theme',localStorage.getItem('cn2o_tema')==='dark'?'dark':'light')}}catch(e){{document.documentElement.setAttribute('data-theme','light')}}</script>
<link rel="icon" type="image/png" href="favicon.png">
<link rel="apple-touch-icon" href="apple-touch-icon.png">
<link rel="manifest" href="manifest.webmanifest">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600;700;800&family=Lato:wght@400;700&family=Caveat:wght@600&family=Atkinson+Hyperlegible:wght@400;700&display=swap">
<style>
{css}
</style>
</head>
<body>
{corpo}
{clausulas}
<script>
{app}
{pdf_mini}
{itbi}
{produtividade}
</script>
</body>
</html>
'''
for marca in ('__ENDPOINT__', '__LOGO_', '__CALCULADORA__'):
    if marca in html:
        sys.exit('placeholder sobrando: ' + marca)

os.makedirs(a.saida, exist_ok=True)
with open(os.path.join(a.saida, 'index.html'), 'w', encoding='utf-8') as f:
    f.write(html)

manifest = {
    "name": "Hub CN2O",
    "short_name": "Hub CN2O",
    "description": "Ferramentas, mural e IA do Time CN2O — Cartório de Notas do 2º Ofício de Itabaiana/SE.",
    "start_url": "./",
    "scope": "./",
    "display": "standalone",
    "background_color": "#ffffff",
    "theme_color": "#631325",
    "lang": "pt-BR",
    "icons": [
        {"src": "icone-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any"},
        {"src": "icone-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any"}
    ]
}
with open(os.path.join(a.saida, 'manifest.webmanifest'), 'w', encoding='utf-8') as f:
    json.dump(manifest, f, ensure_ascii=False, indent=2)
import shutil
PROD_ANEXO = "const ENDPOINT_RAILWAY='https://cn2o-hub-backend-production.up.railway.app';"
for icone in ('icone-192.png', 'icone-512.png', 'apple-touch-icon.png', 'favicon.png'):
    shutil.copy(os.path.join(AQUI, icone), os.path.join(a.saida, icone))
# v1.39.2 (segurança, pacote B): cabeçalhos de segurança + bloqueio de /versoes (Netlify)
# e a página 404. Vão para a raiz do site como estão.
for extra in ('netlify.toml', '404.html'):
    shutil.copy(os.path.join(AQUI, extra), os.path.join(a.saida, extra))
if not a.calculadora.startswith('http'):   # testes locais: cópia da calculadora no próprio site
    calc = os.path.join(SRC, 'calculadora-local.html')
    shutil.copy(calc, os.path.join(a.saida, a.calculadora))
    os.chmod(os.path.join(a.saida, a.calculadora), 0o644)
# v1.36: a página que abre o anexo do pedido de certidão. Usa o mesmo endpoint do
# protocolo, então a troca é a mesma nos testes locais.
anexo = ler(os.path.join(SRC, 'anexo.html'))
assert PROD_ANEXO in anexo, 'endpoint do anexo.html não encontrado'
anexo = anexo.replace(PROD_ANEXO, "const ENDPOINT_RAILWAY='" + a.endpoint.rstrip('/') + "';")
with open(os.path.join(a.saida, 'anexo.html'), 'w', encoding='utf-8') as f:
    f.write(anexo)

prot = ler(os.path.join(AQUI, 'protocolo', 'protocolo.html'))
PROD = PROD_ANEXO
assert PROD in prot, 'endpoint do protocolo não encontrado'
prot = prot.replace(PROD, "const ENDPOINT_RAILWAY='" + a.endpoint.rstrip('/') + "';")
with open(os.path.join(a.saida, 'protocolo.html'), 'w', encoding='utf-8') as f:
    f.write(prot)
print('ok', a.saida, len(html), 'bytes')
