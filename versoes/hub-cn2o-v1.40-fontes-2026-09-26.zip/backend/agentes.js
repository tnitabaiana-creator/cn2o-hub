// agentes.js — módulo de redação de atos do Hub CN2O.
//
// Monta-se em server.js com uma linha:
//     app.use('/agentes', exigeSessao, require('./agentes'));
//
// Todas as rotas assumem req.usuario = { login, nome, cargo }, entregue pelo
// middleware exigeSessao que já existe. Nada aqui reimplementa autenticação.

const express = require('express');
const dba = require('./db-agentes');
const gemini = require('./gemini');
const docx = require('./docx');
const { pool } = require('./db');

const router = express.Router();

// Anexos chegam em base64 no corpo JSON. O limite global do express.json é de
// 256kb — insuficiente para uma matrícula escaneada. Este parser vale só aqui.
const LIMITE_UPLOAD = process.env.LIMITE_UPLOAD || '24mb';
router.use(express.json({ limit: LIMITE_UPLOAD }));

// Só quem manda na redação mexe no cadastro de agentes.
const CARGOS_ADMIN = ['Tabelião', 'Substituta do Tabelião'];
const ehAdmin = u => CARGOS_ADMIN.includes(u.cargo) ||
  (process.env.AGENTES_ADMIN || '').split(',').map(s => s.trim()).includes(u.login);

// v1.39.3 (segurança): o detalhe só vai à tela quando é recado nosso (gemini.js escreve
// mensagens em português para truncamento, resposta vazia, tempo esgotado e bloqueio);
// erro cru do banco ou do provedor fica só no log.
const RE_RECADO = /excedeu o limite de saída|voltou vazia|não respondeu em|bloqueou a requisição|não configurada/i;
const erro = (res, code, msg, detalhe) => {
  if (detalhe && !RE_RECADO.test(String(detalhe))) {
    console.error('agentes:', msg, '—', String(detalhe).slice(0, 300));
    detalhe = null;
  }
  return res.status(code).json(detalhe ? { erro: msg, detalhe } : { erro: msg });
};

// v1.39.3 (segurança, pacote C): freio nas 4 rotas que chamam a IA — antes não havia
// limite nenhum além da cota do projeto Google. Mesmo módulo do Hub (limite-ia.js):
// limite por pessoa a cada 10 min, teto diário de gasto, tipos e tamanho dos arquivos,
// teto de texto, e a chamada entra na trilha de auditoria (só o caminho, nunca o conteúdo).
const { aguardarLimite, tetoDiario, MSG_TETO } = require('./limite-ia');
const MIMES_IA = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/heic', 'image/heif', 'application/pdf']);
const MAX_ARQUIVOS = 12, MAX_B64 = 18 * 1024 * 1024, MAX_TEXTO = 20000;
async function freioIA(req, res, next) {
  const b = req.body || {};
  const arquivos = Array.isArray(b.arquivos) ? b.arquivos : [];
  if (arquivos.length > MAX_ARQUIVOS) return erro(res, 400, 'no máximo 12 arquivos por pedido');
  let total = 0;
  for (const a of arquivos) {
    if (!MIMES_IA.has(String((a && a.mime) || '').toLowerCase())) return erro(res, 400, 'formato não aceito: use foto JPG/PNG ou PDF');
    total += String((a && a.base64) || '').length;
  }
  if (total > MAX_B64) return erro(res, 413, 'arquivos grandes demais para um pedido só (máx. ≈ 13 MB somados)');
  for (const k of ['observacoes', 'pedido', 'titulo']) {
    if (typeof b[k] === 'string' && b[k].length > MAX_TEXTO) b[k] = b[k].slice(0, MAX_TEXTO);
  }
  const espera = aguardarLimite(req.usuario.login);
  if (espera) return res.status(429).json({ erro: 'muitas análises seguidas — aguarde um pouco e tente de novo', tente_em_s: espera });
  try {
    const t = await tetoDiario(req.usuario.login);
    if (t.excedido) return res.status(429).json({ erro: MSG_TETO(t), motivo: 'teto' });
  } catch (e) { console.error('agentes teto:', e.message); }
  try { require('./hub').auditar(req, 'ia', 'agentes', req.path.slice(0, 80)); } catch (e) { /* trilha nunca derruba */ }
  next();
}

// ---------------------------------------------------------------- CATÁLOGO

// GET /agentes — os cards do painel.
router.get('/', async (req, res) => {
  try {
    res.json(await dba.listarAgentes(ehAdmin(req.usuario) && req.query.todos === '1'));
  } catch (e) { erro(res, 500, 'falha ao listar agentes', e.message); }
});

// GET /agentes/modelos — o que a chave do Gemini enxerga de verdade.
// Use isto para conferir os IDs antes de culpar o código.
router.get('/modelos', async (req, res) => {
  if (!ehAdmin(req.usuario)) return erro(res, 403, 'somente Tabelião ou Substituta');   // v1.39.3
  try {
    res.json({
      configurado: { extracao: gemini.MODELO_EXTRACAO, redacao: gemini.MODELO_REDACAO },
      disponiveis: await gemini.listarModelos()
    });
  } catch (e) { erro(res, 502, 'falha ao consultar os modelos', e.message); }
});

// GET /agentes/consumo — quanto a plataforma gastou. Só admin.
router.get('/consumo', async (req, res) => {
  if (!ehAdmin(req.usuario)) return erro(res, 403, 'somente Tabelião ou Substituta');
  try {
    const r = await dba.resumoConsumo(Math.min(365, parseInt(req.query.dias, 10) || 30));
    const cambio = parseFloat(process.env.CAMBIO_USD_BRL || '5.12');
    res.json({ ...r, cambio, total_brl: Number((r.total.usd || 0) * cambio).toFixed(2) });
  } catch (e) { erro(res, 500, 'falha ao apurar consumo', e.message); }
});

// GET /agentes/minutas — as minutas do usuário (ou todas, se admin).
router.get('/minutas', async (req, res) => {
  try {
    res.json(await dba.listarMinutas({
      usuario: req.usuario.login,
      todos: ehAdmin(req.usuario) && req.query.todos === '1',
      limite: Math.min(200, parseInt(req.query.limite, 10) || 50)
    }));
  } catch (e) { erro(res, 500, 'falha ao listar minutas', e.message); }
});

// GET /agentes/minutas/:id — minuta completa, com o histórico de ajustes.
router.get('/minutas/:id', async (req, res) => {
  try {
    const m = await dba.obterMinuta(parseInt(req.params.id, 10));
    if (!m) return erro(res, 404, 'minuta não encontrada');
    if (m.usuario !== req.usuario.login && !ehAdmin(req.usuario)) return erro(res, 403, 'minuta de outra escrevente');
    res.json(m);
  } catch (e) { erro(res, 500, 'falha ao abrir a minuta', e.message); }
});

// GET /agentes/minutas/:id/arquivo — baixa o Word.
router.get('/minutas/:id/arquivo', async (req, res) => {
  try {
    const m = await dba.obterMinuta(parseInt(req.params.id, 10));
    if (!m) return erro(res, 404, 'minuta não encontrada');
    if (m.usuario !== req.usuario.login && !ehAdmin(req.usuario)) return erro(res, 403, 'minuta de outra escrevente');
    if (!m.texto) return erro(res, 409, 'esta minuta ainda não foi redigida');

    const ag = await dba.obterAgente(m.agente);
    const html = docx.gerar({
      texto: m.texto,
      titulo: m.titulo || (ag && ag.nome) || 'Minuta',
      protocolo: m.protocolo,
      agente: ag && ag.nome,
      escrevente: m.usuario
    });
    const nome = docx.nomeArquivo({ protocolo: m.protocolo, agente: m.agente, titulo: m.titulo });
    res.setHeader('Content-Type', 'application/msword; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${nome}"`);
    res.send(html);
  } catch (e) { erro(res, 500, 'falha ao gerar o arquivo', e.message); }
});

// ------------------------------------------------------- CATÁLOGO DO PROTOCOLO

// Os códigos de ato e as bandeiras que o POST /protocolo já entende. Ficam aqui
// para a tela não precisar decorá-los — e para você corrigir num lugar só quando
// o cartório criar um tipo de ato novo.
const ATOS = [
  { codigo: 'CV-Urbano', nome: 'Compra e Venda — urbano' },
  { codigo: 'CV-Rural',  nome: 'Compra e Venda — rural' },
  { codigo: 'CDH',       nome: 'Cessão de Direitos Hereditários' },
  { codigo: 'CDP',       nome: 'Cessão de Direitos Possessórios' },
  { codigo: 'DOA',       nome: 'Doação' },
  { codigo: 'INV',       nome: 'Inventário e Partilha' },
  { codigo: 'TEST',      nome: 'Testamento' },
  { codigo: 'PER',       nome: 'Permuta' },
  { codigo: 'PERM',      nome: 'Permuta (variante)' },
  { codigo: 'DIV',       nome: 'Divórcio' },
  { codigo: 'UE',        nome: 'União Estável' },
  { codigo: 'UE-DIS',    nome: 'União Estável — dissolução' },
  { codigo: 'DUE',       nome: 'Dissolução de União Estável' },
  { codigo: 'RERRAT',    nome: 'Rerratificação' },
  { codigo: 'ATA-U',     nome: 'Ata Notarial — usucapião' },
  { codigo: 'ATA-USO',   nome: 'Ata Notarial — uso' },
  { codigo: 'ATA-W',     nome: 'Ata Notarial — constatação digital' },
  { codigo: 'ATA-W/A',   nome: 'Ata Notarial — constatação com áudio' },
  { codigo: 'PROC',      nome: 'Procuração' },
  { codigo: 'LAJE',      nome: 'Direito Real de Laje' },
  { codigo: 'DAC',       nome: 'Dação em Pagamento' }
];

// As mesmas cinco do server.js (NOMES_BANDEIRA). Mudou lá, mude aqui.
const BANDEIRAS = [
  { chave: 'verde',   nome: 'Loteador/Incorporador' },
  { chave: 'amarelo', nome: 'Construtor' },
  { chave: 'rosa',    nome: 'Santa Mônica' },
  { chave: 'roxo',    nome: 'Advogado' },
  { chave: 'cinza',   nome: 'Corretor' }
];

// GET /agentes/protocolo-catalogo — o que a tela precisa para montar o formulário.
router.get('/protocolo-catalogo', (req, res) => {
  res.json({ atos: ATOS, bandeiras: BANDEIRAS });
});

// ---------------------------------------------------------------- PIPELINE

// POST /agentes/:slug/extrair
// { arquivos: [{nome, mime, base64}], observacoes?, protocolo? }
// → { minuta_id, dados, alertas, uso }
// Etapa barata: lê os documentos e devolve o JSON para a escrevente CONFERIR.
// Nada é redigido aqui — de propósito.
router.post('/:slug/extrair', freioIA, async (req, res) => {
  try {
    const ag = await dba.obterAgente(req.params.slug);
    if (!ag || !ag.ativo) return erro(res, 404, 'agente não encontrado');

    const arquivos = Array.isArray(req.body.arquivos) ? req.body.arquivos : [];
    if (!arquivos.length && !req.body.observacoes) {
      return erro(res, 400, 'anexe ao menos um documento ou escreva as observações do caso');
    }

    const { dados, uso } = await gemini.extrair({
      agente: ag, arquivos, observacoes: req.body.observacoes
    });

    const alertas = Array.isArray(dados._alertas) ? dados._alertas : [];
    delete dados._alertas;

    const m = await dba.criarMinuta({
      protocolo: req.body.protocolo ? parseInt(req.body.protocolo, 10) : null,
      agente: ag.slug,
      usuario: req.usuario.login,
      titulo: req.body.titulo || ag.nome,
      dados, alertas
    });

    await dba.registrarConsumo({
      minuta_id: m.id, usuario: req.usuario.login, agente: ag.slug, etapa: 'extracao', uso
    });

    res.json({
      minuta_id: m.id, dados, alertas,
      campos: ag.campos,
      uso: { modelo: uso.modelo, tokens_entrada: uso.tokens_entrada, tokens_saida: uso.tokens_saida, custo_usd: uso.custo_usd }
    });
  } catch (e) { erro(res, 502, 'falha na extração dos documentos', e.message); }
});

// POST /agentes/:slug/executar
// { arquivos?: [{nome, mime, base64}], campos?: {}, observacoes?, protocolo?, titulo? }
// → { minuta_id, texto, uso }
//
// Etapa única, para os agentes que não redigem escritura: Qualificação do Imóvel,
// Extração de Certidões e o Redator Oficial. Grava mesmo assim em `minutas`, para
// a escrevente reencontrar o resultado no histórico e o custo entrar no relatório.
router.post('/:slug/executar', freioIA, async (req, res) => {
  try {
    const ag = await dba.obterAgente(req.params.slug);
    if (!ag || !ag.ativo) return erro(res, 404, 'agente não encontrado');
    if (ag.categoria === 'escritura') {
      return erro(res, 400, 'este agente redige escritura — use o fluxo de extração e minuta');
    }

    const arquivos = Array.isArray(req.body.arquivos) ? req.body.arquivos : [];
    const campos = req.body.campos && typeof req.body.campos === 'object' ? req.body.campos : {};
    const temCampo = Object.values(campos).some(v => v != null && String(v).trim() !== '');
    if (!arquivos.length && !temCampo && !req.body.observacoes) {
      return erro(res, 400, 'anexe um documento ou preencha o formulário');
    }

    const { texto, uso } = await gemini.executar({
      agente: ag, arquivos, campos, observacoes: req.body.observacoes
    });

    const m = await dba.criarMinuta({
      protocolo: req.body.protocolo ? parseInt(req.body.protocolo, 10) : null,
      agente: ag.slug,
      usuario: req.usuario.login,
      titulo: req.body.titulo || ag.nome,
      dados: campos, alertas: []
    });
    await dba.atualizarMinuta(m.id, { texto, status: 'pronto' });
    await dba.registrarTurno(m.id, 'agente', texto);
    await dba.registrarConsumo({
      minuta_id: m.id, usuario: req.usuario.login, agente: ag.slug, etapa: 'redacao', uso
    });

    res.json({
      minuta_id: m.id, texto,
      uso: { modelo: uso.modelo, tokens_entrada: uso.tokens_entrada, tokens_saida: uso.tokens_saida, custo_usd: uso.custo_usd }
    });
  } catch (e) { erro(res, 502, 'falha ao executar o agente', e.message); }
});

// POST /agentes/minutas/:id/redigir
// { dados?, observacoes? } — dados = o JSON já corrigido na tela.
// → { texto, uso }
router.post('/minutas/:id/redigir', freioIA, async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const m = await dba.obterMinuta(id);
    if (!m) return erro(res, 404, 'minuta não encontrada');
    if (m.usuario !== req.usuario.login && !ehAdmin(req.usuario)) return erro(res, 403, 'minuta de outra escrevente');

    const ag = await dba.obterAgente(m.agente);
    if (!ag) return erro(res, 404, 'agente não encontrado');

    // O que a escrevente conferiu na tela manda; o que veio da extração é só ponto de partida.
    const dados = req.body.dados && typeof req.body.dados === 'object' ? req.body.dados : m.dados;

    const { texto, uso } = await gemini.redigir({
      agente: ag, dados, observacoes: req.body.observacoes
    });

    await dba.atualizarMinuta(id, { dados, texto, status: 'redigida' });
    await dba.registrarTurno(id, 'agente', texto);
    await dba.registrarConsumo({
      minuta_id: id, usuario: req.usuario.login, agente: ag.slug, etapa: 'redacao', uso
    });

    res.json({
      minuta_id: id, texto,
      uso: { modelo: uso.modelo, tokens_entrada: uso.tokens_entrada, tokens_saida: uso.tokens_saida, custo_usd: uso.custo_usd }
    });
  } catch (e) { erro(res, 502, 'falha ao redigir a minuta', e.message); }
});

// POST /agentes/minutas/:id/revisar
// { pedido } → { texto, uso }
router.post('/minutas/:id/revisar', freioIA, async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const pedido = (req.body.pedido || '').trim();
    if (!pedido) return erro(res, 400, 'escreva o ajuste que você quer na minuta');

    const m = await dba.obterMinuta(id);
    if (!m) return erro(res, 404, 'minuta não encontrada');
    if (m.usuario !== req.usuario.login && !ehAdmin(req.usuario)) return erro(res, 403, 'minuta de outra escrevente');
    if (!m.texto) return erro(res, 409, 'redija a minuta antes de pedir revisão');

    const ag = await dba.obterAgente(m.agente);
    const historico = (m.turnos || []).filter(t => t.papel === 'usuario').map(t => t.conteudo).slice(-10);   // v1.39.3: só os 10 últimos ajustes

    const { texto, uso } = await gemini.revisar({
      agente: ag, minutaAtual: m.texto, pedido, historico
    });

    await dba.registrarTurno(id, 'usuario', pedido);
    await dba.registrarTurno(id, 'agente', texto);
    await dba.atualizarMinuta(id, { texto, status: 'revisada' });
    await dba.registrarConsumo({
      minuta_id: id, usuario: req.usuario.login, agente: m.agente, etapa: 'revisao', uso
    });

    res.json({
      minuta_id: id, texto,
      uso: { modelo: uso.modelo, tokens_entrada: uso.tokens_entrada, tokens_saida: uso.tokens_saida, custo_usd: uso.custo_usd }
    });
  } catch (e) { erro(res, 502, 'falha ao revisar a minuta', e.message); }
});

// POST /agentes/minutas/:id/salvar — edição manual do texto, sem gastar token.
router.post('/minutas/:id/salvar', async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const m = await dba.obterMinuta(id);
    if (!m) return erro(res, 404, 'minuta não encontrada');
    if (m.usuario !== req.usuario.login && !ehAdmin(req.usuario)) return erro(res, 403, 'minuta de outra escrevente');

    const campos = {};
    if (typeof req.body.texto === 'string') campos.texto = req.body.texto;
    if (typeof req.body.titulo === 'string') campos.titulo = req.body.titulo;
    if (req.body.dados && typeof req.body.dados === 'object') campos.dados = req.body.dados;
    if (typeof req.body.status === 'string') campos.status = req.body.status;
    // Depois de protocolar pela tela, a minuta guarda o número do ato.
    if (req.body.protocolo != null && req.body.protocolo !== '') {
      const n = parseInt(req.body.protocolo, 10);
      if (!Number.isInteger(n)) return erro(res, 400, 'número de protocolo inválido');
      campos.protocolo = n;
    }
    if (!Object.keys(campos).length) return erro(res, 400, 'nada para salvar');

    res.json(await dba.atualizarMinuta(id, campos));
  } catch (e) { erro(res, 500, 'falha ao salvar', e.message); }
});

// ---------------------------------------------------------- PROTOCOLO (ponte)

// GET /agentes/protocolo/:numero — traz o payload do balcão para pré-preencher
// o ato. É o elo com o Hub de Protocolo que já roda: partes, telefones,
// tipo de ato e checklist do dossiê já estão em protocolos.dados.
router.get('/protocolo/:numero', async (req, res) => {
  try {
    const { rows } = await pool.query(
      'SELECT numero, dados, card_id, usuario, criado_em FROM protocolos WHERE numero = $1',
      [parseInt(req.params.numero, 10)]
    );
    if (!rows[0]) return erro(res, 404, 'protocolo não encontrado');
    res.json(rows[0]);
  } catch (e) { erro(res, 500, 'falha ao buscar o protocolo', e.message); }
});

// ---------------------------------------------------------------- CADASTRO

// GET /agentes/:slug — o agente inteiro, com prompt e template. Só admin.
router.get('/:slug', async (req, res) => {
  if (!ehAdmin(req.usuario)) return erro(res, 403, 'somente Tabelião ou Substituta');
  try {
    const a = await dba.obterAgente(req.params.slug);
    if (!a) return erro(res, 404, 'agente não encontrado');
    res.json(a);
  } catch (e) { erro(res, 500, 'falha ao abrir o agente', e.message); }
});

// POST /agentes/:slug — cria ou atualiza. Toda gravação vira uma versão.
router.post('/:slug', async (req, res) => {
  if (!ehAdmin(req.usuario)) return erro(res, 403, 'somente Tabelião ou Substituta');
  try {
    const b = req.body || {};
    if (!b.nome || !b.prompt_sistema) return erro(res, 400, 'nome e prompt_sistema são obrigatórios');
    const salvo = await dba.salvarAgente({ ...b, slug: req.params.slug }, req.usuario.login);
    res.json(salvo);
  } catch (e) { erro(res, 500, 'falha ao salvar o agente', e.message); }
});

// GET /agentes/:slug/versoes — histórico de edições do prompt.
router.get('/:slug/versoes', async (req, res) => {
  if (!ehAdmin(req.usuario)) return erro(res, 403, 'somente Tabelião ou Substituta');
  try {
    res.json(await dba.versoesDoAgente(req.params.slug));
  } catch (e) { erro(res, 500, 'falha ao listar versões', e.message); }
});

module.exports = router;
