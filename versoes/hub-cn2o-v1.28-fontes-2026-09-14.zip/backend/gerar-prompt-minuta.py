#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gerar-prompt-minuta.py — monta o prompt do Gerador de Minuta (card 05 do Hub CN2O)
e reescreve o bloco gerado de backend/hub-prompts.js. Python 3, sem dependências.

    PROMPT_MINUTA = PROMPT_MINUTA_BV + '\\n\\n' + PROMPT_MINUTA_HUB

    PROMPT_MINUTA_BV  = fatia de docs/prompt-mestre-bv-4.0.txt entre as linhas
                        <BEGIN_SYSTEM_PROMPT> e <END_SYSTEM_PROMPT> — as duas linhas
                        de tag ficam de fora; da fatia só se removem as quebras de
                        linha iniciais e finais (.strip('\\n')); o resto é byte a byte.
                        O documento do Tabelião nunca é editado pelo Hub.
    PROMPT_MINUTA_HUB = docs/hub-camada-integracao.txt inteiro (.rstrip('\\n')).

Uso:
    python3 backend/gerar-prompt-minuta.py            # gera (recusa o STUB)
    python3 backend/gerar-prompt-minuta.py --permitir-stub   # só desenvolvimento

Recusa (código de saída 2, com mensagem) quando:
  - docs/prompt-mestre-bv-4.0.txt não existe ou não está em UTF-8 válido;
  - falta a tag <BEGIN_SYSTEM_PROMPT> ou a tag <END_SYSTEM_PROMPT> (cada uma sozinha na
    sua linha — só espaços ao redor), ou alguma das duas aparece mais de uma vez (a fatia
    ficaria ambígua: quem decide é o Tabelião, não o script);
  - a fatia ainda contém "[STUB — AGUARDANDO" (o marcador de posição) — salvo com
    --permitir-stub, que existe só para o ambiente de desenvolvimento: o teste-guarda
    de teste/api.test.js continua falhando de propósito até o texto íntegro do
    Tabelião entrar em docs/;
  - o bloco delimitado (">>> GERADO …" / "<<< FIM DO BLOCO GERADO") não existe, ou
    existe mais de uma vez, em backend/hub-prompts.js.

Os caminhos são relativos a este script (../docs/…), então roda de qualquer pasta.
A mesma regra de extração da fatia está em teste/api.test.js (fatiaPromptMestre),
que confere a igualdade byte a byte entre hub-prompts.js e os dois documentos.
"""
import argparse
import json
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.normpath(os.path.join(AQUI, '..'))
ARQ_BV = os.path.join(RAIZ, 'docs', 'prompt-mestre-bv-4.0.txt')
ARQ_HUB = os.path.join(RAIZ, 'docs', 'hub-camada-integracao.txt')
ARQ_JS = os.path.join(AQUI, 'hub-prompts.js')

TAG_INI = '<BEGIN_SYSTEM_PROMPT>'
TAG_FIM = '<END_SYSTEM_PROMPT>'
MARCA_STUB = '[STUB — AGUARDANDO'
# O que o String.prototype.trim() do JavaScript remove (WhiteSpace + LineTerminator do
# ECMAScript). É a regra do teste (l.trim() === TAG); o str.strip() do Python difere nas
# pontas — remove U+001C–U+001F e U+0085 e NÃO remove U+FEFF (o BOM que o Bloco de Notas do
# Windows grava no início do arquivo) —, por isso a lista explícita: as duas regras têm de
# reconhecer exatamente as mesmas linhas como tag.
ESPACOS_JS = (' \t\n\v\f\r\u00a0\u1680\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007'
              '\u2008\u2009\u200a\u2028\u2029\u202f\u205f\u3000\ufeff')


def eh_tag(linha, tag):
    return linha.strip(ESPACOS_JS) == tag

LINHA_INI = ('// >>> GERADO por backend/gerar-prompt-minuta.py a partir de '
             'docs/prompt-mestre-bv-4.0.txt e docs/hub-camada-integracao.txt — NÃO EDITE À MÃO')
LINHA_FIM = '// <<< FIM DO BLOCO GERADO'


def recusar(mensagem):
    sys.stderr.write('gerar-prompt-minuta: ' + mensagem + '\n')
    sys.exit(2)


def ler(caminho):
    # newline='' — nenhuma tradução de CRLF: o que está no arquivo é o que entra no prompt.
    # UTF-8 estrito: um arquivo gravado em Latin-1/Windows-1252 não pode virar prompt (o Node
    # o leria com U+FFFD no lugar dos acentos), então a recusa é limpa, sem traceback.
    try:
        with open(caminho, encoding='utf-8', newline='') as f:
            return f.read()
    except UnicodeDecodeError as e:
        recusar(os.path.relpath(caminho, RAIZ) + ' não está em UTF-8 válido (byte inválido na posição '
                + str(e.start) + ') — grave o arquivo em UTF-8 (sem conversão de acentos) e gere de novo')


def fatia_prompt_mestre(texto):
    """Fatia entre as tags. Regra (a mesma do teste de API, fatiaPromptMestre): a linha que,
    sem espaços ao redor (no sentido do trim() do JavaScript — ESPACOS_JS), é exatamente a
    tag; a <BEGIN…> do arquivo e a <END…> depois dela; as linhas entre as duas, unidas por
    '\\n', sem as quebras de linha iniciais/finais. Cada tag tem de aparecer UMA vez: com
    tag repetida, a fatia seria ambígua (e o corte, silencioso) — recusa."""
    linhas = texto.split('\n')
    inis = [i for i, l in enumerate(linhas) if eh_tag(l, TAG_INI)]
    fins = [i for i, l in enumerate(linhas) if eh_tag(l, TAG_FIM)]
    for tag, achadas in ((TAG_INI, inis), (TAG_FIM, fins)):
        if not achadas:
            dica = (' — a tag existe no arquivo, mas não está sozinha na sua linha (só espaços ao redor)'
                    if tag in texto else '')
            recusar('docs/prompt-mestre-bv-4.0.txt não tem a linha ' + tag + dica + ' — nada a extrair')
        if len(achadas) > 1:
            recusar('docs/prompt-mestre-bv-4.0.txt tem a linha ' + tag + ' mais de uma vez (linhas '
                    + ', '.join(str(i + 1) for i in achadas) + ') — a fatia ficaria ambígua; '
                    'o documento do Tabelião tem de trazer cada tag uma única vez')
    ini, fim = inis[0], fins[0]
    if fim < ini:
        recusar('docs/prompt-mestre-bv-4.0.txt tem a linha ' + TAG_FIM + ' (linha ' + str(fim + 1) + ') ANTES de '
                + TAG_INI + ' (linha ' + str(ini + 1) + ')')
    return '\n'.join(linhas[ini + 1:fim]).strip('\n')


def literal_js(texto):
    """String JS a partir de json.dumps (ensure_ascii=False). U+2028/U+2029 são escapados por
    cautela — JSON aceita-os crus, e motores JS antigos não."""
    return json.dumps(texto, ensure_ascii=False).replace('\u2028', '\\u2028').replace('\u2029', '\\u2029')


def main():
    ap = argparse.ArgumentParser(description='Regenera o bloco PROMPT_MINUTA de backend/hub-prompts.js.')
    ap.add_argument('--permitir-stub', action='store_true',
                    help='gera mesmo com o STUB no prompt-mestre (só desenvolvimento — NÃO PUBLICAR)')
    args = ap.parse_args()

    if not os.path.isfile(ARQ_BV):
        recusar('docs/prompt-mestre-bv-4.0.txt não existe (' + ARQ_BV + ') — grave o documento do Tabelião antes de gerar')
    if not os.path.isfile(ARQ_HUB):
        recusar('docs/hub-camada-integracao.txt não existe (' + ARQ_HUB + ')')
    if not os.path.isfile(ARQ_JS):
        recusar('backend/hub-prompts.js não existe (' + ARQ_JS + ')')

    bv = fatia_prompt_mestre(ler(ARQ_BV))
    if not bv.strip(ESPACOS_JS):
        recusar('a fatia entre ' + TAG_INI + ' e ' + TAG_FIM + ' está vazia (ou só tem espaços)')
    eh_stub = MARCA_STUB in bv
    if eh_stub and not args.permitir_stub:
        recusar('docs/prompt-mestre-bv-4.0.txt ainda é o STUB ("' + MARCA_STUB + '…") — grave o texto íntegro do '
                'Tabelião entre as tags. Para gerar mesmo assim (só desenvolvimento), use --permitir-stub.')

    hub = ler(ARQ_HUB).rstrip('\n')
    if not hub:
        recusar('docs/hub-camada-integracao.txt está vazio')

    total = bv + '\n\n' + hub
    bloco = [
        LINHA_INI,
        # contagem em pontos de código Unicode (len do Python); o .length do JS conta unidades
        # UTF-16, então difere quando há emoji ou outro caractere fora do BMP — é só informativo.
        '// PROMPT_MINUTA_BV: %d caracteres · PROMPT_MINUTA_HUB: %d caracteres · PROMPT_MINUTA: %d caracteres'
        % (len(bv), len(hub), len(total)),
        'const PROMPT_MINUTA_BV = ' + literal_js(bv) + ';',
        'const PROMPT_MINUTA_HUB = ' + literal_js(hub) + ';',
        "const PROMPT_MINUTA = PROMPT_MINUTA_BV + '\\n\\n' + PROMPT_MINUTA_HUB;",
        LINHA_FIM,
    ]

    js = ler(ARQ_JS)
    linhas = js.split('\n')
    inis = [i for i, l in enumerate(linhas) if l.strip() == LINHA_INI]
    fins = [i for i, l in enumerate(linhas) if l.strip() == LINHA_FIM]
    if len(inis) != 1 or len(fins) != 1 or fins[0] < inis[0]:
        recusar('bloco gerado não encontrado (ou duplicado) em backend/hub-prompts.js — as linhas\n  '
                + LINHA_INI + '\n  ' + LINHA_FIM + '\ntêm de existir uma vez cada, nesta ordem')
    novo = '\n'.join(linhas[:inis[0]] + bloco + linhas[fins[0] + 1:])

    if novo != js:
        with open(ARQ_JS, 'w', encoding='utf-8', newline='') as f:
            f.write(novo)
        situacao = 'bloco gerado reescrito'
    else:
        situacao = 'já estava atualizado — nada a reescrever'

    print('PROMPT_MINUTA_BV  = %d caracteres  (docs/prompt-mestre-bv-4.0.txt — fatia entre %s e %s)' % (len(bv), TAG_INI, TAG_FIM))
    print('PROMPT_MINUTA_HUB = %d caracteres  (docs/hub-camada-integracao.txt)' % len(hub))
    print("PROMPT_MINUTA     = %d caracteres  (BV + '\\n\\n' + HUB)" % len(total))
    print('backend/hub-prompts.js: ' + situacao + '.')
    if eh_stub:
        sys.stderr.write('ATENÇÃO: a fatia do prompt-mestre é o STUB — NÃO PUBLICAR. O teste-guarda de '
                         'teste/api.test.js ("prompt-mestre é o texto íntegro do Tabelião") vai falhar de propósito.\n')


if __name__ == '__main__':
    main()
