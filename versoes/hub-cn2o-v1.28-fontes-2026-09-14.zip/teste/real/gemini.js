// MOCK do gemini.js (teste local): mesmas exportações do real; executar() simulado.
'use strict';
const fs = require('fs');
const ARQ = process.env.GEMINI_LOG || '/tmp/gemini-chamadas.json';
const MODELO_REDACAO = 'gemini-3.8-flash', MODELO_EXTRACAO = 'gemini-3.5-flash-lite';
const PRECOS = { 'gemini-3.8-flash': [0.75, 3.75] };
function registrar(x) { let l = []; try { l = JSON.parse(fs.readFileSync(ARQ, 'utf8')); } catch (e) {} l.push(x); fs.writeFileSync(ARQ, JSON.stringify(l)); }
async function executar({ agente, arquivos = [], campos = {}, observacoes, modelo }) {
  if (!process.env.GEMINI_API_KEY) throw new Error('GEMINI_API_KEY não configurada nas variáveis do serviço');
  registrar({ prompt: agente.prompt_sistema, temperatura: agente.temperatura, usa_busca: agente.usa_busca,
    arquivos: arquivos.map(a => ({ mime: a.mime, tam: Buffer.from(a.base64, 'base64').length, cabeca: Buffer.from(a.base64, 'base64').slice(0, 5).toString('latin1') })),
    observacoes, modelo: modelo || null });
  await new Promise(r => setTimeout(r, Number(process.env.MOCK_ATRASO_MS || 1200)));
  if (/inexistente/.test(modelo || '')) throw new Error('Gemini ' + modelo + ' 404: {"error":{"code":404,"message":"models/' + modelo + ' is not found for API version v1beta, or is not supported for generateContent.","status":"NOT_FOUND"}}');
  if (/FORCAR_ERRO/.test(observacoes || '')) throw new Error('Gemini gemini-3.8-flash 500: {"error":{"message":"falha simulada"}}');
  // v1.21 — simulação do congestionamento do Google (503 UNAVAILABLE)
  const nomes = arquivos.map(a => String(a.nome || '')).join(' ');
  if (/FORCAR_503_SEMPRE/.test(observacoes || '') || /forcar-503/i.test(nomes)) throw new Error('Gemini ' + (modelo || '?') + ' 503: {"error":{"code":503,"message":"This model is currently experiencing high demand. Spikes in demand are usually temporary. Please try again later.","status":"UNAVAILABLE"}}');
  if (/FORCAR_503_UMA/.test(observacoes || '')) {
    global.__cn2o503 = (global.__cn2o503 || 0) + 1;
    if (global.__cn2o503 === 1) throw new Error('Gemini ' + (modelo || '?') + ' 503: {"error":{"code":503,"message":"The model is overloaded. Please try again later.","status":"UNAVAILABLE"}}');
  }
  // Gerador de Minuta (v1.28 — Prompt-Mestre BV 4.0 + docs/hub-camada-integracao.txt).
  // O mock reconhece o prompt pelo SENTINELA da camada de integração (o prompt-mestre
  // pode ser o stub) e responde pela ficha das observações — ver respostaMinuta().
  const ehMinuta = /=== CAMADA DE INTEGRAÇÃO COM O HUB CN2O — GERADOR DE MINUTA ===/.test(agente.prompt_sistema || '');
  if (ehMinuta) {
    const texto = respostaMinuta(observacoes || '');
    const uso = { texto, modelo: modelo || MODELO_REDACAO, tokens_entrada: 2000, tokens_saida: 500, custo_usd: 0.004, finish: 'STOP' };
    return { texto, uso };
  }
  const ehDescricao = /extrator de DESCRIÇÃO DE IMÓVEL/.test(agente.prompt_sistema || '');
  if (ehDescricao) {
    const texto = 'DESCRIÇÃO ATUALIZADA DO IMÓVEL — MATRÍCULA Nº 8.412 (CRI de Itabaiana/SE)\n\nUma casa residencial situada na Rua Coronel Sebastião, nº 156, Bairro Centro, nesta cidade, com área total de 240,00m².\n\nORIGEM DA DESCRIÇÃO\n- Abertura da matrícula; AV.3 de 10/04/2019 (retificação de área).\n\n⚠ CONFERIR\n- Nada a apontar.';
    const uso = { texto, modelo: modelo || MODELO_REDACAO, tokens_entrada: 1500, tokens_saida: 260, custo_usd: 0.0018, finish: 'STOP' };
    return { texto, uso };
  }
  const ehRedator = /REDATOR CN2O/.test(agente.prompt_sistema || '');
  if (ehRedator) {
    const pend = /aviso_pendencia/i.test(observacoes || '');
    const texto = pend
      ? 'AVISO DE PENDÊNCIA — Documento faltante no protocolo 1400\n\n===TEXTO_COPIAVEL===\nAssunto: CN2O — Protocolo 1400 — documento pendente\n\nPrezado Senhor,\n\nPara concluirmos a lavratura, ainda precisamos de:\n- Certidão de ônus atualizada (exigida pela lei do ato)\n\nAtenciosamente,\nCamily\nEscrevente — Cartório de Notas do 2º Ofício de Itabaiana/SE\n===FIM_TEXTO===\n\n===WHATSAPP_COPIAVEL===\nBom dia! Aqui é do Cartório de Notas do 2º Ofício de Itabaiana. Sobre o protocolo *1400*, ainda falta a certidão de ônus atualizada. Qualquer dúvida, estamos à disposição.\n===FIM_WHATSAPP===\n\n⚠ CONFERIR\n- Nada a apontar.'
      : 'OFÍCIO — Comunicação de teste\n\n===TEXTO_COPIAVEL===\nOfício nº ____/2026 — CN2O\n\nItabaiana/SE, 13 de setembro de 2026.\n\nExcelentíssimo Senhor Doutor Juiz de Direito,\n\nAssunto: teste\n\nO Cartório de Notas do 2º Ofício de Itabaiana/SE, por seu Tabelião que esta subscreve, vem respeitosamente à presença de Vossa Excelência prestar a informação requisitada.\n\nSendo o que se apresenta para o momento, renovamos protestos de elevada estima e distinta consideração.\n\nCésar Bravo\nTabelião de Notas\nCartório de Notas do 2º Ofício de Itabaiana/SE\n===FIM_TEXTO===\n\n⚠ CONFERIR\n- Numerar o ofício pelo livro da serventia.';
    const uso = { texto, modelo: modelo || MODELO_REDACAO, tokens_entrada: 1800, tokens_saida: 400, custo_usd: 0.0021, finish: 'STOP' };
    return { texto, uso };
  }
  const ehMatricula = /Analista de Matrículas/.test(agente.prompt_sistema || '');
  const texto = ehMatricula
    ? 'EXTRATO DA SITUAÇÃO JURÍDICA DO IMÓVEL — MATRÍCULA Nº 8.412\n\n1. IDENTIFICAÇÃO — Matrícula 8.412 (teste).\n2. TITULARIDADE ATUAL — JOSÉ RAIMUNDO SANTOS BISPO.\n10. CONCLUSÃO — APTO COM RESSALVAS (penhora vigente).\n\n===DESCRICAO_COPIAVEL===\nUma casa residencial situada na Rua Coronel Sebastião, nº 156, Bairro Centro, nesta cidade, com área total de 240,00m².\n===FIM_DESCRICAO==='
    : 'QUALIFICAÇÃO PRONTA\n\nMARÍLIA FONTES DE JESUS, brasileira, solteira, maior, farmacêutica, portadora da cédula de identidade RG nº 3.845.216 – SSP/SE, inscrita no CPF/MF sob o nº 054.318.276-90.\n\n⚠ CONFERIR\n- Nada a apontar nos textos fornecidos.';
  const uso = { texto, modelo: modelo || MODELO_REDACAO, tokens_entrada: 1234 + arquivos.length * 1000, tokens_saida: 321, custo_usd: 0.0021, finish: 'STOP' };
  return { texto, uso };
}
// ---------------------------------------------------------------- Gerador de Minuta (mock)
// Decide pela FICHA da entrevista dirigida (spec §2) que vem nas observações e responde
// EXATAMENTE no envelope do item 4 da camada de integração (spec §5):
//   DECISÃO DO ROTEADOR (Ato, Especialista, Rota, Módulos autorizados, Por quê,
//   Descartadas, Estado com o nome em português + código) → linha em branco →
//   PRONTA / PRELIMINAR: minuta entre ===MINUTA_COPIAVEL=== e ===FIM_MINUTA=== (marcadores
//     sozinhos na linha), com os placeholders [LAVRATURA: …], título em CAIXA ALTA por ato
//     e os nomes REAIS da ficha; PRELIMINAR traz [FALTA: …] na minuta e a seção PENDÊNCIAS;
//   BLOQUEADA / DECISÃO DO TABELIÃO / FORA DO ESCOPO: sem marcadores e sem trecho de
//     minuta — seção QUALIFICAÇÃO DEVOLVIDA AO TABELIÃO;
//   sempre ao final: ⚠ CONFERIR e o rodapé. Nunca "{{", "}}", "[[" ou "]]".
// Regras de decisão, em ordem de precedência:
//   a) sem linha ATO → BLOQUEADA — entrevista sem ATO
//   b) ATO fora de PROC|UE|DISS_UE|DIV|EMANC → FORA DO ESCOPO — ato não coberto
//   c) PARTILHA: agora → FORA DO ESCOPO — partilha no mesmo ato
//   d) EMANC com QUEM_OUTORGA: tutor → FORA DO ESCOPO — emancipação judicial (menor sob tutela)
//      (camada 2.6; §15.1 do Prompt-Mestre); com MOTIVO_UM_SO: outro_discorda → BLOQUEADA ([HARD_BLOCKER])
//   e) DISS_UE com GRAVIDEZ: sim → DECISÃO DO TABELIÃO — nascituro em extinção de união estável
//   f) PROC com FINALIDADE casamento | divorcio_ue | imovel_comprar → DECISÃO DO TABELIÃO —
//      <finalidade> sem módulo na MATRIX 01 (MATRIX_EXTENSION_REVIEW)
//   g) PROC com SUBSTABELECIMENTO nao_informado (ou ausente) → PRELIMINAR — [FALTA: substabelecimento — …]
//   h) UE com FILHOS nao_informado (ou ausente) → PRELIMINAR — [FALTA: filhos em comum]
//   i) PROC com FINALIDADE veiculo_regularizar → PRONTA, Rota PROC.VEICULO.REGULARIZE,
//      Módulos autorizados: PROC.VEHICLE.REGULARIZE (+ os demais IDs de MODULOS_AUTORIZADOS)
//   Os IDs de módulo são os da biblioteca do Prompt-Mestre, todos com o prefixo "PROC." (camada,
//   item 2.2). Chaves novas da ficha (PARTICULARIDADES, ADVOGADO_FACULTATIVO, REGIME/REGIME_ALTERADO
//   em DISS_UE, NOME_SOLTEIRO_1/2 e AVERBACAO em DIV, SITUACAO_DOS_PAIS em EMANC) são toleradas: não
//   mudam regra; SUBSTABELECIMENTO aceita também com_ou_sem_reserva.
//   j) qualquer outro caso dos cinco atos → PRONTA (Rota <ATO>.PADRAO — …; em PROC, Módulos
//      autorizados = linha MODULOS_AUTORIZADOS da ficha ou "nenhum")
// Chave ausente vale como nao_informado (camada, item 1.3). Nome de parte ausente na ficha
// vira "[FALTA: nome — …]" + pendência (camada 2.1 / 9.1-d: todo [FALTA] conta e vai a
// PENDÊNCIAS), porque uma minuta sem o nome das partes nunca é PRONTA.
const ATOS_MINUTA = {
  PROC: { especialista: 'ACT.PROC.PUBLICA', titulo: 'PROCURAÇÃO PÚBLICA' },
  UE: { especialista: 'ACT.UE.VIGENTE', titulo: 'ESCRITURA PÚBLICA DE DECLARAÇÃO DE UNIÃO ESTÁVEL' },
  DISS_UE: { especialista: 'ACT.UE.DISSOLUCAO.SEM_PARTILHA', titulo: 'ESCRITURA PÚBLICA DE EXTINÇÃO CONSENSUAL DE UNIÃO ESTÁVEL' },
  DIV: { especialista: 'ACT.DIVORCIO.CONSENSUAL.SEM_PARTILHA', titulo: 'ESCRITURA PÚBLICA DE DIVÓRCIO CONSENSUAL' },
  EMANC: { especialista: 'ACT.EMANCIPACAO.VOLUNTARIA', titulo: 'ESCRITURA PÚBLICA DE EMANCIPAÇÃO' }
};
const RODAPE_MINUTA = 'Minuta de rascunho gerada pelo Hub CN2O — sujeita à conferência e ao aperfeiçoamento do Tabelião.';
const LAVRATURA_CONFERIR = 'campos de lavratura a preencher: livro, folhas, data por extenso, emolumentos e selo, escrevente ou tabelião que lavra e assina, testemunhas se exigidas, forma do ato';
function respostaMinuta(obs) {
  const campo = (chave) => { const m = new RegExp('^' + chave + ':[ \\t]*(.*)$', 'm').exec(obs); return m ? m[1].trim() : ''; };
  const valor = (chave) => (campo(chave).split(/\s+/)[0] || '').replace(/:$/, ''); // o código da enumeração (sem o ':' de 'convencao:', 'sim:' etc.)
  const nome = (chave) => { const n = campo(chave).split(' · ')[0].trim(); return n && n !== 'nao_informado' ? n.toUpperCase() : ''; };
  const ato = valor('ATO').toUpperCase();
  const info = ATOS_MINUTA[ato];
  const finalidade = valor('FINALIDADE');
  const cab = (l) => 'DECISÃO DO ROTEADOR\n' + [
    'Ato: ' + l.ato, 'Especialista: ' + l.especialista, 'Rota: ' + l.rota, 'Módulos autorizados: ' + l.modulos,
    'Por quê: ' + l.porque, 'Descartadas: ' + l.descartadas, 'Estado: ' + l.estado
  ].map(x => '- ' + x).join('\n');
  const devolvida = (impede, fundamento, destrava) => 'QUALIFICAÇÃO DEVOLVIDA AO TABELIÃO\n- O que impede: ' + impede + '\n- Fundamento: ' + fundamento + '\n- O que destravaria: ' + destrava;
  const conferir = (itens) => '⚠ CONFERIR\n' + itens.map(i => '- ' + i).join('\n');
  const semMinuta = (cabecalho, dev, itens) => [cab(cabecalho), dev, conferir(itens), RODAPE_MINUTA].join('\n\n');

  // a) sem ATO
  if (!ato) {
    return semMinuta(
      { ato: 'nenhum', especialista: 'nenhum', rota: 'nenhuma', modulos: 'nenhum', porque: 'a entrevista não traz a chave ATO (ficha)', descartadas: 'nenhuma — sem ato não há rota', estado: 'BLOQUEADA (BLOCKED) — entrevista sem ATO' },
      devolvida('ficha sem o campo ATO', 'camada de integração, item 1.3 — a primeira chave é sempre ATO; o roteamento é pelo conteúdo, nunca por adivinhação', 'refazer a entrevista dirigida na tela do Gerador de Minuta'),
      ['[FALTA: ATO da entrevista]']);
  }
  // b) ato fora dos cinco (INVENTARIO, CV…): o Gerador não aproxima
  if (!info) {
    return semMinuta(
      { ato: 'nenhum', especialista: 'nenhum', rota: 'nenhuma', modulos: 'nenhum', porque: 'ATO ' + ato + ' não está entre PROC | UE | DISS_UE | DIV | EMANC (ficha)', descartadas: 'nenhuma', estado: 'FORA DO ESCOPO (OUT_OF_SCOPE) — ato não coberto' },
      devolvida('ato ' + ato + ' fora dos cinco atos do Gerador', 'camada de integração, item 2.1 — o Gerador não aproxima nem adapta', 'lavratura pelo fluxo próprio do ato, fora do Hub'),
      ['ato fora do escopo: ' + ato]);
  }
  // c) partilha no mesmo ato
  if (/^PARTILHA:\s*agora\b/m.test(obs)) {
    return semMinuta(
      { ato: 'nenhum', especialista: 'nenhum', rota: 'nenhuma — partilha de bens no mesmo ato', modulos: 'nenhum', porque: 'PARTILHA: agora (ficha) — as partes querem partilhar os bens nesta escritura', descartadas: ato + ' sem partilha / partilha diferida — não é o que as partes querem', estado: 'FORA DO ESCOPO (OUT_OF_SCOPE) — partilha no mesmo ato' },
      devolvida('divórcio ou extinção de união estável COM partilha de bens no mesmo ato', 'camada de integração, itens 2.1 e 7.3 — NO_PARTITION_MODULE → NO_ASSET_ALLOCATION', 'partilha diferida (ato próprio) ou lavratura do ato completo pelo Tabelião, fora do Hub'),
      ['[PARTITION_EFFECT] as partes querem atribuir bens neste ato.']);
  }
  // d) emancipação de menor sob tutela: só por sentença — fora do escopo (camada 2.6; §15.1 do Prompt-Mestre)
  if (ato === 'EMANC' && /^QUEM_OUTORGA:\s*tutor\b/m.test(obs)) {
    return semMinuta(
      { ato: 'EMANC', especialista: info.especialista, rota: 'nenhuma — emancipação judicial (menor sob tutela)', modulos: 'nenhum', porque: 'QUEM_OUTORGA: tutor (ficha) — BLOCK_IF:GUARDIANSHIP_OUT_OF_SCOPE', descartadas: 'EMANC.PADRAO (pelos pais) — não há pais outorgando', estado: 'FORA DO ESCOPO (OUT_OF_SCOPE) — emancipação judicial (menor sob tutela)' },
      devolvida('emancipação de menor sob tutela não se faz por escritura', 'CC, art. 5º, parágrafo único, I — por tutor, só por sentença do juiz; camada de integração, item 2.6; §15.1 e §15.8 do Prompt-Mestre', 'sentença judicial de emancipação, ouvido o tutor — fora do Hub'),
      ['emancipação por tutor: via judicial (CC, art. 5º, parágrafo único, I) — dispositivo a confirmar.']);
  }
  // d) emancipação por um só genitor com o outro discordando: suprimento judicial
  if (ato === 'EMANC' && /^MOTIVO_UM_SO:\s*outro_discorda\b/m.test(obs)) {
    return semMinuta(
      { ato: 'EMANC', especialista: info.especialista, rota: 'EMANC.PADRAO — emancipação voluntária pelos pais', modulos: 'nenhum', porque: 'MOTIVO_UM_SO: outro_discorda (ficha)', descartadas: 'nenhuma', estado: 'BLOQUEADA (BLOCKED) — suprimento judicial' },
      devolvida('o outro genitor discorda da emancipação', 'CC, art. 1.631, parágrafo único — divergência entre os pais resolve-se pelo juiz', 'decisão judicial (suprimento) ou comparecimento de ambos os pais'),
      ['[HARD_BLOCKER] emancipação exige a concordância de ambos os pais ou suprimento judicial.', 'CC, art. 5º, parágrafo único, I; CC, art. 1.631, parágrafo único — dispositivos a confirmar.']);
  }
  // e) nascituro em extinção de união estável
  if (ato === 'DISS_UE' && /^GRAVIDEZ:\s*sim\b/m.test(obs)) {
    return semMinuta(
      { ato: 'DISS_UE', especialista: info.especialista, rota: 'DISS_UE.PADRAO — extinção consensual de união estável sem partilha', modulos: 'nenhum', porque: 'GRAVIDEZ: sim (ficha) — há nascituro', descartadas: 'DISS_UE.PADRAO sem a questão do nascituro — o fato consta da ficha', estado: 'DECISÃO DO TABELIÃO (REQUIRES_NOTARY_DECISION) — nascituro em extinção de união estável' },
      devolvida('nascituro declarado pelas partes', 'CPC, art. 733, caput ("não havendo nascituro ou filhos incapazes"); Res. CNJ 35, art. 34, §1º, c/c art. 46-A — questão reservada ao Tabelião pelo Prompt-Mestre', 'alternativa A: o Tabelião decide pela via judicial; alternativa B: o Tabelião autoriza a lavratura com a declaração das partes e a fundamentação que entender cabível'),
      ['nascituro em extinção de união estável — decisão do Tabelião.', 'CPC, art. 733; Res. CNJ 35, art. 34, §1º, e art. 46-A — dispositivos a confirmar.']);
  }
  // f) finalidade sem módulo na MATRIX 01
  if (ato === 'PROC' && ['casamento', 'divorcio_ue', 'imovel_comprar'].includes(finalidade)) {
    const fund = { casamento: 'CC, art. 1.542, §3º — instrumento público, poderes especiais, eficácia de 90 dias', divorcio_ue: 'Res. CNJ 35, art. 36 c/c art. 46-A — procuração pública, poderes especiais, cláusulas essenciais, 30 dias', imovel_comprar: 'CC, art. 661, §1º — poderes especiais e expressos para adquirir' }[finalidade];
    const modulo = { casamento: 'PROC.MARRIAGE', divorcio_ue: 'PROC.DIVORCE_REPRESENTATION', imovel_comprar: 'PROC.REAL_ESTATE.BUY' }[finalidade];
    return semMinuta(
      { ato: 'PROC', especialista: info.especialista, rota: 'nenhuma — MATRIX 01 sem módulo para ' + finalidade, modulos: 'nenhum', porque: 'FINALIDADE ' + finalidade + ' (ficha); FINALIDADE_DESCRICAO: ' + (campo('FINALIDADE_DESCRICAO') || 'nao_informado') + ' (ficha)', descartadas: 'PROC.PADRAO com módulos vizinhos — proibido improvisar módulo fora da biblioteca (camada, item 8.1)', estado: 'DECISÃO DO TABELIÃO (REQUIRES_NOTARY_DECISION) — ' + finalidade + ' sem módulo na MATRIX 01 (MATRIX_EXTENSION_REVIEW)' },
      devolvida('a biblioteca do Prompt-Mestre não traz módulo de poderes para ' + finalidade, fund + '; camada de integração, item 8.1 (MATRIX_EXTENSION_REVIEW)', 'alternativa A: o Tabelião aprova o módulo proposto ' + modulo + ' (spec §8), com seus poderes e o prazo legal, e a entrevista é refeita; alternativa B: lavratura fora do Hub'),
      ['MATRIX_EXTENSION_REVIEW — finalidade ' + finalidade + ' sem módulo na MATRIX 01.', fund + ' — dispositivo a confirmar.']);
  }

  // g) a j): estados com minuta. Toda [FALTA: …] vira pendência; o estado sai da contagem.
  const pend = [];
  const falta = (texto, chave, oque, destrava) => { pend.push('B1 · ' + chave + ' · ' + oque + ' · ' + destrava); return '[FALTA: ' + texto + ']'; };
  const nomeOu = (chave, rotulo) => nome(chave) || falta('nome — ' + rotulo, chave, 'nome de ' + rotulo + ' não informado', 'preencher o nome na ficha');
  const abertura = (comparecimento) => 'Livro [LAVRATURA: livro], folhas [LAVRATURA: folhas].\n\nSAIBAM quantos este público instrumento virem que, aos [LAVRATURA: data por extenso], nesta cidade de Itabaiana, Estado de Sergipe, no Cartório de Notas do 2º Ofício, perante mim, [LAVRATURA: escrevente ou tabelião que lavra e assina], ' + comparecimento;
  const advogado = () => { const a = campo('ADVOGADO').replace(/^(comum|separados|defensor_publico):\s*/, ''); return a && a !== 'nao_informado' ? a : 'advogado(a) ou defensor(a) público(a) a indicar'; };
  const fecho = (assinantes) => 'FECHO: lida e achada conforme, assinam. [LAVRATURA: emolumentos e selo]. [LAVRATURA: testemunhas, se exigidas]. [LAVRATURA: forma do ato — presencial / e-Notariado].\n\n' + assinantes.map(n => '____________________ ' + n).join('\n\n');
  let rota, modulos = 'nenhum', porque, descartadas, corpo, normas;

  if (ato === 'PROC') {
    const outorgante = nomeOu('OUTORGANTE_1', 'outorgante');
    const outorgado = nomeOu('OUTORGADO_1', 'outorgado');
    const objeto = campo('OBJETO');
    const regularizar = finalidade === 'veiculo_regularizar';
    const ids = campo('MODULOS_AUTORIZADOS').split(',').map(s => s.trim()).filter(s => s && s !== 'nao_informado');
    const lista = regularizar ? ['PROC.VEHICLE.REGULARIZE'].concat(ids.filter(m => m !== 'PROC.VEHICLE.REGULARIZE')) : ids;
    modulos = lista.length ? lista.join(', ') : 'nenhum';
    rota = regularizar ? 'PROC.VEICULO.REGULARIZE — regularização de veículo' : 'PROC.PADRAO — procuração pública (finalidade ' + (finalidade || 'nao_informado') + ')';
    porque = 'FINALIDADE ' + (finalidade || 'nao_informado') + ' (ficha); MODULOS_AUTORIZADOS: ' + (ids.length ? ids.join(', ') : 'nenhum') + ' (ficha)';
    descartadas = regularizar ? 'PROC.VEICULO.TRANSFER — PROC.VEHICLE.TRANSFER não está em MODULOS_AUTORIZADOS (ficha)' : 'nenhuma';
    const poderes = regularizar
      ? 'poderes para regularizar, transferir para o nome do outorgante, licenciar, emplacar, vistoriar e representar perante o DETRAN e os órgãos de trânsito o veículo ' + (objeto && objeto !== 'nao_informado' ? objeto : 'de sua propriedade') + ', pagar e contestar multas e taxas' + (lista.length > 1 ? '; e ainda os poderes dos módulos ' + lista.slice(1).join(', ') : '')
      : (lista.length ? 'os poderes dos módulos autorizados na ficha: ' + lista.join(', ') : 'poderes gerais de administração (CC, art. 661, caput), sem módulo de autorização expressa');
    const substab = valor('SUBSTABELECIMENTO');
    const clSubstab = substab === 'vedado' ? 'É vedado o substabelecimento desta procuração (CC, art. 667).'
      : substab === 'com_reserva' ? 'Permitido o substabelecimento, com reserva de iguais poderes.'
      : substab === 'sem_reserva' ? 'Permitido o substabelecimento, sem reserva de poderes.'
      : substab === 'com_ou_sem_reserva' ? 'Permitido o substabelecimento, com ou sem reserva de poderes.'
      : falta('substabelecimento — vedado / com reserva / sem reserva', 'SUBSTABELECIMENTO', 'opção de substabelecimento não informada', 'marcar vedado, com reserva ou sem reserva');
    const prazo = campo('PRAZO');
    const clPrazo = prazo === 'indeterminado' ? '\n\nPRAZO: esta procuração vigora por prazo indeterminado.' : /^ate\s+\S/.test(prazo) ? '\n\nPRAZO: esta procuração vigora ' + prazo.replace(/^ate\s+/, 'até ') + '.' : '';
    corpo = abertura('compareceu como OUTORGANTE: ' + outorgante + ', na forma da qualificação apresentada; e, como OUTORGADO: ' + outorgado + '.') +
      '\n\nPODERES: pelo presente instrumento, o outorgante nomeia e constitui o outorgado seu bastante procurador, conferindo-lhe ' + poderes + ' (CC, art. 661, §1º).' +
      '\n\nSUBSTABELECIMENTO: ' + clSubstab + clPrazo + '\n\n' + fecho([outorgante]);
    normas = 'CC, art. 661, §1º' + (substab === 'vedado' ? '; CC, art. 667' : '');
  } else if (ato === 'UE') {
    const c1 = nomeOu('CONVIVENTE_1', 'convivente 1'), c2 = nomeOu('CONVIVENTE_2', 'convivente 2');
    const inicio = campo('INICIO_CONVIVENCIA');
    const regime = valor('REGIME');
    const filhos = campo('FILHOS');
    const nomeCl = campo('NOME');
    const clInicio = /^\d{2}\/\d{2}\/\d{4}$/.test(inicio) ? 'desde ' + inicio : inicio === 'nao_sabem_precisar' ? 'há tempo que não sabem precisar' : 'sem data de início declarada na ficha';
    const clRegime = regime === 'legal_comunhao_parcial' ? 'o da comunhão parcial de bens (CC, art. 1.725)'
      : /^convencao/.test(regime) ? 'o convencionado nesta escritura — ' + campo('REGIME').replace(/^convencao:\s*/, '') + ' — com efeitos a partir desta data, sem retroação'
      : /^pacto_anterior/.test(regime) ? 'o do pacto anterior referido na ficha (' + campo('REGIME').replace(/^pacto_anterior:\s*/, '') + ')'
      : 'não declarado na ficha';
    const clFilhos = filhos === 'nenhum' ? 'os conviventes declaram não ter filhos em comum.'
      : /^sim/.test(filhos) ? 'os conviventes declaram ter em comum: ' + filhos.replace(/^sim:?\s*/, '') + '.'
      : 'não há informação sobre filhos em comum — ' + falta('filhos em comum', 'FILHOS', 'filhos em comum não informados', 'marcar nenhum ou informar nomes e datas de nascimento') + '.';
    const clNome = nomeCl === 'ninguem_altera' ? 'os conviventes mantêm os seus nomes.'
      : /^convivente_1_acrescenta/.test(nomeCl) ? c1 + ' passará a assinar ' + nomeCl.replace(/^convivente_1_acrescenta:\s*/, '').toUpperCase() + ', cláusula condicionada ao registro desta escritura no Livro E (Lei 6.015/73, art. 57, §2º).'
      : /^convivente_2_acrescenta/.test(nomeCl) ? c2 + ' passará a assinar ' + nomeCl.replace(/^convivente_2_acrescenta:\s*/, '').toUpperCase() + ', cláusula condicionada ao registro desta escritura no Livro E (Lei 6.015/73, art. 57, §2º).'
      : /^ambos/.test(nomeCl) ? 'acréscimo de sobrenome conforme a ficha (' + nomeCl.replace(/^ambos:\s*/, '') + '), condicionado ao registro desta escritura no Livro E (Lei 6.015/73, art. 57, §2º).'
      : 'nada consta na ficha sobre alteração de nome.';
    rota = 'UE.PADRAO — união estável, ' + (regime === 'legal_comunhao_parcial' ? 'regime legal' : 'regime conforme a ficha');
    porque = 'ATO UE (ficha); conviventes ' + c1 + ' e ' + c2 + ' (ficha); REGIME ' + (regime || 'nao_informado') + ' (ficha)';
    descartadas = 'UE.SEPARADO_DE_FATO — nenhum convivente casado (ficha); UE.SEPTUAGENARIO — MAIOR_70 não marcado como sim (ficha)';
    corpo = abertura('compareceram como CONVIVENTES: ' + c1 + ' e ' + c2 + ', na forma da qualificação apresentada.') +
      '\n\nDECLARAÇÃO: os conviventes declaram que vivem em união estável, pública, contínua e duradoura, com o objetivo de constituição de família (CC, art. 1.723), ' + clInicio + '.' +
      '\n\nREGIME DE BENS: ' + clRegime + '.' +
      '\n\nFILHOS: ' + clFilhos +
      '\n\nNOME: ' + clNome +
      '\n\nREGISTRO NO LIVRO E: os conviventes foram advertidos de que os efeitos desta escritura perante terceiros, inclusive a alteração de nome, dependem do registro no Livro E do Registro Civil das Pessoas Naturais (Lei 6.015/73, arts. 57, §2º, e 94-A).' +
      '\n\n' + fecho([c1, c2]);
    normas = 'CC, arts. 1.723 e 1.725; Lei 6.015/73, arts. 57, §2º, e 94-A';
  } else if (ato === 'DISS_UE') {
    const c1 = nomeOu('CONVIVENTE_1', 'convivente 1'), c2 = nomeOu('CONVIVENTE_2', 'convivente 2');
    const bens = valor('BENS_COMUNS'), filhos = valor('FILHOS'), grav = valor('GRAVIDEZ');
    rota = 'DISS_UE.PADRAO — extinção consensual de união estável sem partilha';
    porque = 'ATO DISS_UE (ficha); PARTILHA ' + (valor('PARTILHA') || 'nao_informado') + ' (ficha); FILHOS ' + (filhos || 'nao_informado') + ' (ficha)';
    descartadas = 'nenhuma';
    corpo = abertura('compareceram como CONVIVENTES: ' + c1 + ' e ' + c2 + ', na forma da qualificação apresentada.') +
      '\n\nDECLARAÇÃO: os conviventes declaram extinta, por mútuo consentimento, a união estável que mantinham' + (/^\d{2}\/\d{2}\/\d{4}$/.test(campo('DATA_TERMINO')) ? ', desde ' + campo('DATA_TERMINO') : '') + ' (Res. CNJ 35, art. 46-A; CPC, art. 733).' +
      '\n\nBENS: ' + (bens === 'nao' ? 'os conviventes declaram não possuir bens comuns a partilhar.' : bens === 'sim' || bens === 'sim_parcialmente_identificados' ? 'os conviventes declaram que a partilha dos bens comuns será feita em ato próprio (CPC, art. 731, parágrafo único).' : 'os conviventes nada declaram sobre bens neste ato.') +
      '\n\nFILHOS: ' + (filhos === 'nenhum' ? 'os conviventes declaram não ter filhos em comum.' : filhos === 'capazes' ? 'os filhos em comum são maiores e capazes.' : filhos === 'incapazes' ? 'há filho incapaz, com guarda, convivência e alimentos já decididos judicialmente (' + campo('DECISAO_JUDICIAL_FILHOS') + ').' : 'conforme a ficha.') +
      ' ' + (grav === 'nao' ? 'Declaram que não há gravidez em curso (Res. CNJ 35, art. 34, §1º).' : grav === 'desconhece' ? 'Declaram não ter conhecimento de gravidez (Res. CNJ 35, art. 34, §1º).' : '') +
      '\n\nALIMENTOS: ' + (valor('ALIMENTOS_ENTRE_CONVIVENTES') === 'dispensa_reciproca' ? 'os conviventes dispensam-se reciprocamente de alimentos.' : campo('ALIMENTOS_ENTRE_CONVIVENTES') || 'conforme a ficha.') +
      '\n\nNOME: ' + (valor('NOME') === 'nunca_alterado' ? 'os conviventes declaram que a união não alterou o nome de nenhum deles.' : valor('NOME') === 'mantem_nome_atual' ? campo('NOME').replace(/^mantem_nome_atual:\s*/, '') + ' mantém o nome atual.' : valor('NOME') === 'retoma_nome_anterior' ? campo('NOME').replace(/^retoma_nome_anterior:\s*/, '') + ' retoma o nome anterior à união (Lei 6.015/73, art. 57, §3º-A).' : 'conforme a ficha.') +
      '\n\nASSISTÊNCIA: as partes estão assistidas por ' + advogado() + ' (CPC, art. 733, §2º; Res. CNJ 35, art. 8º).' +
      '\n\n' + fecho([c1, c2]);
    normas = 'CPC, arts. 731, parágrafo único, e 733; Res. CNJ 35, arts. 8º, 34, §1º, e 46-A';
  } else if (ato === 'DIV') {
    const c1 = nomeOu('CONJUGE_1', 'cônjuge 1'), c2 = nomeOu('CONJUGE_2', 'cônjuge 2');
    const bens = valor('BENS_COMUNS'), filhos = valor('FILHOS'), grav = valor('GRAVIDEZ');
    rota = 'DIV.PADRAO — divórcio consensual sem partilha';
    porque = 'ATO DIV (ficha); PARTILHA ' + (valor('PARTILHA') || 'nao_informado') + ' (ficha); FILHOS ' + (filhos || 'nao_informado') + ' (ficha)';
    descartadas = 'nenhuma';
    corpo = abertura('compareceram como CÔNJUGES: ' + c1 + ' e ' + c2 + ', na forma da qualificação apresentada.') +
      '\n\nDECLARAÇÃO: os cônjuges, casados conforme a ficha (' + (campo('CASAMENTO') || 'dados do casamento a conferir') + '), regime de bens: ' + (campo('REGIME') || 'declarado na ficha') + ', declaram dissolvido o vínculo conjugal pelo DIVÓRCIO CONSENSUAL (CC, art. 1.581; CPC, art. 733).' +
      '\n\nBENS: ' + (bens === 'nao' ? 'os cônjuges declaram não possuir bens comuns a partilhar.' : bens === 'so_bens_particulares' ? 'os cônjuges declaram que só existem bens particulares, nada havendo a partilhar.' : bens === 'sim' || bens === 'sim_parcialmente_identificados' ? 'os cônjuges declaram que a partilha dos bens comuns será feita em ato próprio (CC, art. 1.581; CPC, art. 731, parágrafo único).' : 'os cônjuges nada declaram sobre bens neste ato.') +
      '\n\nFILHOS: ' + (filhos === 'nenhum' ? 'os cônjuges declaram não ter filhos em comum.' : filhos === 'maiores_capazes' ? 'os filhos em comum são maiores e capazes.' : filhos === 'menores_ou_incapazes' ? 'há filho menor ou incapaz, com guarda, convivência e alimentos já decididos judicialmente (' + campo('DECISAO_JUDICIAL_FILHOS') + ').' : 'conforme a ficha.') +
      ' ' + (grav === 'nao' ? 'Declaram que não há gravidez em curso (Res. CNJ 35, art. 34, §1º).' : grav === 'desconhece' ? 'Declaram não ter conhecimento de gravidez (Res. CNJ 35, art. 34, §1º).' : '') +
      '\n\nPENSÃO: ' + (valor('PENSAO_ENTRE_CONJUGES') === 'dispensa_reciproca' ? 'os cônjuges dispensam-se reciprocamente de pensão alimentícia.' : campo('PENSAO_ENTRE_CONJUGES') || 'conforme a ficha.') +
      '\n\nNOME: ' + (valor('NOME') === 'cada_um_mantem' ? 'cada cônjuge mantém o nome que usa.' : campo('NOME') || 'conforme a ficha.') +
      '\n\nASSISTÊNCIA: as partes estão assistidas por ' + advogado() + ' (CPC, art. 733, §2º; Res. CNJ 35, art. 8º).' +
      '\n\n' + fecho([c1, c2]);
    normas = 'CC, art. 1.581; CPC, arts. 731, parágrafo único, e 733; Res. CNJ 35, arts. 8º e 34, §1º';
  } else {   // EMANC
    const menor = nomeOu('MENOR', 'emancipando');
    const quem = campo('QUEM_OUTORGA');
    rota = 'EMANC.PADRAO — emancipação voluntária pelos pais';
    porque = 'ATO EMANC (ficha); QUEM_OUTORGA ' + (quem || 'nao_informado') + ' (ficha)';
    descartadas = 'nenhuma';
    corpo = abertura('compareceram ' + (/^um_dos_pais/.test(quem) ? 'o genitor indicado na ficha (' + quem.replace(/^um_dos_pais:\s*/, '') + ', na falta do outro — ' + (campo('MOTIVO_UM_SO') || 'motivo na ficha') + ')' : 'ambos os pais') + ' do(a) EMANCIPANDO(A): ' + menor + ', na forma da qualificação apresentada.') +
      '\n\nEMANCIPAÇÃO: pelo presente instrumento, concedem a emancipação ao(à) emancipando(a), nos termos do art. 5º, parágrafo único, I, do Código Civil, para todos os fins de direito.' +
      '\n\nEFEITOS: a emancipação só produz efeitos após o registro no Livro E do Registro Civil das Pessoas Naturais do 1º Ofício da comarca do domicílio do(a) emancipando(a) (CC, art. 9º, II; Lei 6.015/73, arts. 89 a 91, parágrafo único).' +
      '\n\n' + fecho([menor]);
    normas = 'CC, arts. 5º, parágrafo único, I, e 9º, II; Lei 6.015/73, arts. 89 a 91';
  }

  const estado = pend.length
    ? 'PRELIMINAR COM PENDÊNCIAS (PRELIMINARY_WITH_PENDING_ITEMS) — ' + pend.length + ' pendência(s)'
    : 'PRONTA PARA MINUTA (READY_FOR_RELEASE)';
  const partes = [
    cab({ ato, especialista: info.especialista, rota, modulos, porque, descartadas, estado }),
    '===MINUTA_COPIAVEL===\n' + info.titulo + '\n\n' + corpo + '\n===FIM_MINUTA==='
  ];
  if (pend.length) partes.push('PENDÊNCIAS\n' + pend.map(p => '- ' + p).join('\n'));
  const itens = [];
  if (pend.length) itens.push('minuta preliminar — não apta à assinatura: ' + pend.length + ' pendência(s)');   // item 3.4: primeira linha, exatamente assim
  // cada [FALTA: …] distinto uma vez (o mesmo nome faltante aparece na abertura, na cláusula de nome e no fecho)
  Array.from(new Set(corpo.match(/\[FALTA: [^\]]*\]/g) || [])).forEach(f => itens.push(f));
  itens.push(LAVRATURA_CONFERIR + '.');
  itens.push(normas + ' — dispositivos citados na minuta, a confirmar.');
  partes.push(conferir(itens), RODAPE_MINUTA);
  return partes.join('\n\n');
}
const naoUsado = async () => { throw new Error('mock: não usado nos testes do hub'); };
module.exports = { extrair: naoUsado, redigir: naoUsado, revisar: naoUsado, executar, listarModelos: naoUsado,
  custoUsd: () => 0, MODELO_EXTRACAO, MODELO_REDACAO, PRECOS };
