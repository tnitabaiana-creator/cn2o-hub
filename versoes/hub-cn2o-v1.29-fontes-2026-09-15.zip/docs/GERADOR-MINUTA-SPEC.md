# Gerador de Minuta — especificação da integração (v1.28)

*Cartório de Notas do 2º Ofício de Itabaiana/SE · Hub CN2O · 14/09/2026*

## 0. Origem e propósito

Na v1.27 o card 05 passou a se chamar **Gerador de Minuta**, com uma entrevista dirigida por ato e um
roteador que decide a variante. Na v1.28 o Tabelião entregou o **AGENTE JURÍDICO-NOTARIAL BV CARTÓRIOS —
Prompt-Mestre + Arquitetura + Cinco Especialistas + Cinco Minutas-Matrizes, versão consolidada 4.0
(data-base 13/09/2026)** e pediu que a operação fosse refeita sobre ele. O prompt do Gerador passa a ser:

```
PROMPT_MINUTA = <texto do Prompt-Mestre entre <BEGIN_SYSTEM_PROMPT> e <END_SYSTEM_PROMPT>, byte a byte>
              + "\n\n"
              + <docs/hub-camada-integracao.txt>
```

Fontes da verdade: `docs/prompt-mestre-bv-4.0.txt` (documento do Tabelião, íntegro, nunca editado pelo Hub)
e `docs/hub-camada-integracao.txt` (camada do Hub: transporte, mapeamento da ficha, modo one-shot, envelope
de saída, placeholders de lavratura, revalidação normativa e regras aditivas). O teste de API confere a
igualdade byte a byte entre `hub-prompts.js` e os dois arquivos.

Princípio mantido: **a escrevente informa FATOS e a VONTADE das partes; o Prompt-Mestre escolhe o
especialista, a rota, os módulos e a matriz.** Nenhum botão da tela se chama "modelo". Toda enumeração
admite `nao_informado` (UNKNOWN ≠ FALSE); nenhum chip com consequência jurídica nasce pré-marcado; texto
livre nunca vira chave nem autorização.

## 1. Atos cobertos e especialistas

| Código da ficha | Especialista do Prompt-Mestre | Matriz |
|---|---|---|
| `PROC` | `ACT.PROC.PUBLICA` | MATRIX 01 |
| `UE` | `ACT.UE.VIGENTE` | MATRIX 02 |
| `DISS_UE` | `ACT.UE.DISSOLUCAO.SEM_PARTILHA` | MATRIX 03 |
| `DIV` | `ACT.DIVORCIO.CONSENSUAL.SEM_PARTILHA` | MATRIX 04 |
| `EMANC` | `ACT.EMANCIPACAO.VOLUNTARIA` | MATRIX 05 |

Fora desses cinco, ou com partilha no mesmo ato: `FORA DO ESCOPO (OUT_OF_SCOPE)` — o Gerador não aproxima.

## 2. Contrato da ficha (o que a tela manda ao servidor)

Uma chave por linha, na ordem abaixo; valores ausentes viajam como `nao_informado`; texto livre é achatado
em uma linha (`umaLinha()`) ou recuado com dois espaços (OBSERVACOES), para nunca virar chave falsa.

```
=== ENTREVISTA DIRIGIDA — GERADOR DE MINUTA ===
ATO: PROC | UE | DISS_UE | DIV | EMANC
FORMA_DO_ATO: presencial | eletronico | hibrido | nao_informado
PARTICULARIDADES: <lista entre parte_estrangeira, interprete, assinatura_especial, gratuidade> | nenhuma
<chaves do ato>
OBSERVACOES: <texto livre; linhas seguintes recuadas com dois espaços>
```

O servidor acrescenta, por conta própria e antes da ficha: `=== HOJE ===` e `=== QUEM ESTÁ MINUTANDO ===`;
com anexos, a `=== LEITURA OCR DEDICADA ===`. Cabeçalhos reservados vindos do navegador são removidos.

### 2.1 PROC

```
FINALIDADE: imovel_administrar | imovel_vender | imovel_comprar | bancaria | financiamento |
            veiculo_regularizar | veiculo_vender | inventario | previdenciaria | ad_judicia |
            casamento | divorcio_ue | tributaria | empresarial | saude | outra
FINALIDADE_DESCRICAO: <o que o cliente quer, nas palavras da escrevente>
OUTORGANTES: <n>
OUTORGANTE_<i>: <nome> · PF|PJ · <estado civil> · regime: <…> · capaz | representado por <…>
QUALIFICACAO_OUTORGANTE_<i>: <uma linha: atributos transcritos dos documentos (transposição) e revisados> | nao_informado
OUTORGADOS: <n>
OUTORGADO_<i>: <nome> · <vínculo>
QUALIFICACAO_OUTORGADO_<i>: <idem> | nao_informado
ATUACAO: conjunta | separadamente | sucessivamente | por_atribuicoes: <quem faz o quê> | nao_informado
OBJETO: <…> | nao_informado
MODULOS_AUTORIZADOS: <IDs BV separados por vírgula: o módulo fixo da finalidade + os opcionais marcados>
PODERES_CPC_105: <só em ad_judicia; lista entre os dez do CPC 105; vazio = nenhum>
AUTOCONTRATO: sim | nao | nao_informado
PRECO: livre | fixado: R$ … | nao_se_aplica
PRAZO: indeterminado | ate dd/mm/aaaa | nao_informado
SUBSTABELECIMENTO: vedado | com_reserva | sem_reserva | com_ou_sem_reserva | nao_informado
IRREVOGABILIDADE: nao | sim: <causa> | nao_informado
```

**Finalidade → módulos da biblioteca do Prompt-Mestre.** O módulo *fixo* entra sozinho em
`MODULOS_AUTORIZADOS` (é o que a finalidade significa; aparece marcado e travado). Os *opcionais* são
caixas desmarcadas. Os *proibidos* da rota nem aparecem. Módulos transversais: `PROC.ADMIN` (representação administrativa geral — repartições, protocolos,
certidões) e `PROC.BASE.ACCOUNTABILITY` (prestação de contas) em toda finalidade que tenha módulos; `PROC.SPECIAL.IRREVOCABLE` e `PROC.SPECIAL.IN_REM_SUAM` só nas
finalidades de alienação; `PROC.CONFLICT.SELF_CONTRACT` é a chave AUTOCONTRATO; `PROC.BASE.TERM` é a chave PRAZO.

| FINALIDADE | Fixo | Opcionais | Não aparecem |
|---|---|---|---|
| imovel_administrar | PROC.REAL_ESTATE.ADMINISTER | PROC.ADMIN, PROC.REAL_ESTATE.LEASE, PROC.TAX.ADMIN, PROC.LEGAL.HIRE_LAWYER, PROC.LEGAL.JUDICIAL, PROC.BASE.ACCOUNTABILITY | PROC.REAL_ESTATE.SELL, PROC.DISPOSITION.DONATE, PROC.OBLIGATION.GUARANTEE |
| imovel_vender | PROC.REAL_ESTATE.SELL | PROC.ADMIN, PROC.REAL_ESTATE.NEGOTIATE_PRICE, PROC.REAL_ESTATE.RECEIVE_PRICE, PROC.REAL_ESTATE.QUIT, PROC.TAX.ADMIN, PROC.SPECIAL.IRREVOCABLE, PROC.SPECIAL.IN_REM_SUAM, PROC.BASE.ACCOUNTABILITY | PROC.DISPOSITION.DONATE |
| imovel_comprar | — (sem módulo na MATRIX 01 → DECISÃO DO TABELIÃO) | PROC.ADMIN, PROC.BANK.CREDIT, PROC.OBLIGATION.GUARANTEE, PROC.OBLIGATION.DEBT_CONFESSION, PROC.TAX.ADMIN, PROC.BASE.ACCOUNTABILITY | — |
| bancaria | PROC.BANK.INFORMATION, PROC.BANK.MOVEMENT | PROC.ADMIN, PROC.BANK.OPEN_ACCOUNT, PROC.BANK.CLOSE_ACCOUNT, PROC.BANK.INVESTMENT, PROC.BANK.CREDIT, PROC.BANK.RENEGOTIATE, PROC.OBLIGATION.DEBT_CONFESSION, PROC.OBLIGATION.GUARANTEE, PROC.BASE.ACCOUNTABILITY | — |
| financiamento | PROC.BANK.CREDIT, PROC.OBLIGATION.GUARANTEE | PROC.ADMIN, PROC.OBLIGATION.DEBT_CONFESSION, PROC.BANK.RENEGOTIATE, PROC.BANK.INFORMATION, PROC.BANK.MOVEMENT, PROC.TAX.ADMIN, PROC.BASE.ACCOUNTABILITY | — |
| veiculo_regularizar | PROC.VEHICLE.REGULARIZE | PROC.ADMIN, PROC.VEHICLE.QUIT, PROC.TAX.ADMIN, PROC.TAX.INSTALLMENT, PROC.LEGAL.JUDICIAL, PROC.BASE.ACCOUNTABILITY | PROC.VEHICLE.TRANSFER, PROC.VEHICLE.SELF_TRANSFER, PROC.VEHICLE.RECEIVE_PRICE |
| veiculo_vender | PROC.VEHICLE.TRANSFER | PROC.ADMIN, PROC.VEHICLE.RECEIVE_PRICE, PROC.VEHICLE.QUIT, PROC.VEHICLE.SELF_TRANSFER, PROC.SPECIAL.IRREVOCABLE, PROC.BASE.ACCOUNTABILITY | — |
| inventario | PROC.SUCCESSION.PREPARATORY | PROC.ADMIN, PROC.SUCCESSION.APPOINT_INVENTORY_ADMIN, PROC.SUCCESSION.ASSIGN_RIGHTS.ONEROUS, PROC.SUCCESSION.ASSIGN_RIGHTS.GRATUITOUS, PROC.SUCCESSION.RENUNCIATION, PROC.LEGAL.HIRE_LAWYER, PROC.LEGAL.JUDICIAL, PROC.TAX.ADMIN, PROC.BASE.ACCOUNTABILITY | — |
| previdenciaria | PROC.INSS.APPLICATION | PROC.ADMIN, PROC.INSS.RECEIVE_BENEFIT, PROC.LEGAL.HIRE_LAWYER, PROC.LEGAL.JUDICIAL, PROC.BASE.ACCOUNTABILITY | — |
| ad_judicia | PROC.LEGAL.JUDICIAL | PROC.ADMIN, PROC.LEGAL.HIRE_LAWYER, PROC.BASE.ACCOUNTABILITY | — |
| casamento | — (DECISÃO DO TABELIÃO) | — | — |
| divorcio_ue | — (DECISÃO DO TABELIÃO) | — | — |
| tributaria | PROC.TAX.ADMIN | PROC.ADMIN, PROC.TAX.INSTALLMENT, PROC.OBLIGATION.DEBT_CONFESSION, PROC.LEGAL.JUDICIAL, PROC.BASE.ACCOUNTABILITY | — |
| empresarial | PROC.CORPORATE.MANAGEMENT | PROC.ADMIN, PROC.CORPORATE.LABOR, PROC.BANK.INFORMATION, PROC.BANK.MOVEMENT, PROC.BANK.CREDIT, PROC.TAX.ADMIN, PROC.TAX.INSTALLMENT, PROC.LEGAL.JUDICIAL, PROC.BASE.ACCOUNTABILITY | — |
| saude | PROC.HEALTH.ADMIN | PROC.ADMIN, PROC.HEALTH.MEDICAL_CONSENT, PROC.INSS.APPLICATION, PROC.BASE.ACCOUNTABILITY | — |
| outra | — | toda a biblioteca, agrupada por família (PROC.ADMIN, PROC.BANK.*, PROC.OBLIGATION.*, PROC.VEHICLE.*, PROC.REAL_ESTATE.*, PROC.DISPOSITION.DONATE, PROC.WAIVER, PROC.SUCCESSION.*, PROC.TAX.*, PROC.CORPORATE.*, PROC.INSS.*, PROC.HEALTH.*, PROC.LEGAL.*, PROC.SPECIAL.*, PROC.BASE.ACCOUNTABILITY) | — |

Sub-bloco **Poderes especiais do CPC 105** (dez caixas → `PODERES_CPC_105`): aparece sempre que
`PROC.LEGAL.JUDICIAL` estiver incluído (fixo em ad_judicia; marcado como opcional nas demais); fora disso a
chave viaja como `nao_se_aplica`. `PROC.LEGAL.SETTLE`, `PROC.LEGAL.RECEIVE` e `PROC.LEGAL.QUIT` não são
oferecidos fora de "outra": são os mesmos poderes transigir/receber/dar_quitacao do CPC 105 e, sem
`PROC.LEGAL.JUDICIAL`, não têm cláusula na MATRIX 01. Sete módulos existem na biblioteca mas **não têm
cláusula pronta na MATRIX 01** — `PROC.SPECIAL.IRREVOCABLE`, `PROC.SPECIAL.IN_REM_SUAM`, `PROC.WAIVER`,
`PROC.HEALTH.MEDICAL_CONSENT`, `PROC.LEGAL.SETTLE`, `PROC.LEGAL.RECEIVE`, `PROC.LEGAL.QUIT` (os três últimos
fora de LEGAL.JUDICIAL): a tela os marca com a nota "sem cláusula na matriz — vai ao Tabelião" e o Gerador
devolve DECISÃO DO TABELIÃO (camada, item 8.3).

`PROC.VEHICLE.SELF_TRANSFER` só fica marcável com AUTOCONTRATO = sim. AUTOCONTRATO, PRECO e IRREVOGABILIDADE
aparecem só nas finalidades de alienação (imovel_vender, veiculo_vender, inventario, outra; PRECO também
em imovel_comprar). Quando o cliente pedir "poderes amplos / para tudo", a escrevente escolhe `outra` e
marca módulo a módulo — nada entra por praxe.

### 2.2 UE

```
CONVIVENTE_1 / CONVIVENTE_2: <nome> · <estado civil registral> · nascido(a) em … · CPF … · profissão: …
QUALIFICACAO_CONVIVENTE_1 / QUALIFICACAO_CONVIVENTE_2: <uma linha: atributos transcritos dos documentos> | nao_informado   (cada uma logo após a linha da pessoa)
INICIO_CONVIVENCIA: dd/mm/aaaa | nao_sabem_precisar | nao_informado
REGIME: legal_comunhao_parcial | pacto_anterior: <instrumento, data, serventia> | convencao: <regime> | nao_informado
MAIOR_70: sim (<quem>) | nao | nao_informado
AFASTA_SEPARACAO_OBRIGATORIA: sim | nao | nao_informado          (só com MAIOR_70 sim; senão nao_se_aplica)
FILHOS: nenhum | sim: <nomes (datas)> | nao_informado
NOME: ninguem_altera | convivente_1_acrescenta: <nome final> | convivente_2_acrescenta: <nome final> | ambos: convivente 1 → …; convivente 2 → …
TITULO_ANTERIOR: nenhum | escritura_anterior: <dados> | contrato_particular: <data> | decisao_judicial: <juízo, autos, data> | nao_informado
LIVRO_E: registrada | nao_registrada | nao_informado              (só com título anterior; senão nao_informado)
INTERESSE_LIVRO_E: sim | nao | nao_informado
ENDERECO_COMUM: <endereço> | nao_informado
ADVOGADO_FACULTATIVO: nao | sim: <nome · OAB> | nao_informado
```

### 2.3 DISS_UE

```
CONVIVENTE_1 / CONVIVENTE_2: <nome> · <estado civil registral>
QUALIFICACAO_CONVIVENTE_1 / QUALIFICACAO_CONVIVENTE_2: <uma linha> | nao_informado   (cada uma logo após a linha da pessoa)
TITULO_ANTERIOR: nenhum | escritura: <dados> | contrato_particular: <data> | decisao_judicial: <dados> | nao_informado
LIVRO_E: registrada | nao_registrada | nao_informado
DATA_TERMINO: dd/mm/aaaa | nao_sabem_precisar | nao_informado
REGIME: legal_comunhao_parcial | contrato: <regime, instrumento, data> | nao_informado
REGIME_ALTERADO: nao | sim: <novo regime, data, instrumento> | nao_informado
BENS_COMUNS: nao | sim | sim_parcialmente_identificados | nao_informado
PARTILHA: nenhuma_a_fazer | diferida | agora                       (agora ⇒ FORA DO ESCOPO)
FILHOS: nenhum | capazes | incapazes | nao_informado
DECISAO_JUDICIAL_FILHOS: cobre_guarda_convivencia_alimentos: <…> | parcial: <…> | nao_ha | nao_se_aplica
GRAVIDEZ: nao | sim | desconhece | nao_se_aplica
ALIMENTOS_ENTRE_CONVIVENTES: dispensa_reciproca | fixados: <…> | nao_informado
NOME: nunca_alterado | mantem_nome_atual: <quem> | retoma_nome_anterior: <quem> | nao_informado
ADVOGADO: comum: <nome · OAB> | separados: <adv. 1 · OAB; adv. 2 · OAB> | defensor_publico: <nome> | nao_informado
REPRESENTACAO: pessoal | por_procuracao: <data da outorga, serventia>
```

### 2.4 DIV

```
CONJUGE_1 / CONJUGE_2: <nome>
QUALIFICACAO_CONJUGE_1 / QUALIFICACAO_CONJUGE_2: <uma linha> | nao_informado   (cada uma logo após a linha da pessoa)
CASAMENTO: <data · serventia · matrícula> · certidão emitida em dd/mm/aaaa | nao_informado
REGIME: <regime> | nao_informado
PACTO_ANTENUPCIAL: nao | sim: <dados> | nao_informado
REGIME_ALTERADO: nao | sim: <juízo, autos, data> | nao_informado
SEPARACAO_ANTERIOR: nao | judicial: <dados> | extrajudicial: <dados> | de_fato: <desde> | nao_informado
BENS_COMUNS: nao | sim | sim_parcialmente_identificados | so_bens_particulares | nao_informado
PARTILHA: nenhuma_a_fazer | diferida | agora                       (agora ⇒ FORA DO ESCOPO)
FILHOS: nenhum | maiores_capazes | menores_ou_incapazes | nao_informado
DECISAO_JUDICIAL_FILHOS: cobre_guarda_convivencia_alimentos: <…> | parcial: <…> | nao_ha | nao_se_aplica
GRAVIDEZ: nao | sim | desconhece | nao_se_aplica
PENSAO_ENTRE_CONJUGES: dispensa_reciproca | fixada: <…> | nao_informado
NOME_SOLTEIRO_1: <nome antes do casamento> | igual_ao_atual | nao_informado
NOME_SOLTEIRO_2: idem
NOME: cada_um_mantem | retoma_nome_de_solteiro: <quem>
NOME_FINAL_1: <nome exato após o divórcio> | nao_se_aplica         (só quando o cônjuge 1 retoma)
NOME_FINAL_2: idem
ADVOGADO: comum: <…> | separados: <…> | defensor_publico: <…> | nao_informado
PROCESSO_JUDICIAL: nao | sim: <nº, juízo, providência adotada> | nao_informado
AVERBACAO: pelas_partes | eletronica_pela_serventia | nao_informado
REPRESENTACAO: pessoal | por_procuracao: <data da outorga, serventia>
```

### 2.5 EMANC

```
MENOR: <nome> · nascido em dd/mm/aaaa · domicílio: <município/UF>
QUALIFICACAO_MENOR: <uma linha> | nao_informado
CERTIDAO_NASCIMENTO: <serventia · matrícula · emitida em dd/mm/aaaa> | nao_informado
PAI: <nome> · <qualificação em uma linha> | nao_informado
MAE: <nome> · <qualificação em uma linha> | nao_informado
QUEM_OUTORGA: ambos_os_pais | um_dos_pais: <pai|mãe> | tutor
MOTIVO_UM_SO: outro_falecido | filiacao_unica | destituido_ou_suspenso_por_decisao: <dados> | outro_nao_localizado | outro_discorda | nao_informado
SITUACAO_DOS_PAIS: casados | divorciados | separados | ex_conviventes | nunca_conviveram | nao_informado
GUARDA: compartilhada | unilateral: <quem> | nao_informado
PARTICIPACAO_DO_MENOR: comparece_e_assina | comparece_sem_assinar | nao_comparece | nao_informado
REPRESENTACAO_DOS_PAIS: pessoal | por_procuracao: <dados> | nao_informado
EMANCIPACAO_ANTERIOR: nao | sim: <causa> | nao_informado
FINALIDADE: <opcional>
```

## 3. Roteamento

As regras de roteamento, os módulos, os invariantes, as lacunas B3/B2/B1/B0, os níveis de risco e as
matrizes são os do Prompt-Mestre. A camada de integração só (a) traduz cada chave da ficha para
CASE.FACT com os quatro estados lógicos, (b) fixa o modo one-shot (perguntas do QUESTION_ENGINE viram
pendências) e (c) acrescenta as regras auditadas na v1.27 que não conflitam com o Prompt-Mestre
(texto livre não é marcação; correção do ato marcado sem inventar chaves; matriz não acrescenta fato;
sinônimos de atribuição patrimonial; certidão antiga prova o passado; filhos desconhecidos bloqueiam
DIV/DISS; vocabulário por ato). Regra prévia mantida: `ATO` é hipótese — ato inequivocamente diverso
⇒ BLOQUEADA com pedido de nova entrevista.

## 4. Invariantes de execução

Os do Prompt-Mestre (cadeia SOURCE → FACT → CLAUSE → RELEASE; NO_SOURCE → NO_FACT; UNKNOWN ≠ FALSE;
WRONG_ACT → BLOCK; NO_AUTHORIZATION → NO_HIGH_RISK_EFFECT; NO_PARTITION_MODULE → NO_ASSET_ALLOCATION;
MODEL_ERROR → MUST_NOT_OVERRIDE_CURRENT_LAW; CLAUSE_NOT_IN_PLAN → MUST_NOT_APPEAR) e os erros fatais
F01–F10. A camada acrescenta um erro fatal de transporte: sintaxe de matriz (`{{`, `}}`, `[[`, `]]`)
sobrevivendo na saída.

## 5. Formato de saída (lido pela tela)

```
DECISÃO DO ROTEADOR
- Ato: …
- Especialista: ACT.…
- Rota: <código> — <nome>
- Módulos autorizados: … | nenhum
- Por quê: <fatos com a fonte entre parênteses>
- Descartadas: …
- Estado: PRONTA PARA MINUTA (READY_FOR_RELEASE)
        | PRELIMINAR COM PENDÊNCIAS (PRELIMINARY_WITH_PENDING_ITEMS) — n pendência(s)
        | BLOQUEADA (BLOCKED) — motivo
        | DECISÃO DO TABELIÃO (REQUIRES_NOTARY_DECISION) — questão
        | FORA DO ESCOPO (OUT_OF_SCOPE) — motivo

===MINUTA_COPIAVEL===            ← só PRONTA e PRELIMINAR
<minuta integral>
===FIM_MINUTA===

PENDÊNCIAS                       ← só PRELIMINAR
- <nível B> · <chave> · <o que falta> · <o que destrava>

QUALIFICAÇÃO DEVOLVIDA AO TABELIÃO   ← BLOQUEADA, DECISÃO DO TABELIÃO, FORA DO ESCOPO
- O que impede: …
- Fundamento: …
- O que destravaria: …

<demais seções do OUTPUT CONTRACT do Prompt-Mestre>

⚠ CONFERIR
- <um item por linha>

Minuta de rascunho gerada pelo Hub CN2O — sujeita à conferência e ao aperfeiçoamento do Tabelião.
```

Placeholders na minuta: `[FALTA: …]` = pendência (conta para o estado); `[LAVRATURA: …]` = campo que só
existe na lavratura (livro, folhas, data por extenso, emolumentos e selo, quem lavra e assina,
testemunhas, forma do ato) — não é pendência e não impede PRONTA.

Leitura pela tela (`processarMinuta`): estado pela linha `Estado:` (aceita também só o código inglês);
`PRELIMINAR` mostra a minuta com a faixa "Minuta preliminar — não apta à assinatura" e a seção
PENDÊNCIAS no quadro da decisão; `BLOQUEADA`, `DECISÃO DO TABELIÃO` e `FORA DO ESCOPO` escondem o
botão Copiar e mostram a QUALIFICAÇÃO DEVOLVIDA; seção devolvida sem linha de estado fecha (bloqueia),
nunca abre. Título guardado no link permanente recebe o sufixo do estado quando não for PRONTA.

## 6. Auditorias

v1.27 (14/09/2026): red-team em duas passagens (26 casos do QA; 12 brechas parciais e 5 contradições
corrigidas; 10 pendências residuais aplicadas) e auditoria da tela por Playwright (16 fichas, 37
verificações, 4 defeitos corrigidos). As regras que sobreviveram estão na camada de integração, item 7.

v1.28: red-team do prompt composto (Prompt-Mestre + camada) com os poison cases do QA do Prompt-Mestre
(PROC-P01..P04, UE-P01/02, DISS-P01..03, DIV-P01..03, EMANC-P01..03) e os cenários one-shot / cinco estados
/ placeholders de lavratura — executado assim que o texto íntegro do Tabelião entrar no repositório;
correções só na camada de integração. Auditoria do backend e da tela por agentes ao fim de cada etapa.

## 7. Matrizes

As cinco Minutas-Matrizes estão dentro do Prompt-Mestre e mandam na redação (nunca na regra jurídica).
A sintaxe `{{CAMPO}}`, `[[IF]]`, `[[CHOOSE_ONE]]`, `[[INTERNAL]]`, `[[BLOCK_IF]]` é resolvida antes da
saída; o aviso "matriz institucional não fornecida" da v1.27 deixa de existir.

## 8. Lacunas da MATRIX 01 — proposta para decisão do Tabelião (não ativa)

A biblioteca de módulos não cobre três finalidades frequentes no balcão. Até a aprovação expressa, o
Gerador devolve essas hipóteses como `DECISÃO DO TABELIÃO — MATRIX_EXTENSION_REVIEW`.

| Finalidade | Módulo proposto | Conteúdo mínimo | Limite legal |
|---|---|---|---|
| Comprar imóvel | `PROC.REAL_ESTATE.BUY` | comprar, pagar o preço, assinar a escritura e o registro; financiamento e garantia só com PROC.BANK.CREDIT + PROC.OBLIGATION.GUARANTEE | CC 661, §1º |
| Casamento por procuração | `PROC.MARRIAGE` | representar no casamento com nubente nomeado, regime declarado | instrumento público, poderes especiais, eficácia de 90 dias (CC 1.542, §3º) |
| Divórcio / extinção de UE por procuração | `PROC.DIVORCE_REPRESENTATION` | cláusulas essenciais do ato (bens, filhos, nome, alimentos) descritas no instrumento | pública, poderes especiais, 30 dias (Res. CNJ 35, art. 36; art. 46-A) |

## 9. Transposição de dados dos documentos para a ficha (v1.29)

Pedido do Tabelião (14/09/2026): o mesmo poder de leitura do Extrator (card 03), mas **dentro da página do
Gerador**, com um botão que extrai os dados das pessoas dos documentos anexados (RG, CNH, certidões de
nascimento/casamento/óbito, comprovantes) e os **transpõe diretamente para os campos** da entrevista —
convivente 1 e 2, cônjuges, outorgantes e outorgados, emancipando e pais — inclusive a referência à
certidão, para que o Gerador produza a minuta já completa.

### 9.1 Fluxo na tela

1. A zona **"Documentos das partes"** passa para logo depois do passo 1 (o ato), com o botão
   **"Extrair e transpor dados"**. É a mesma zona de anexos do Gerador: os documentos que alimentam a
   transposição seguem anexados e vão também na chamada de geração (o Gerador os recebe como SOURCE).
2. O botão chama `POST /hub/ia/transpor` com os anexos (sem ficha). O servidor roda o prompt
   `docs/prompt-transposicao.txt` (Gemini Pro, temperatura 0, OCR dedicado como segunda leitura), faz o
   parse do JSON e devolve `{ dados: { pessoas, casamento, alertas }, ms, custo_usd, modelo, ocr }`.
3. A tela **preenche os campos automaticamente**, na ordem das pessoas devolvidas, conforme o ato aberto,
   e abre o painel **"Dados transpostos"**: uma linha por pessoa ("NOME → destino"), com o destino
   alterável (convivente 1/2; cônjuge 1/2; outorgante 1–4 / outorgado 1–3; emancipando / pai / mãe),
   botão **Reaplicar**, botão **Desfazer** (restaura os valores anteriores à transposição), os alertas do
   modelo e a linha de custo/tempo. Campo já preenchido pela escrevente com valor diferente é substituído
   e listado como "substituído" no painel.
4. O que é transposto por pessoa: nome; CPF, profissão e data de nascimento (onde o ato tem o campo);
   estado civil (chip, só quando comprovado); e a **qualificação** (parágrafo do padrão da casa) no campo
   novo **"Qualificação (dos documentos)"** de cada pessoa — editável. No DIV, a certidão de casamento
   preenche data, serventia, matrícula, data de emissão, regime (chip) e nomes de solteiro. No EMANC, a
   certidão de nascimento preenche o emancipando, a **certidão** (serventia · matrícula · emitida em) e os
   nomes dos pais (filiação); RG/CNH dos pais anexados preenchem a qualificação de cada um.
5. A escrevente confere e corrige o que quiser; só depois clica em GERAR MINUTA.

### 9.2 Contrato do JSON (saída do prompt)

`pessoas[]` com nome, nacionalidade, estado_civil (só comprovado), regime_bens, profissao,
data_nascimento, naturalidade, filiacao, rg, cnh, cpf, endereco, certidao {tipo, serventia, matricula,
livro, folha, termo, data_ato, data_emissao, averbacoes}, documentos[], qualificacao; `casamento`
(objeto ou null) com conjuges[], data, serventia, matricula, regime, pacto, data_emissao_certidao,
nome_solteiro{}, averbacoes; `alertas[]`. Valor ausente = "" — nunca inventado. Divergências com os dois
valores nos alertas. O servidor rejeita resposta que não seja JSON (502 "o modelo não devolveu dados
estruturados — tente de novo").

### 9.3 Mapeamento pessoa → campos, por ato

| Ato | Destinos (ordem padrão) | Campos por pessoa | Extras |
|---|---|---|---|
| UE | convivente 1, convivente 2 | nome, CPF, profissão, nascimento, estado civil (chip), qualificação | — |
| DISS_UE | convivente 1, convivente 2 | nome, estado civil (chip), qualificação | — |
| DIV | cônjuge 1, cônjuge 2 | nome, qualificação | casamento: data, serventia, matrícula, emissão, regime (chip), nome de solteiro 1/2 |
| EMANC | emancipando, pai, mãe | nome, nascimento (menor), qualificação | certidão de nascimento do menor; pais pela filiação |
| PROC | outorgante 1…n, outorgado 1…m | nome, estado civil e regime (chips, PF), qualificação | — |

Mapa do estado civil: casado→casado; divorciado→divorciado; viuvo→viúvo; solteiro→solteiro;
uniao_estavel→união estável (PROC) / não informado (UE, DISS — a ficha não tem o chip); ""→não altera.

### 9.4 Chaves da ficha

`QUALIFICACAO_CONVIVENTE_1/2`, `QUALIFICACAO_CONJUGE_1/2`, `QUALIFICACAO_OUTORGANTE_i`,
`QUALIFICACAO_OUTORGADO_i`, `QUALIFICACAO_MENOR`, `CERTIDAO_NASCIMENTO`, `PAI`, `MAE` — sempre presentes
no ato correspondente, `nao_informado` quando vazias, uma linha (`umaLinha()`). Na camada de integração
(item 2.1) elas são SOURCE documental transcrita quando o documento está anexado, e declaração da
escrevente quando não está.
