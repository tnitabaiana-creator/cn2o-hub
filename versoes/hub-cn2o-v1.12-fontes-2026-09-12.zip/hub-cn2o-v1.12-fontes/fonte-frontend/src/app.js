/* ============================================================
   HUB CN2O — o hub do Time CN2O · versão definitiva
   Site no Netlify (este arquivo) ↔ servidor no Railway (login, mural, IA).
   Tudo que muda com o tempo fica no CONFIG.
============================================================ */
'use strict';

const CONFIG = {
  endpoint: '__ENDPOINT__',
  ferramentas: {
    protocolo:   { url: 'protocolo.html',   titulo: 'e-Protocolo' },
    calculadora: { url: '__CALCULADORA__', titulo: 'Calculadora de Emolumentos' }, // site próprio, sempre na versão atual
    agenda:      { // Google Agenda do Tabelião (tnitabaiana@gmail.com), embutida no hub
      url: 'https://calendar.google.com/calendar/embed?src=tnitabaiana%40gmail.com&ctz=America%2FMaceio&hl=pt_BR&mode=WEEK&showTitle=0&showPrint=0&showCalendars=0&showTz=0&wkst=1',
      abrir: 'https://calendar.google.com/calendar/u/0?cid=dG5pdGFiYWlhbmFAZ21haWwuY29t',
      titulo: 'Agenda do Tabelião'
    }
  },
  // Chaves de sessão compartilhadas com o protocolo.html (mesmo site, mesmo login):
  // gravadas na aba (sessionStorage, que o protocolo sempre leu) e lembradas no
  // navegador (localStorage) até a sessão expirar no servidor (12 h) ou "Sair".
  sessao: { token: 'cn2o_token', nome: 'cn2o_nome', cargo: 'cn2o_cargo', login: 'cn2o_login' },
  muralMinutos: 5
};

// Se o hub for aberto dentro de um quadro (ex.: dentro da própria ferramenta
// embutida), assume a janela inteira.
if (window.top !== window.self) {
  try { window.top.location.replace(window.location.href); } catch (e) {}
}

/* ============================================================
   UTILITÁRIOS
============================================================ */
const el = function (id) { return document.getElementById(id); };
function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
const store = {
  get: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
  set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} },
  del: function (k) { try { localStorage.removeItem(k); } catch (e) {} }
};
const aba = {
  get: function (k) { try { return sessionStorage.getItem(k); } catch (e) { return null; } },
  set: function (k, v) { try { sessionStorage.setItem(k, v); } catch (e) {} },
  del: function (k) { try { sessionStorage.removeItem(k); } catch (e) {} }
};
function clone(o) { return JSON.parse(JSON.stringify(o)); }
function primeiraMaiuscula(s) { s = String(s || ''); return s.charAt(0).toUpperCase() + s.slice(1); }

let toastTimer = null;
function toast(msg, erro) {
  const t = el('toast');
  t.textContent = msg;
  t.classList.toggle('erro', !!erro);
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function () { t.hidden = true; }, erro ? 4200 : 2600);
}
function copiarFallback(txt) {
  const ta = document.createElement('textarea');
  ta.value = txt; ta.setAttribute('readonly', '');
  ta.style.position = 'fixed'; ta.style.opacity = '0';
  document.body.appendChild(ta); ta.select();
  try { document.execCommand('copy'); } catch (e) {}
  ta.remove();
}
function copiar(txt) {
  return new Promise(function (res) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(txt).then(res, function () { copiarFallback(txt); res(); });
    } else { copiarFallback(txt); res(); }
  });
}

/* Datas */
const MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
const DIAS_SEMANA = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];
function dd(n) { return (n < 10 ? '0' : '') + n; }
function hojeBR() { const d = new Date(); return dd(d.getDate()) + '/' + dd(d.getMonth() + 1) + '/' + d.getFullYear(); }
function agoraCurto() {
  const ag = new Date();
  return dd(ag.getDate()) + '/' + dd(ag.getMonth() + 1) + '/' + ag.getFullYear() + ', ' + dd(ag.getHours()) + 'h' + dd(ag.getMinutes());
}
function quandoCurto(iso) {
  const d = new Date(iso);
  if (isNaN(d)) return '';
  return dd(d.getDate()) + '/' + dd(d.getMonth() + 1) + ' às ' + dd(d.getHours()) + 'h' + dd(d.getMinutes());
}
function preencherData() {
  const ag = new Date();
  el('seloDia').textContent = dd(ag.getDate());
  el('seloMes').textContent = MESES[ag.getMonth()].slice(0, 3).toUpperCase() + ' ' + ag.getFullYear();
  el('seloSemana').textContent = DIAS_SEMANA[ag.getDay()];
}
function saudacaoHora() {
  const h = new Date().getHours();
  return h < 12 ? 'Bom dia' : (h < 18 ? 'Boa tarde' : 'Boa noite');
}

/* ============================================================
   SERVIDOR (Railway)
============================================================ */
const SESSAO = { token: null, nome: null, login: null, cargo: null, admin: false };

function api(caminho, opcoes) {
  opcoes = opcoes || {};
  const temCorpo = opcoes.corpo !== undefined;
  const headers = {};
  if (temCorpo) headers['Content-Type'] = 'application/json';
  if (SESSAO.token) headers['X-Auth-Token'] = SESSAO.token;
  return fetch(CONFIG.endpoint + caminho, {
    method: opcoes.metodo || (temCorpo ? 'POST' : 'GET'),
    headers: headers,
    body: temCorpo ? JSON.stringify(opcoes.corpo) : undefined,
    signal: opcoes.sinal,
    cache: 'no-store'
  }).then(function (r) {
    return r.text().then(function (bruto) {
      let dados = null;
      try { dados = bruto ? JSON.parse(bruto) : null; } catch (e) {}
      if (!r.ok) {
        const err = { status: r.status, erro: (dados && dados.erro) || ('erro ' + r.status), dados: dados || {} };
        if (r.status === 401 && !opcoes.semRedirecionar) sessaoExpirada();
        throw err;
      }
      semConexao(false);
      return dados;
    });
  }, function (e) {
    if (e && e.name === 'AbortError') throw { cancelado: true };
    semConexao(true);
    throw { status: 0, erro: 'sem conexão com o servidor — verifique a internet e tente de novo' };
  });
}
let retentativa = null;
function semConexao(liga) {
  el('semConexao').hidden = !liga;
  if (liga && !retentativa && SESSAO.token) {
    retentativa = setTimeout(function () { retentativa = null; carregarMural(true); }, 30000);
  }
}

/* ============================================================
   LOGIN INDIVIDUAL (o mesmo do Protocolo)
============================================================ */
let PRIMEIRO_LOGIN = null;
function msg(id, texto, ok) {
  const p = el(id);
  p.textContent = texto || '';
  p.classList.toggle('ok', !!ok);
  p.hidden = !texto;
}
function ocupado(botao, sim, rotulo) {
  botao.disabled = sim;
  if (rotulo) botao.textContent = rotulo;
}
function mostrarLogin(mensagem) {
  el('app').hidden = true;
  el('telaLogin').hidden = false;
  el('formPrimeiro').hidden = true;
  el('formLogin').hidden = false;
  msg('msgLogin', mensagem || '');
  setTimeout(function () { (el('campoLogin').value ? el('campoSenha') : el('campoLogin')).focus(); }, 30);
}
function salvarSessao() {
  const k = CONFIG.sessao;
  [store, aba].forEach(function (lugar) {
    lugar.set(k.token, SESSAO.token);
    lugar.set(k.nome, SESSAO.nome || '');
    lugar.set(k.cargo, SESSAO.cargo || '');
    lugar.set(k.login, SESSAO.login || '');
  });
}
function limparSessao() {
  SESSAO.token = SESSAO.nome = SESSAO.login = SESSAO.cargo = null; SESSAO.admin = false;
  const k = CONFIG.sessao;
  [store, aba].forEach(function (lugar) { [k.token, k.nome, k.cargo, k.login].forEach(function (c) { lugar.del(c); }); });
}
function lerSessao(chave) { return store.get(chave) || aba.get(chave); }
function sessaoExpirada() {
  if (!SESSAO.token) return;
  limparSessao();
  fecharSubMural(true); fecharTelaClausulas();
  mostrarLogin('Sua sessão expirou — entre de novo.');
}

function entrar(ev) {
  ev.preventDefault();
  const login = el('campoLogin').value.trim().toLowerCase();
  const senha = el('campoSenha').value;
  if (!login) { msg('msgLogin', 'Digite o seu usuário (nome.sobrenome).'); el('campoLogin').focus(); return; }
  const b = el('btnEntrar');
  ocupado(b, true, 'Entrando…');
  msg('msgLogin', '');
  api('/login', { corpo: { login: login, senha: senha }, semRedirecionar: true }).then(function (r) {
    if (r && r.primeiro_acesso) { mostrarPrimeiroAcesso(login); return; }
    return iniciarSessao(r.token, r.nome, login, r.cargo);
  }).catch(function (e) {
    msg('msgLogin', e.status === 401 ? 'Usuário ou senha não conferem.' : primeiraMaiuscula(e.erro) + '.');
    el('campoSenha').select();
  }).then(function () { ocupado(b, false, 'Entrar no Hub'); });
}
function mostrarPrimeiroAcesso(login) {
  PRIMEIRO_LOGIN = login;
  el('nomePrimeiro').textContent = login;
  el('formLogin').hidden = true;
  el('formPrimeiro').hidden = false;
  msg('msgPrimeiro', '');
  el('senhaNova').value = ''; el('senhaConf').value = '';
  setTimeout(function () { el('senhaNova').focus(); }, 30);
}
function criarSenha(ev) {
  ev.preventDefault();
  const s1 = el('senhaNova').value, s2 = el('senhaConf').value;
  if (s1.length < 8) { msg('msgPrimeiro', 'A senha precisa ter pelo menos 8 caracteres.'); return; }
  if (s1 !== s2) { msg('msgPrimeiro', 'As duas senhas não são iguais.'); return; }
  const b = el('btnCriarSenha');
  ocupado(b, true, 'Criando…');
  api('/definir-senha', { corpo: { login: PRIMEIRO_LOGIN, senha: s1 }, semRedirecionar: true }).then(function (r) {
    return iniciarSessao(r.token, r.nome, PRIMEIRO_LOGIN, r.cargo);
  }).catch(function (e) {
    msg('msgPrimeiro', primeiraMaiuscula(e.erro) + '.');
  }).then(function () { ocupado(b, false, 'Criar senha e entrar'); });
}
function iniciarSessao(token, nome, login, cargo) {
  SESSAO.token = token; SESSAO.nome = nome || login; SESSAO.login = login; SESSAO.cargo = cargo || '';
  salvarSessao();
  return api('/hub/eu').then(function (eu) {
    SESSAO.nome = eu.nome || SESSAO.nome;
    SESSAO.login = eu.login || SESSAO.login;
    SESSAO.cargo = eu.cargo || SESSAO.cargo;
    SESSAO.admin = !!eu.admin;
    salvarSessao();
  }).catch(function (e) {
    if (e.status === 401) throw e;
    // /hub ainda não publicado ou servidor instável: entra mesmo assim.
  }).then(function () {
    el('campoSenha').value = '';
    mostrarApp();
  });
}
function restaurarSessao() {
  const token = lerSessao(CONFIG.sessao.token);
  if (!token) { mostrarLogin(); return; }
  SESSAO.token = token;
  SESSAO.nome = lerSessao(CONFIG.sessao.nome) || '';
  SESSAO.cargo = lerSessao(CONFIG.sessao.cargo) || '';
  SESSAO.login = lerSessao(CONFIG.sessao.login) || '';
  api('/hub/eu', { semRedirecionar: true }).then(function (eu) {
    SESSAO.nome = eu.nome || SESSAO.nome;
    SESSAO.login = eu.login || SESSAO.login;
    SESSAO.cargo = eu.cargo || SESSAO.cargo;
    SESSAO.admin = !!eu.admin;
    salvarSessao();
    mostrarApp();
  }).catch(function (e) {
    if (e.status === 401) { limparSessao(); mostrarLogin(); return; }
    mostrarApp(); // sem conexão: abre com o que dá (links, cláusulas, calculadora)
  });
}
function sair() {
  const token = SESSAO.token;
  if (token) {
    fetch(CONFIG.endpoint + '/logout', { method: 'POST', headers: { 'X-Auth-Token': token } }).catch(function () {});
  }
  limparSessao();
  MURAL = null;
  fecharSubMural(true);
  mostrarLogin();
}
function mostrarApp() {
  el('saudacao').innerHTML = 'Olá, <b>' + esc(primeiroNome(SESSAO.nome)) + '</b>!';
  fraseDoDia();
  el('avatarIni').textContent = (SESSAO.nome || '?').split(/\s+/).filter(Boolean).slice(0, 2).map(function (n) { return n.charAt(0).toUpperCase(); }).join('') || '?';
  el('btnEditarMural').hidden = !SESSAO.admin;
  el('telaLogin').hidden = true;
  el('app').hidden = false;
  abrirPorEndereco();
  carregarMural();
  verificarIA();
}
function primeiroNome(n) {
  n = String(n || '').trim();
  if (!n) return 'equipe';
  if (/^[a-z]+\.[a-z]+$/i.test(n)) n = n.split('.')[0];
  const p = n.split(/\s+/)[0];
  return p.charAt(0).toUpperCase() + p.slice(1);
}

/* ============================================================
   NAVEGAÇÃO (com botão Voltar do navegador e atalhos #protocolo etc.)
============================================================ */
const PAGINAS = ['paginaHub', 'paginaExtrator', 'paginaAnalisador', 'paginaMinutas', 'paginaEmbutida'];
const ROTAS = { extrator: 'paginaExtrator', analista: 'paginaAnalisador', minutas: 'paginaMinutas', protocolo: 'protocolo', calculadora: 'calculadora', agenda: 'agenda' };
function mostrarPagina(id, semHistorico, rota) {
  PAGINAS.forEach(function (p) { el(p).hidden = (p !== id); });
  el('wrapPrincipal').classList.toggle('largo', id === 'paginaEmbutida');
  window.scrollTo({ top: 0 });
  if (!semHistorico) {
    const hash = id === 'paginaHub' ? '' : '#' + (rota || '');
    try { history.pushState({ pagina: id, rota: rota || '' }, '', location.pathname + location.search + hash); } catch (e) {}
  }
}
function abrirRota(rota, semHistorico) {
  if (rota === 'protocolo' || rota === 'calculadora' || rota === 'agenda') { abrirEmbutida(rota, semHistorico); return; }
  if (ROTAS[rota]) { mostrarPagina(ROTAS[rota], semHistorico, rota); return; }
  mostrarPagina('paginaHub', semHistorico);
}
function abrirPorEndereco() {
  const rota = (location.hash || '').replace('#', '');
  abrirRota(rota, true);
}
window.addEventListener('popstate', function (ev) {
  if (el('app').hidden) return;
  const r = (ev.state && ev.state.rota) || (location.hash || '').replace('#', '');
  abrirRota(r, true);
});

/* Ferramentas embutidas (mesmo site → mesma sessão) */
const EMBUTIDAS = {};
function abrirEmbutida(chave, semHistorico) {
  const f = CONFIG.ferramentas[chave];
  if (!f || !f.url) { toast('Esta ferramenta ainda não foi configurada — avise o Tabelião.'); return; }
  el('embutidaTitulo').textContent = f.titulo;
  el('embutidaNovaAba').href = f.abrir || f.url;
  const moldura = el('molduraEmbutida');
  Object.keys(EMBUTIDAS).forEach(function (k) { EMBUTIDAS[k].hidden = true; });
  if (!EMBUTIDAS[chave]) {
    const ifr = document.createElement('iframe');
    ifr.title = f.titulo;
    ifr.setAttribute('allow', 'clipboard-read; clipboard-write');
    const aguarde = document.createElement('div');
    aguarde.className = 'carregando';
    aguarde.dataset.chave = chave;
    aguarde.textContent = 'Abrindo ' + f.titulo + '…';
    ifr.addEventListener('load', function () { aguarde.remove(); });
    moldura.appendChild(aguarde);
    moldura.appendChild(ifr);
    ifr.src = f.url;
    EMBUTIDAS[chave] = ifr;
  }
  // o véu "Abrindo…" de uma ferramenta não pode cobrir a outra
  moldura.querySelectorAll('.carregando').forEach(function (v) { v.hidden = (v.dataset.chave !== chave); });
  EMBUTIDAS[chave].hidden = false;
  mostrarPagina('paginaEmbutida', semHistorico, chave);
}
function aplicarLinks() {
  el('cardMinutas').addEventListener('click', function () { mostrarPagina('paginaMinutas', false, 'minutas'); });
  (function () {
    const c1 = el('minCiente1'), c2 = el('minCiente2'), btn = el('btnGerarMinuta'), nota = el('minNota');
    function rever() {
      const ok = c1.checked && c2.checked;
      btn.disabled = !ok;
      nota.textContent = ok
        ? 'Ciência registrada. O motor está em preparação pelo Tabelião — em breve, gera aqui mesmo.'
        : 'Marque as duas caixas de ciência para liberar o botão.';
    }
    c1.addEventListener('change', rever); c2.addEventListener('change', rever);
    btn.addEventListener('click', function () {
      toast('O motor do Gerador PROC / UE está em preparação pelo Tabelião — em breve aqui no Hub.');
    });
    rever();
  })();
}

/* ============================================================
   HTML SEGURO (avisos formatados) — lista de tags permitidas
============================================================ */
const TAGS_OK = { B: 'b', STRONG: 'b', I: 'i', EM: 'i', U: 'u', S: 's', STRIKE: 's', MARK: 'mark', BR: 'br', P: 'p', DIV: 'p',
  UL: 'ul', OL: 'ol', LI: 'li', A: 'a', SPAN: 'span', FONT: 'span', H1: 'p', H2: 'p', H3: 'p', H4: 'p', BLOCKQUOTE: 'blockquote', HR: 'hr' };
const TAGS_FORA = /^(SCRIPT|STYLE|IFRAME|FRAME|OBJECT|EMBED|TEMPLATE|SVG|MATH|NOSCRIPT|TITLE|HEAD|META|LINK|BASE|FORM|INPUT|BUTTON|TEXTAREA|SELECT|OPTION|IMG|VIDEO|AUDIO|CANVAS)$/;
const CLASSES_OK = ['t-vinho', 't-marinho', 't-grande', 't-pequeno', 'a-centro'];
function corParaClasse(c) {
  c = String(c || '').replace(/\s+/g, '').toLowerCase();
  if (c === '#631325' || c === 'rgb(99,19,37)') return 't-vinho';
  if (c === '#202a3a' || c === 'rgb(32,42,58)') return 't-marinho';
  return null;
}
function classesDoElemento(n) {
  const tag = n.tagName, st = n.getAttribute('style') || '', out = [];
  (n.getAttribute('class') || '').split(/\s+/).forEach(function (c) { if (CLASSES_OK.indexOf(c) !== -1) out.push(c); });
  const cor = /(?:^|;)\s*color\s*:\s*([^;]+)/i.exec(st);
  if (cor) { const k = corParaClasse(cor[1]); if (k) out.push(k); }
  if (tag === 'FONT' && n.getAttribute('color')) { const k = corParaClasse(n.getAttribute('color')); if (k) out.push(k); }
  const tam = /font-size\s*:\s*([^;]+)/i.exec(st);
  const tamFont = tag === 'FONT' ? parseInt(n.getAttribute('size'), 10) : NaN;
  let grande = /^H[1-3]$/.test(tag) || tamFont >= 4, pequeno = tamFont <= 2;
  if (tam) {
    const v = tam[1].trim().toLowerCase(), px = parseFloat(v);
    if (/^(large|x-large|xx-large|xxx-large)$/.test(v) || (/px$/.test(v) && px >= 19) || (/em$/.test(v) && px >= 1.2)) grande = true;
    if (/^(small|x-small|xx-small)$/.test(v) || (/px$/.test(v) && px <= 12)) pequeno = true;
  }
  if (grande) out.push('t-grande'); else if (pequeno) out.push('t-pequeno');
  if (/text-align\s*:\s*center/i.test(st) || (n.getAttribute('align') || '').toLowerCase() === 'center') out.push('a-centro');
  return out.filter(function (c, i) { return out.indexOf(c) === i; });
}
const BLOCOS = /^(P|DIV|UL|OL|LI|BLOCKQUOTE|H[1-6]|TABLE|HR|SECTION|ARTICLE|HEADER|FOOTER)$/;
// Negrito/itálico/sublinhado que vêm como estilo (Word, WhatsApp Web, execCommand) viram tags.
function estilosInline(n) {
  const st = (n.getAttribute('style') || '').toLowerCase(), out = [];
  const fw = /font-weight\s*:\s*([^;]+)/.exec(st);
  if (fw && /^(bold|bolder|[6-9]00)$/.test(fw[1].trim())) out.push('b');
  if (/font-style\s*:\s*italic/.test(st)) out.push('i');
  if (/text-decoration(?:-line)?\s*:[^;]*underline/.test(st)) out.push('u');
  if (/text-decoration(?:-line)?\s*:[^;]*line-through/.test(st)) out.push('s');
  return out;
}
function temFundo(n) {
  const f = /background(?:-color)?\s*:\s*([^;]+)/i.exec(n.getAttribute('style') || '');
  return !!(f && !/^(transparent|initial|inherit|none|rgba\(\s*0\s*,\s*0\s*,\s*0\s*,\s*0\s*\))$/i.test(f[1].trim()));
}
function limparHtml(html) {
  const doc = new DOMParser().parseFromString('<div>' + (html || '') + '</div>', 'text/html');
  const raiz = doc.body.firstElementChild || doc.body;
  const saida = document.createElement('div');
  (function copiarFilhos(origem, destino) {
    Array.prototype.forEach.call(origem.childNodes, function (n) {
      if (n.nodeType === 3) { destino.appendChild(document.createTextNode(n.nodeValue)); return; }
      if (n.nodeType !== 1) return;
      const tag = n.tagName.toUpperCase();
      if (TAGS_FORA.test(tag)) return;
      let alvo = TAGS_OK[tag];
      if (!alvo) { copiarFilhos(n, destino); return; }
      // <div>/<p> que embrulham listas ou parágrafos só desembrulham (p não pode conter ul)
      if ((tag === 'DIV' || tag === 'P') && Array.prototype.some.call(n.children, function (c) { return BLOCOS.test(c.tagName); })) {
        copiarFilhos(n, destino); return;
      }
      if (alvo === 'br' || alvo === 'hr') { destino.appendChild(document.createElement(alvo)); return; }
      if (alvo === 'a') {
        const href = (n.getAttribute('href') || '').trim();
        if (!/^(https?:\/\/|mailto:|tel:)/i.test(href)) { copiarFilhos(n, destino); return; }
        const a = document.createElement('a');
        a.setAttribute('href', href); a.setAttribute('target', '_blank'); a.setAttribute('rel', 'noopener noreferrer');
        destino.appendChild(a); copiarFilhos(n, a); return;
      }
      const classes = classesDoElemento(n);
      const inline = alvo === 'span';
      if (inline && temFundo(n)) alvo = 'mark';
      const cadeia = [];
      if (alvo !== 'span' || classes.length) {
        const e = document.createElement(alvo);
        if (classes.length) e.className = classes.join(' ');
        cadeia.push(e);
      }
      if (inline) estilosInline(n).forEach(function (t) { cadeia.push(document.createElement(t)); });
      if (!cadeia.length) { copiarFilhos(n, destino); return; }
      destino.appendChild(cadeia[0]);
      for (let i = 1; i < cadeia.length; i++) cadeia[i - 1].appendChild(cadeia[i]);
      copiarFilhos(n, cadeia[cadeia.length - 1]);
    });
  })(raiz, saida);
  return saida.innerHTML
    .replace(/(<br>\s*){3,}/g, '<br><br>')
    .replace(/^(\s|<br>|<p><\/p>|<p><br><\/p>)+|(\s|<br>|<p><\/p>|<p><br><\/p>)+$/g, '');
}
function textoParaHtml(t) { return esc(t).replace(/\n/g, '<br>'); }

/* ============================================================
   MURAL DO TIME CN2O (conteúdo vem do servidor)
============================================================ */
let MURAL = null;
let MURAL_META = { atualizado_em: null, atualizado_por: null };
let MURAL_LIDO_EM = 0;
function normalizarLocal(d) {
  d = d && typeof d === 'object' ? d : {};
  const avisos = (Array.isArray(d.avisos) ? d.avisos : []).map(function (a, i) {
    return {
      id: a.id || ('a' + i + '-' + (a.data || '')),
      titulo: a.titulo || 'Aviso',
      data: a.data || '',
      html: a.html != null ? a.html : textoParaHtml(a.texto || ''),
      fixado: !!a.fixado,
      estilo: a.estilo || 'padrao',
      imagem: typeof a.imagem === 'string' && a.imagem.indexOf('data:image/') === 0 ? a.imagem : ''
    };
  });
  const m = d.metas && !Array.isArray(d.metas) ? d.metas : { em_breve: true, itens: Array.isArray(d.metas) ? d.metas : [] };
  return {
    versao: 2,
    avisos: avisos,
    aniversariantes: Array.isArray(d.aniversariantes) ? d.aniversariantes : [],
    metas: { em_breve: m.em_breve !== false, itens: Array.isArray(m.itens) ? m.itens : [] }
  };
}
function avisosOrdenados() {
  const lista = (MURAL && MURAL.avisos) || [];
  return lista.filter(function (a) { return a.fixado; }).concat(lista.filter(function (a) { return !a.fixado; }));
}
function chaveLidos() { return 'cn2o_hub_lidos_' + (SESSAO.login || ''); }
function lidos() { try { return JSON.parse(store.get(chaveLidos()) || '[]'); } catch (e) { return []; } }
function marcarLido(id) {
  const l = lidos();
  if (l.indexOf(id) === -1) { l.push(id); store.set(chaveLidos(), JSON.stringify(l.slice(-300))); }
}
function aniverDoMes(mes) {
  return ((MURAL && MURAL.aniversariantes) || [])
    .filter(function (a) { return Number(a.mes) === mes; })
    .sort(function (a, b) { return Number(a.dia) - Number(b.dia); });
}
function fotoAniv(a) {
  if (a.foto && String(a.foto).indexOf('data:image/') === 0) return '<img class="aniv-foto" src="' + esc(a.foto) + '" alt="">';
  return '<span class="aniv-foto aniv-inicial" aria-hidden="true">' + esc((a.nome || '?').trim().charAt(0).toUpperCase()) + '</span>';
}
function linhaAniver(a) {
  const ag = new Date();
  const hoje = Number(a.mes) === ag.getMonth() + 1 && Number(a.dia) === ag.getDate();
  return '<li' + (hoje ? ' class="hoje"' : '') + '>' + fotoAniv(a) + '<span class="mural-dia">dia ' + dd(Number(a.dia)) + '</span><span>' + esc(a.nome) + '</span></li>';
}
const ICONE_DOC = '<svg viewBox="0 0 24 24"><path d="M7 3h7l4 4v14H7z"/><path d="M14 3v4h4"/></svg>';
const ICONE_PIN = '<svg viewBox="0 0 24 24"><path d="M9 3h6l-1 6 4 3v2H6v-2l4-3z"/><path d="M12 14v7"/></svg>';
const ICONE_FESTA = '<svg viewBox="0 0 24 24"><path d="M4 20 9 7l8 8z"/><path d="M14 4v2M19 9h2M17 5l1.5-1.5"/></svg>';
function linhaAviso(av) {
  const lido = lidos().indexOf(av.id) !== -1;
  const cls = ['aviso-row'];
  if (!lido) cls.push('novo');
  if (av.fixado) cls.push('fixado');
  if (av.estilo === 'importante') cls.push('importante');
  if (av.estilo === 'celebracao') cls.push('celebracao');
  const icone = av.imagem ? '<img src="' + esc(av.imagem) + '" alt="">'
    : (av.fixado ? ICONE_PIN : (av.estilo === 'celebracao' ? ICONE_FESTA : ICONE_DOC));
  return '<button class="' + cls.join(' ') + '" data-aviso="' + esc(av.id) + '" type="button">' +
    '<span class="aviso-doc">' + icone + '</span>' +
    '<span class="aviso-info"><span class="aviso-titulo">' + esc(av.titulo) + '</span><span class="aviso-data">' + esc(av.data) + (av.fixado ? ' · fixado' : '') + '</span></span>' +
    '<span class="aviso-seta">›</span></button>';
}
function ligarLinhasAviso(raiz) {
  raiz.querySelectorAll('[data-aviso]').forEach(function (b) {
    b.addEventListener('click', function () { abrirSub('aviso', b.dataset.aviso); });
  });
}
function renderMural() {
  if (!MURAL) return;
  const mesAtual = new Date().getMonth() + 1;
  const aniver = aniverDoMes(mesAtual);
  el('muralAniversariantes').innerHTML = aniver.length
    ? aniver.map(linhaAniver).join('')
    : '<li class="mural-vazio">Sem aniversariantes cadastrados para ' + MESES[mesAtual - 1] + '.</li>';

  const avisos = avisosOrdenados();
  const caixa = el('muralAvisos');
  caixa.innerHTML = avisos.length
    ? avisos.slice(0, 3).map(linhaAviso).join('')
    : '<p class="mural-vazio">Sem avisos no momento.</p>';
  ligarLinhasAviso(caixa);
  const lista = lidos();
  const novos = avisos.filter(function (a) { return lista.indexOf(a.id) === -1; }).length;
  const pill = el('pillAvisos');
  pill.textContent = novos ? '● ' + novos + (novos > 1 ? ' novos' : ' novo') : '● Em destaque';
  pill.classList.toggle('tem-novos', !!novos);

  const metas = MURAL.metas || { em_breve: true, itens: [] };
  const caixaMetas = el('muralMetas');
  if (metas.em_breve || !metas.itens.length) {
    caixaMetas.innerHTML = '<div class="carimbo-breve" aria-label="Em breve"><span>Em breve</span></div>';
  } else {
    caixaMetas.innerHTML = '<div class="metas-lista">' + metas.itens.slice(0, 3).map(htmlMeta).join('') + '</div>';
  }
  el('muralAtualizado').textContent = MURAL_META.atualizado_em ? 'Atualizado em ' + quandoCurto(MURAL_META.atualizado_em) : '';
}
function htmlMeta(m) {
  const p = Math.max(0, Math.min(100, Number(m.progresso) || 0));
  return '<div class="meta-item"><div class="meta-topo"><b>' + esc(m.titulo) + '</b><span>' + p + '%</span></div>' +
    '<div class="meta-barra"><i style="width:' + p + '%"></i></div>' +
    (m.premio ? '<span class="meta-premio">🏆 ' + esc(m.premio) + '</span>' : '') + '</div>';
}
/* ============================================================
   FRASE DO DIA — planilha do Drive (edite lá) + roleta por colaborador/dia
   Coluna "fixar" com HOJE ou dd/mm/aaaa faz todos verem a mesma frase.
============================================================ */
var FRASES_PLANILHA_ID = '1C5LITosUYQyagLP3vwXqklIuZgPOy8WP2T8OJ68FlBM';
var FRASES_CSV_URL = 'https://docs.google.com/spreadsheets/d/' + FRASES_PLANILHA_ID + '/gviz/tq?tqx=out:csv&headers=1';
var FRASES_EDITAR_URL = 'https://docs.google.com/spreadsheets/d/' + FRASES_PLANILHA_ID + '/edit';
var FRASES_DIA = [
  ['Não é porque as coisas são difíceis que não ousamos; é porque não ousamos que elas são difíceis.', 'Sêneca'],
  ['Nenhum vento sopra a favor de quem não sabe para onde ir.', 'Sêneca'],
  ['A felicidade da sua vida depende da qualidade dos seus pensamentos.', 'Marco Aurélio'],
  ['Não são as coisas que nos perturbam, mas a leitura que fazemos delas.', 'Epicteto'],
  ['A sabedoria começa na admiração.', 'Sócrates'],
  ['Somos o que fazemos repetidamente. A excelência, então, não é um ato, mas um hábito.', 'Aristóteles, por W. Durant'],
  ['O rio atinge seus objetivos porque aprendeu a contornar obstáculos.', 'Lao Tsé'],
  ['Quem conhece os outros é sábio; quem conhece a si mesmo é iluminado.', 'Lao Tsé'],
  ['Uma longa caminhada começa com o primeiro passo.', 'Lao Tsé'],
  ['Não importa o quão devagar você vá, desde que você não pare.', 'Confúcio'],
  ['Escolhe um trabalho de que gostes, e não terás de trabalhar nem um dia na tua vida.', 'atribuído a Confúcio'],
  ['Põe quanto és no mínimo que fazes.', 'Fernando Pessoa'],
  ['O correr da vida embrulha tudo. A vida é assim: esquenta e esfria, aperta e daí afrouxa, sossega e depois desinquieta. O que ela quer da gente é coragem.', 'Guimarães Rosa'],
  ['Feliz aquele que transfere o que sabe e aprende o que ensina.', 'Cora Coralina'],
  ['O saber a gente aprende com os mestres e os livros. A sabedoria se aprende é com a vida e com os humildes.', 'Cora Coralina'],
  ['A paciência é amarga, mas o seu fruto é doce.', 'Rousseau'],
  ['Só se vê bem com o coração; o essencial é invisível aos olhos.', 'Antoine de Saint-Exupéry'],
  ['Cada pessoa que passa em nossa vida leva um pouco de nós e deixa um pouco de si.', 'atribuído a Saint-Exupéry'],
  ['A gentileza é a linguagem que o surdo ouve e o cego vê.', 'Mark Twain'],
  ['Entre o estímulo e a resposta há um espaço. Nesse espaço mora a nossa liberdade de escolher — e, na escolha, o nosso crescimento.', 'atribuído a Viktor Frankl'],
  ['Quem tem um porquê enfrenta quase qualquer como.', 'inspirado em Nietzsche'],
  ['Se quer ir rápido, vá sozinho; se quer ir longe, vá acompanhado.', 'provérbio africano'],
  ['Sonho que se sonha só é só um sonho que se sonha só; mas sonho que se sonha junto é realidade.', 'Raul Seixas'],
  ['A vida não é esperar a tempestade passar: é aprender a dançar na chuva.', 'atribuído a Vivian Greene'],
  ['Bom mesmo é ir à luta com determinação, abraçar a vida com paixão, perder com classe e vencer com ousadia.', 'atribuído a Charlie Chaplin'],
  ['O sucesso é a soma de pequenos esforços repetidos dia após dia.', 'Robert Collier'],
  ['Não há atalho para lugar que valha a pena.', 'Beverly Sills'],
  ['A verdadeira força de uma equipe está em cada pessoa; a verdadeira força de cada pessoa está na equipe.', 'Phil Jackson'],
  ['O entusiasmo é a maior força da alma.', 'atribuído a Napoleon Hill'],
  ['Há um tempo em que é preciso abandonar as roupas usadas, que já têm a forma do nosso corpo, e esquecer os nossos caminhos, que nos levam sempre aos mesmos lugares.', 'Fernando Teixeira de Andrade'],
  ['Ninguém caminha sem aprender a caminhar: fazendo o caminho, refazendo e retocando o sonho pelo qual se pôs a caminhar.', 'Paulo Freire'],
  ['Mesmo a noite mais escura terminará com o nascer do sol.', 'Victor Hugo'],
  ['As pequenas oportunidades são o começo dos grandes empreendimentos.', 'Demóstenes'],
  ['Aprender é a única coisa de que a mente nunca se cansa, nunca tem medo e nunca se arrepende.', 'Leonardo da Vinci'],
  ['A confiança se constrói nos detalhes: um ato bem feito de cada vez.', ''],
  ['Servir bem é a forma mais elegante de ser grande.', ''],
  ['O cuidado com o pequeno é o que dá segurança ao grande.', ''],
  ['Cada ato lavrado carrega a história de alguém. Trate cada história como única — porque é.', ''],
  ['Um documento bem lavrado é uma promessa cumprida com quem confiou na gente.', ''],
  ['A cortesia abre portas que a competência mantém abertas.', ''],
  ['Não existe vento ruim para o barco que tem rumo e tripulação unida.', ''],
  ['Todo dia é uma nova chance de fazer melhor — e de fazer bem a alguém.', '']
];
function csvLinhas(t) {
  var linhas = [], linha = [], campo = '', dentro = false;
  for (var i = 0; i < t.length; i++) {
    var ch = t[i];
    if (dentro) {
      if (ch === '"') { if (t[i + 1] === '"') { campo += '"'; i++; } else dentro = false; }
      else campo += ch;
    } else if (ch === '"') dentro = true;
    else if (ch === ',') { linha.push(campo); campo = ''; }
    else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && t[i + 1] === '\n') i++;
      linha.push(campo); campo = '';
      linhas.push(linha); linha = [];
    } else campo += ch;
  }
  if (campo !== '' || linha.length) { linha.push(campo); linhas.push(linha); }
  return linhas;
}
function listaFrasesDe(csv) {
  return csvLinhas(csv).slice(1).map(function (l) {
    return [String(l[0] || '').trim(), String(l[1] || '').trim(), String(l[2] || '').trim()];
  }).filter(function (l) { return l[0].length > 3 && l[0].charAt(0) !== '#'; });
}
function fixadaParaHoje(v) {
  v = String(v || '').trim().toLowerCase();
  if (!v) return false;
  if (v === 'hoje') return true;
  var m = /^(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?$/.exec(v);
  if (!m) return false;
  var d = new Date();
  if (+m[1] !== d.getDate() || +m[2] !== d.getMonth() + 1) return false;
  if (m[3] && m[3].length === 4 && +m[3] !== d.getFullYear()) return false;
  return true;
}
function escolherFrase(lista) {
  for (var i = 0; i < lista.length; i++) { if (fixadaParaHoje(lista[i][2])) return lista[i]; }
  var d = new Date();
  var chave = String(SESSAO.login || 'cn2o') + '|' + d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
  var hash = 0;
  for (var j = 0; j < chave.length; j++) { hash = (hash * 31 + chave.charCodeAt(j)) >>> 0; }
  return lista[hash % lista.length];
}
function pintarFrase(f) {
  if (!f) return;
  el('fraseTexto').textContent = f[0];
  var autor = el('fraseAutor');
  autor.hidden = !f[1];
  autor.textContent = f[1] ? '— ' + f[1] : '';
}
function fraseDoDia() {
  if (!el('fraseDia')) return;
  var cache = null;
  try { cache = JSON.parse(store.get('cn2o_frases_v1') || 'null'); } catch (e) { cache = null; }
  var local = cache && cache.csv ? listaFrasesDe(cache.csv) : [];
  pintarFrase(escolherFrase(local.length ? local : FRASES_DIA));
  if (cache && cache.t && Date.now() - cache.t < 6 * 3600e3) return;
  var ctl = (typeof AbortController === 'function') ? new AbortController() : null;
  if (ctl) setTimeout(function () { try { ctl.abort(); } catch (e) {} }, 7000);
  fetch(FRASES_CSV_URL, ctl ? { signal: ctl.signal } : undefined)
    .then(function (r) { if (!r.ok) throw new Error('planilha indisponível'); return r.text(); })
    .then(function (csv) {
      var nova = listaFrasesDe(csv);
      if (!nova.length) return;
      try { store.set('cn2o_frases_v1', JSON.stringify({ t: Date.now(), csv: csv })); } catch (e) {}
      pintarFrase(escolherFrase(nova));
    })
    .catch(function () {});
}
function carregarMural(silencioso) {
  if (!SESSAO.token) return Promise.resolve();
  return api('/hub/mural').then(function (r) {
    MURAL = normalizarLocal(r && r.dados);
    MURAL_META = { atualizado_em: r && r.atualizado_em, atualizado_por: r && r.atualizado_por };
    MURAL_LIDO_EM = Date.now();
    renderMural();
  }).catch(function (e) {
    if (e.status === 401) return;
    if (!MURAL) {
      el('muralAvisos').innerHTML = '<p class="mural-vazio">' + (e.status === 404
        ? 'O mural está sendo implantado no servidor — volte daqui a pouco.'
        : 'Não consegui carregar o mural agora. Tentando de novo…') + '</p>';
    }
    if (!silencioso && e.status && e.status !== 404) toast('Não consegui atualizar o mural (' + e.erro + ').', true);
  });
}
setInterval(function () {
  if (!el('app').hidden && document.visibilityState === 'visible') carregarMural(true);
}, CONFIG.muralMinutos * 60000);
document.addEventListener('visibilitychange', function () {
  if (document.visibilityState === 'visible' && !el('app').hidden && Date.now() - MURAL_LIDO_EM > 60000) carregarMural(true);
});

/* Subpáginas flutuantes do mural */
function cabecalhoSub(eyebrow, titulo) {
  return '<p class="sub-eyebrow">' + eyebrow + '</p>' +
    '<div class="sub-cab"><h2>' + titulo + '</h2><button class="fechar-x" data-fechar-sub type="button" aria-label="Fechar">✕</button></div>';
}
function abrirSub(tipo, chave) {
  if (!MURAL && tipo !== 'editar') { toast('O mural ainda está carregando…'); return; }
  const box = el('subConteudo');
  el('subpagina').classList.toggle('larga', tipo === 'editar');
  let html = '';
  if (tipo === 'aviso') {
    const av = avisosOrdenados().filter(function (a) { return a.id === chave; })[0];
    if (!av) { abrirSub('avisos'); return; }
    marcarLido(av.id);
    const selo = av.estilo === 'importante' ? '<span class="sub-selo importante">⚠ Importante</span>'
      : (av.estilo === 'celebracao' ? '<span class="sub-selo celebracao">🎉 Celebração</span>' : '');
    html = cabecalhoSub('Mural · Avisos do Tabelião', esc(av.titulo)) +
      '<p class="sub-data">Publicado em ' + esc(av.data) + (av.fixado ? ' · 📌 fixado no topo' : '') + '</p>' + selo +
      (av.imagem ? '<img class="sub-imagem" src="' + esc(av.imagem) + '" alt="Imagem do aviso">' : '') +
      '<div class="sub-texto rico">' + limparHtml(av.html) + '</div>' +
      '<p class="sub-assina">— César Bravo, Tabelião</p>' +
      '<button class="sub-voltar" data-sub-voltar type="button">← Todos os avisos</button>';
  } else if (tipo === 'avisos') {
    const avisos = avisosOrdenados();
    html = cabecalhoSub('Mural · Avisos do Tabelião', 'Todos os avisos') +
      '<div class="sub-lista">' + (avisos.length ? avisos.map(linhaAviso).join('') : '<p class="mural-vazio">Sem avisos publicados ainda.</p>') + '</div>';
  } else if (tipo === 'aniversariantes') {
    const ag = new Date(), mesAtual = ag.getMonth() + 1, prox = mesAtual % 12 + 1;
    const este = aniverDoMes(mesAtual), seguinte = aniverDoMes(prox);
    html = cabecalhoSub('Mural · Aniversariantes', 'Aniversariantes de ' + MESES[mesAtual - 1]) +
      '<div class="sub-texto">' + (este.length
        ? '<ul class="mural-lista">' + este.map(linhaAniver).join('') + '</ul>'
        : 'Nenhum aniversariante cadastrado para este mês.') + '</div>' +
      (seguinte.length ? '<p class="sub-eyebrow" style="margin-top:18px">Em ' + MESES[prox - 1] + '</p><ul class="mural-lista">' + seguinte.map(linhaAniver).join('') + '</ul>' : '');
  } else if (tipo === 'metas') {
    const metas = MURAL.metas || { em_breve: true, itens: [] };
    if (metas.em_breve || !metas.itens.length) {
      html = cabecalhoSub('Mural · Metas CN2O', 'Em breve — e valendo prêmio') +
        '<div class="sub-texto">O quadro de metas está a caminho, do jeito que uma boa promessa merece: a cada mês, um desafio claro para a equipe — e, para quem bater, premiações e bônus de verdade.\n\nO Tabelião está calibrando os primeiros indicadores. Quando a primeira meta do mês entrar aqui, ela já entra valendo. Prepare-se.</div>';
    } else {
      html = cabecalhoSub('Mural · Metas CN2O', 'Metas do mês') +
        '<div class="metas-lista" style="margin-top:14px">' + metas.itens.map(function (m) {
          return htmlMeta(m) + (m.html ? '<div class="sub-texto rico" style="margin-top:4px;font-size:13.5px">' + limparHtml(m.html) + '</div>' : '');
        }).join('') + '</div>';
    }
  } else if (tipo === 'editar') {
    html = htmlEditorMural();
  }
  box.innerHTML = html;
  box.querySelectorAll('[data-fechar-sub]').forEach(function (b) { b.addEventListener('click', function () { fecharSubMural(); }); });
  box.querySelectorAll('[data-sub-voltar]').forEach(function (b) { b.addEventListener('click', function () { abrirSub('avisos'); }); });
  ligarLinhasAviso(box);
  if (tipo === 'editar') ligarEditorMural(box);
  el('veuMural').classList.add('aberto');
  const foco = box.querySelector('.fechar-x');
  if (foco) foco.focus({ preventScroll: true });
  if (tipo === 'aviso') renderMural();
}
function fecharSubMural(forcar) {
  if (!forcar && ED && ED.sujo && el('veuMural').classList.contains('aberto') && !ED.confirmarSaida) {
    ED.confirmarSaida = true;
    const st = el('edStatus');
    if (st) { st.textContent = 'Há alterações não publicadas — clique em ✕ de novo para descartar.'; st.classList.add('pendente'); }
    return;
  }
  el('veuMural').classList.remove('aberto');
  ED = null;
}

/* ============================================================
   EDITOR DE TEXTO RICO (negrito, destaque, cores, listas, emojis)
============================================================ */
const EMOJIS = ['📌', '📣', '⚠️', '✅', '❗', '⭐', '🎉', '🎂', '👏', '💪', '🙏', '📅', '⏰', '📄', '🏆', '🔔', '❤️', '😊'];
function criarEditorRico(inicial, placeholder) {
  const raiz = document.createElement('div');
  raiz.className = 'rico-editor';
  raiz.innerHTML =
    '<div class="rico-barra" role="toolbar" aria-label="Formatação do texto">' +
      '<button type="button" class="rb" data-cmd="bold" title="Negrito (Ctrl+B)"><b>N</b></button>' +
      '<button type="button" class="rb" data-cmd="italic" title="Itálico (Ctrl+I)"><i>I</i></button>' +
      '<button type="button" class="rb" data-cmd="underline" title="Sublinhado (Ctrl+U)"><u>S</u></button>' +
      '<span class="rb-sep"></span>' +
      '<button type="button" class="rb" data-acao="marca" title="Marca-texto (destacar)"><span class="amostra" style="background:rgba(99,19,37,.28)"></span>Destacar</button>' +
      '<button type="button" class="rb" data-acao="vinho" title="Texto em vinho"><span class="amostra" style="background:#631325"></span></button>' +
      '<button type="button" class="rb" data-acao="marinho" title="Texto em marinho"><span class="amostra" style="background:#202a3a"></span></button>' +
      '<button type="button" class="rb" data-acao="grande" title="Texto grande (chamada)">A<sup>+</sup></button>' +
      '<span class="rb-sep"></span>' +
      '<button type="button" class="rb" data-cmd="insertUnorderedList" title="Lista com marcadores">• Lista</button>' +
      '<button type="button" class="rb" data-cmd="insertOrderedList" title="Lista numerada">1. Lista</button>' +
      '<button type="button" class="rb" data-cmd="justifyCenter" title="Centralizar">≡</button>' +
      '<button type="button" class="rb" data-acao="link" title="Inserir link">🔗</button>' +
      '<button type="button" class="rb" data-acao="emoji" title="Emojis">😊</button>' +
      '<span class="rb-sep"></span>' +
      '<button type="button" class="rb" data-cmd="removeFormat" title="Limpar a formatação do trecho selecionado">Limpar</button>' +
    '</div>' +
    '<div class="rico-emojis">' + EMOJIS.map(function (e) { return '<button type="button" data-emoji="' + e + '">' + e + '</button>'; }).join('') + '</div>' +
    '<div class="rico-emojis" data-link-linha style="gap:6px;align-items:center"><input class="campo" data-link-url placeholder="cole o endereço (https://…)" style="flex:1;min-width:200px;padding:7px 10px;font-size:13px"><button type="button" class="btn-fantasma" data-link-ok style="padding:7px 12px">Inserir</button></div>' +
    '<div class="rico-area rico" contenteditable="true" spellcheck="true"></div>';
  const area = raiz.querySelector('.rico-area');
  area.setAttribute('data-placeholder', placeholder || 'Escreva o aviso… selecione um trecho e use a barra para negritar, destacar e colorir.');
  area.innerHTML = limparHtml(inicial || '');
  let selecaoSalva = null;
  function salvarSelecao() {
    const s = window.getSelection();
    if (s && s.rangeCount && area.contains(s.anchorNode)) selecaoSalva = s.getRangeAt(0).cloneRange();
  }
  function restaurarSelecao() {
    area.focus();
    if (selecaoSalva) { const s = window.getSelection(); s.removeAllRanges(); s.addRange(selecaoSalva); }
  }
  function exec(cmd, valor) {
    restaurarSelecao();
    // Tags simples (<b>, <font>) para tudo; só o marca-texto precisa de estilo.
    try { document.execCommand('styleWithCSS', false, cmd === 'hiliteColor'); } catch (e) {}
    document.execCommand(cmd, false, valor);
    if (cmd === 'removeFormat') tirarDestaques();
    salvarSelecao();
    atualizarEstado();
  }
  // "Limpar" também desfaz marca-texto e cores da casa no trecho selecionado.
  function tirarDestaques() {
    const s = window.getSelection();
    if (!s || !s.rangeCount) return;
    const r = s.getRangeAt(0);
    area.querySelectorAll('mark, span, font').forEach(function (e) {
      if (!r.intersectsNode(e)) return;
      const pai = e.parentNode;
      while (e.firstChild) pai.insertBefore(e.firstChild, e);
      pai.removeChild(e);
    });
  }
  function atualizarEstado() {
    raiz.querySelectorAll('[data-cmd]').forEach(function (b) {
      let on = false;
      try { on = ['bold', 'italic', 'underline', 'insertUnorderedList', 'insertOrderedList', 'justifyCenter'].indexOf(b.dataset.cmd) !== -1 && document.queryCommandState(b.dataset.cmd); } catch (e) {}
      b.classList.toggle('on', !!on && area.contains((window.getSelection() || {}).anchorNode));
    });
  }
  ['keyup', 'mouseup', 'input'].forEach(function (ev) { area.addEventListener(ev, function () { salvarSelecao(); atualizarEstado(); }); });
  raiz.querySelector('.rico-barra').addEventListener('mousedown', function (ev) { if (ev.target.closest('button')) ev.preventDefault(); });
  raiz.querySelectorAll('[data-cmd]').forEach(function (b) {
    b.addEventListener('click', function () { exec(b.dataset.cmd); });
  });
  const linhaEmoji = raiz.querySelectorAll('.rico-emojis')[0];
  const linhaLink = raiz.querySelector('[data-link-linha]');
  raiz.querySelectorAll('[data-acao]').forEach(function (b) {
    b.addEventListener('click', function () {
      const a = b.dataset.acao;
      if (a === 'marca') exec('hiliteColor', 'rgba(99, 19, 37, 0.14)');
      else if (a === 'vinho') exec('foreColor', '#631325');
      else if (a === 'marinho') exec('foreColor', '#202a3a');
      else if (a === 'grande') exec('fontSize', '5');
      else if (a === 'emoji') { linhaEmoji.classList.toggle('aberto'); linhaLink.classList.remove('aberto'); }
      else if (a === 'link') {
        linhaLink.classList.toggle('aberto'); linhaEmoji.classList.remove('aberto');
        if (linhaLink.classList.contains('aberto')) setTimeout(function () { linhaLink.querySelector('input').focus(); }, 20);
      }
    });
  });
  linhaEmoji.addEventListener('mousedown', function (ev) { ev.preventDefault(); });
  linhaEmoji.querySelectorAll('[data-emoji]').forEach(function (b) {
    b.addEventListener('click', function () { exec('insertText', b.dataset.emoji); });
  });
  function inserirLink() {
    let url = linhaLink.querySelector('input').value.trim();
    if (!url) return;
    if (!/^(https?:\/\/|mailto:|tel:)/i.test(url)) url = 'https://' + url;
    restaurarSelecao();
    const s = window.getSelection();
    if (!s || s.isCollapsed) exec('insertHTML', '<a href="' + esc(url) + '">' + esc(url) + '</a>&nbsp;');
    else exec('createLink', url);
    linhaLink.querySelector('input').value = '';
    linhaLink.classList.remove('aberto');
  }
  linhaLink.querySelector('[data-link-ok]').addEventListener('click', inserirLink);
  linhaLink.querySelector('input').addEventListener('keydown', function (ev) { if (ev.key === 'Enter') { ev.preventDefault(); inserirLink(); } });
  // Colar do Word/WhatsApp Web: entra só a formatação permitida.
  area.addEventListener('paste', function (ev) {
    const cd = ev.clipboardData;
    if (!cd) return;
    const html = cd.getData('text/html'), texto = cd.getData('text/plain');
    if (!html && !texto) return;
    ev.preventDefault();
    const limpo = html ? limparHtml(html) : textoParaHtml(texto);
    document.execCommand('insertHTML', false, limpo);
  });
  return {
    elemento: raiz,
    obterHtml: function () {
      const h = limparHtml(area.innerHTML);
      const soTexto = area.textContent.replace(/\s+/g, '');
      return soTexto ? h : '';
    },
    focar: function () { area.focus(); }
  };
}

/* ============================================================
   MODO DO TABELIÃO — editar e publicar o mural
============================================================ */
let ED = null; // { copia, base, sujo, aba, editando, editor, confirmarSaida }
function abrirEditorMural() {
  if (!SESSAO.admin) return;
  const partida = MURAL || normalizarLocal({});
  ED = { copia: clone(partida), base: MURAL_META.atualizado_em || null, sujo: false, aba: 'avisos', editando: null, editor: null, confirmarSaida: false };
  abrirSub('editar');
}
function htmlEditorMural() {
  return cabecalhoSub('Mural · Modo do Tabelião', 'Editar o mural') +
    '<p class="sub-data">Monte os avisos com a formatação que quiser e publique — a mudança aparece para toda a equipe na hora.</p>' +
    '<p class="sub-data">Frases do Dia: <a href="' + FRASES_EDITAR_URL + '" target="_blank" rel="noopener">editar a planilha no Drive</a> · escreva HOJE na coluna \u201cfixar\u201d para todos verem a mesma frase.</p>' +
    '<div class="ed-abas">' +
      ['avisos:Avisos', 'aniversariantes:Aniversariantes', 'metas:Metas', 'equipe:Equipe', 'historico:Histórico', 'consumo:Consumo de IA'].map(function (x) {
        const p = x.split(':');
        return '<button type="button" class="ed-aba" data-aba="' + p[0] + '">' + p[1] + '</button>';
      }).join('') +
    '</div>' +
    '<div class="ed-painel" id="edPainel"></div>' +
    '<div class="ed-rodape"><span class="nota" id="edStatus">Nenhuma alteração ainda.</span><button class="btn-vinho" id="edPublicar" type="button">Publicar mural</button></div>';
}
function marcarSujo(texto) {
  ED.sujo = true; ED.confirmarSaida = false;
  const st = el('edStatus');
  if (st) { st.textContent = texto || 'Alterações ainda não publicadas.'; st.classList.add('pendente'); }
}
function ligarEditorMural(box) {
  box.querySelectorAll('[data-aba]').forEach(function (b) {
    b.addEventListener('click', function () {
      if (ED.editando && ED.aba === 'avisos' && b.dataset.aba !== 'avisos') { toast('Salve ou cancele o aviso em edição primeiro.'); return; }
      ED.aba = b.dataset.aba; pintarAba();
    });
  });
  box.querySelector('#edPublicar').addEventListener('click', publicarMural);
  pintarAba();
}
function pintarAba() {
  const painel = el('edPainel');
  if (!painel || !ED) return;
  document.querySelectorAll('.ed-aba').forEach(function (b) { b.classList.toggle('ativa', b.dataset.aba === ED.aba); });
  if (ED.aba === 'avisos') pintarAbaAvisos(painel);
  else if (ED.aba === 'aniversariantes') pintarAbaAniver(painel);
  else if (ED.aba === 'metas') pintarAbaMetas(painel);
  else if (ED.aba === 'equipe') pintarAbaEquipe(painel);
  else if (ED.aba === 'historico') pintarAbaHistorico(painel);
  else if (ED.aba === 'consumo') pintarAbaConsumo(painel);
}

function pintarAbaAvisos(painel) {
  const avisos = ED.copia.avisos;
  if (ED.editando) {
    const e = ED.editando;
    const av = e.indice != null ? avisos[e.indice] : { titulo: '', html: '', estilo: 'padrao', fixado: false };
    painel.innerHTML =
      '<div class="ed-form">' +
        '<input type="text" id="edAvTitulo" maxlength="120" placeholder="Título do aviso (aparece no mural)">' +
        '<div class="ed-chips" id="edAvEstilo">' +
          '<button type="button" class="ed-chip" data-estilo="padrao">Padrão</button>' +
          '<button type="button" class="ed-chip" data-estilo="importante">⚠ Importante</button>' +
          '<button type="button" class="ed-chip" data-estilo="celebracao">🎉 Celebração</button>' +
        '</div>' +
        '<label class="ed-check"><input type="checkbox" id="edAvFixado"> 📌 Fixar no topo do mural</label>' +
        '<div id="edAvEditor"></div>' +
        '<div class="ed-img-linha">' +
          '<label class="btn-fantasma ed-arquivo">📷 Imagem do aviso (opcional)<input type="file" id="edAvImg" accept="image/jpeg,image/png,image/webp" hidden></label>' +
          '<img id="edAvImgPrev" class="ed-img-prev" alt="" hidden>' +
          '<button type="button" class="btn-fantasma" id="edAvImgRm" hidden>✕ Remover imagem</button>' +
        '</div>' +
        '<div class="linha-botoes"><button type="button" class="btn-vinho" id="edAvSalvar">' + (e.indice != null ? 'Salvar alterações do aviso' : 'Adicionar ao mural') + '</button>' +
        '<button type="button" class="btn-fantasma" id="edAvCancelar">Cancelar</button></div>' +
      '</div>';
    el('edAvTitulo').value = av.titulo || '';
    el('edAvFixado').checked = !!av.fixado;
    let estilo = av.estilo || 'padrao';
    function pintarEstilo() { painel.querySelectorAll('[data-estilo]').forEach(function (b) { b.classList.toggle('ativo', b.dataset.estilo === estilo); }); }
    painel.querySelectorAll('[data-estilo]').forEach(function (b) { b.addEventListener('click', function () { estilo = b.dataset.estilo; pintarEstilo(); }); });
    pintarEstilo();
    ED.editor = criarEditorRico(av.html || '');
    el('edAvEditor').appendChild(ED.editor.elemento);
    let imagemAviso = av.imagem || '';
    function pintarImgAviso() {
      const pv = el('edAvImgPrev'), rm = el('edAvImgRm');
      pv.hidden = !imagemAviso; rm.hidden = !imagemAviso;
      if (imagemAviso) pv.src = imagemAviso;
    }
    pintarImgAviso();
    el('edAvImg').addEventListener('change', function () {
      const f = this.files && this.files[0]; this.value = '';
      if (!f) return;
      imagemMural(f, 1400, 0.82, 1200000).then(function (d) {
        imagemAviso = d; pintarImgAviso();
      }).catch(function (er) { toast('Não deu para usar essa imagem: ' + er.message, true); });
    });
    el('edAvImgRm').addEventListener('click', function () { imagemAviso = ''; pintarImgAviso(); });
    el('edAvCancelar').addEventListener('click', function () { ED.editando = null; ED.editor = null; pintarAba(); });
    el('edAvSalvar').addEventListener('click', function () {
      const titulo = el('edAvTitulo').value.trim();
      const html = ED.editor.obterHtml();
      if (!titulo) { toast('Dê um título ao aviso.'); el('edAvTitulo').focus(); return; }
      if (!html) { toast('Escreva o texto do aviso.'); ED.editor.focar(); return; }
      if (html.length > 30000) { toast('Aviso longo demais — divida em dois.', true); return; }
      if (e.indice != null) {
        const alvo = avisos[e.indice];
        alvo.titulo = titulo; alvo.html = html; alvo.estilo = estilo; alvo.fixado = el('edAvFixado').checked; alvo.imagem = imagemAviso;
      } else {
        avisos.unshift({ id: 'av' + Date.now().toString(36), titulo: titulo, data: hojeBR(), html: html, estilo: estilo, fixado: el('edAvFixado').checked, imagem: imagemAviso });
      }
      ED.editando = null; ED.editor = null;
      marcarSujo('Aviso pronto — clique em “Publicar mural” para a equipe ver.');
      pintarAba();
    });
    setTimeout(function () { (av.titulo ? ED.editor : { focar: function () { el('edAvTitulo').focus(); } }).focar(); }, 30);
    return;
  }
  painel.innerHTML =
    '<div class="linha-botoes" style="margin-bottom:10px"><button type="button" class="btn-vinho" id="edNovoAviso">+ Novo aviso</button></div>' +
    '<ul class="ed-lista">' + (avisos.length ? avisos.map(function (a, i) {
      return '<li class="ed-item' + (a.fixado ? ' fixado' : '') + '"><b>' + esc(a.titulo) + '</b><small>' + esc(a.data) + '</small>' +
        '<span class="ed-acoes">' +
          '<button type="button" class="ed-btn" data-sobe="' + i + '" title="Subir"' + (i === 0 ? ' disabled' : '') + '>↑</button>' +
          '<button type="button" class="ed-btn" data-desce="' + i + '" title="Descer"' + (i === avisos.length - 1 ? ' disabled' : '') + '>↓</button>' +
          '<button type="button" class="ed-btn' + (a.fixado ? ' on' : '') + '" data-fixa="' + i + '" title="Fixar no topo">📌</button>' +
          '<button type="button" class="ed-btn" data-edita="' + i + '" title="Editar">✎</button>' +
          '<button type="button" class="ed-btn" data-remove="' + i + '" title="Remover">✕</button>' +
        '</span></li>';
    }).join('') : '<li class="ed-vazio">Nenhum aviso — clique em “+ Novo aviso”.</li>') + '</ul>';
  el('edNovoAviso').addEventListener('click', function () { ED.editando = { indice: null }; pintarAba(); });
  function mover(i, d) { const j = i + d; if (j < 0 || j >= avisos.length) return; const t = avisos[i]; avisos[i] = avisos[j]; avisos[j] = t; marcarSujo(); pintarAba(); }
  painel.querySelectorAll('[data-sobe]').forEach(function (b) { b.addEventListener('click', function () { mover(+b.dataset.sobe, -1); }); });
  painel.querySelectorAll('[data-desce]').forEach(function (b) { b.addEventListener('click', function () { mover(+b.dataset.desce, 1); }); });
  painel.querySelectorAll('[data-fixa]').forEach(function (b) { b.addEventListener('click', function () { const a = avisos[+b.dataset.fixa]; a.fixado = !a.fixado; marcarSujo(); pintarAba(); }); });
  painel.querySelectorAll('[data-edita]').forEach(function (b) { b.addEventListener('click', function () { ED.editando = { indice: +b.dataset.edita }; pintarAba(); }); });
  painel.querySelectorAll('[data-remove]').forEach(function (b) {
    b.addEventListener('click', function () {
      if (b.dataset.confirma !== '1') { b.dataset.confirma = '1'; b.textContent = 'remover?'; b.classList.add('on'); setTimeout(function () { if (b.isConnected) { b.dataset.confirma = ''; b.textContent = '✕'; b.classList.remove('on'); } }, 3000); return; }
      avisos.splice(+b.dataset.remove, 1); marcarSujo(); pintarAba();
    });
  });
}

function pintarAbaAniver(painel) {
  const lista = ED.copia.aniversariantes;
  const meses = MESES.map(function (m, i) { return '<option value="' + (i + 1) + '">' + m + '</option>'; }).join('');
  const ord = lista.map(function (a, i) { return { a: a, i: i }; }).sort(function (x, y) { return (x.a.mes - y.a.mes) || (x.a.dia - y.a.dia); });
  painel.innerHTML =
    '<ul class="ed-lista">' + (ord.length ? ord.map(function (x) {
      return '<li class="ed-item ed-item-foto">' + fotoAniv(x.a) + '<b>' + esc(x.a.nome) + '</b><small>' + dd(Number(x.a.dia)) + ' de ' + MESES[Number(x.a.mes) - 1] + '</small>' +
        '<span class="ed-acoes">' +
          '<button type="button" class="ed-btn" data-foto="' + x.i + '" title="' + (x.a.foto ? 'Trocar a foto' : 'Adicionar foto') + '">📷</button>' +
          (x.a.foto ? '<button type="button" class="ed-btn" data-fotorm="' + x.i + '" title="Remover a foto">🚫</button>' : '') +
          '<button type="button" class="ed-btn" data-rm="' + x.i + '" title="Remover">✕</button></span></li>';
    }).join('') : '<li class="ed-vazio">Nenhum aniversariante cadastrado.</li>') + '</ul>' +
    '<input type="file" id="edAnFoto" accept="image/jpeg,image/png,image/webp" hidden>' +
    '<div class="ed-form ed-linha">' +
      '<input type="text" id="edAnNome" placeholder="Nome" maxlength="60">' +
      '<input type="number" id="edAnDia" min="1" max="31" placeholder="Dia">' +
      '<select id="edAnMes">' + meses + '</select>' +
      '<button class="btn-fantasma" id="edAnAdd" type="button">Adicionar</button>' +
    '</div>' +
    '<h3 class="ed-titulo versalete">Colar a lista de uma vez</h3>' +
    '<div class="ed-form"><textarea id="edAnLote" rows="3" placeholder="Um por linha, no formato  Nome - dd/mm   (ex.: Josilene - 12/03)"></textarea>' +
    '<button class="btn-fantasma" id="edAnLoteAdd" type="button">Adicionar todos</button></div>';
  el('edAnMes').value = String(new Date().getMonth() + 1);
  let fotoAlvo = null;
  el('edAnFoto').addEventListener('change', function () {
    const f = this.files && this.files[0]; this.value = '';
    if (!f || fotoAlvo == null || !lista[fotoAlvo]) return;
    const quem = fotoAlvo; fotoAlvo = null;
    imagemMural(f, 240, 0.85, 160000).then(function (d) {
      lista[quem].foto = d;
      marcarSujo('Foto de ' + lista[quem].nome + ' pronta — publique para valer.');
      pintarAba();
    }).catch(function (er) { toast('Não deu para usar essa foto: ' + er.message, true); });
  });
  painel.querySelectorAll('[data-foto]').forEach(function (b) { b.addEventListener('click', function () { fotoAlvo = +b.dataset.foto; el('edAnFoto').click(); }); });
  painel.querySelectorAll('[data-fotorm]').forEach(function (b) { b.addEventListener('click', function () { delete lista[+b.dataset.fotorm].foto; marcarSujo(); pintarAba(); }); });
  painel.querySelectorAll('[data-rm]').forEach(function (b) { b.addEventListener('click', function () { lista.splice(+b.dataset.rm, 1); marcarSujo(); pintarAba(); }); });
  el('edAnAdd').addEventListener('click', function () {
    const n = el('edAnNome').value.trim(), d = parseInt(el('edAnDia').value, 10), m = parseInt(el('edAnMes').value, 10);
    if (!n || !(d >= 1 && d <= 31)) { toast('Informe o nome e um dia entre 1 e 31.'); return; }
    lista.push({ nome: n, dia: d, mes: m }); marcarSujo(); pintarAba();
  });
  el('edAnLoteAdd').addEventListener('click', function () {
    let ok = 0, ruins = [];
    el('edAnLote').value.split(/\n+/).forEach(function (linha) {
      linha = linha.trim(); if (!linha) return;
      const r = /^(.+?)[\s\-–—:,;]+(\d{1,2})\s*\/\s*(\d{1,2})(?:\s*\/\s*\d{2,4})?\s*$/.exec(linha);
      if (!r) { ruins.push(linha); return; }
      const d = +r[2], m = +r[3];
      if (!(d >= 1 && d <= 31 && m >= 1 && m <= 12)) { ruins.push(linha); return; }
      lista.push({ nome: r[1].trim(), dia: d, mes: m }); ok++;
    });
    if (ok) marcarSujo(ok + ' aniversariante(s) adicionado(s) — publique para valer.');
    pintarAba();
    if (ruins.length) toast('Não entendi ' + ruins.length + ' linha(s): use  Nome - dd/mm', true);
  });
}

function pintarAbaMetas(painel) {
  const metas = ED.copia.metas;
  painel.innerHTML =
    '<label class="ed-check"><input type="checkbox" id="edMtBreve"> Mostrar o cartão como “EM BREVE” (esconde as metas abaixo)</label>' +
    '<ul class="ed-lista" style="margin-top:12px">' + (metas.itens.length ? metas.itens.map(function (m, i) {
      return '<li class="ed-item"><b>' + esc(m.titulo) + '</b><small>' + (Number(m.progresso) || 0) + '%' + (m.premio ? ' · 🏆 ' + esc(m.premio) : '') + '</small>' +
        '<span class="ed-acoes"><input type="number" min="0" max="100" value="' + (Number(m.progresso) || 0) + '" data-prog="' + i + '" style="width:64px;border:1.5px solid rgba(32,42,58,.22);border-radius:6px;padding:3px 6px" title="Progresso (%)">' +
        '<button type="button" class="ed-btn" data-rm="' + i + '" title="Remover">✕</button></span></li>';
    }).join('') : '<li class="ed-vazio">Nenhuma meta cadastrada.</li>') + '</ul>' +
    '<div class="ed-form">' +
      '<input type="text" id="edMtTitulo" maxlength="120" placeholder="Meta (ex.: 120 atos lavrados em outubro)">' +
      '<div class="ed-linha ed-form" style="margin-top:0"><input type="number" id="edMtProg" min="0" max="100" placeholder="% atingido"><input type="text" id="edMtPremio" maxlength="160" placeholder="Prêmio/bônus (opcional)"></div>' +
      '<textarea id="edMtDesc" rows="2" placeholder="Explicação curta (opcional)"></textarea>' +
      '<button class="btn-fantasma" id="edMtAdd" type="button">Adicionar meta</button>' +
    '</div>';
  el('edMtBreve').checked = metas.em_breve !== false;
  el('edMtBreve').addEventListener('change', function () { metas.em_breve = this.checked; marcarSujo(); });
  painel.querySelectorAll('[data-prog]').forEach(function (inp) {
    inp.addEventListener('change', function () { metas.itens[+inp.dataset.prog].progresso = Math.max(0, Math.min(100, parseInt(inp.value, 10) || 0)); marcarSujo(); });
  });
  painel.querySelectorAll('[data-rm]').forEach(function (b) { b.addEventListener('click', function () { metas.itens.splice(+b.dataset.rm, 1); marcarSujo(); pintarAba(); }); });
  el('edMtAdd').addEventListener('click', function () {
    const t = el('edMtTitulo').value.trim();
    if (!t) { toast('Escreva a meta.'); return; }
    metas.itens.push({ id: 'mt' + Date.now().toString(36), titulo: t, progresso: Math.max(0, Math.min(100, parseInt(el('edMtProg').value, 10) || 0)), premio: el('edMtPremio').value.trim(), html: textoParaHtml(el('edMtDesc').value.trim()) });
    marcarSujo('Meta adicionada — desmarque “EM BREVE” e publique para a equipe ver.');
    pintarAba();
  });
}

// Equipe: quem entra no Hub (inclusive quem não é escrevente) e senha esquecida.
function sugerirLogin(nome) {
  const p = String(nome || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter(Boolean);
  return p.length > 1 ? p[0] + '.' + p[p.length - 1] : (p[0] || '');
}
function pintarAbaEquipe(painel) {
  painel.innerHTML = '<p class="ed-vazio">Carregando a equipe…</p>';
  api('/hub/admin/equipe').then(function (lista) {
    if (!ED || ED.aba !== 'equipe') return;
    painel.innerHTML =
      '<p class="sub-data" style="margin-bottom:10px">Quem entra no Hub CN2O. O que você faz nesta aba vale na hora — não precisa publicar o mural.</p>' +
      '<ul class="ed-lista">' + (lista || []).map(function (u) {
        const situacao = u.tem_senha
          ? (u.ultimo_acesso ? 'último acesso ' + quandoCurto(u.ultimo_acesso) : 'senha criada')
          : 'aguardando o primeiro acesso';
        const podeZerar = u.tem_senha && u.login !== SESSAO.login;
        return '<li class="ed-item"><b>' + esc(u.nome) + '</b><small>' + esc(u.login) + ' · ' + esc(u.cargo) + ' · ' + situacao + '</small>' +
          '<span class="ed-acoes">' + (podeZerar ? '<button type="button" class="ed-btn" data-zera="' + esc(u.login) + '" title="Zerar a senha desta pessoa">Zerar senha</button>' : '') + '</span></li>';
      }).join('') + '</ul>' +
      '<h3 class="ed-titulo versalete">Cadastrar pessoa</h3>' +
      '<div class="ed-form ed-linha">' +
        '<input type="text" id="edEqNome" placeholder="Nome completo" maxlength="80">' +
        '<input type="text" id="edEqLogin" placeholder="nome.sobrenome" maxlength="60" autocapitalize="none" spellcheck="false">' +
        '<input type="text" id="edEqCargo" placeholder="Função" maxlength="60" list="edEqCargos">' +
        '<datalist id="edEqCargos"><option value="Escrevente"><option value="Substituta do Tabelião"><option value="Cadastro e Protocolo"><option value="Secretária"><option value="Auxiliar"><option value="Estagiário(a)"></datalist>' +
        '<button class="btn-fantasma" id="edEqAdd" type="button">Cadastrar</button>' +
      '</div>' +
      '<p class="sub-data">A pessoa entra com esse usuário e cria a própria senha no primeiro acesso. Cadastre — ou zere uma senha — só quando ela for entrar em seguida.</p>';
    const nomeEl = el('edEqNome'), loginEl = el('edEqLogin');
    let loginMexido = false;
    loginEl.addEventListener('input', function () { loginMexido = true; });
    nomeEl.addEventListener('input', function () { if (!loginMexido) loginEl.value = sugerirLogin(nomeEl.value); });
    el('edEqAdd').addEventListener('click', function () {
      const corpo = { nome: nomeEl.value.trim(), login: loginEl.value.trim().toLowerCase(), cargo: el('edEqCargo').value.trim() };
      if (!corpo.nome || !corpo.login) { toast('Preencha o nome e o usuário.'); return; }
      api('/hub/admin/equipe', { corpo: corpo }).then(function () {
        toast('✓ ' + corpo.nome + ' cadastrado(a) — usuário ' + corpo.login);
        pintarAba();
      }).catch(function (e) { toast(primeiraMaiuscula(e.erro) + '.', true); });
    });
    painel.querySelectorAll('[data-zera]').forEach(function (b) {
      b.addEventListener('click', function () {
        if (b.dataset.confirma !== '1') {
          b.dataset.confirma = '1'; b.textContent = 'Confirmar?'; b.classList.add('on');
          setTimeout(function () { if (b.isConnected) { b.dataset.confirma = ''; b.textContent = 'Zerar senha'; b.classList.remove('on'); } }, 3500);
          return;
        }
        api('/hub/admin/zerar-senha', { corpo: { login: b.dataset.zera } }).then(function () {
          toast('✓ Senha zerada — ' + b.dataset.zera + ' cria uma nova no próximo acesso');
          pintarAba();
        }).catch(function (e) { toast(primeiraMaiuscula(e.erro) + '.', true); });
      });
    });
  }).catch(function (e) { if (painel.isConnected) painel.innerHTML = '<p class="ed-vazio">Não consegui ler a equipe (' + esc(e.erro) + ').</p>'; });
}

function pintarAbaHistorico(painel) {
  painel.innerHTML = '<p class="ed-vazio">Carregando as últimas publicações…</p>';
  api('/hub/mural/historico').then(function (linhas) {
    if (!ED || ED.aba !== 'historico') return;
    if (!linhas || !linhas.length) { painel.innerHTML = '<p class="ed-vazio">Ainda não há publicações anteriores.</p>'; return; }
    painel.innerHTML = '<p class="sub-data" style="margin-bottom:10px">Toque em “Carregar” para trazer uma versão anterior para o editor; depois publique para restaurá-la.</p>' +
      '<ul class="ed-lista">' + linhas.map(function (l, i) {
        const n = ((l.dados && l.dados.avisos) || []).length;
        return '<li class="ed-item"><b>' + quandoCurto(l.em) + '</b><small>' + esc(l.por || '') + ' · ' + n + ' aviso(s)</small>' +
          '<span class="ed-acoes"><button type="button" class="ed-btn" data-carrega="' + i + '">Carregar</button></span></li>';
      }).join('') + '</ul>';
    painel.querySelectorAll('[data-carrega]').forEach(function (b) {
      b.addEventListener('click', function () {
        ED.copia = normalizarLocal(linhas[+b.dataset.carrega].dados);
        ED.aba = 'avisos';
        marcarSujo('Versão de ' + quandoCurto(linhas[+b.dataset.carrega].em) + ' carregada — publique para restaurá-la.');
        pintarAba();
      });
    });
  }).catch(function (e) { if (painel.isConnected) painel.innerHTML = '<p class="ed-vazio">Não consegui ler o histórico (' + esc(e.erro) + ').</p>'; });
}

function pintarAbaConsumo(painel) {
  painel.innerHTML = '<p class="ed-vazio">Carregando o consumo do mês…</p>';
  api('/hub/ia/uso').then(function (linhas) {
    if (!ED || ED.aba !== 'consumo') return;
    if (!linhas || !linhas.length) { painel.innerHTML = '<p class="ed-vazio">Nenhuma análise de IA neste mês ainda.</p>'; return; }
    const nomes = { qualificacao: 'Extrator', matricula: 'e-Analista' };
    let total = 0, usos = 0;
    const corpo = linhas.map(function (l) {
      total += Number(l.custo_usd) || 0; usos += Number(l.usos) || 0;
      return '<tr><td>' + esc(l.login) + '</td><td>' + esc(nomes[l.ferramenta] || l.ferramenta) + '</td><td class="num">' + l.usos + '</td><td class="num">US$ ' + (Number(l.custo_usd) || 0).toFixed(3).replace('.', ',') + '</td></tr>';
    }).join('');
    painel.innerHTML = '<table class="ed-tabela"><thead><tr><th>Quem</th><th>Ferramenta</th><th style="text-align:right">Usos</th><th style="text-align:right">Custo</th></tr></thead><tbody>' + corpo +
      '<tr><td><b>Total do mês</b></td><td></td><td class="num"><b>' + usos + '</b></td><td class="num"><b>US$ ' + total.toFixed(2).replace('.', ',') + '</b></td></tr></tbody></table>' +
      '<p class="sub-data" style="margin-top:8px">Custo estimado pela tabela de preços do modelo (Gemini), só das análises concluídas.</p>';
  }).catch(function (e) { if (painel.isConnected) painel.innerHTML = '<p class="ed-vazio">Não consegui ler o consumo (' + esc(e.erro) + ').</p>'; });
}

function publicarMural() {
  if (!ED) return;
  if (ED.editando) { toast('Salve ou cancele o aviso em edição antes de publicar.'); return; }
  const btn = el('edPublicar'), st = el('edStatus');
  btn.disabled = true; st.textContent = 'Publicando…'; st.classList.remove('pendente');
  api('/hub/mural', { corpo: { dados: ED.copia, base: ED.base } }).then(function (r) {
    MURAL = normalizarLocal(r.dados);
    MURAL_META = { atualizado_em: r.atualizado_em, atualizado_por: r.atualizado_por };
    renderMural();
    ED.sujo = false;
    fecharSubMural(true);
    toast('✓ Mural publicado para toda a equipe');
  }).catch(function (e) {
    btn.disabled = false;
    if (e.status === 409) {
      st.textContent = 'O mural foi alterado em outro lugar agora há pouco. Recarreguei a versão atual — refaça a sua alteração.';
      st.classList.add('pendente');
      const atual = e.dados && e.dados.atual;
      if (atual) {
        MURAL = normalizarLocal(atual.dados);
        MURAL_META = { atualizado_em: atual.atualizado_em, atualizado_por: atual.atualizado_por };
        renderMural();
        ED.copia = clone(MURAL); ED.base = MURAL_META.atualizado_em; ED.sujo = false; ED.editando = null;
        pintarAba();
      }
    } else if (e.status === 403) {
      st.textContent = 'Só o Tabelião pode publicar o mural.';
    } else if (e.status === 401) {
      st.textContent = 'Sua sessão expirou — entre de novo.';
    } else {
      st.textContent = 'Não consegui publicar: ' + e.erro + '. Tente de novo.';
      st.classList.add('pendente');
    }
  });
}

/* ============================================================
   CLÁUSULAS ESPECIAIS DO GUIA
============================================================ */
function renderClausulas() {
  const box = el('listaTemas'); box.innerHTML = '';
  CLAUSULAS.forEach(function (t) {
    const sec = document.createElement('section'); sec.className = 'tema';
    const cab = document.createElement('button'); cab.type = 'button'; cab.className = 'tema-cab';
    cab.innerHTML = '<span>' + t.tema + '</span><span class="cont">' + t.itens.length + (t.itens.length > 1 ? ' cláusulas' : ' cláusula') + '</span><span class="seta">›</span>';
    cab.setAttribute('aria-expanded', 'false');
    cab.addEventListener('click', function () {
      const aberto = sec.classList.toggle('aberto');
      cab.setAttribute('aria-expanded', aberto ? 'true' : 'false');
    });
    const corpo = document.createElement('div'); corpo.className = 'tema-corpo';
    const interno = document.createElement('div');
    t.itens.forEach(function (item) {
      const b = document.createElement('button'); b.type = 'button'; b.className = 'clausula';
      const rot = document.createElement('b'); rot.textContent = item.nome;
      b.appendChild(rot);
      if (item.nota) { const nt = document.createElement('small'); nt.textContent = item.nota; b.appendChild(nt); }
      b.addEventListener('click', function () {
        copiar(item.texto).then(function () {
          toast('✓ Cláusula copiada — cole na minuta');
          if (!rot.querySelector('.ok-copia')) {
            const ok = document.createElement('span'); ok.className = 'ok-copia'; ok.textContent = '✓ copiada';
            rot.appendChild(ok);
            setTimeout(function () { ok.remove(); }, 2600);
          }
        });
      });
      interno.appendChild(b);
    });
    corpo.appendChild(interno);
    sec.appendChild(cab); sec.appendChild(corpo); box.appendChild(sec);
  });
}
function abrirClausulas() { el('veuClausulas').classList.add('aberto'); }
function fecharTelaClausulas() { el('veuClausulas').classList.remove('aberto'); }

/* ============================================================
   ANEXOS (fotos, prints e PDF) — vão direto para a IA do servidor
============================================================ */
const MAX_ARQUIVOS = 12;
const MAX_TOTAL = 13 * 1024 * 1024;      // bytes somados — o pedido à IA precisa caber em 20 MB
const MAX_PDF = 13 * 1024 * 1024;
function tamanhoLegivel(b) { return b >= 1048576 ? (b / 1048576).toFixed(1).replace('.', ',') + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB'; }
function blobParaBase64(blob) {
  return new Promise(function (res, rej) {
    const fr = new FileReader();
    fr.onload = function () { const s = String(fr.result); res(s.slice(s.indexOf(',') + 1)); };
    fr.onerror = function () { rej(fr.error); };
    fr.readAsDataURL(blob);
  });
}
// Foto de celular (5–12 MB) vira JPEG de até 2400 px — nítido para leitura e leve para enviar.
function prepararImagem(f) {
  const mime = (f.type || '').toLowerCase();
  if (mime === 'image/heic' || mime === 'image/heif') return Promise.resolve({ blob: f, mime: mime });
  const leve = /^image\/(jpeg|png|webp)$/.test(mime) && f.size <= 1.5 * 1048576;
  if (leve || typeof createImageBitmap !== 'function') {
    return Promise.resolve({ blob: f, mime: /^image\/(jpeg|png|webp)$/.test(mime) ? mime : 'image/jpeg' });
  }
  return createImageBitmap(f).then(function (bmp) {
    const escala = Math.min(1, 2400 / Math.max(bmp.width, bmp.height));
    const c = document.createElement('canvas');
    c.width = Math.round(bmp.width * escala); c.height = Math.round(bmp.height * escala);
    const g = c.getContext('2d');
    g.fillStyle = '#ffffff'; g.fillRect(0, 0, c.width, c.height);
    g.drawImage(bmp, 0, 0, c.width, c.height);
    return new Promise(function (res) { c.toBlob(function (b) { res({ blob: b || f, mime: b ? 'image/jpeg' : mime }); }, 'image/jpeg', 0.86); });
  }).catch(function () { return { blob: f, mime: mime || 'image/jpeg' }; });
}
// Imagem do mural (foto de aniversariante ou imagem de aviso) vira data URL leve.
function imagemMural(f, lado, qualidade, maxChars) {
  if (typeof createImageBitmap !== 'function') return Promise.reject(new Error('navegador sem suporte'));
  return createImageBitmap(f).then(function (bmp) {
    function gerar(l, q) {
      const escala = Math.min(1, l / Math.max(bmp.width, bmp.height));
      const cv = document.createElement('canvas');
      cv.width = Math.max(1, Math.round(bmp.width * escala));
      cv.height = Math.max(1, Math.round(bmp.height * escala));
      const g = cv.getContext('2d');
      g.fillStyle = '#ffffff'; g.fillRect(0, 0, cv.width, cv.height);
      g.drawImage(bmp, 0, 0, cv.width, cv.height);
      return cv.toDataURL('image/jpeg', q);
    }
    let d = gerar(lado, qualidade);
    if (d.length > maxChars) d = gerar(Math.round(lado * 0.75), 0.72);
    if (d.length > maxChars) throw new Error('a imagem ficou pesada mesmo comprimida — use uma menor');
    return d;
  });
}
function criarAnexos(raiz) {
  const input = raiz.querySelector('input[type=file]');
  const lista = raiz.querySelector('.anexo-lista');
  const cont = raiz.querySelector('.cont-anexos');
  const aviso = raiz.querySelector('[data-aviso-anexo]');
  const drop = raiz.querySelector('.anexo-drop');
  const itens = [];
  function avisar(m) { aviso.textContent = m || ''; aviso.hidden = !m; }
  function total() { return itens.reduce(function (s, a) { return s + a.blob.size; }, 0); }
  function render() {
    lista.innerHTML = '';
    itens.forEach(function (a, i) {
      const li = document.createElement('li'); li.className = 'anexo-item';
      let thumb;
      if (a.mime === 'application/pdf') { thumb = document.createElement('span'); thumb.className = 'anexo-thumb pdf'; thumb.textContent = 'PDF'; }
      else { thumb = document.createElement('img'); thumb.className = 'anexo-thumb'; thumb.alt = ''; thumb.src = a.url; }
      const nm = document.createElement('span'); nm.className = 'anexo-nome'; nm.textContent = a.nome;
      const tm = document.createElement('span'); tm.className = 'anexo-tam'; tm.textContent = tamanhoLegivel(a.blob.size);
      const x = document.createElement('button'); x.type = 'button'; x.className = 'anexo-x'; x.textContent = '✕';
      x.setAttribute('aria-label', 'Remover ' + a.nome);
      x.addEventListener('click', function () { if (a.url) { try { URL.revokeObjectURL(a.url); } catch (e) {} } itens.splice(i, 1); avisar(''); render(); });
      li.appendChild(thumb); li.appendChild(nm); li.appendChild(tm); li.appendChild(x); lista.appendChild(li);
    });
    cont.textContent = itens.length ? itens.length + ' arquivo(s) · ' + tamanhoLegivel(total()) + ' — enviados na ordem da lista' : '';
  }
  function receber(arquivos) {
    avisar('');
    const arr = Array.prototype.slice.call(arquivos || []);
    return arr.reduce(function (p, f) {
      return p.then(function () {
        if (itens.length >= MAX_ARQUIVOS) { avisar('No máximo ' + MAX_ARQUIVOS + ' arquivos por análise — divida em duas.'); return; }
        const tipo = (f.type || '').toLowerCase();
        const ehPdf = tipo === 'application/pdf' || /\.pdf$/i.test(f.name || '');
        if (ehPdf) {
          if (f.size > MAX_PDF) { avisar('"' + f.name + '" tem ' + tamanhoLegivel(f.size) + ' — acima do aceito (13 MB). Envie só as páginas necessárias.'); return; }
          if (total() + f.size > MAX_TOTAL) { avisar('Os anexos passaram de 13 MB somados — remova algum ou divida a análise.'); return; }
          itens.push({ nome: f.name || 'documento.pdf', mime: 'application/pdf', blob: f, url: null });
          return;
        }
        if (!/^image\//.test(tipo)) { avisar('"' + (f.name || 'arquivo') + '" não é foto nem PDF.'); return; }
        return prepararImagem(f).then(function (r) {
          if (total() + r.blob.size > MAX_TOTAL) { avisar('Os anexos passaram de 13 MB somados — remova algum ou divida a análise.'); return; }
          itens.push({ nome: f.name || 'imagem', mime: r.mime, blob: r.blob, url: URL.createObjectURL(r.blob) });
        });
      });
    }, Promise.resolve()).then(render);
  }
  raiz.querySelector('[data-anexar]').addEventListener('click', function () { input.click(); });
  input.addEventListener('change', function () { receber(this.files); this.value = ''; });
  ['dragover', 'dragenter'].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add('arrasto'); }); });
  ['dragleave', 'drop'].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.remove('arrasto'); }); });
  drop.addEventListener('drop', function (e) { if (e.dataTransfer && e.dataTransfer.files) receber(e.dataTransfer.files); });
  return {
    receber: receber,
    itens: function () { return itens.slice(); },
    limpar: function () { itens.splice(0).forEach(function (a) { if (a.url) { try { URL.revokeObjectURL(a.url); } catch (e) {} } }); avisar(''); render(); },
    avisar: avisar
  };
}

/* ============================================================
   FERRAMENTAS DE IA (Gemini, pelo servidor do cartório)
============================================================ */
let IA_STATUS = { configurada: null, modelo: null };
function nomeModelo(m) {
  if (!m) return '';
  return String(m).replace(/^gemini-/i, 'Gemini ').replace(/-flash-lite/i, ' Flash-Lite').replace(/-flash/i, ' Flash').replace(/-pro/i, ' Pro');
}
function pintarIA() {
  document.querySelectorAll('[data-chip-ia]').forEach(function (c) {
    c.classList.remove('ok', 'falha');
    if (IA_STATUS.configurada === true) { c.textContent = 'IA ativa'; c.classList.add('ok'); }
    else if (IA_STATUS.configurada === false) { c.textContent = 'IA não configurada'; c.classList.add('falha'); }
    else c.textContent = 'verificando IA…';
  });
  document.querySelectorAll('[data-nota-ia]').forEach(function (n) {
    n.textContent = IA_STATUS.configurada === false
      ? 'A IA ainda não foi ligada no servidor — avise o Tabelião.'
      : 'Os documentos vão para o servidor do cartório só para esta análise e não ficam gravados. Confira sempre o resultado antes de usar.';
  });
}
function verificarIA() {
  api('/hub/ia/status').then(function (r) {
    IA_STATUS = { configurada: !!(r && r.configurada), modelo: r && r.modelo };
    pintarIA();
  }).catch(function (e) {
    if (e.status === 404) IA_STATUS = { configurada: false, modelo: null };
    pintarIA();
  });
}

const EXEMPLO_EXTRATOR = '== EXEMPLO FICTÍCIO — apenas para testar a ferramenta ==\nREPUBLICA FEDERATIVA DO BRASIL  SECRETARIA DE SEGURANCA PUBLICA  SSP SE\nCARTEIRA DE IDENTIDADE  RG 3.845.216  MARILIA FONTES DE JESUS\nFILIACAO JOSE ARNALDO DE JESUS / MARIA APARECIDA FONTES DE JESUS   NASC 12/04/1991  ITABAIANA SE\nCPF 054 318 276 90\nENERGISA SERGIPE - FATURA   TITULAR: MARILIA F DE JESUS\nRUA BOANERGES PINHEIRO 214  CENTRO  ITABAIANA SE  CEP 49500-121\ncertidao de nascimento: MARÍLIA FONTES DE JESUS, solteira\nprofissao declarada no balcao: farmaceutica';
const EXEMPLO_ANALISADOR = '== MATRÍCULA FICTÍCIA — apenas para testar a ferramenta ==\nLIVRO Nº 2 — REGISTRO GERAL   MATRÍCULA 8.412   FICHA 01\nCartório do 1º Ofício (Registro de Imóveis) da Comarca de Itabaiana/SE. Aberta em 12/03/2001.\nIMÓVEL: Uma casa residencial situada na Rua Coronel Sebastião, nº 156, Bairro Centro, nesta cidade, com área construída de 96,00m², edificada em terreno próprio medindo 8,00m de frente por 30,00m da frente aos fundos, com área total de 240,00m², limitando-se ao Norte com a referida rua, ao Sul com herdeiros de Manoel Vieira, ao Leste com José Alves Filho e ao Oeste com Maria das Graças Santana. Inscrição municipal nº 01.02.034.0156.001.\nPROPRIETÁRIOS: JOSÉ RAIMUNDO SANTOS BISPO, brasileiro, comerciante, RG nº 1.234.567 – SSP/SE, CPF 456.789.123-01, e sua esposa MARIA LÚCIA MENEZES BISPO, brasileira, do lar, CPF 567.890.123-02, casados sob o regime da comunhão parcial de bens. Registro anterior: transcrição nº 9.870, fls. 12 do Livro 3-B.\nR.1/8.412 — 12/03/2001 — COMPRA E VENDA: adquirido de Manoel Vieira Sobrinho, viúvo, pelo valor de R$ 35.000,00.\nR.2/8.412 — 20/06/2010 — HIPOTECA de 1º grau em favor do BANCO DO ESTADO DE SERGIPE S.A. — BANESE, no valor de R$ 80.000,00.\nAV.3/8.412 — 18/01/2016 — CANCELAMENTO da hipoteca do R.2, mediante autorização de baixa do credor.\nR.4/8.412 — 09/05/2023 — PENHORA sobre a totalidade do imóvel. Processo nº 0801234-56.2022.8.25.0034, 1ª Vara Cível da Comarca de Itabaiana/SE. Exequente: COOPERATIVA DE CRÉDITO DO AGRESTE LTDA. Valor da execução: R$ 142.350,00.\nAV.5/8.412 — 03/04/2024 — ÓBITO de MARIA LÚCIA MENEZES BISPO, falecida em 21/02/2024 (certidão de óbito, matrícula nº 095232 01 55 2024 4 00012 087 0004321 90).\nCERTIDÃO DE INTEIRO TEOR emitida em 15/07/2026.';

/* Descrição ipsis litteris destacada no extrato */
const RE_DESC = /===DESCRICAO_COPIAVEL===([\s\S]*?)(?:===FIM_DESCRICAO===|$)/;
let DESC_ATUAL = '';
function processarExtrato(t) {
  const m = String(t || '').match(RE_DESC);
  DESC_ATUAL = m ? m[1].trim() : '';
  const box = el('descBox');
  if (DESC_ATUAL) { box.hidden = false; el('descTexto').textContent = DESC_ATUAL; }
  else { box.hidden = true; el('descTexto').textContent = ''; }
  return String(t || '').replace(RE_DESC, '').replace(/\s+$/, '');
}

const FERRAMENTAS = {};
function montarFerramenta(cfg) {
  const pagina = el(cfg.pagina), entrada = el(cfg.entrada), saida = el(cfg.saida), meta = el(cfg.meta),
    btn = el(cfg.btnRodar), btnCop = el(cfg.btnCopiar), btnEx = el(cfg.btnExemplo), btnLimpar = el(cfg.btnLimpar);
  const anexos = criarAnexos(pagina.querySelector('[data-anexos]'));
  const textoVazio = saida.textContent;
  let ctrl = null, rodando = false, relogio = null;

  function voltarVazio(texto) { saida.classList.add('vazia'); saida.textContent = texto; }
  btn.addEventListener('click', function () {
    if (rodando) { if (ctrl) ctrl.abort(); return; }
    const texto = entrada.value.trim();
    const arqs = anexos.itens();
    if (!texto && !arqs.length) { toast(cfg.pedirEntrada); entrada.focus(); return; }
    if (IA_STATUS.configurada === false) { voltarVazio('A IA ainda não foi ligada no servidor — avise o Tabelião.'); return; }
    rodando = true; btn.textContent = 'Interromper';
    saida.classList.remove('vazia'); btnCop.hidden = true; meta.textContent = '';
    if (cfg.aoIniciar) cfg.aoIniciar();
    const t0 = Date.now();
    function pintar() {
      const s = Math.round((Date.now() - t0) / 1000);
      saida.innerHTML = '<span class="progresso-ia"><span class="giro"></span>' + esc(cfg.msgProgresso(arqs.length)) + ' · ' + s + ' s</span>';
    }
    pintar(); relogio = setInterval(pintar, 1000);
    ctrl = new AbortController();
    Promise.all(arqs.map(function (a) {
      return blobParaBase64(a.blob).then(function (b64) { return { nome: a.nome, mime: a.mime, base64: b64 }; });
    })).then(function (arquivos) {
      return api('/hub/ia/' + cfg.ferramenta, { corpo: { texto: texto, arquivos: arquivos }, sinal: ctrl.signal });
    }).then(function (r) {
      clearInterval(relogio);
      saida.textContent = cfg.processar ? cfg.processar(r.texto) : r.texto;
      btnCop.hidden = false;
      const custo = r.custo_usd ? ' · US$ ' + Number(r.custo_usd).toFixed(4).replace('.', ',') : '';
      meta.textContent = cfg.assinatura + ' ' + (SESSAO.nome || '—') + ' · ' + agoraCurto() +
        (r.modelo ? ' · ' + nomeModelo(r.modelo) : '') + ' · ' + Math.max(1, Math.round((r.ms || (Date.now() - t0)) / 1000)) + ' s' + custo;
    }).catch(function (e) {
      clearInterval(relogio);
      if (e && e.cancelado) voltarVazio('Interrompido.');
      else if (e.status === 401) voltarVazio('Sua sessão expirou — entre de novo e repita a análise.');
      else if (e.status === 429) voltarVazio('Muitas análises seguidas. Aguarde ' + Math.ceil(((e.dados && e.dados.tente_em_s) || 60) / 60) + ' min e tente de novo.');
      else if (e.status === 503) voltarVazio('A IA ainda não foi ligada no servidor — avise o Tabelião.');
      else if (e.status === 404) voltarVazio('Esta ferramenta ainda está sendo implantada no servidor — tente daqui a pouco.');
      else if (e.status === 400 || e.status === 413) voltarVazio(primeiraMaiuscula(e.erro) + '.');
      else if (e.status === 0) voltarVazio('Sem conexão com o servidor. Verifique a internet e tente de novo — seus anexos continuam aqui.');
      else voltarVazio('A IA não conseguiu concluir: ' + e.erro + '\n\nTente de novo em instantes; se persistir, avise o Tabelião.');
    }).then(function () {
      rodando = false; btn.textContent = cfg.rotuloRodar; ctrl = null;
    });
  });
  btnCop.addEventListener('click', function () { copiar(saida.textContent).then(function () { toast('✓ Copiado'); }); });
  btnEx.addEventListener('click', function () {
    entrada.value = cfg.exemplo; entrada.focus();
    toast('Exemplo fictício inserido — apenas para teste');
  });
  btnLimpar.addEventListener('click', function () {
    if (rodando) return;
    entrada.value = ''; anexos.limpar(); btnCop.hidden = true; meta.textContent = '';
    voltarVazio(textoVazio);
    if (cfg.aoIniciar) cfg.aoIniciar();
  });
  FERRAMENTAS[cfg.pagina] = { anexos: anexos, entrada: entrada };
}

/* Colar print (Ctrl+V) em qualquer ponto da ferramenta aberta */
document.addEventListener('paste', function (ev) {
  const ativa = ['paginaExtrator', 'paginaAnalisador'].filter(function (p) { return !el(p).hidden; })[0];
  if (!ativa || !ev.clipboardData || el('app').hidden) return;
  const alvo = ev.target;
  const emCampo = alvo && (alvo.tagName === 'TEXTAREA' || alvo.tagName === 'INPUT' || alvo.isContentEditable);
  if (emCampo && (ev.clipboardData.getData('text/plain') || '').trim()) return; // texto segue o caminho normal
  const itens = ev.clipboardData.items || [];
  const imgs = [];
  for (let i = 0; i < itens.length; i++) {
    const it = itens[i];
    if (it.kind === 'file' && (/^image\//.test(it.type) || it.type === 'application/pdf')) { const f = it.getAsFile(); if (f) imgs.push(f); }
  }
  if (!imgs.length) return;
  ev.preventDefault();
  const ag = new Date();
  const rotulo = 'print colado ' + dd(ag.getHours()) + 'h' + dd(ag.getMinutes());
  FERRAMENTAS[ativa].anexos.receber(imgs.map(function (f, i) {
    const semNome = !f.name || /^image\.(png|jpe?g)$/i.test(f.name);
    if (!semNome) return f;
    try { return new File([f], rotulo + (imgs.length > 1 ? ' (' + (i + 1) + ')' : '') + '.png', { type: f.type }); }
    catch (e) { return f; }
  })).then(function () { toast('✓ Print anexado — é só clicar em ' + (ativa === 'paginaExtrator' ? 'Gerar qualificação' : 'Analisar matrícula')); });
});

/* ============================================================
   TEMA — claro por padrão (conforto de leitura); escuro só se a pessoa escolher
============================================================ */
function temaAtual() { return document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light'; }
function pintarBotaoTema() {
  const b = el('btnTema');
  if (b) b.textContent = temaAtual() === 'dark' ? '☀ Tema claro' : '☾ Tema escuro';
}
function alternarTema() {
  const novo = temaAtual() === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', novo);
  store.set('cn2o_tema', novo);
  pintarBotaoTema();
}

/* ============================================================
   LIGAÇÕES E INICIALIZAÇÃO
============================================================ */
el('formLogin').addEventListener('submit', entrar);
// Olhos de mostrar/ocultar senha (home v1.3)
document.querySelectorAll('[data-olho]').forEach(function (b) {
  b.addEventListener('click', function () {
    const c = el(b.dataset.olho);
    const mostrar = c.type === 'password';
    c.type = mostrar ? 'text' : 'password';
    b.classList.toggle('aberto', mostrar);
    b.setAttribute('aria-label', mostrar ? 'Ocultar a senha' : 'Mostrar a senha');
    c.focus();
  });
});
el('formPrimeiro').addEventListener('submit', criarSenha);
el('btnVoltarLogin').addEventListener('click', function () { mostrarLogin(); });
el('btnSair').addEventListener('click', sair);
el('btnTema').addEventListener('click', alternarTema);
el('cardProtocolo').addEventListener('click', function () { abrirEmbutida('protocolo'); });
el('cardCalculadora').addEventListener('click', function () { abrirEmbutida('calculadora'); });
el('cardExtrator').addEventListener('click', function () { mostrarPagina('paginaExtrator', false, 'extrator'); });
el('cardAnalisador').addEventListener('click', function () { mostrarPagina('paginaAnalisador', false, 'analista'); });
el('cardClausulas').addEventListener('click', abrirClausulas);
el('fecharClausulas').addEventListener('click', fecharTelaClausulas);
el('veuClausulas').addEventListener('click', function (ev) { if (ev.target === el('veuClausulas')) fecharTelaClausulas(); });
el('veuMural').addEventListener('click', function (ev) { if (ev.target === el('veuMural')) fecharSubMural(); });
document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape') { fecharTelaClausulas(); fecharSubMural(); } });
document.querySelectorAll('[data-sub]').forEach(function (b) { b.addEventListener('click', function () { abrirSub(b.dataset.sub); }); });
el('btnEditarMural').addEventListener('click', abrirEditorMural);
el('btnCopiarDesc').addEventListener('click', function () {
  if (DESC_ATUAL) copiar(DESC_ATUAL).then(function () { toast('✓ Descrição copiada — cole na escritura'); });
});
document.querySelectorAll('[data-voltar]').forEach(function (b) {
  b.addEventListener('click', function () { mostrarPagina('paginaHub'); });
});

montarFerramenta({
  ferramenta: 'qualificacao', pagina: 'paginaExtrator', exemplo: EXEMPLO_EXTRATOR,
  entrada: 'entradaExtrator', saida: 'saidaExtrator', meta: 'metaExt',
  btnRodar: 'btnGerar', rotuloRodar: 'Gerar qualificação', btnCopiar: 'btnCopiarExt', btnExemplo: 'btnExemploExt', btnLimpar: 'btnLimparExt',
  assinatura: 'Qualificação gerada para', pedirEntrada: 'Anexe os documentos ou cole o texto antes de continuar.',
  msgProgresso: function (n) { return n ? 'Lendo ' + n + ' documento(s) e montando a qualificação' : 'Montando a qualificação'; }
});
montarFerramenta({
  ferramenta: 'matricula', pagina: 'paginaAnalisador', exemplo: EXEMPLO_ANALISADOR,
  entrada: 'entradaAnalisador', saida: 'saidaAnalisador', meta: 'metaAna',
  btnRodar: 'btnAnalisar', rotuloRodar: 'Analisar matrícula', btnCopiar: 'btnCopiarAna', btnExemplo: 'btnExemploAna', btnLimpar: 'btnLimparAna',
  assinatura: 'Análise solicitada por', pedirEntrada: 'Anexe a certidão ou cole o texto antes de continuar.',
  processar: processarExtrato,
  aoIniciar: function () { DESC_ATUAL = ''; el('descBox').hidden = true; el('descTexto').textContent = ''; },
  msgProgresso: function (n) { return n ? 'Lendo a certidão (' + n + ' arquivo(s)) e montando o extrato' : 'Analisando a matrícula'; }
});

pintarBotaoTema();
aplicarLinks();

/* Links CNJ — sobreposição com os três endereços */
(function () {
  const veu = el('veuCnj');
  function abrirCnj() { veu.hidden = false; veu.classList.add('aberto'); el('fecharCnj').focus(); }
  function fecharCnj() { veu.classList.remove('aberto'); veu.hidden = true; el('linkCnj').focus(); }
  el('linkCnj').addEventListener('click', abrirCnj);
  el('fecharCnj').addEventListener('click', fecharCnj);
  veu.addEventListener('click', function (ev) { if (ev.target === veu) fecharCnj(); });
  document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape' && !veu.hidden) fecharCnj(); });
})();

/* ============================================================
   BARRA LATERAL, TOPO E ATALHOS DO DASHBOARD (v1.6)
============================================================ */
function marcarNav(chave) {
  document.querySelectorAll('.lat-nav .nav-item').forEach(function (b) { b.classList.toggle('ativo', b.dataset.nav === chave); });
}
function irParaInicio(rolarAte) {
  mostrarPagina('paginaHub', false, '');
  marcarNav('inicio');
  if (rolarAte) { const alvo = el(rolarAte); if (alvo) setTimeout(function () { alvo.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 60); }
}
document.querySelectorAll('.lat-nav .nav-item').forEach(function (b) {
  b.addEventListener('click', function () {
    const n = b.dataset.nav;
    if (n === 'inicio') { irParaInicio(); window.scrollTo({ top: 0, behavior: 'smooth' }); }
    else if (n === 'ferramentas') { irParaInicio('secFerramentas'); marcarNav('ferramentas'); }
    else if (n === 'links') { irParaInicio('linksUteis'); marcarNav('links'); }
    else if (n === 'avisos') { irParaInicio(); document.querySelector('[data-sub="avisos"]').click(); }
    else if (n === 'metas') { irParaInicio(); document.querySelector('[data-sub="metas"]').click(); }
    else if (n === 'calendario') { marcarNav('calendario'); abrirEmbutida('agenda', false); }
    else if (n === 'documentos') { window.open('https://drive.google.com/drive/folders/17jiEqA5ufl4L_7fKKvHzvWF23wvDnlWT', '_blank', 'noopener'); }
    else if (n === 'ajuda') { const v = el('veuAjuda'); v.hidden = false; v.classList.add('aberto'); }
  });
});
el('fecharAjuda').addEventListener('click', function () { el('veuAjuda').classList.remove('aberto'); el('veuAjuda').hidden = true; });
el('veuAjuda').addEventListener('click', function (ev) { if (ev.target === el('veuAjuda')) { el('veuAjuda').classList.remove('aberto'); el('veuAjuda').hidden = true; } });
document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape' && !el('veuAjuda').hidden) { el('veuAjuda').classList.remove('aberto'); el('veuAjuda').hidden = true; } });

el('btnSino').addEventListener('click', function () { irParaInicio(); document.querySelector('[data-sub="avisos"]').click(); });
new MutationObserver(function () {
  el('sinoDot').hidden = !/novo/.test(el('pillAvisos').textContent || '');
}).observe(el('pillAvisos'), { childList: true, characterData: true, subtree: true });

/* busca simples: filtra ferramentas e links pelo texto */
el('btnBusca').addEventListener('click', function () {
  const c = el('campoBusca');
  c.hidden = !c.hidden;
  if (!c.hidden) { irParaInicio(); c.focus(); } else { c.value = ''; filtrarHub(''); }
});
el('campoBusca').addEventListener('input', function () { filtrarHub(el('campoBusca').value); });
el('campoBusca').addEventListener('keydown', function (ev) { if (ev.key === 'Escape') { el('campoBusca').value = ''; filtrarHub(''); el('campoBusca').hidden = true; } });
function filtrarHub(txt) {
  const t = (txt || '').trim().toLowerCase();
  document.querySelectorAll('#secFerramentas .card, #linksUteis .link-item').forEach(function (n) {
    n.hidden = !!t && n.textContent.toLowerCase().indexOf(t) === -1;
  });
}
preencherData();
renderClausulas();
pintarIA();
restaurarSessao();
