# Auditoria v1.29 — frontend (transposição de dados + minuta no Google Docs)

*Cartório de Notas do 2º Ofício de Itabaiana/SE · Hub CN2O · 15/09/2026 · agente de frontend*

Escopo desta etapa: (A) a transposição dos dados dos documentos para a ficha do Gerador de Minuta
(spec `docs/GERADOR-MINUTA-SPEC.md`, §9), sobre a rota `POST /hub/ia/transpor` entregue pelo backend;
(B) a exibição da minuta nascida como Google Doc (`doc` / `doc_erro` na resposta de `/hub/ia/minuta`,
`doc_url` no link permanente). Nada de `backend/*`, `docs/prompt-*.txt` ou `docs/hub-camada-integracao.txt`
foi tocado; `teste/real/{hub,hub-prompts,atos,recibo,docs}.js` já estavam idênticos a `backend/` (conferido
com `cmp`, sem cópia necessária). Sem commits: a árvore não é repositório.

## 1. O que mudou, arquivo a arquivo

### frontend/src/corpo.html (`#paginaMinutas`)
- **Zona de anexos movida** para logo depois do passo 1 (os cinco botões de ato), antes de "Forma do ato":
  bloco novo `#minDocs` (quadro próprio) que contém a MESMA zona `[data-anexos="min"]` (o `montarFerramenta`
  a encontra por `[data-anexos]`; a geração continua enviando os mesmos arquivos), com título fixo
  "Documentos das partes" (`rotulo versalete min-grupo`), a ajuda por ato em `#minAnexosRot` (agora um `<p>`
  preenchido pelo `ANEXOS_ROT[ATO]`), o botão `#btnTranspor` "Extrair e transpor dados" (`btn-vinho`) e a nota
  "Lê RG/CNH, certidões e comprovantes anexados e preenche os campos abaixo — confira antes de gerar. Os mesmos
  documentos seguem com a minuta." A zona antiga do fim da página ("Documentos apresentados") foi removida.
- **Painel "Dados transpostos"** `#minTransposto` (escondido ao nascer): cabeçalho com selo-resumo
  (`#minTranspostoResumo`), caixa de texto para progresso/erro (`#minTranspostoTexto`), linhas por pessoa
  (`#minTranspostoLinhas`, montadas pelo app.js), botões `#btnReaplicarTransp` / `#btnDesfazerTransp`
  (`btn-mini`, padrão da página) com a dica de uso, lista de alertas (`#minTranspostoAlertas`) e a linha de
  custo (`#minTranspostoMeta`).
- **Campos novos de qualificação** (textarea, rótulo "Qualificação (dos documentos)" — nos atos com duas
  pessoas o rótulo diz de quem é —, placeholder "Preenchida pela transposição dos documentos; edite se
  preciso", editáveis, `min-largo`): `minC1Qual`/`minC2Qual` (UE), `minDsC1Qual`/`minDsC2Qual` (DISS_UE),
  `minDvC1Qual`/`minDvC2Qual` (DIV), `minEmMenorQual` (EMANC — ver §5), `minEmPaiQual`/`minEmMaeQual`.
- **EMANC**: campo "Certidão de nascimento — serventia · matrícula · emitida em" (`minEmCertidao`, texto
  livre) no grupo do emancipando e grupo novo "Os pais" com `minEmPai`, `minEmMae` e as duas qualificações.
- **Google Docs**: no painel de resultado, antes do quadro da decisão, a caixa `#minDocBox` (botão-link
  `#minDocLink` "Abrir no Google Docs", `target="_blank" rel="noopener"`, título do Doc em `#minDocTitulo` e a
  frase "A minuta foi criada na pasta do Gerador (Drive) com a formatação da casa — ajuste no Docs e lance no
  Extra Digital.") e a nota discreta `#minDocErro`.

### frontend/src/app.js
- `IA_STATUS` ganha `docs_ativo` (lido de `GET /hub/ia/status`); `pintarIA()` dispara o evento
  `cn2o-ia-status` no `document`, que o Gerador escuta para ajustar a nota de ajuda.
- **Refatoração compartilhada (sem mudança de texto)**: a assinatura das ferramentas (quem, quando, modelo,
  segundos, custo, dupla leitura OCR) virou `assinaturaIA(rotulo, r, t0)` e as mensagens de balcão por falha
  viraram `mensagemErroIA(e)`; `montarFerramenta` passa a usá-las (mesmas strings de antes).
  `FERRAMENTAS[pagina]` expõe `ocupada()` (chamada de IA em curso).
- `mostrarDocMinuta(doc, erro)` (global): mostra a caixa do Docs só com URL `https://` sem espaços/aspas/`<>`;
  monta a nota "Google Docs: não foi possível criar o documento — use o Copiar. (motivo)" tirando o prefixo
  "Google Docs:" do `doc_erro`; sem `doc` nem `doc_erro`, esconde as duas. Chamada por `esconderDecisao()`,
  por `aoConcluir` e por `abrirRota('#minuta=<id>')` (quando `m.doc_url` existe, botão sem título).
- Bloco do Gerador:
  - `ANEXOS_ROT` reescrito como ajuda por ato (o título passou a ser fixo).
  - `montarPessoasProc()` acrescenta `minPOutQual{1..4}` e `minPDadoQual{1..3}` (placeholder comum
    `QUAL_PLACEHOLDER`).
  - Fichas (ver §3): `fichaPROC`, `fichaUE`, `fichaDISS`, `fichaDIV`, `fichaEMANC` emitem as chaves novas.
  - `tituloDaMinuta()` refatorada em `tituloBase()` (ato + partes) + sufixo do estado; `corpoExtra` envia
    `{ titulo_base: tituloBase().slice(0, 120) }`.
  - `reverCiencia()` também trava o botão Gerar enquanto a transposição corre e escreve a nota com a menção
    ao Google Doc quando `IA_STATUS.docs_ativo`.
  - `aoConcluir`: `mostrarDocMinuta(r.doc, r.doc_erro)`; o `POST /hub/minutas` leva `doc_url` quando a caixa
    está visível (URL válida).
  - `aplicarAto()`: o painel da transposição é do ato em que foi aplicada — trocar de ato o esconde (anexos
    ficam); voltar ao mesmo ato o traz de volta.
  - Limpar: `limparTransposicao()` (zera `TRANSP`, esconde o painel, descarta uma chamada em curso sem
    reabrir o painel com "Interrompido."); os campos novos são textareas/inputs dentro do bloco do ato e já
    caíam no Limpar existente.
  - **Módulo da transposição** (comentado no código): `TRANSP` = `{ ato, dados, destinos[], antes, marcas[],
    casamento[], notas[], meta, preenchidos, aplicado }`; `fotografar/restaurar` (foto dos campos, chips e
    multi-chips que o ato pode tocar — `CAMPOS_TRANSP`); `marcarChip/marcarMulti/aplicarChip` (chip só marca se
    o grupo tiver o valor); `isoDe` (dd/mm/aaaa → aaaa-mm-dd; inválida não altera; data impossível que o
    `<input type=date>` recuse volta ao valor anterior e não conta); `normNome/mesmoNome` (sem acento, caixa
    alta); `regimeChip` (regime transcrito → valor exato do chip); `separarFiliacao` ("PAI e MÃE" → pai/mãe;
    aceita " E ", "; " e " / "; sem separador devolve null e o painel avisa); `nomeSolteiroDe`;
    `certidaoNascimento`; `por/porData/porChip` (escrevem e anotam "substituído" quando havia valor
    diferente); `garantirContagem` (PROC: destino além das pessoas existentes sobe o chip "Quantos
    outorgantes/outorgados?" — o equivalente ao "+ outorgante"); `aplicarPessoa`, `aplicarCasamento`,
    `destinosPadrao`, `aplicarTransp` (recusa destino repetido, restaura a foto e aplica; no EMANC o
    emancipando entra primeiro), `renderTransp` (só `createElement`/`textContent`), `progressoTransp`
    (spinner `.progresso-ia` + relógio de segundos, como as outras ferramentas), `erroTransp`, `concluirTransp`
    e os três handlers (Extrair/Interromper com `AbortController`, Reaplicar, Desfazer).
  - Toast do print colado no Gerador cita "Extrair e transpor dados ou Gerar minuta".

### frontend/src/estilo-extra.css
- Bloco final "Gerador de Minuta (v1.29)": `.min-docs` (quadro da zona), `.min-docs-ajuda`, `.min-transpor-linha`,
  `.min-transposto` e filhos (`.mt-cab/.mt-rotulo/.mt-resumo/.mt-texto/.mt-linha/.mt-nome/.mt-seta/.mt-destino/
  .mt-marca/.mt-detalhe/.mt-botoes/.mt-dica/.mt-alertas/.mt-meta`), `.min-docbox/.min-docbtn/.min-doctitulo/
  .min-docnota/.min-docerro`, variantes do tema escuro (mesma paleta dos quadros da decisão: `#c7d2e2`,
  `#f2d7dc`) e ajustes para 520 px. Regras do Tabelião: caixa clara (`--leitura-caixa`) com texto quase-preto;
  linhas do painel e mensagens em 18 px (Atkinson Hyperlegible); alertas e notas em vinho `#631325`, 16 px;
  botões e chips nas classes já usadas (`btn-vinho`, `btn-mini`, `ed-chip`); nenhum emoji novo.

### teste/e2e.py
- Expectativas das fichas existentes atualizadas para as chaves novas (UE, DISS_UE, PROC, EMANC — spec §2).
- Auxiliares novos (`anexo_teste`, `anexar`, `transpor`, `chip_ativo`, `valor`, `destino`, `ordem_no_dom`) e
  quatro passos novos (ver §4). O último passo novo volta ao hub, porque o passo "dashboard" que vem em seguida
  lê o mural (fica escondido com o Gerador aberto).

## 2. Mapeamento aplicado (spec §9.3)

| Ato | Destinos (padrão: ordem das pessoas) | Por pessoa | Extras |
|---|---|---|---|
| UE | convivente 1, convivente 2, (não usar) | nome → `minC{i}Nome`; CPF → `minC{i}Cpf`; profissão → `minC{i}Prof`; nascimento → `minC{i}Nasc` (ISO); estado civil → chip `ue.c{i}civil` (só comprovado); qualificação → `minC{i}Qual` | certidão de casamento: linha só informativa |
| DISS_UE | idem | nome → `minDsC{i}Nome`; estado civil → chip `dss.c{i}civil`; qualificação → `minDsC{i}Qual` | idem |
| DIV | cônjuge 1, cônjuge 2, (não usar) | nome → `minDvC{i}Nome`; qualificação → `minDvC{i}Qual`; nome de solteiro → `minDvSolteiro{i}` pelo `casamento.nome_solteiro[nome]` (o chip "igual ao atual" cai) | `casamento`: data → `minDvCasData`, serventia → `minDvCasServ`, matrícula → `minDvCasMatr`, emissão → `minDvCertData`, regime → chip `div.regime` |
| EMANC | emancipando (a pessoa mais nova; sem datas, a primeira), pai, mãe (quem tiver documento próprio com o nome da filiação), (não usar) | emancipando: nome → `minEmNome`, nascimento → `minEmNasc`, qualificação → `minEmMenorQual`, certidão → `minEmCertidao` ("serventia · matrícula … · emitida em dd/mm/aaaa"; livro/fls./termo nas certidões antigas), filiação → `minEmPai`/`minEmMae`; pai/mãe: nome → `minEmPai`/`minEmMae`, qualificação → `minEmPaiQual`/`minEmMaeQual` | filiação sem o "e" entre os nomes: campos ficam vazios e o painel avisa |
| PROC | outorgantes 1..n e outorgados 1..m já existentes, depois (não usar); qualquer um dos 4+3 escolhível (sobe a contagem) | outorgante: nome → `minPOutNome{i}`, estado civil → chip `proc.out{i}.civil` (só PF), regime → chip `proc.out{i}.regime` (se casado/união estável e o regime casar com um chip), qualificação → `minPOutQual{i}`; outorgado: nome → `minPDadoNome{i}`, qualificação → `minPDadoQual{i}` | — |

Estado civil: `casado→casado`, `divorciado→divorciado`, `viuvo→viuvo`, `solteiro→solteiro`,
`uniao_estavel→uniao_estavel` só onde o grupo tem o chip (PROC); onde não tem (UE, DISS_UE) e para `""`, não
altera. Valor vazio nunca altera campo. "Substituído": anotado por campo quando o valor que estava no campo
(ou o chip ativo, exceto `nao_informado`) era diferente do transposto; aparece na linha da pessoa (e na linha
da certidão de casamento no DIV) como "substituído: CPF, estado civil…".

## 3. Chaves da ficha e posições (spec §2 e §9.4) — sempre presentes, `nao_informado` quando vazias, `umaLinha()`

- **PROC**: `OUTORGANTE_i` → `QUALIFICACAO_OUTORGANTE_i` (por i, antes de `OUTORGADOS:`); `OUTORGADO_i` →
  `QUALIFICACAO_OUTORGADO_i` (por i, antes de `ATUACAO`).
- **UE / DISS_UE**: `CONVIVENTE_1`, `QUALIFICACAO_CONVIVENTE_1`, `CONVIVENTE_2`, `QUALIFICACAO_CONVIVENTE_2`.
- **DIV**: `CONJUGE_1`, `QUALIFICACAO_CONJUGE_1`, `CONJUGE_2`, `QUALIFICACAO_CONJUGE_2`, `CASAMENTO` …
- **EMANC**: `MENOR`, `QUALIFICACAO_MENOR`, `CERTIDAO_NASCIMENTO`, `PAI`, `MAE`, `QUEM_OUTORGA` … — `PAI`/`MAE`
  = `<nome> · <qualificação em uma linha>`; só um dos dois presente sai sozinho; nenhum ⇒ `nao_informado`.

Divergências spec §2 × tela: nenhuma na ordem das chaves já existentes (as fichas dos testes anteriores
continuam idênticas, só com as linhas novas intercaladas). Observação documental, não corrigida aqui por ser
arquivo vedado: `docs/hub-camada-integracao.txt`, item 2.6, ainda diz que "a ficha NÃO traz o nome nem a
qualificação dos pais", enquanto o item 2.1 (editado em 15/09) já descreve `PAI`, `MAE` e
`CERTIDAO_NASCIMENTO` como linhas preenchidas pela transposição — cabe ao dono da camada alinhar o 2.6.

## 4. Resultado das suítes (cada uma após o seu próprio `RESET_DB=1 ./reiniciar-real.sh`)

| Suíte | Antes | Depois |
|---|---|---|
| `python3 e2e.py` (site gerado por `frontend/build.py --endpoint http://127.0.0.1:3999 --saida teste/site --calculadora calculadora.html`) | 51 ok / 0 falhas | **56 ok / 0 falhas; 0 erros de console** (três rodadas iguais; ≈ 1 min 30 s) |
| `node api.test.js` | 61 ok | **61 ok / 0 falhas** (backend intacto) |

Passos novos do e2e (todos verdes):
- *zona de documentos*: `#minDocs` entre `#minAtos` e `#minEntrevista`, uma única `[data-anexos="min"]` dentro
  dela, `#btnTranspor` com o rótulo certo, ajuda que muda com o ato, painel escondido ao nascer, os 16 campos
  novos com o placeholder pedido, nota do Gerador citando o Google Doc (`docs_ativo`), clique sem anexo → toast
  "Anexe os documentos das partes" e nenhuma chamada.
- *UE* (b, c, d, e, i): chamada só com o documento (sem ficha, sem HOJE/QUEM ESTÁ MINUTANDO); duas linhas;
  destinos padrão c1/c2; nome, CPF, nascimento, profissão e qualificação dos dois; chips intactos quando o
  estado civil não é comprovado; os dois alertas em vinho ≥ 16 px; linhas em 18 px; "substituído: CPF"; meta
  com modelo, custo e dupla leitura OCR; Desfazer restaura (inclusive o chip); troca de destino + Reaplicar
  inverte as pessoas; destino repetido recusado; variante "certidao-casamento" marca `casado` nos dois chips
  (aviso do casado aparece), sem alertas, linha da certidão com o nome de solteira, marcas "substituído: CPF" e
  "substituído: estado civil"; ficha enviada com `QUALIFICACAO_CONVIVENTE_1` (parágrafo inteiro) e `_2`; os
  documentos seguem na geração; minuta PRONTA com "Abrir no Google Docs" (`https://docs.google.com/document/d/
  doc-teste-<n>/edit`, `_blank`/`noopener`), título do Doc a partir do `titulo_base`, caixa antes do quadro da
  decisão, Copiar mantido, pedido gravado pelo fake com o título certo, `doc_url` na minuta guardada, e o link
  `#minuta=<id>` reabre com o botão.
- *DIV* (f): cônjuges, qualificações, data/serventia/matrícula/emissão, regime como chip, nome de solteira do
  cônjuge 1 (o chip "igual ao atual" cai) e o do cônjuge 2 intocado; Desfazer devolve também casamento, regime e
  chip; Reaplicar; ficha com `QUALIFICACAO_CONJUGE_1/2`, `CASAMENTO`, `REGIME` e `NOME_SOLTEIRO_1/2`; a minuta
  PRONTA do divórcio também mostra a caixa do Docs.
- *EMANC* (g): emancipando (nome, nascimento, qualificação), certidão ("1º Ofício de Itabaiana/SE · matrícula …
  · emitida em 01/09/2026"), PAI/MAE pela filiação, qualificações dos pais vazias, sem nota de estado civil no
  menor, opções do select; ficha com `QUALIFICACAO_MENOR`, `CERTIDAO_NASCIMENTO`, `PAI`, `MAE` entre `MENOR` e
  `QUEM_OUTORGA`; qualificação do pai digitada entra como `PAI: <nome> · <qualificação>`.
- *erros* (h + doc_erro): "json-quebrado" → mensagem em vinho 18 px "O modelo não devolveu dados estruturados —
  tente de novo. Os campos não foram alterados.", botão de volta ao rótulo, campos e chip intactos; Limpar zera
  painel, anexos e campos novos; minuta com "FALHA-DOCS" no título → sem caixa, nota "Google Docs: não foi
  possível criar o documento — use o Copiar. (o Apps Script respondeu HTTP 500)" em vinho ≥ 16 px, Copiar
  presente, minuta guardada sem `doc_url`; Limpar esconde a nota.

Capturas (pasta `SHOTS` do e2e, hoje `/tmp/claude-0/…/scratchpad/shots`): `27-gerador-transposicao-ue.png`,
`27-gerador-transposicao-docs.png`, `27-gerador-transposicao-div.png`, `27-gerador-transposicao-emanc.png`,
`27-gerador-transposicao-erro.png` (além das 27-gerador-*.png anteriores). Exploração manual extra (fora da
suíte, com Playwright): PROC (Maria → outorgante 1 casada com regime, João → outorgado 1; João → outorgante 2
sobe a contagem para 2; Desfazer devolve a 1; outorgante PJ não recebe chips; ficha com
`QUALIFICACAO_OUTORGANTE_1`/`QUALIFICACAO_OUTORGADO_1`), DISS_UE (nomes, chips `casado`, qualificações),
Interromper no meio ("Interrompido." no painel, botões liberados), Limpar no meio (painel fica fechado),
tema escuro (painel e caixa do Docs) e celular de 400 px (sem rolagem horizontal).

## 5. Decisões tomadas por conta própria

- A textarea da qualificação do menor chama-se `minEmMenorQual`: `minEmQual` já era o id do grupo de chips
  "O pai / A mãe" (em.qual) — os demais ids seguem o pedido (`minEmCertidao`, `minEmPai`, `minEmMae`,
  `minEmPaiQual`, `minEmMaeQual`).
- O painel "Dados transpostos" nasce escondido; durante a chamada ocupa a caixa de texto com o spinner e o
  relógio; a falha aparece na mesma caixa (vinho, 18 px) e, se havia uma transposição aplicada no mesmo ato, as
  linhas dela continuam abaixo da mensagem (o Desfazer segue válido).
- "Desfazer" desfaz a ÚLTIMA transposição: a foto dos campos é tirada a cada nova transposição (quem transpõe
  duas vezes volta, no Desfazer, ao estado depois da primeira). "Reaplicar" restaura a foto e aplica de novo com
  os destinos escolhidos (edições manuais feitas depois da transposição se perdem — a dica do painel avisa).
- "Substituído" compara com o valor presente no campo na hora de escrever (é a foto, porque os destinos são
  únicos); no EMANC, o emancipando é aplicado antes dos pais, de modo que o documento próprio do genitor
  prevalece sobre a grafia da filiação — e uma grafia diferente aparece como "substituído: pai/mãe".
- Destino repetido (duas pessoas → convivente 1) é recusado com toast, sem tocar nos campos.
- Trocar de ato esconde o painel, mas o estado fica guardado por ato: voltar ao mesmo ato o mostra de novo
  (nova transposição substitui). Limpar zera tudo.
- PROC: os destinos padrão preenchem os outorgantes e outorgados já existentes na tela, na ordem das pessoas;
  os demais ficam "(não usar)". Um destino além da contagem sobe o chip "Quantos…?" (é o que o "+ outorgante"
  faria); Desfazer devolve a contagem.
- EMANC: o emancipando padrão é a pessoa mais nova; pai e mãe são preenchidos por casamento de nome com a
  filiação (sem acento, caixa alta); sem casamento de nome, ficam "(não usar)" para a escrevente escolher.
- `CERTIDAO_NASCIMENTO` traz "matrícula " antes do número (e "livro/fls./termo" quando não há matrícula), na
  mesma forma da linha CASAMENTO do DIV.
- DIV: quando a certidão traz o nome anterior, o chip "Igual ao atual" daquele cônjuge é desmarcado antes de
  escrever o nome (a foto guarda o chip; Desfazer o devolve). `pacto` e `averbacoes` só aparecem na linha
  informativa do painel — não há campo mapeado na spec.
- A linha "Certidão de casamento" aparece no painel em todos os atos quando o modelo a devolve; fora do DIV
  diz "só informativa neste ato (o estado civil vai pelos chips)".
- O botão Gerar fica travado durante a transposição e o "Extrair" recusa (toast) enquanto a minuta está
  sendo gerada — os dois usam os mesmos anexos.
- O Doc reaberto pelo link permanente mostra o botão sem o título (o servidor guarda só `doc_url`).
- `doc_url` só vai ao `POST /hub/minutas` quando a caixa está visível (URL `https://` válida); o href só
  recebe URLs assim.
- A nota do Gerador menciona o Google Doc apenas com `docs_ativo` verdadeiro, via evento `cn2o-ia-status`
  (a nota é recalculada quando o status chega e a cada mudança das caixas de ciência).
- `assinaturaIA`/`mensagemErroIA` extraídas do `montarFerramenta` para reuso, com os textos preservados.
- A transposição não envia `texto` (observações) — só os anexos, como diz a spec §9.1.

## 6. Riscos

- **Mock ≠ modelo**: o e2e prova a mecânica com o mock; a qualidade real (acentos, dígitos, filiação com
  "e" no meio de um nome, regime transcrito de forma diferente dos cinco chips) só se afere com documentos
  reais no Gemini Pro. `separarFiliacao` corta no primeiro " e " minúsculo (depois " E ", ";" e "/"); nomes em
  caixa alta com "E" no meio podem separar no lugar errado — a escrevente confere.
- **Limite de IA no harness**: o e2e faz ≈ 27 pedidos de IA com o login cesar.bravo em ≈ 1,5 min (teto 40 por
  10 min). Quem acrescentar mais de ~10 chamadas precisa subir `HUB_IA_LIMITE` por `EXTRA_ENV` ou dividir a suíte.
- **Transposição repetida**: a segunda transposição fotografa os campos já preenchidos pela primeira; o
  "Desfazer" não volta ao estado original da entrevista (só ao anterior à última transposição).
- **`uniao_estavel` em UE/DISS_UE** não tem chip: o dado sobrevive apenas no parágrafo da qualificação e no
  painel.
- **Datas** que o modelo devolva fora de dd/mm/aaaa não entram (o campo fica como estava, sem aviso além do
  resumo da pessoa no painel).
- **PROC/DISS_UE sem cobertura no e2e** (só exploração manual), para não estourar o teto de IA da suíte.

## 7. Pendências

- Alinhar `docs/hub-camada-integracao.txt` item 2.6 ao item 2.1 (PAI/MAE/CERTIDAO_NASCIMENTO agora vêm da
  ficha) — arquivo vedado a este agente.
- Aferição com documentos reais (RG/CNH fotografados, certidão antiga com livro/folha/termo, filiação
  única) e, se preciso, refinar `separarFiliacao`/`regimeChip`.
- Se o balcão pedir, cobertura do PROC/DISS_UE no e2e com `HUB_IA_LIMITE` maior.
- Variáveis do Railway (`HUB_DOCS_WEBAPP_URL`, `HUB_DOCS_SECRET`) e o Apps Script continuam com o
  orquestrador; sem elas, a tela simplesmente não mostra a caixa do Docs (a nota de ajuda também não cita o Doc).
