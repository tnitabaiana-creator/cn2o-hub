# Auditoria v1.29 — backend (transposição de dados + ponte Minuta → Google Docs)

*Cartório de Notas do 2º Ofício de Itabaiana/SE · Hub CN2O · 15/09/2026 · agente de backend*

Escopo desta etapa: (A) a ferramenta `transpor` (POST /hub/ia/transpor) pedida na spec §9 do
GERADOR-MINUTA-SPEC; (B) a minuta nascendo como Google Doc pelo Apps Script do Tabelião, com o Hub
devolvendo o link. Nada do frontend foi tocado (só o build para o e2e). Sem commits: a árvore
`/home/claude/hub-definitivo` não é repositório.

## 1. O que mudou, arquivo a arquivo

### backend/gerar-prompt-minuta.py
- Passa a gravar **dois** blocos em `hub-prompts.js`, cada um entre as suas linhas-marca, com a mesma
  disciplina do bloco da minuta (UTF-8 estrito, `newline=''` — CRLF intacto —, U+2028/U+2029 escapados no
  literal, BOM tratado como espaço só na detecção das tags do prompt-mestre):
  - bloco 1 (inalterado): `// >>> GERADO … prompt-mestre … <<< FIM DO BLOCO GERADO`;
  - bloco 2 (novo): `// >>> GERADO por backend/gerar-prompt-minuta.py a partir de docs/prompt-transposicao.txt
    — TRANSPOSIÇÃO DE DADOS (v1.29) — NÃO EDITE À MÃO` … `// <<< FIM DO BLOCO GERADO — TRANSPOSIÇÃO`,
    com `const PROMPT_TRANSPOR = <docs/prompt-transposicao.txt inteiro, .strip('\n')>`.
- Recusa (saída 2) se `docs/prompt-transposicao.txt` faltar, não for UTF-8 ou estiver vazio, e se
  qualquer um dos dois blocos não existir exatamente uma vez em `hub-prompts.js` (o script não inventa
  onde pôr um bloco que sumiu). Idempotente: a segunda execução imprime "já estava atualizado".
- Rodado nesta etapa: além do bloco novo, o bloco da minuta foi **regenerado** porque
  `docs/hub-camada-integracao.txt` tinha sido editado em 15/09 (uma linha nova no item 2.1, sobre as chaves
  `QUALIFICACAO_*`, `PAI`, `MAE`, `CERTIDAO_NASCIMENTO` como SOURCE documental transcrita) depois da última
  geração — era a única falha do baseline (47 ok / 1 falha antes de qualquer alteração minha).
  Tamanhos: PROMPT_MINUTA_BV 124412 · PROMPT_MINUTA_HUB 76538 · PROMPT_MINUTA 200952 · PROMPT_TRANSPOR 7103.

### backend/hub-prompts.js
- Cabeçalho: explica a segunda exceção (o prompt da transposição também não se edita ali).
- Bloco gerado da transposição (acima) e exportação `transpor: { nome: 'Transposição de dados', prompt:
  PROMPT_TRANSPOR }`. `docs/prompt-mestre-bv-4.0.txt` e `docs/hub-camada-integracao.txt` não foram editados.

### backend/docs.js (novo)
- `ativo()` → `!!(HUB_DOCS_WEBAPP_URL && HUB_DOCS_SECRET)`.
- `criarMinuta({ titulo, ato, estado, minuta, anotacoes, escrevente, modelo, protocolo, gerada_em })` →
  POST com `fetch` global para `HUB_DOCS_WEBAPP_URL`, corpo JSON serializado, `Content-Type:
  text/plain;charset=utf-8`, `redirect: 'follow'` (o Apps Script responde o POST com 302 para
  script.googleusercontent.com; a resposta de verdade vem no GET seguinte), `AbortSignal.timeout(HUB_DOCS_TIMEOUT_MS
  || 40000)`. Devolve `{ id, url, titulo }`. Qualquer outra coisa lança `Error('Google Docs: …')` curto:
  "o Apps Script não respondeu em N s", "sem resposta do Apps Script (fetch failed)", "o Apps Script respondeu
  HTTP 500", "a resposta do Apps Script não é JSON", "segredo inválido" (o `erro` do web app, até 200 chars),
  "o Apps Script não devolveu a URL do documento" (url que não começa por https://). O segredo só existe no
  corpo do pedido: nunca vai para URL, mensagem de erro ou log (conferido no log do servidor de teste: zero
  ocorrências).

### backend/hub.js
- Cabeçalho de rotas atualizado (transpor, doc/doc_erro, doc_url, docs_ativo, variáveis HUB_MODELO_* e HUB_DOCS_*).
- `require('./docs')`.
- `preparar()`: `ALTER TABLE hub_minutas ADD COLUMN IF NOT EXISTS doc_url TEXT`.
- `modeloDe('transpor')` → `HUB_MODELO_TRANSPOR || HUB_MODELO_EXTRATOR || 'gemini-pro-latest'`.
- `GET /ia/status` ganha `docs_ativo` (decisão minha — ver §5).
- Rota `/ia/:ferramenta`:
  - `transpor` exige ao menos um arquivo válido (400 `anexe os documentos das partes para transpor`, antes
    do 400 genérico); texto opcional entra como DADOS no invólucro `=== TEXTO COLADO …`; sem
    `=== HOJE ===` nem `=== QUEM ESTÁ MINUTANDO ===` (a ficha nunca vai); OCR dedicado entra como hoje.
  - depois da resposta e do `registrarUso` (agente `hub-transpor`, cobrado também quando a resposta vem sem
    JSON): `extrairJson()` tira cercas ``` e o que estiver antes do primeiro `{` / depois do último `}`,
    `JSON.parse`; falha → 502 `{ erro: 'o modelo não devolveu dados estruturados — tente de novo', motivo:
    'json' }` e os 300 primeiros caracteres da resposta em `console.error`; sucesso → `normalizarTransposicao()`.
  - `minuta` / `minuta_ue`: depois de montar `textoFinal` (com o rodapé garantido), se `docs.ativo()` e o
    texto traz `===MINUTA_COPIAVEL=== … ===FIM_MINUTA===`, e a linha `Estado:` não é de estado fechado
    (BLOQUEADA / DECISÃO DO TABELIÃO / FORA DO ESCOPO, em português ou pelo código), chama
    `docs.criarMinuta(pedidoDocs(...))` em try/catch: sucesso → `doc: { url, id, titulo }`; falha →
    `doc_erro: <mensagem>` + `console.error`. A resposta com `texto` sai igual nos dois casos.
- Funções novas: `textoTransposto`, `listaTransposta`, `normalizarPessoa`, `normalizarCasamento`,
  `normalizarTransposicao`, `extrairJson`, `separarMinuta`, `estadoFechado`, `agoraMaceio`, `pedidoDocs`,
  `docUrlSegura`.
- `POST /minutas` aceita `doc_url` opcional; `GET /minutas/:id` devolve `doc_url` (null quando não há).

### teste/real/gemini.js (mock)
- Ramo da transposição, detectado por `TRANSPOSITOR DE DADOS` no `prompt_sistema`, decidido pelo nome dos
  arquivos: padrão (Maria + João, casamento null, dois alertas de estado civil), `casamento` (casados, regime,
  objeto casamento com nome de solteiro), `com-cerca` (mesmo JSON dentro de ```json com "Segue o JSON:"),
  `json-quebrado` (texto sem JSON), `menor` (Lucas, certidão de nascimento, alertas []). A chamada é registrada
  em /tmp/gemini-chamadas.json como as demais. Os mocks ocr/trello/whats não foram tocados.

### teste/docs-falso.js (novo) e teste/reiniciar-real.sh
- Fake do web app na porta 3997, só com `http` do Node (o `express` da pasta de teste é um shim sem `text()`
  e sem `redirect`): `POST /exec` grava a chamada em /tmp/docs-chamadas.json e responde **302** para
  `http://127.0.0.1:3997/resultado?k=<n>`; `GET /resultado` devolve `{ ok:false, erro:'segredo inválido' }`
  (segredo ≠ `segredo-teste`), HTTP 500 em texto (título com `FALHA-DOCS`) ou `{ ok:true, id:'doc-teste-<n>',
  url:'https://docs.google.com/document/d/doc-teste-<n>/edit' }`.
- `reiniciar-real.sh`: mata também `docs-falso.js` (padrão do awk), espera a 3997 liberar, apaga
  /tmp/docs-chamadas.json, passa `HUB_DOCS_WEBAPP_URL=http://127.0.0.1:3997/exec HUB_DOCS_SECRET=segredo-teste`
  ANTES de `${EXTRA_ENV}` (no `env`, a última atribuição vence — `EXTRA_ENV="HUB_DOCS_WEBAPP_URL="` desliga a
  ponte) e sobe o fake junto com o site de teste.

### teste/api.test.js
- 13 testes novos (48 → 61): 6 da ponte do Docs + 7 da transposição; contagens de consumo atualizadas
  (`hub-minuta` 10 → 14, com o motivo no comentário; `hub-transpor` = 5; `hub-minuta_ue` segue 2).

## 2. Contratos

### 2.1 POST /hub/ia/transpor
Pedido: `{ arquivos: [{ nome, mime, base64 }], texto? }` — mesmos limites da rota (12 arquivos, ≈13 MB, JPG/PNG/WebP/HEIC/PDF);
`texto` = observações da escrevente (DADOS), nunca a ficha. Erros: 400 `anexe os documentos das partes para
transpor` (sem arquivo), 400/413/429/503 como as outras ferramentas, 502 `{ erro, motivo: 'json' }`.

Resposta 200:
```
{ dados: { pessoas: [ Pessoa ], casamento: Casamento | null, alertas: [ string ] },
  modelo, tokens_entrada, tokens_saida, custo_usd, ms, ocr }
Pessoa    = { nome, nacionalidade, estado_civil, regime_bens, profissao, data_nascimento, naturalidade,
              filiacao, rg, cnh, cpf, endereco,
              certidao: { tipo, serventia, matricula, livro, folha, termo, data_ato, data_emissao, averbacoes },
              documentos: [ string ], qualificacao }
Casamento = { conjuges: [ string ], data, serventia, matricula, regime, pacto, data_emissao_certidao,
              nome_solteiro: { NOME: nome anterior }, averbacoes }
```
Forma fixa: toda chave sempre presente e na ordem acima; string com trim, sem caracteres de controle, "" por
padrão, ≤ 2000 caracteres; listas só com strings não vazias (≤ 40 itens); `pessoas` ≤ 12; número/booleano
vira texto; objeto onde se esperava texto vira ""; chave desconhecida é descartada; `casamento` que não seja
objeto vira null.

### 2.2 Resposta de /hub/ia/minuta (e minuta_ue) com a ponte ligada
Além de `{ texto, modelo, tokens_entrada, tokens_saida, custo_usd, ms, ocr }`:
- `doc: { url, id, titulo }` quando o documento foi criado (só PRONTA e PRELIMINAR);
- `doc_erro: "Google Docs: …"` quando a ponte falhou (a minuta sai normalmente);
- nada dos dois nos estados fechados ou com a ponte desligada.
Entradas opcionais no corpo, usadas só para o título: `titulo_base` (uma linha, ≤ 120 caracteres, espaços
colapsados) e `protocolo` (só dígitos, 1–6). Título: `MINUTA — Hub — <titulo_base | ATO da ficha | MINUTA> —
dd/mm/aaaa HH:mm[ — PRELIMINAR]` (hora de Maceió).

### 2.3 O que o Apps Script recebe (versao 1) e deve responder
Pedido (POST, `text/plain;charset=utf-8`, JSON em `e.postData.contents`):
`{ segredo, versao: 1, titulo, ato, estado, minuta, anotacoes, escrevente, modelo, protocolo, gerada_em }`
- `minuta` = trecho entre os marcadores, sem eles (corpo do documento);
- `anotacoes` = o resto do envelope (DECISÃO DO ROTEADOR, PENDÊNCIAS, ⚠ CONFERIR, rodapé), sem os marcadores
  e sem buracos de linhas em branco;
- `estado` = valor da linha `Estado:` (ex.: `PRONTA PARA MINUTA (READY_FOR_RELEASE)`), `ato` = `UE | PROC | …`,
  `escrevente` = nome da sessão, `gerada_em` = ISO 8601.
Resposta esperada (JSON, após o 302 do Google): `{ ok: true, id, url }` (url iniciada por https://) ou
`{ ok: false, erro }`. HTTP ≠ 2xx ou corpo que não é JSON viram `doc_erro`.

### 2.4 /hub/minutas
`POST { titulo, texto, doc_url? }` — `doc_url` só é gravada se for string ≤ 300 casando com
`/^https:\/\/docs\.google\.com\/document\/d\/[\w-]+/` e sem espaço, aspas, `<`, `>`, `\` ou caractere de
controle; senão fica null sem erro. `GET /hub/minutas/:id` devolve `doc_url`.

### 2.5 Variáveis (Railway)
| Variável | Efeito |
|---|---|
| `HUB_DOCS_WEBAPP_URL` | URL …/exec do web app. Sem ela (ou sem o segredo), a ponte fica desligada e nada muda. |
| `HUB_DOCS_SECRET` | segredo compartilhado; vai no corpo do POST. |
| `HUB_DOCS_TIMEOUT_MS` | espera máxima pelo Apps Script (padrão 40000). |
| `HUB_MODELO_TRANSPOR` | modelo da transposição; sem ela, `HUB_MODELO_EXTRATOR`, e sem esta, `gemini-pro-latest` (socorro no flash como as demais). |
`GET /hub/ia/status` passa a informar `docs_ativo: true|false`.

## 3. Resultado das suítes (cada uma após o seu próprio `RESET_DB=1 ./reiniciar-real.sh`)
| Suíte | Antes | Depois |
|---|---|---|
| `node api.test.js` | 47 ok / 1 falha (prompt da minuta desatualizado em relação à camada editada em 15/09) | **61 ok / 0 falhas** |
| `node ocr.test.js` | 12 ok | **12 ok / 0 falhas** |
| `node recibo.test.js` | 15 ok | **15 ok / 0 falhas** |
| `python3 e2e.py` (após `frontend/build.py --endpoint http://127.0.0.1:3999 --saida teste/site --calculadora calculadora.html`) | 51 ok | **51 ok / 0 falhas; 0 erros de console** |
O e2e não exercita nada da v1.29 (a tela ainda é a v1.28); passou inteiro, o que mostra que a ponte ligada por
padrão no harness não altera o comportamento visível das telas atuais.

Testes novos em api.test.js: igualdade byte a byte de `PROMPTS.transpor.prompt` com docs/prompt-transposicao.txt;
400 sem arquivos (três formas de corpo, e 401 sem sessão); caminho feliz (forma fixa, casamento null, alertas,
modelo pro por padrão na resposta e na chamada registrada, OCR nas observações, ficha/HOJE/QUEM ESTÁ MINUTANDO
ausentes); variante casamento; cercas ```json removidas (dados idênticos ao caminho feliz); json-quebrado → 502
motivo json; menor; consumo `hub-transpor` = 5. Docs: PRONTA (POST → 302 → GET, doc {url,id,titulo}, chamada
gravada com segredo/versao/text-plain/ato UE/estado/escrevente Camily/modelo/protocolo 1400/gerada_em, minuta
sem marcadores nem seções do envelope, anotações com DECISÃO DO ROTEADOR + ⚠ CONFERIR + rodapé e sem a minuta,
titulo_base colapsado no título, `docs_ativo` no status); PRELIMINAR (sufixo, PENDÊNCIAS nas anotações, título
pelo ATO); BLOQUEADA (sem doc, sem chamada); FALHA-DOCS (texto normal + doc_erro, sem doc, tentativa gravada);
doc_url válida gravada e sete inválidas ignoradas; docs.js com env vazio (ativo() false, criarMinuta recusa sem rede).

## 4. Riscos
- **Limitador de IA no harness**: a suíte de API faz 34 pedidos de IA com o login camily.jesus (teto 40 por
  10 min). Quem acrescentar mais de 6 chamadas precisa subir `HUB_IA_LIMITE` por `EXTRA_ENV` ou usar outro login.
- **Redirecionamento do Apps Script**: o fetch do Node converte POST → GET no 302 (é o que o Google espera e o
  que o fake prova). Se o Google passar a responder 307/308 (que preservam o POST), o corpo seria reenviado
  para script.googleusercontent.com — comportamento diferente, a observar no primeiro deploy real.
- **Timeout de 40 s**: o Apps Script que formata um documento longo pode passar disso; o Hub responde com
  `doc_erro` e a minuta segue — o documento pode ter sido criado mesmo assim (órfão na pasta). Ajustável por
  `HUB_DOCS_TIMEOUT_MS`; o .gs deve ser idempotente ou rápido.
- **Sem retentativa no Docs**: uma oscilação do Google vira `doc_erro` na hora; a escrevente reenvia a minuta
  (nova chamada de IA) ou copia o texto. Se isso pesar no balcão, cabe um "criar Doc de novo" pela tela com o
  texto já gerado (rota nova, sem IA) — não existe ainda.
- **Estado civil e demais chaves vêm do modelo**: o servidor garante forma, não verdade. A tela deve tratar
  `estado_civil` "" como "não altera" (spec §9.3) e mostrar os `alertas`.
- **Parse tolerante**: `extrairJson` pega do primeiro `{` ao último `}`; uma resposta com prosa que contenha
  chaves fora do objeto ainda falha o `JSON.parse` e vira 502 — comportamento desejado (nunca se adivinha dado).
- **Mock ≠ modelo**: o mock decide pelo nome do arquivo; a qualidade real da transposição (acentos, dígitos,
  divergências) só se afere com documentos reais no Gemini Pro — fora desta etapa.

## 5. Decisões tomadas por conta própria
- `GET /hub/ia/status` ganhou `docs_ativo` (campo aditivo; a tela só lê `configurada`/`modelo`).
- `doc_url` em /minutas, além do regex pedido, recusa espaço, aspas, `<`, `>`, `\` e controles (a tela vai pôr
  a URL num href); uma `doc_url` inválida não impede guardar a minuta.
- Estado fechado com marcadores (o modelo desobedecendo o envelope) não cria documento: a linha `Estado:` manda,
  além da presença dos marcadores.
- `docs.js` exige que a `url` devolvida comece por `https://` (não restringe o domínio; a restrição a
  docs.google.com fica na persistência, como pedido).
- O consumo da transposição é registrado antes do parse: resposta sem JSON também custou tokens.
- O fake do Apps Script usa `http` puro em vez do shim de express da pasta de teste (que não tem `text()` nem
  `redirect`); a Location do 302 é absoluta, como a do Google.
- `titulo_base` passa por `txt()` (limpeza de controles, 120 chars) e depois colapsa espaços/quebras.

## 6. O que ficou por fazer
- O Apps Script (.gs) em si — o orquestrador escreve; o contrato está no §2.3 e no cabeçalho de docs.js.
- Frontend (outro agente): botão "Extrair e transpor dados", painel "Dados transpostos", exibição do link
  `doc.url` / do `doc_erro`, envio de `titulo_base` e `doc_url` no link permanente.
- Variáveis no Railway: `HUB_DOCS_WEBAPP_URL`, `HUB_DOCS_SECRET` (e, se quiser, `HUB_DOCS_TIMEOUT_MS`,
  `HUB_MODELO_TRANSPOR`).
- Aferição da transposição com documentos reais (acentos, dígitos de CPF/matrícula, divergências entre OCR e
  leitura do modelo), como foi feito com o Extrator.
- Rota para recriar o Google Doc a partir de uma minuta já gerada (sem nova chamada de IA), se a falha do Docs
  se mostrar frequente.
