# Auditoria independente — Hub CN2O v1.33 (frente)

**Auditor:** agente independente (não participou da construção da v1.33)
**Data:** 16/09/2026
**Escopo:** `frontend/src/{corpo.html, app.js, estilo-extra.css, itbi.js, pdf-mini.js}` e `backend/{hub.js, acervo.js}`
**Ambiente:** harness `teste/reiniciar-real.sh` (site 8088, API 3999, fake do acervo 3996), Postgres 54329,
Playwright/Chromium 141, `pdfinfo`/`pdftotext`/`pdftoppm` (poppler).
**Capturas:** `docs/auditoria-v1.33-final/` (81 PNG + 2 PDF) — lista no fim.

---

## VEREDITO: **APROVADA COM RESSALVAS**

A v1.33 está sólida. As duas suítes passam sem falha (`api.test.js` **69 ok / 0 falhas**,
`e2e.py` **62 ok / 0 falhas, 0 erros de console relevantes**), e tudo o que as suítes **não**
cobrem — queda do servidor no meio do salvamento, refresh periódico durante a digitação,
XSS vindo da planilha, ITBI com 4+4 partes, isolamento entre escreventes, entradas
maliciosas no acervo — também passou.

**Nenhum achado bloqueante.** O hotfix do `@container` está resolvido com folga: as duas
folhas fecham no nível de topo e o navegador enxerga exatamente as mesmas regras que o
arquivo tem (conferência numérica no item A). Não houve nenhum erro de página (`pageerror`)
em nenhuma das ~40 sessões de navegação.

As ressalvas são **1 achado importante** e **4 cosméticos**, todos de tipografia/contraste,
todos com correção de uma linha.

---

## Achados

### 1 · IMPORTANTE — a linha vazia do recorte "Agenda Cn2o" fica abaixo do contraste mínimo

| | |
|---|---|
| **Seletor** | `.ficha-bloco .mural-vazio` |
| **Arquivo/linha** | `frontend/src/estilo-extra.css:1431` (base em `estilo-base.css:229`) |
| **Medida** | `font-size: 12.5px` · `color: rgba(32,42,58,.62)` sobre `#fbf5dd` → **contraste 4,13:1** |
| **Regra violada** | leitura ≥ 16 px e contraste ≥ 4,5:1 |
| **Captura** | `B1-mural-dois-paineis.png`, `A2-escuro-mural.png` |

É o **único** texto em toda a superfície nova da v1.33 que reprova no contraste — medi 44
elementos no mural, 85 na subpágina do dia, 178 na vista da semana, 14 no bloco, 178 na
página ITBI e 68 na página Acervo, nos dois temas, e todo o resto fica entre 5,88:1 e 15:1.

A v1.33 introduziu o fundo amarelo-palha `#fbf5dd` (linha 1429) e **tentou** compensar,
subindo o alfa de `.55` (herdado) para `.62` na linha 1431 — o que de fato melhorou o número
em relação à v1.32 (era 3,41:1 sobre o rosé). Só não subiu o bastante.

Atenua: só aparece no **estado vazio**. Com aniversariantes cadastrados o bloco usa
`.mural-lista`, que medi em **16 px / 13,21:1** — perfeito (`B7-agenda-cn2o-preenchida.png`).
Agrava: como não há aniversariantes cadastrados hoje, é exatamente o que está na tela do
Tabelião agora.

**Correção sugerida** (uma linha, `estilo-extra.css:1431`):

```css
.ficha-bloco .mural-vazio{color:rgba(32,42,58,.72);font-size:16px;font-style:normal}
```

`.72` dá **5,49:1** sobre a palha (medi a curva: `.70` → 5,24, `.78` → 6,72). Vale trocar
também o `.mural-vazio` de `estilo-base.css:229` de `.55` para `.72`, porque em fundo branco
ele está em 3,48:1 — **isto é anterior à v1.33** e aparece em todos os quadros, não só neste.

---

### 2 · COSMÉTICO — texto de leitura novo abaixo de 16 px

Dois textos corridos criados pela v1.33 ficaram sob o piso de leitura. Ambos legíveis e com
contraste folgado; é o tamanho que destoa da regra do Tabelião.

| Seletor | Linha | Medido | Texto |
|---|---|---|---|
| `.nt-vazio` | `estilo-extra.css:1827` | **14,5 px** (7,47:1) | "Nenhuma nota ainda. Guarde aqui os textos que você repete todo dia…" |
| `.ma-prox-sub` | `estilo-extra.css:1589` | **14 px** (7,09:1) | "o que já está marcado nos próximos 60 dias, fora deste dia — clique para abrir a data" |

**Correção:** `font-size:16px` nos dois (cabem: o painel de notas tem 233 px a 1366 e o
`.ma-prox-sub` ocupa uma linha inteira da subpágina).

Para contexto, e **fora do escopo da v1.33**: a casa já vinha com `.ma-status` em 15 px
(`:1491`), `.ma-dica` em 14 px (`:1458`), `.ficha-ver` em 11 px e `.sub-eyebrow` em 10 px.
A v1.33 seguiu o padrão existente; não é regressão, mas se a régua dos 16 px for para valer,
`.ma-status` merece atenção — é a frase "✓ Salvo às 20h38", o retorno mais importante das
duas telas novas.

---

### 3 · COSMÉTICO — rótulos novos a 13 px (piso é 13,5 px)

Meia unidade abaixo, sempre com contraste alto (12,7:1 a 14,5:1):

| Seletor | Linha | Onde aparece |
|---|---|---|
| `.ma-btn` | `estilo-extra.css:1487` | os 5 botões da barra: "← Dia anterior", "Hoje", "Dia seguinte →", "Outra data…", "Ver a semana" (e "+ Nova nota" no bloco) |
| `.ma-hora` | `estilo-extra.css:1452` | a hora de cada item no quadro do mural |
| `.ma-mais` | `estilo-extra.css:1456` | o "+N" quando o dia tem mais itens do que cabe |
| `.ma-dia-nome` | `estilo-extra.css:1465` e `:1476` | "SEG…SEX" no quadro |

Sobre `.ma-dia-nome`: a regra de topo (`:1446`) está correta em 13,5 px. Quem baixa para
13 px é a cópia dentro de `@container (max-width:540px)` — e como o painel da agenda mede
**349 px a 1366×900** e **381 px a 1920×1080**, esse bloco fica **sempre ativo nas duas telas
do cartório**, não só no telefone. Vale conferir se a redução ainda faz sentido ali.

**Correção:** `font-size:13.5px` nos quatro pontos (ou remover o `font-size` da cópia em
`:1465`/`:1476`, deixando herdar os 13,5 px de `:1446`).

---

### 4 · COSMÉTICO — "Depois desta semana" corta em 3 sem dizer quantos ficaram de fora

| | |
|---|---|
| **Seletor** | `.ma-depois` / `.ma-depois-item` |
| **Evidência** | com 5 compromissos marcados além da sexta, o quadro mostra 3 e para (`C27-depois-desta-semana.png`); a subpágina lista os 9 corretamente (`C28-proximos-60-dias.png`) |

Bate com a especificação ("até 3 itens"), então **não é defeito** — é uma sugestão. O padrão
da própria v1.33 no quadro do dia é `.ma-mais` ("+2"); aplicar o mesmo aqui evitaria que a
escrevente confiasse no quadro achando que aquilo é tudo.

**Correção sugerida:** acrescentar um `+N` ao fim da linha quando `maProximos()` devolver
mais de 3 dias.

---

### 5 · COSMÉTICO — `Caveat` sem alternativa sem-serifa

| | |
|---|---|
| **Seletor** | `.mural-cards .ficha-titulo.titulo-script` — `font-family: Caveat, "Segoe Script", cursive` (`estilo-extra.css:1420`) |
| **Evidência** | com o Google Fonts indisponível, `CSS.getPlatformFontsForNode` reporta **Liberation Serif** desenhando "Avisos" e "Minha Agenda" |

**Anterior à v1.33** (a classe já existia na v1.32) e sem efeito no Chrome do Tabelião, que
carrega o Caveat normalmente — no meu ambiente não há saída para `fonts.googleapis.com`, e
foi só por isso que os títulos saíram serifados nas capturas. Registro porque a regra da casa
é "sem serifada" e o *fallback* atual entrega justamente uma serifada quando a fonte falha.

**Correção sugerida:** `font-family: Caveat, "Segoe Script", "Trebuchet MS", sans-serif`.

Bom sinal: o subtítulo novo **"Agenda Cn2o"** (`.ficha-subtitulo`, `:1432`) e o **"Bloco de
Notas"** (`.nt-titulo`, `:1806`) usam Montserrat/sans — os agentes não propagaram a cursiva
para os títulos novos.

---

## O que foi verificado e passou

### A · Integridade do CSS — **PASSA**

Conferência tripla, porque era o ponto do hotfix da manhã.

1. **Contagem de chaves fora de comentários e de strings:**
   `estilo-extra.css` → 1621 `{` e 1621 `}`; `estilo-base.css` → 266 e 266.
2. **Varredura estrutural** (parser próprio, comentários e strings neutralizados): as duas
   folhas **terminam na profundidade 0**, sem bloco aberto. Histograma de profundidade:
   extra `{0: 1289, 1: 332}`, base `{0: 239, 1: 27}` — **nenhum bloco em profundidade ≥ 2**,
   ou seja, nenhuma at-rule engolindo outra.
3. **`document.styleSheets` no navegador:** 1528 regras de topo = **1289 + 239, casamento
   exato** com os arquivos. Por família, o CSSOM devolve o mesmo total do arquivo:

   | Família | Total | No topo | Dentro de at-rule (todas fechadas) |
   |---|---|---|---|
   | `.ma-*` | 149 | 116 | `@container 540/520`, `@media 560/620/700/720` |
   | `.nt-*` | 57 | 47 | `@container 265`, `@media 620` |
   | `.itbi-*` | 84 | 60 | `@media dark`, `@media 560` |
   | `.acv-*` | 151 | 101 | `@media dark`, `@media 760` |
   | `.ficha-bloco*` | 3 | 3 | — |

   Nenhuma regra nova "vazando": se alguma at-rule estivesse sem fechar, o total do CSSOM
   seria menor que o do arquivo. É idêntico.
4. **`@container` com contexto:** os três `@container` têm `container-type:inline-size`
   declarado — `.ficha-agenda` (`:1409`), `.ma-painel-agenda` (`:1799`), `.ma-painel-notas`
   (`:1803`). Verifiquei que disparam de verdade (o `(max-width:265px)` do painel de notas
   é o que joga o "Copiar" para baixo do título a 1366).

**Tema escuro — sem texto claro sobre escuro nos quadros/subpáginas/páginas novas.**
Varri os dois temas. Em escuro, **zero reprovações de contraste** na página ITBI (57
medições, 8,61:1 a 15,07:1) e na página Acervo (17 medições, 5,88:1 a 12,72:1). Os quadros
do mural e as subpáginas permanecem claros por desenho (fichas de papel no quadro escuro) e
mantêm texto escuro sobre claro (`A2`…`A7`).

Investiguei uma suspeita e **descartei com teste**: as regras escuras de `.ma-*`/`.nt-*`
existem só como `:root[data-theme="dark"]` (`:1854`–`:1858`), sem a contrapartida
`@media (prefers-color-scheme: dark){:root:not([data-theme="light"])…}` que o resto da casa
usa. Como `build.py:55` injeta um script de arranque que **sempre** fixa `data-theme` em
`light` ou `dark`, o caminho da media query é código morto. Confirmei o comportamento com SO
em escuro e sem escolha no Hub → `data-theme="light"`, fundo branco (`A1`). E fui além:
removi o atributo à força com o SO em escuro (`A8`) — mesmo assim tudo continua legível
(`.ma-painel-notas` 12,82:1, `.nt-vazio` 7,47:1, `.ficha-bloco` 13,21:1), porque cada regra
nova fixa a própria cor. **Não é achado.**

### B · Legibilidade (astigmatismo) — **PASSA**, salvo os achados 1–3

- **Campos ≥ 16 px: 100 %.** Subpágina do dia **13/13**; vista da semana **65/65**; bloco de
  notas **2/2**; página ITBI **31/31**; página Acervo **8/8**. Nenhum abaixo de 16 px.
- **Nome acessível em 100 % dos campos** (`aria-label` ou `<label for>`): 0 sem nome nas
  cinco telas.
- **Contraste:** única reprovação é o achado 1. Tudo o mais ≥ 4,64:1.
- **Sem serifada** no texto novo: `CSS.getPlatformFontsForNode` confirma sans em todos os
  itens de leitura e rótulos novos (o achado 5 é só o *fallback* dos dois títulos do mural).
- **Paleta:** só vinho `#631325`, marinho `#202a3a`, branco, palha `#fbf5dd` e sálvia
  `#edf3ec`. Nenhuma cor fora da lista.
- **Foco visível:** percorri o Tab pelas quatro telas novas — **todas as paradas** têm anel
  visível (contorno 2–3 px vinho ou sombra 3 px `rgba(99,19,37,.18)`). Conferi os 8 campos do
  Acervo um a um: todos com `outline: solid 3px rgba(99,19,37,.5)` (`G1`–`G3`).

### C · Fluxos — **PASSA**

**(1) Agenda.** Clique numa coluna abre **só aquele dia**: 13 faixas exatas — "Dia inteiro /
prazos" + 07h…18h. Digitar → "**✓ Salvo às 20h38**". "Outra data…" aceitou **07/10/2026**
(3 semanas à frente); o texto lá gravou e apareceu (a) em "Próximos", agrupado por dia com
a data por extenso no `aria-label`, e (b) no quadro, em "Depois desta semana: qua 07/10 ⚑".
Escape fecha. Recarregar preserva tudo. "Ver a semana" → grade **13 linhas × 5 colunas = 65
campos**, cabeçalhos SEGUNDA…SEXTA; "Ver o dia" volta aos 13. (`C1`, `C3`–`C6`, `C27`, `C28`)

**(2) Bloco de notas.** "+ Nova nota" cria; título e texto salvam sozinhos ("✓ Salvo às");
"Copiar" põe no *clipboard* **o texto exato** (comparei caractere a caractere, 96 bytes);
sai no painel do mural e sobrevive ao recarregar; "Apagar" vira "**Apagar mesmo?**" e só o
segundo clique apaga. **Outra pessoa não vê:** a Camily abre o Hub com o bloco vazio e a
agenda vazia; pela API, `GET /hub/notas` devolve `{"itens":[]}` para ela e as notas do César
para ele. (`C2`, `C7`–`C10`)

**(3) ITBI.** 2 adquirentes + 1 transmitente, "não consta" no RG, "Não declarado" no valor
(campo desabilitado, `aria-pressed=true`), conferência listando os 23 campos em branco com
"Gerar assim mesmo" / "Voltar e completar". Gerou **PDF 1 página, 595,28 × 841,89 pt (A4)**,
PDF 1.4, 20 562 bytes, abriu em aba nova, "Baixar" habilitado como
`Guia-ITBI-MARIA-2026-09-16.pdf`, e `window.ITBI_ULTIMO_PDF` com os 20 562 bytes.
`pdftotext` confirma: os três nomes com acentuação correta (MARIA DAS **GRAÇAS**, **JOSÉ**
CARLOS FERREIRA DA **CONCEIÇÃO**, **ANTÔNIO** BOMFIM), **PROFISSÃO**, **NÃO CONSTA**,
**NÃO DECLARADO** (quebrado em duas linhas dentro da célula) e **César Bravo / Tabelião**.
Renderizei e olhei: layout oficial, sem sobreposição (`C14-itbi-pdf-2mais1.png`).
"Limpar" zera tudo — campos, "não consta", "Não declarado", quantidades de volta a 1,
município de volta a `ITABAIANA/SE`, `ITBI_ULTIMO_PDF = null`, "Baixar" oculto. (`C11`–`C14`, `C29`)

**(4) Acervo.** As duas abas trocam a fonte (`antigo1` ↔ `cn2o`) com `role="tablist"` e
`aria-selected`. Livro 10 no 2º Ofício → **Livros (1)** + **Atos (2)**. Partes "maria" → 1
ato; "maria, josé" (vírgula = exige os dois) → 1 ato. Chip "Testamentos" → 1 livro, grupo
Atos zerado (filtro de prateleira). "Pasta digital" e "Abrir no Drive" saem como
`<a target="_blank" rel="noopener">` para `drive.google.com`. "mais…" abre as observações e
as colunas que o Hub não conhece. Fonte 1 com atos vazios → "**Nenhum ato indexado ainda
nesta planilha — a aba INDICE_ATOS vai sendo preenchida pela equipe.**" `#acervo=cn2o` e
`#acervo=antigo1` abrem na aba certa, e o **Voltar do navegador** restaura a aba anterior.
"Mostrar mais 50" acumula corretamente: 50 → 100 linhas. (`C15`–`C20`, `C25`, `C26`)

**(5) Regressões — todas passam.** Aviso abre; "Ver todos os avisos" abre; o recorte
"Agenda Cn2o" está no quadro Avisos com `background: rgb(251,245,221)` = **#fbf5dd**
confirmado; "Editar mural" abre para o Tabelião e está `display:none` para a escrevente;
o sino abre o painel de avisos; a busca filtra os cartões ("acervo" → só `cardAcervo`,
"itbi" → só `cardItbi`); os 10 cartões existem e abrem (01→`paginaEmbutida`,
02→`paginaEmbutida`, 03→`paginaExtrator`, 04→`paginaAnalisador`, 05→`paginaMinutas` com o
chip **EM BREVE**, 06→modal de cláusulas, 07→`paginaConsulta`, 08→`paginaRedator`,
09→`paginaItbi`, 10→`paginaAcervo`); a Agenda do Tabelião embute o Google Calendar em
`iframe`; o tema escuro funciona; o Voltar do navegador funciona. (`C21`–`C24`, `C30`, `C31`)

### D · Robustez — **PASSA** (o ponto mais forte da entrega)

**Queda do servidor no meio do salvamento** (bloqueei o POST com `page.route` → 503):

- *Agenda:* status vira "**Não consegui salvar (servidor indisponível). Vou tentar de novo
  em instantes…**", a célula ganha `.pendente`, e o texto **nunca some da tela**. As 6
  retentativas rodam com recuo progressivo; aos **~55 s** a célula vira `.erro` e aparece o
  botão "**Tentar de novo**". Liberei o POST, cliquei → "✓ Salvo às". Recarreguei: o texto
  estava no servidor. (`D2`–`D5`)
- *Notas:* idêntico — `.nt-cartao.pendente`, mesma mensagem, mesmo "Tentar de novo", mesma
  recuperação, texto preservado. (`D6`–`D8`)

**Refresh periódico não sobrescreve o que está sendo editado.** Digitei sem salvar e
disparei `maAtualizarSemanaAtual()` e `ntCarregar(true)` à mão: o texto ficou **idêntico** e
**o foco continuou na célula**. Confere com o código — `maCarregarPeriodo` pula `MA.pendentes`
e `ntAtualizarCartoes` pula `document.activeElement`. (`D9`)

**Troca de dia/semana com pendência não perde texto.** Troquei de dia pelos chips com a
anotação ainda por salvar e voltei: o texto estava lá, e o aviso de erro continuou visível. (`D4`)

**ITBI 4+4 com endereços longos.** Gerou **2 páginas A4**, corpo reduzido para **7,5 pt**, e a
tela informou honestamente "*2 páginas*". **Renderizei e olhei as duas páginas**
(`D1-itbi-4mais4-pagina1.png`, `pagina2.png`): os 8 endereços de 150 caracteres quebram em
duas linhas dentro da célula, **nenhuma sobreposição**, molduras alinhadas, e a quebra caiu
**entre blocos** (fim da seção 4 → seção 5 inteira na página 2), com a faixa "5 – DOCUMENTAÇÃO
DO IMÓVEL" no topo, não órfã. É exatamente o previsto em `docs/GUIA-ITBI-SPEC.md`, seção 3.

**Acervo com a fonte em 500.** Mensagem humana, sem *stack trace*: "**Não consegui pesquisar
agora. A planilha respondeu HTTP 500.**" (`D10`)

**Fonte não vinculada** (`vinculado:false`): "**Fonte ainda não vinculada.** O índice do
acervo ainda não foi vinculado ao Hub. Quando o Tabelião indicar a planilha do Google Sheets,
a pesquisa passa a funcionar aqui mesmo. *Os campos abaixo já estão no lugar definitivo — é
só o índice que falta chegar.*" O botão "Reler a planilha" some. Pesquisar repete o aviso. (`D11`, `D12`)

**XSS — nada executa, tudo sai literal.** Injetei `<img src=x onerror=alert(1)>` e
`"><script>window.__XSS__=1</script><svg onload=alert(2)>` em:

| Alvo | Resultado |
|---|---|
| título e texto de uma nota | 0 `<img>/<script>/<svg>` no painel e na subpágina; texto literal |
| célula da agenda | 0 elementos injetados no quadro, na subpágina e em "Próximos" |
| campos da ITBI (nomes, "outras informações") | 0 elementos; sai literal na conferência **e no PDF** |
| linhas da planilha (interceptei `/hub/acervo` e envenenei `tipo`, `obs`, `partes`, `codigo`, `status`, `livro`) | 0 elementos; texto literal na tabela e no "mais…" |

**0 diálogos** disparados em todos os casos. Além disso, pus `link: "javascript:alert(9)"`
numa linha de livro e `"javascript:alert(8)"` num ato: **nenhum dos dois virou link** — o
`linkSeguro()` do `app.js` só aceita `^https?://[^\s"'<>\\]+$`. (`D13`–`D16`)

### E · Responsivo — **PASSA**

`scrollWidth == clientWidth` nas cinco telas novas nas três larguras — **zero rolagem
horizontal**. (Os únicos elementos que ultrapassam são `<path>` internos de SVG decorativo
com `viewBox` próprio, que não geram rolagem.)

| | 400×860 | 1366×900 | 1920×1080 |
|---|---|---|---|
| `.ma-dois-paineis` | `282px` (**empilhados**) | `349,875px 233,25px` (**3fr : 2fr**) | `381,594px 254,391px` |
| `.ma-semana` | 1 coluna (dias em linhas) | 1 coluna (painel < 540 px) | 1 coluna |
| Tabela do Acervo | `display:block` + `.acv-rolo` (**vira cartões**) | `display:table` | `display:table` |

A 1366 e 1920 os dois painéis ficam lado a lado, na proporção pedida, com os dias em linhas
legíveis (`E-*`).

### F · Backend — **PASSA**

**Login sempre da sessão.** Todas as consultas de `/hub/agenda` e `/hub/notas` filtram por
`login = req.usuario.login`, e `UPDATE`/`DELETE` carregam `AND login = $2`
(`hub.js:694,713,721,755,789,805`). Testes:

- `GET /hub/agenda?…&login=cesar.bravo` com o token da Camily → `{"itens":[]}`, o parâmetro é ignorado.
- Camily tentando **alterar** e **apagar** uma nota do César pelo `id` → **404** nos dois casos; a nota ficou intacta.

**Limites, todos exatos:**

| Limite | Testado | Resultado |
|---|---|---|
| Agenda 2000 chars | 2000 / 2001 | 200 / **400** "anotação longa demais (máximo 2000 caracteres)" |
| Título 80 | 80 / 81 | 200 / **400** "título longo demais (máximo 80 caracteres)" |
| Texto 4000 | 4000 / 4001 | 200 / **400** "nota longa demais (máximo 4000 caracteres)" |
| 60 notas | criei em sequência | parou **exatamente em 60** com mensagem em português |
| Janela da agenda | 62 dias / 365 dias | 200 / **400** "período inválido (até 62 dias, de ≤ ate)" |
| Faixa | `-1, 24, 99, "abc", 7.5` | **400** em todos |
| Dia malformado | `2026-13-45` | **400** "informe de e ate no formato aaaa-mm-dd" |

**Acervo.** Verifiquei o cache e o portão de admin numa instância separada, na porta 3995,
com `HUB_ACERVO_CACHE_MIN=10` (o harness roda com 0), contando as chamadas ao fake:

- 5 pesquisas seguidas em `cn2o` → **1 única leitura** da planilha (cache funciona);
- 1 pesquisa em `antigo1` → **+1 leitura** (cache **por fonte**, não compartilhado);
- escrevente com `?atualizar=1` → **0 leituras novas** (o `recarga()` de `hub.js:852` exige `ehAdmin`);
- Tabelião com `?atualizar=1` → **+1 leitura**.

**Segredo nunca vaza:** `grep "segredo-acervo"` em `/tmp/real.log` e `/tmp/real3995.log` →
**0 ocorrências**. O segredo vai no **corpo** do POST (`acervo.js:564`), não na URL, e o log
registra só `e.message`, que o `acervo.js` monta sem o corpo (`:569`–`:574`). Timeout por
`AbortSignal.timeout` com padrão de 20 s (`:558`, `:566`), e há deduplicação de leituras
simultâneas (`carregando[chave]`), com o cuidado — comentado no código — de não guardar o
`.finally()` para não travar o mapa.

**Entradas maliciosas não derrubam o servidor.** Dez requisições com ReDoS clássico
(`(a+)+$`, `.*.*.*.*.*.*.*.*.*.*.*b`), colchetes desbalanceados, `' OR 1=1--`, string de
5000 caracteres, barra invertida solta, número de folhas de 20 dígitos, data inválida,
`(?:` em tipo de livro e paginação negativa com `por_pagina=99999`: **HTTP 200 em todas**,
`/saude` seguiu em 200. O único `RegExp` construído com entrada do usuário
(`acervo.js:115`) passa por `escapeRe()` (`:114`), e todo filtro é truncado por
`txt(q.x, n)` em `filtrosDoPedido` (`hub.js`). Sem token → **401**.

### G · Acessibilidade — **PASSA**

- **`aria-label` em todos os campos das subpáginas**, e descritivos: cada uma das 13
  textareas do dia diz "**quarta-feira, 16 de setembro de 2026 — 07h**". Os campos da nota:
  "Título da nota" / "Texto da nota". O `input[type=date]` tem `<label>` "Ir para outra data".
- **Foco visível em todas as paradas de Tab** nas quatro telas novas (item B).
- **Nenhum botão sem nome acessível** nas subpáginas, na ITBI nem no Acervo.
- **Escape fecha** a subpágina do dia, a vista da semana e a subpágina do bloco.
- **`aria-live="polite"`** em `#maStatus` e `#ntStatus` — o "Salvo às" e o erro são anunciados.
- Botões de "Próximos" com `aria-label` completo: "quarta-feira, 7 de outubro de 2026, Dia
  inteiro / prazos — PRAZO: … . Abrir a agenda neste dia."
- Abas do Acervo com `role="tablist"`/`role="tab"`/`aria-selected`; chips com `aria-pressed`.
- Movimento: o balanço das fichas do mural está protegido por
  `@media (prefers-reduced-motion: reduce)`.

---

## Observações que não são achados

- **`mm/dd/yyyy` nos campos de data** (`#maOutraData`, `#acvDe`, `#acvAte`) nas capturas: o
  `input[type=date]` segue o idioma **do navegador**, não o `lang` do documento — e o
  Chromium do meu ambiente está em en-US. O documento declara `lang="pt-BR"` corretamente;
  no Chrome do cartório sai `dd/mm/aaaa`. Não mexer.
- **Títulos do mural aparentando serifa** nas capturas: ver achado 5 — é o Google Fonts
  inacessível daqui, não o CSS.
- **A ITBI em 2 páginas com 4+4 partes** é comportamento especificado, não defeito.

## Como reproduzir

```bash
cd /home/claude/hub-definitivo/teste && RESET_DB=1 ./reiniciar-real.sh
timeout 300 node api.test.js        # 69 ok
cd /home/claude/hub-definitivo/teste && RESET_DB=1 ./reiniciar-real.sh
timeout 900 python3 e2e.py          # 62 ok
```

---

## Capturas — `docs/auditoria-v1.33-final/` (81 PNG + 2 PDF)

**A · CSS e tema escuro (9)** — `A1-so-escuro-sem-escolha`, `A2-escuro-mural`,
`A3-escuro-subpagina-dia`, `A4-escuro-semana`, `A5-escuro-notas`, `A6-escuro-itbi`,
`A7-escuro-acervo`, `A8-latente-sem-data-theme`, `00-mural-inicial`.

**B · Legibilidade (7)** — `B1-mural-dois-paineis`, `B2-subpagina-dia-1366`,
`B3-vista-semana`, `B4-subpagina-notas`, `B5-itbi-1366`, `B6-acervo-1366`,
`B7-agenda-cn2o-preenchida`.

**C · Fluxos (31)** — agenda: `C1-subpagina-dia`, `C3-agenda-salvo`, `C4-agenda-outra-data`,
`C5-quadro-depois-desta-semana`, `C6-grade-semana-13x5`, `C27-depois-desta-semana`,
`C28-proximos-60-dias`. Notas: `C2-notas-nova`, `C7-notas-salva`, `C8-notas-no-mural`,
`C9-notas-apagar-confirma`, `C10-camily-isolada`. ITBI: `C11-itbi-preenchido`,
`C12-itbi-conferencia`, `C13-itbi-gerada`, `C14-itbi-pdf-2mais1.png`,
**`C14-itbi-2mais1.pdf`**, `C29-itbi-limpo`. Acervo: `C15-acervo-livro10`,
`C16-acervo-mais`, `C17-acervo-partes`, `C18-acervo-tipo-livro`,
`C19-acervo-antigo1-sem-atos`, `C20-rota-acervo-cn2o`, `C25-acervo-mostrar-mais-50`,
`C26-acervo-apos-mais-50`, `C31-acervo-escrevente`. Regressões: `C21-sino`, `C22-busca`,
`C23-agenda-tabeliao`, `C24-card05-em-breve`, `C30-editar-mural-admin`.

**D · Robustez (19)** — `D1-itbi-4mais4-tela`, `D1-itbi-4mais4-pagina1`,
`D1-itbi-4mais4-pagina2`, **`D1-itbi-4mais4.pdf`**, `D2-agenda-erro-salvar`,
`D3-agenda-tentar-de-novo`, `D4-agenda-troca-dia-pendente`, `D5-agenda-recuperada`,
`D6-notas-erro-salvar`, `D7-notas-tentar-de-novo`, `D8-notas-recuperada`,
`D9-refresh-nao-sobrescreve`, `D10-acervo-erro-500`, `D11-acervo-nao-vinculada`,
`D12-acervo-nao-vinculada-pesquisa`, `D13-xss-nota`, `D14-xss-agenda`, `D15-xss-itbi`,
`D16-xss-planilha`.

**E · Responsivo (15)** — `E-400x860-{mural,dia,notas,itbi,acervo}`,
`E-1366x900-{mural,dia,notas,itbi,acervo}`, `E-1920x1080-{mural,dia,notas,itbi,acervo}`.

**G · Acessibilidade (3)** — `G1-foco-dia`, `G2-foco-acervo`, `G3-foco-campo-agenda`.
