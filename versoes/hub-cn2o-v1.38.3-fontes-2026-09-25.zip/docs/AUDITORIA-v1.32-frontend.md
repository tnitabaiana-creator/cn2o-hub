# Auditoria v1.32 — frontend (mural em dois quadros + Minha Agenda)

*Cartório de Notas do 2º Ofício de Itabaiana/SE · Hub CN2O · 16/09/2026 · auditor de frontend*

## Veredito

> ### APROVADA COM RESSALVAS
>
> A funcionalidade está correta de ponta a ponta — salvamento automático, isolamento por
> login, validações do servidor, XSS, tema escuro, 400 px sem rolagem horizontal, teclado e
> regressões: tudo passou. Mas há **um defeito bloqueante de leitura**: sempre que a subpágina
> é aberta, **toda anotação que ocupa mais de uma linha aparece cortada** (a célula fica presa
> em 40 px). Como a razão de existir da tela é ler o que já foi anotado — e o leitor é um
> Tabelião com astigmatismo —, isso precisa ser corrigido antes de fechar a versão. A correção
> é de uma linha (achado 1) e resolve, junto, o achado 2.

Escopo: as mudanças da v1.32 — mural de 3 para 2 quadros ("Avisos" com o bloco *Agenda Cn2o* e
"Minha Agenda"), o quadro da semana seg–sex com hoje em destaque, a subpágina com a grade
13 faixas × 5 dias e salvamento automático (`POST /hub/agenda`), a navegação de semana e a troca
de "Metas" por "Minha Agenda" no menu lateral — conferidas contra as regras da casa (texto escuro
sobre claro, caixas de leitura ≥ 18 px, notas ≥ 16 px, rótulos ≥ ~13,5 px, paleta vinho `#631325` /
marinho `#202a3a` / branco, tema escuro coberto, 400 px sem rolagem horizontal).

**Nenhum arquivo do projeto foi alterado.** Este relatório e a pasta `docs/auditoria-v1.32/`
(33 capturas) são os únicos acréscimos. As linhas da agenda de teste gravadas durante a
auditoria foram apagadas ao final; a tabela `hub_agenda` voltou às 3 linhas que já existiam.

### Como foi testado

O site servido em `http://127.0.0.1:8088` é **byte a byte igual** a um build novo dos fontes
(`cmp` contra a saída de `python3 frontend/build.py --endpoint http://127.0.0.1:3999`), portanto
os testes valem para `frontend/src/{corpo.html,app.js,estilo-extra.css}` e `backend/hub.js` atuais.
Playwright/Chromium headless, `locale=pt-BR`, `reduced_motion=reduce`; logins `camily.jesus`
(escrevente) e `cesar.bravo` (Tabelião, admin), em contextos separados; larguras 1366, 1920 e
400 px; tema escuro por `#btnTema`. Relógio do contêiner: **quarta-feira, 16/09/2026, UTC**.
Contraste pela fórmula WCAG a partir das cores computadas, compondo os fundos translúcidos dos
ancestrais. Falhas de rede simuladas com `page.route` (abortar, 401 e 500 no `POST /hub/agenda`).
O Google Fonts não é alcançável neste ambiente (`document.fonts.size === 0`): as capturas usam a
fonte de reserva, o que **não muda tamanhos nem cores** medidos.

Leitura de código: bloco "v1.32 — MINHA AGENDA" (`app.js` 835–1102), `abrirSub`/`fecharSubMural`
(760–833), `renderMural` (588–605), `api` (105–134), `sair`/`mostrarApp` (262–284), nav
`minha-agenda` (3948); `corpo.html` 121–149; bloco "v1.32 — MURAL EM DOIS QUADROS"
(`estilo-extra.css` 1403–1511); seção "Minha Agenda (v1.32)" (`backend/hub.js` 640–702) e o
DDL de `hub_agenda` (89–98).

---

## 1. Resultado item a item

### 1.1 Visual do mural (1366×900 e 1920×1080)

| Verificação | Resultado |
|---|---|
| Dois quadros | OK — `.mural-cards.mural-dois` com 2 `<article>`; grade `minmax(0,5fr) / minmax(0,7fr)`: 399/559 px a 1366 e 433/611 px a 1920 |
| Títulos "Avisos" e "Minha Agenda" | OK — `<h3 class="ficha-titulo titulo-script">`, texto exato conferido no DOM |
| Grafia manuscrita | OK **na declaração**: `font-family` computado = `Caveat, "Segoe Script", cursive` (estilo-extra.css:1420), 48 px, centralizado, com o traço `::after` vinho/marinho. O arquivo da Caveat não carrega no contêiner (`document.fonts.size === 0`; as larguras de `Caveat`, `Segoe Script`, `cursive` e `serif` medem todas 302,8 px → reserva) — a aparência manuscrita **não pôde ser conferida visualmente aqui**, só a cadeia de fontes, que está certa |
| Tons pastel diferentes e sutis | OK — `tom-a` `rgb(253,245,246)` (rosé/vinho) e `tom-b` `rgb(243,245,249)` (azul-acinzentado/marinho), mais um gradiente de 2 %→11/12 % da cor-tema (1415–1416). Distinguíveis lado a lado e discretos (capturas 02 e 27) |
| Alfinetes | OK — `::before` de 24×32 px, `top:-13px`, gradiente radial vinho (`#c25a72`→`#5e0f26`), um por quadro |
| Inclinação | OK — `matrix(0.999877,-0.0157073,…)` ≈ −0,9° no quadro Avisos e ≈ +0,7° no Minha Agenda (1411–1412), com o ponteiro fora dos quadros |
| Hoje em vinho, na coluna certa | OK — `2026-09-16` é o 3º botão (seg 14 · ter 15 · **qua 16** · qui 17 · sex 18); `.ma-dia.hoje` com `border: 2px solid rgb(99,19,37)` = **#631325**, fundo `linear-gradient(rgba(99,19,37,.14), …)`, nome e número em vinho |
| Rolagem horizontal a 1920 | OK — `scrollWidth` 1920 = `innerWidth` |

Capturas: `01`, `02`, `03`, `27`.

### 1.2 Legibilidade (regras do Tabelião)

**Texto claro sobre fundo escuro em conteúdo de leitura:** nenhum. O único caso é a pílula
`#maResumo.tem-novos` (branco sobre vinho, contraste 12,72:1) — chip curto, tolerado desde a v1.29.

**Medidas (`getComputedStyle`, 1366 px, tema claro):**

| Seletor | Tamanho | Contraste | Regra | Situação |
|---|---|---|---|---|
| `.ma-campo` (célula da grade) | **16 px** | 13,41:1 | notas ≥ 16 px | OK (no limite) |
| `.ma-campo.tem` / `.ma-cel.hoje .ma-campo` | 16 px, peso 600 | 10,47:1 | ≥ 16 px | OK |
| `.ma-linha-hora` (rótulo da faixa) | **13,5 px** | 12,72:1 | rótulo ≥ 13,5 px | OK (no limite) |
| `.ma-cab-nome` | **13,5 px** | 6,03:1 | rótulo ≥ 13,5 px | OK (no limite) |
| `.ma-cab-num` | 17 px | 12,92:1 | — | OK |
| `.ma-status` | 14 px | 14,45:1 | rótulo ≥ 13,5 px | OK |
| `#subConteudo .sub-cab h2` | 18 px | 14,45:1 | leitura ≥ 18 px | OK |
| `.ma-item` / `.ma-txt` (prévia no quadro) | **14 px** (12,5 px a ≤ 560) | 14,2:1 | notas ≥ 16 px | **achado 4** |
| `.ma-hora` | **11,5 px** (10,5 a ≤ 560) | 12,51:1 | rótulo ≥ 13,5 px | **achado 5** |
| `.ma-dia-nome` | **12 px** (10,5 a ≤ 560) | 5,42:1 | rótulo ≥ 13,5 px | **achado 5** |
| `.ma-mais` | **11 px** | **4,02:1** | rótulo ≥ 13,5 px | **achados 5 e 8** |
| `.ma-cab-hoje` | **11 px** | 10,09:1 | rótulo ≥ 13,5 px | **achado 5** |
| `.ma-btn` (← Semana anterior / Hoje / →) | **12 px** | 14,45:1 | rótulo ≥ 13,5 px | **achado 5** |
| `.ma-tentar` ("Tentar de novo") | **11,5 px** | — | rótulo ≥ 13,5 px | **achado 5** |
| `.ficha-legenda` ("semana de 14 a 18…") | **11,5 px** | **4,16:1** | rótulo ≥ 13,5 px | **achado 5** |
| `.ficha-ver-mini` ("Ver mais") | **10,5 px** | 13,46:1 | rótulo ≥ 13,5 px | **achado 5** |
| `.ma-livre` ("livre" / "nada anotado para hoje") | 13,5 px (11,5 a ≤ 560) | **3,02:1** | — | **achado 7** |
| `.ma-dica` (frase sob o quadro) | 13,5 px | 5,57:1 | frase de leitura | borderline — ver achado 5 |
| `.ma-ajuda` (instruções da subpágina) | **14,5 px** | 7,57:1 | leitura ≥ 18 px | **achado 9** |
| `.ficha-subtitulo` ("Agenda Cn2o") | 16,5 px | 13,46:1 | — | OK |

**Paleta:** só vinho `#631325`, marinho `#202a3a`, branco e transparências dos dois. Os pastéis
`#fdf5f6` e `#f3f5f9` são vinho e marinho a ~4 % sobre branco. Nenhuma cor estranha à paleta.

### 1.3 Funcional

| # | Verificação | Resultado |
|---|---|---|
| — | Abrir por "Abrir minha agenda" | OK — grade `role="grid"`, 13 `rowheader` (`Dia inteiro / prazos`, `07h`…`18h`), 5 `columnheader`, 65 `gridcell`; foco vai para o ✕ |
| — | Abrir por um dia do quadro | OK — sexta 18/09 ganha `.ma-cabdia.alvo` (borda tracejada) + 13 `.ma-cel.alvo`; clicar em **hoje** não cria `.alvo` (0 elementos), fica só `.hoje` — como especificado |
| — | Abrir pelo menu lateral "Minha Agenda" | OK — volta ao Início e abre a subpágina; rótulos do menu: Início · Ferramentas · Links úteis · Avisos · **Minha Agenda** · Agenda do Tabelião · Documentos · Ajuda |
| a | `.pendente` enquanto espera | OK — logo após digitar: `class="ma-campo tem pendente"`, `MA.pendentes = ["2026-09-15\|11"]`, status "Salvando…" |
| b | Status "Salvo às HHhMM" | OK — `✓ Salvo às 17h15`, `class="ma-status ok"`; a célula volta a `ma-campo tem` |
| c | `GET /hub/agenda` devolve o texto | OK — `200 {"itens":[{"dia":"2026-09-14","faixa":7,"texto":"Salvo pela auditoria — confere no GET"}, …]}` |
| d | Quadro do mural atualiza após Escape | OK — a coluna de ter 15/09 passou de "livre" para `11h Auditoria v1.32 — …` e o `aria-label` para "…1 anotação" |
| e | Reload preserva | OK — quadro e grade voltam com o mesmo conteúdo |
| f | Apagar o texto apaga no servidor | OK — `POST` com texto vazio devolve `{ok:true, apagado:true}`; o `GET` seguinte não traz a célula; a classe `.tem` cai |
| g | Semana anterior / seguinte / hoje | OK — títulos "Semana de 07 a 11 de setembro" → "… 21 a 25 …" → "… 14 a 18 …"; cabeçalhos e preenchimento acompanham; `.hoje` só na semana corrente |
| h | Isolamento entre logins | OK — César vê os 5 dias "livre"/"nada anotado para hoje" e 0 células preenchidas; grava a dele (16/09 15h) e a de Camily não muda; Camily não vê a dele. O campo `login` forjado no corpo do POST é ignorado (a linha foi para `camily.jesus`) |
| i | Escape fecha | OK — `#veuMural` perde `.aberto`; `MA.subAberta = false` |
| j | Textarea cresce com o texto | OK **durante a digitação** — 40 px (vazio) → 59 px (1 linha) → 146 px (3 linhas). **Não** ao abrir a subpágina: **achado 1** |
| k | Tab de célula em célula | OK — `15\|11 → 16\|11 → 17\|11 → 18\|11 → 14\|12 → 15\|12 …` (ordem de leitura, pulando os rótulos) |

Capturas: `04`–`08`, `11`.

### 1.4 Robustez

- **Servidor fora do ar durante um salvamento** (rota abortada): a célula fica `.pendente`, o
  status vira *"Não consegui salvar (sem conexão…). Vou tentar de novo em instantes…"* e o
  `POST` é repetido **7 vezes**, com intervalos medidos de **2,5 · 5 · 7,5 · 10 · 12,5 · 15 s**
  (`maSalvarAgora`, app.js:1055–1057). Esgotado o limite, a célula passa a `.erro` (borda vinho
  tracejada) e aparece o botão **"Tentar de novo"**. Liberada a rota, um clique no botão salva:
  status `✓ Salvo às 17h19` e o texto no servidor. Capturas `12`, `13`, `14`.
- **Erro 500**: não desiste — `tentativas = 1` e nova tentativa agendada. Captura `15`.
- **Erro 400 ou 401**: não insiste (app.js:1049–1054) — correto para 400. Para 401, ver **achado 3**.
- **O texto digitado se perde?**
  - *Trocar de semana com pendência*: **não** — `maDescarregarSub()` despacha o pendente e
    `MA.itens` guarda o texto; voltando à semana, a célula reaparece preenchida com `.erro`.
  - *Fechar a subpágina*: **não** — mesmo caminho; reabrindo, o texto está lá.
  - *Sair*: **não** — `sair()` chama `maSair()` **antes** de `limparSessao()`, o `POST` sai com
    `keepalive` e o token; conferido: texto digitado 120 ms antes de `sair()` chegou ao banco.
  - *Fechar a aba*: coberto por `pagehide` → `maDescarregarSub(true)` (app.js:1102).
  - *Sessão expirada no meio do salvamento*: **sim, perde** — **achado 3**.
- **Refresh periódico (`maAtualizarSemanaAtual` a cada `CONFIG.muralMinutos` = 5 min) sobrescreve
  célula em edição?** **Não.** Duas proteções, ambas conferidas em execução: (1)
  `maAtualizarSemanaAtual` só chama `maRenderCard()` — não toca nos `textarea` da grade; (2)
  `maCarregarSemana` preserva `MA.itens` das chaves em `MA.pendentes` (app.js:878–879) e
  `maAtualizarCelulas` pula a célula pendente **ou** com foco (app.js:1009). Teste: com o cursor
  na célula e texto não salvo, `maAtualizarSemanaAtual()` e `maAtualizarCelulas()` deixaram o
  texto intacto; só depois de tirar o foco (e sem pendência) a célula voltou ao valor do servidor
  — que é o comportamento desejado.

### 1.5 Segurança / backend (`backend/hub.js` 640–702)

| Verificação | Resultado |
|---|---|
| Login sempre da sessão | OK — `req.usuario.login` nas 3 consultas (668, 685, 690); `exigeSessao` em ambas as rotas. `POST` com `"login":"cesar.bravo"` no corpo gravou em `camily.jesus` |
| Sem token | OK — `401 {"erro":"sessão inválida ou expirada — entre de novo"}` |
| `dia` | OK — `RE_DIA` + round-trip por `toISOString` (648–652): `2026-02-30`, `2026-9-19` e `01/01/2026` → 400 |
| `faixa` 0..23 | OK — 24, −1 e 9.5 → 400; 0 e 23 aceitos; `"9"` (string) aceito por `Number()` — inofensivo |
| `texto` ≤ 2000 | OK — 2000 aceito, 2001 → `400 "anotação longa demais (máximo 2000 caracteres)"`; `txt()` tira caracteres de controle e apara |
| Janela ≤ 62 dias | OK — 62 dias → 200; 63 dias e `de > ate` → `400 "período inválido (até 62 dias, de ≤ ate)"` |
| Texto vazio apaga | OK — `""`, `null` e `"   "` → `DELETE` + `{apagado:true}` |
| `Cache-Control: no-store` no GET | OK (linha 661) |
| Chave primária `(login, dia, faixa)` + `ON CONFLICT … DO UPDATE` | OK — upsert idempotente |
| **XSS** | OK — `<img src=x onerror=alert(1)>` gravado numa célula: volta **literal** no `textarea` (`.value`), e no quadro sai por `esc()` como `&lt;img src=x onerror=alert(1)&gt;` dentro de `<span class="ma-txt">`. `document.querySelectorAll('#muralAgendaSemana img, script').length === 0`; nenhum `dialog` disparado. Capturas `09`, `21` |

*Observação (não é regressão da v1.32):* `jsonMural` (`express.json({limit:'8mb'})`) corre **antes**
de `exigeSessao` em `/agenda` (676) — como em todas as rotas POST do hub (250, 313, 334, 610).
Um corpo de 8 MB é lido e desserializado antes da autenticação.

### 1.6 Responsivo

- **400×860, página:** `document.documentElement.scrollWidth = 400` (≤ 402 ✔) e `body.scrollWidth = 400`.
  Mural em 1 coluna (`@media(max-width:880px)`, 1409); quadro de **5 colunas** preservado
  (`repeat(5, …)` → 5 × ~53 px). Os únicos elementos que ultrapassam a viewport são os `<path>` do
  SVG decorativo `.serra.serra-mural` (pré-existente, recortado — a página não rola).
  Capturas `17`, `18`.
- **400 px, subpágina:** a grade rola **dentro** da subpágina (`.ma-rolagem` `scrollWidth 821` >
  `clientWidth 340`), a página continua com `scrollWidth 400` mesmo com `scrollLeft = 400`.
  Coluna das horas **sticky**: `position:sticky; left:0; background:#fff; z-index:1` — depois de
  rolar 400 px, `.ma-linha-hora` continua colada na borda esquerda da caixa (left 30 = left da
  `.ma-rolagem`). `.ma-campo` mantém 16 px. Captura `19`.
- Ressalva: a prévia das anotações no quadro fica ilegível a 400 px — **achado 4**, captura `18`.
- Ressalva: abrir a agenda "num dia" não rola até o dia — **achado 2**, captura `32`.

### 1.7 Tema escuro (`#btnTema`)

OK. Com `data-theme="dark"` e fundo da página `rgb(32,42,58)`, os dois quadros continuam claros
(`rgb(253,245,246)` e `rgb(243,245,249)`) com texto `rgb(32,42,58)`; a subpágina continua branca.
Todos os textos medidos dentro dos quadros e da subpágina (16 seletores) seguem **escuros sobre
claro**, com os mesmos tamanhos e contrastes do tema claro; o único claro-sobre-escuro é o chip
`#maResumo`. As faixas sticky (`.ma-canto`, `.ma-linha-hora`) continuam `#ffffff`, sem "buraco"
escuro ao rolar. Capturas `20`, `21`, `22`.

### 1.8 Acessibilidade básica

| Verificação | Resultado |
|---|---|
| `aria-label` das células | OK — `"quarta-feira 16/09 — 09h"`, `"segunda-feira 14/09 — Dia inteiro / prazos"` (app.js:947–949) |
| `aria-label` dos dias do quadro | OK e informativo — `"quarta-feira, 16/09 (hoje) — 2 anotações. Abrir a agenda neste dia."`, `"…— sem anotações…"` (app.js:907) |
| Foco visível | OK — `.ma-dia` por Tab: `outline: rgb(99,19,37) solid 3px` + `offset 2px`, `:focus-visible = true`; `.ma-campo`: borda vinho + `box-shadow 0 0 0 3px rgba(99,19,37,.18)`; `.ma-btn`: anel vinho a 40 %. Captura `28` |
| Teclado no quadro | OK — Tab percorre os 5 dias e cai no "Abrir minha agenda"; Enter abre a subpágina no dia focado (`MA.diaAlvo = "2026-09-17"`) |
| `role=grid` | Presente, **mas sem linhas** — **achado 6** |
| Outros | `role="group" aria-label="Trocar de semana"`, `aria-live="polite"` no `#maStatus`, `.ma-canto` com `aria-hidden="true"`, `maxlength=2000`, `spellcheck="true"` — tudo OK |

### 1.9 Regressões (login `cesar.bravo`)

| Verificação | Resultado |
|---|---|
| Avisos abrem | OK — `.aviso-row` abre a subpágina do aviso, com data, selo, corpo rico e "— César Bravo, Tabelião"; "← Todos os avisos" volta à lista. Captura `23` |
| "Ver todos os avisos" | OK |
| Bloco "Agenda Cn2o" com "Ver mais" | OK — `#blocoAgendaCn2o`, subtítulo "Agenda Cn2o", lista de aniversariantes e "Ver mais" → "Aniversariantes de setembro". Captura `24` |
| Botão "✎ Editar mural" (admin) | OK — visível só para o admin; abre "Editar o mural" com as abas Avisos · Aniversariantes · **Metas** · Equipe · Histórico · Consumo de IA (as metas continuam editáveis, como previsto). Captura `25` |
| Sino | OK — abre "Todos os avisos"; o `MutationObserver` do `#pillAvisos` segue ligado |
| Busca | OK — "analista" filtra para o cartão e-Analista |
| Cartão 05 "Em breve" | OK — `class="card em-breve em-breve-admin"`, selo "Em breve" visível |
| Menu "Agenda do Tabelião" | OK — abre a página embutida com o iframe do Google Agenda e marca `nav.ativo = calendario`. Captura `26` |
| "Metas" saiu do mural | OK — nenhuma ocorrência de "Metas" em `#paginaHub`; o menu lateral traz "Minha Agenda" no lugar |
| Erros de console | Nenhum além dos `ERR_FAILED` do Google Fonts bloqueado |

---

## 2. Achados

### Bloqueante

**1. Ao abrir a subpágina, toda anotação com mais de uma linha aparece cortada.**

*Seletor:* `#subConteudo .ma-campo` · *Arquivos:* `frontend/src/app.js:817–818` (causa),
`app.js:966–969` e `987` (efeito), `frontend/src/estilo-extra.css:1497` (`overflow:hidden`),
`frontend/src/estilo-base.css:248` (`.veu{display:none}`).

`abrirSub()` monta o HTML, chama `maAposAbrir(box)` — que roda `maAjustarAltura()` em cada
`textarea` — e **só depois** abre o véu:

```js
817    if (tipo === 'agenda') maAposAbrir(box);
818    el('veuMural').classList.add('aberto');
```

Enquanto `#veuMural` não tem `.aberto`, ele é `display:none` (estilo-base.css:248), logo
`ta.scrollHeight === 0` e `maAjustarAltura` grava `height: Math.max(40, 0) + 'px'` = **40 px**.
Com `.ma-campo{overflow:hidden}`, o resto do texto simplesmente **some da tela**.

*Evidência* (medido, 1366 px, pelos três caminhos de abertura — botão, dia do quadro e menu lateral):

| célula | caracteres | altura aplicada | altura necessária | cortado |
|---|---|---|---|---|
| 14/09 08h | 149 | **40 px** | 167 px | sim |
| 16/09 "Dia inteiro" | 31 | **40 px** | 59 px | sim |
| 16/09 09h | 49 | **40 px** | 81 px | sim |
| 17/09 10h | 23 | **40 px** | 59 px | sim |

A 400 px é pior: a mesma anotação de 149 caracteres precisa de **275 px** e mostra 40 px.
Prova da causa, no próprio navegador: com o véu fechado, `scrollHeight` da célula é `0` e
`getComputedStyle(veu).display === 'none'`. Trocar de semana (véu **já** aberto) devolve as
alturas certas — 59, 81, 167 px, nada cortado. Clicar na célula **não** conserta; só digitar
(evento `input`) conserta.

*Capturas:* `29-bug-celulas-cortadas-ao-abrir.png` e `31-bug-celulas-cortadas-400.png` (errado)
contra `30-celulas-corretas-apos-trocar-semana.png` e `07-subpagina-semana-hoje.png` (certo);
compare também `04` (ao abrir: "Prazo: ITBI da / matrícula 12.345" com a 2ª linha decepada) com `07`.

*Correção:* inverter as duas linhas em `abrirSub` — abrir o véu **antes** de chamar `maAposAbrir`:

```js
    el('veuMural').classList.add('aberto');
    if (tipo === 'agenda') maAposAbrir(box);
```

(As demais subpáginas não dependem de medição, então a troca é inócua para elas.) Como cinto e
suspensório, vale ainda trocar a linha 987 por `requestAnimationFrame(function(){ maAjustarAltura(ta); })`,
que também cobre o caso de a subpágina nascer com animação.

### Importante

**2. Abrir a agenda "num dia" não leva até esse dia em telas estreitas.** Mesma causa-raiz do
achado 1. `maAposAbrir` termina com `cab.scrollIntoView({block:'nearest', inline:'center'})`
(`app.js:1000–1003`), executado com o véu ainda `display:none` — não faz nada.
*Evidência:* a 400 px, clicando em **sexta 18/09** no quadro, a subpágina abre com
`.ma-rolagem.scrollLeft = 0` e a coluna de sexta fora da vista (`left 711` contra `right 370` da
caixa); rodando o mesmo `scrollIntoView` depois, à mão, o `scrollLeft` vai a 481 e a coluna aparece.
Captura `32-abrir-na-sexta-400-sem-rolar.png`.
*Correção:* a mesma do achado 1 resolve. Se preferir não mexer na ordem, envolver o trecho
1000–1003 em `requestAnimationFrame`.

**3. Sessão expirada durante um salvamento derruba a tela e perde a anotação, sem avisar.**
*Arquivos:* `app.js:124` (`if (r.status === 401 && !opcoes.semRedirecionar) sessaoExpirada();`),
`app.js:181–186`, `app.js:1049–1054`, `app.js:1033` (`semRedirecionar` só é ligado quando
`aoFechar` é verdadeiro — isto é, **nunca** no salvamento normal).
Com o servidor devolvendo 401 no `POST /hub/agenda`: a subpágina fecha na hora
(`fecharSubMural(true)`), aparece "Sua sessão expirou — entre de novo." e o texto digitado
**some do DOM**. `MA.pendentes` é limpo pelo ramo 401 do `catch`, de modo que nada mais é
retentado; entrando de novo, `maCarregarSemana(…, true)` apaga o resto (`MA.itens` da célula
volta `undefined`) e o servidor nunca recebeu nada. Conferido: depois de novo login,
`MA.itens['2026-09-18|13'] === undefined`, `GET /hub/agenda` sem a célula, e **nenhum aviso** ao
usuário de que uma anotação foi descartada. Captura `16-401-sessao-caida-texto-perdido.png`.
*Correção:* passar `semRedirecionar: true` também no salvamento normal da agenda e tratar o 401
na própria tela — manter `MA.pendentes[k]`, marcar a célula `.erro` e escrever no `#maStatus`
algo como *"Sua sessão expirou — entre de novo nesta aba para eu guardar esta anotação"*, só
chamando `sessaoExpirada()` depois que o usuário confirmar. No mínimo, guardar as pendências em
`localStorage` antes de `sessaoExpirada()` e reoferecê-las no próximo login.

**4. A prévia da anotação no quadro do mural fica abaixo do mínimo de notas e quebra no meio da
palavra.** *Seletores:* `.ma-item` (`estilo-extra.css:1447`, `font-size:14px`), `.ma-txt`
(`:1449`, `-webkit-line-clamp:2` + `overflow-wrap:anywhere`), e `@media(max-width:560px)`
(`:1455–1464`, `.ma-item{font-size:12.5px}`).
A regra da casa pede **≥ 16 px** para notas; a prévia é exatamente a nota do escrevente, a 14 px
(12,5 px no telefone). Pior: a coluna do dia mede **100 px** a 1366 px (79 px úteis para o texto)
e **55 px** a 400 px, e o `overflow-wrap:anywhere` corta **no meio da sílaba**. *Evidência:* captura
`33-quadro-mais-de-quatro.png` — "Atendime / nto Maria", "Assinatur / a —…", "Conferir /
matrícu…"; e `18-quadro-agenda-400.png` — "Praz / o:…", "Assi / na…", "Salvo / pela…", onde o
quadro deixa de informar qualquer coisa. Para um leitor com astigmatismo, palavra partida é o
pior caso de leitura.
*Correção:* subir `.ma-item` para 16 px (e ≥ 14,5 px no `@media` de 560 px); trocar
`overflow-wrap:anywhere` por `overflow-wrap:break-word; hyphens:auto` em `.ma-txt`, para só
partir quando não houver mesmo alternativa; e, a ≤ 560 px, considerar `-webkit-line-clamp:1` com
o `title`/`aria-label` completo, ou empilhar os dias em vez de manter 5 colunas de 55 px.

**5. Rótulos novos abaixo do mínimo de 13,5 px.** Todos medidos com `getComputedStyle` a 1366 px
(tema claro e escuro dão o mesmo resultado):

| Seletor | Linha (`estilo-extra.css`) | Valor | Onde aparece |
|---|---|---|---|
| `.ficha-ver-mini` | 1430 | **10,5 px** | "Ver mais" do bloco Agenda Cn2o |
| `.ma-mais` | 1452 | **11 px** | "+ 4 mais" |
| `.ma-cab-hoje` | 1490 | **11 px** | selo "hoje" no cabeçalho da coluna |
| `.ma-hora` | 1448 | **11,5 px** (10,5 a ≤ 560) | "09h" / "⚑" de cada anotação |
| `.ficha-legenda` | 1423 | **11,5 px**, contraste 4,16:1 | "DO TABELIÃO" e **"SEMANA DE 14 A 18 DE SETEMBRO"** |
| `.ma-tentar` | 1480 | **11,5 px** | botão "Tentar de novo" (aparece só no erro) |
| `.ma-dia-nome` | 1442 | **12 px** (10,5 a ≤ 560) | "SEG"…"SEX" |
| `.ma-btn` | 1470 | **12 px** | "← Semana anterior", "Hoje", "Semana seguinte →" |

O caso mais incômodo é `.ficha-legenda`: **não é enfeite**, é a informação de *qual semana* o
quadro está mostrando, a 11,5 px, maiúsculas, `letter-spacing:.2em` e contraste 4,16:1. Depois
dele, `.ma-btn` — os três botões de comando da subpágina — e `.ma-hora`, que diz a que horas é
cada compromisso. `.ma-dica` (13,5 px, 1454) está no limite, mas é uma frase inteira, não um
rótulo: merece 15 px.
*Correção:* levar todos a ≥ 13,5 px (sugestão: `.ficha-legenda` 13,5 px com
`letter-spacing:.12em`; `.ma-btn` 13,5 px; `.ma-hora` 13,5 px; `.ma-dia-nome` 13,5 px;
`.ma-mais`, `.ma-cab-hoje` e `.ma-tentar` 13,5 px) e refazer as reduções do `@media(max-width:560px)`
a partir desse piso.

**6. `role="grid"` sem nenhuma linha (`role="row"`).** *Arquivo:* `app.js:933–952`.
A grade declara `role="grid"` e pendura **84 filhos diretos** — o canto sem papel
(`aria-hidden="true"`), 5 `columnheader`, 13 `rowheader` e 65 `gridcell` — sem nenhum
`role="row"` entre eles (`querySelectorAll('[role="row"]').length === 0`,
conferido também na árvore de acessibilidade do Chromium: `{grid:1, columnheader:5, rowheader:13,
gridcell:65}` e nenhum `row`). A ARIA exige `grid → row → gridcell`; sem as linhas, o modo tabela
do leitor de tela não anuncia "linha 3, coluna 2" nem navega por setas. O estrago é atenuado
porque cada `textarea` carrega um `aria-label` completo ("quarta-feira 16/09 — 09h"), mas o papel
declarado mente sobre a estrutura — o que é pior do que não declarar papel nenhum.
*Correção (mantendo o layout):* envolver cada faixa num `<div role="row" style="display:contents">`
— `display:contents` deixa os filhos participando da mesma grade CSS — e fazer o mesmo com a
fileira de cabeçalhos; opcionalmente acrescentar `aria-rowindex`/`aria-colindex`. Alternativa
mais simples: remover `role="grid"`, `rowheader`, `columnheader` e `gridcell` e confiar apenas
nos `aria-label`, que já são bons.

### Cosmético

**7. `.ma-livre` com contraste 3,02:1.** `estilo-extra.css:1453` —
`color:rgba(32,42,58,.5)`, 13,5 px itálico (11,5 px a ≤ 560 px), composto sobre o cartão dá
`rgb(142,148,156)` sobre `rgb(253,253,254)` = **3,02:1**, abaixo de 4,5:1. É o texto "livre" e
"nada anotado para hoje", que aparece na maioria das colunas na maior parte do tempo.
*Correção:* `rgba(32,42,58,.62)` (≈ 4,6:1) e 14 px.

**8. `.ma-mais` com contraste 4,02:1.** `estilo-extra.css:1452` — `rgba(32,42,58,.6)` a 11 px
dá `rgb(121,127,137)` sobre branco = 4,02:1. É o "+ 4 mais", justamente o aviso de que há coisa
escondida. *Correção:* `rgba(32,42,58,.72)` e 13,5 px (junto do achado 5).

**9. `.ma-ajuda` a 14,5 px.** `estilo-extra.css:1481`. São três linhas de instrução — texto de
leitura, não rótulo —, e a régua da casa para caixa de leitura é 18 px. Contraste 7,57:1 está bom.
*Correção:* 16–18 px (o parágrafo tem largura de sobra na subpágina, que vai a 1180 px).

**10. Célula com retentativas esgotadas volta como `.pendente` ao reabrir a subpágina.**
`app.js:949` monta o `textarea` com `(MA.pendentes[k] ? ' pendente' : '')` e nunca com `' erro'`,
embora `MA.tentativas[k] > 6` já tenha marcado aquela célula como erro antes. *Evidência:* com a
rota bloqueada e as 7 tentativas esgotadas (célula `ma-campo tem erro`), fechar e reabrir a
subpágina devolve `class="ma-campo tem pendente"` — borda tracejada cinza em vez da vinho — ainda
que o `#maStatus` continue, corretamente, com "Tentar de novo". *Correção:* em `maHtmlSub`,
acrescentar `((MA.tentativas[k] || 0) > 6 ? ' erro' : '')`.

**11. Ternário sem efeito em `maRenderCard`.** `app.js:924` —
`total + (total > 1 ? ' esta semana' : ' esta semana')`: os dois ramos são idênticos. Não quebra
nada (o texto sai certo nos dois casos), mas sinaliza uma concordância que se pretendia fazer e
ficou pela metade. *Correção:* remover o ternário, ou usar o singular quando `total === 1`
("● 1 anotação esta semana").

**12. O realce de coluna pinta a faixa inteira, que fica mais alta que o campo.**
`estilo-extra.css:1495–1496` (`.ma-cel.hoje`, `.ma-cel.alvo`) pintam a célula da grade; quando
outra célula da mesma faixa cresce, a faixa toda cresce e sobra um bloco rosado abaixo do campo
vazio da coluna de hoje. Visível na captura `07` (faixas 10h e 11h). *Correção:* mover o realce
para o próprio `.ma-campo` (`.ma-cel.hoje .ma-campo{background:…}`) ou dar
`align-items:start` às células da grade.

---

## 3. Capturas (`docs/auditoria-v1.32/`)

| Arquivo | O que mostra |
|---|---|
| `01-mural-1366x900.png` | Mural inteiro a 1366×900 |
| `02-mural-dois-quadros-1366.png` | Os dois quadros a 1366: tons, alfinetes, inclinação, hoje (qua 16) em vinho |
| `03-mural-1920x1080.png` | Mural a 1920×1080 |
| `27-mural-dois-quadros-1920.png` | Os dois quadros a 1920 |
| `04-subpagina-agenda-1366.png` | Subpágina aberta pelo botão — **anotações cortadas (achado 1)** |
| `05-subpagina-dia-alvo-sexta.png` | Aberta pela sexta 18/09: `.alvo` no cabeçalho e nas células |
| `06-subpagina-salvo.png` | Depois de digitar: `✓ Salvo às HHhMM` |
| `07-subpagina-semana-hoje.png` | Depois de navegar semanas: alturas corretas (contraprova do achado 1) e o realce da faixa (achado 12) |
| `08-quadro-atualizado.png` | Quadro do mural com a coluna de ter 15/09 atualizada após o Escape |
| `09-xss-literal-no-quadro.png` | `<img src=x onerror=alert(1)>` literal no quadro |
| `10-agenda-cesar-vazia.png` | Grade do Tabelião: vazia (isolamento) |
| `11-agenda-camily-so-dela.png` | Grade da escrevente: só as anotações dela |
| `12-erro-salvando-tentando.png` | Falha de rede: célula `.pendente` e "Vou tentar de novo em instantes…" |
| `13-erro-tentar-de-novo.png` | 7 tentativas esgotadas: célula `.erro` e botão "Tentar de novo" |
| `14-recuperado-apos-liberar.png` | Rota liberada + "Tentar de novo": `✓ Salvo` |
| `15-erro-500-insiste.png` | Erro 500: continua insistindo |
| `16-401-sessao-caida-texto-perdido.png` | **Achado 3** — 401 no meio do salvamento: volta ao login e o texto some |
| `17-mural-400x860.png` | Mural a 400×860, página inteira, sem rolagem horizontal |
| `18-quadro-agenda-400.png` | **Achado 4** — prévias ilegíveis a 400 px |
| `19-subpagina-400-rolagem.png` | Subpágina a 400 px: grade rolando por dentro, coluna das horas sticky |
| `20-tema-escuro-mural.png` | Tema escuro, mural inteiro |
| `21-tema-escuro-quadros.png` | Tema escuro: quadros continuam claros e legíveis |
| `22-tema-escuro-subpagina.png` | Tema escuro: subpágina da agenda |
| `23-regressao-aviso-aberto.png` | Regressão: aviso abre |
| `24-regressao-aniversariantes.png` | Regressão: "Ver mais" do bloco Agenda Cn2o |
| `25-regressao-editor-mural.png` | Regressão: "✎ Editar mural" (admin) com as 6 abas |
| `26-regressao-agenda-tabeliao.png` | Regressão: "Agenda do Tabelião" embutida |
| `28-foco-visivel-dia.png` | Foco de teclado num dia do quadro (outline vinho de 3 px) |
| `29-bug-celulas-cortadas-ao-abrir.png` | **Achado 1** — ao abrir, células presas em 40 px |
| `30-celulas-corretas-apos-trocar-semana.png` | **Achado 1, contraprova** — com o véu já aberto, alturas certas |
| `31-bug-celulas-cortadas-400.png` | **Achado 1** a 400 px (precisa 275 px, mostra 40 px) |
| `32-abrir-na-sexta-400-sem-rolar.png` | **Achado 2** — abre na sexta, mas a coluna fica fora da vista |
| `33-quadro-mais-de-quatro.png` | **Achado 4** — "+ 4 mais" e palavras partidas no meio |
