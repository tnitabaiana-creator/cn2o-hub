# 09 · Guia de ITBI — especificação (v1.33)

Ferramenta interna do Hub CN2O que monta a **guia de ITBI da Prefeitura Municipal de
Itabaiana-SE** no layout oficial e devolve um **PDF pronto para imprimir e assinar**.

* Rota: `#itbi` · página `#paginaItbi` · cartão `#cardItbi` (09, chip **PDF**).
* **Nada vai ao servidor.** Não há endpoint, não há gravação: os dados vivem só na
  memória da página; sair da ferramenta ou apertar **Limpar** apaga tudo.
* Arquivos: `frontend/src/itbi.js` (formulário + desenho da guia),
  `frontend/src/pdf-mini.js` (escritor de PDF sem dependência),
  bloco `v1.33 — GUIA DE ITBI` no fim de `frontend/src/estilo-extra.css`.
* Modelo de referência: `docs/FORMULARIO-ITBI-modelo-prefeitura.docx` / `.pdf` e
  `docs/itbi-modelo/modelo-prefeitura.png`. Exemplo gerado:
  `docs/itbi-modelo/exemplo-gerado.pdf`.

---

## 1. Campos

Todos os campos são de texto livre, salvo onde se diz "chips" (escolha única).

### 1 – Adquirente(s) · 2 – Transmitente(es)
Seletor **“Quantas pessoas?”** com 1 · 2 · 3 · 4. Cada pessoa abre um bloco próprio
(*Adquirente 1*, *Adquirente 2*, …) com:

| campo | obrigatório | “não consta” | padrão |
|---|---|---|---|
| Nome completo | **sim** (único obrigatório) | não | — |
| CPF / CNPJ | não | sim | — |
| RG / CNH | não | sim | — |
| **Profissão** (acréscimo pedido pelo Tabelião) | não | sim | — |
| Endereço | não | sim | — |
| Município | não | sim | `ITABAIANA/SE` |
| CEP | não | sim | — |

### 3 – Imóvel
Inscrição cadastral · Logradouro · Complemento · Município (`ITABAIANA/SE`) · CEP ·
Área do terreno (m²) · Testadas · **Situação** (chips: Proprietário · Possuidor ·
Enfiteuse · Almas · Outra + texto) · Área útil (m²) · Área total construída (m²) ·
Fração ideal · **Tipo** (chips: Casa · Apartamento · Galpão · Terreno · Sala · Outro +
texto). Todos com “não consta”.

### 4 – Operação
**Natureza** (chips: Escritura pública de compra e venda *(padrão)* · Dação em
pagamento · Permuta · Cessão de direitos · Integralização de capital · Arrematação ou
adjudicação · Outra + texto) · Entidade financiadora · **Valor atribuído pelo
contribuinte** (campo R$ com máscara pt-BR ao digitar) · Outras informações.
Natureza, financiadora e outras informações têm “não consta”; o **valor** tem, no
lugar dele, o botão **“Não declarado”**.

### 5 – Documentação
Cartório do registro (padrão `1º Ofício de Itabaiana`) · Matrícula — ambos com
“não consta” — e **Nº da guia (opcional)**.

### 6 – Observações
Textarea livre, sem “não consta”.

---

## 2. Regras de “não consta”

* Botão-alternância ao lado de **cada campo**, com três exceções deliberadas:
  * **os nomes** — são o dado que identifica a parte; sem nome não há guia;
  * **as observações** — texto livre, em branco é em branco;
  * **o nº da guia** — é numeração da própria Prefeitura, não sai dos documentos;
    em branco, a guia imprime a linha `__________` para preencher à mão.
* Ligado: o campo é **desabilitado**, o valor digitado fica guardado em
  `dataset.antes`, o campo passa a mostrar `NÃO CONSTA` como *placeholder* e a guia
  imprime **NÃO CONSTA**.
* Desligado: o campo volta a ser editável **com o valor anterior**.
* Em grupos de chips (situação, tipo, natureza) o botão desabilita os chips e o campo
  “Outra”.
* **Campo vazio sem “não consta” sai em branco na guia**, como no modelo da Prefeitura.
* O botão **“Não declarado”** faz o mesmo com o valor do negócio e imprime
  **NÃO DECLARADO**.

### Conferência antes de gerar
Ao clicar em **Gerar guia (PDF)**:
* se **nenhum adquirente** ou **nenhum transmitente** tem nome → o painel
  `#itbiConferencia` mostra *“Falta o essencial”* e **só** oferece *Voltar e completar*
  (é o único bloqueio);
* se há campos em branco → o painel lista cada um (“RG / CNH — adquirente 2”,
  “CEP do imóvel”…), cada item é um botão que rola e foca o campo, com
  **Gerar assim mesmo** e **Voltar e completar**;
* se não há nada em branco → gera direto.

### Saída
* `window.open(URL.createObjectURL(blob))` **dentro do clique** → a guia abre em aba nova.
* Botão **Baixar**: `<a download="Guia-ITBI-<primeiro nome do adquirente>-<aaaa-mm-dd>.pdf">`.
* Estado: *“Guia gerada às HHhMM · 1 página”*.
* Para os testes: `window.ITBI_ULTIMO_PDF` (Uint8Array) e `window.ITBI_ULTIMO_INFO`
  (texto-resumo com páginas, corpo em pt e nº de partes).
* **Limpar** zera campos, alternâncias, chips, contagem de pessoas, o painel, o botão
  Baixar e as duas variáveis, e revoga o object URL.

---

## 3. Algoritmo de encaixe (caber em uma página)

Papel **A4 retrato** (595,28 × 841,89 pt), margens de **11 mm**, tabela de **188 mm**,
traço de **0,35 mm**, área útil de **275 mm**.

A guia é montada como uma lista de **blocos** `{altura, desenhar(pdf, y)}`: cabeçalho,
faixas de seção (fundo `#A6A6A6`, texto em negrito), linhas de 1 a 4 células, os dois
sub-títulos do quadro 3 e os três blocos de altura fixa (documentação/assinatura,
avaliação, observações).

Antes de desenhar, a mesma montagem roda **em degraus**, do maior para o menor, até
a soma das alturas caber nos 275 mm:

| degrau | corpo | fator dos blocos fixos |
|---|---|---|
| 1 | 10 pt | 1,0 |
| 2 | 9,5 pt | 0,8 |
| 3 | 9 pt | 0,6 |
| 4 | 8,5 pt | 0,4 |
| 5 | 8 pt | 0,2 |
| 6 | 7,5 pt | 0,0 |

Os blocos de altura fixa encolhem junto, por interpolação com esse fator:

* cabeçalho **22 → 17 mm**;
* documentação + assinatura **34 → 26 mm**;
* avaliação **24 → 19 mm**;
* observações **18 → 11 mm** (cresce sozinho se o texto pedir mais).

Alturas derivadas do corpo: linha de texto `1,20 × corpo`, respiro da célula
`0,26 × corpo` em cima e embaixo, faixa de seção `1,45 × corpo`.

Se **mesmo a 7,5 pt** não couber (4 + 4 partes com endereços longos, por exemplo), a
guia segue para uma **segunda página**: a quebra é **entre blocos** (nunca no meio de
um) e uma faixa de seção nunca fica órfã no pé da página — ela desce junto com o
bloco seguinte.

Dentro de cada célula, o rótulo sai em **negrito** e o valor continua na mesma linha;
se não couber, o rótulo quebra em linhas e o valor desce — nada transborda a célula.
Endereço, outras informações e observações quebram automaticamente. A célula do nome
sai em **negrito e caixa alta**; com mais de uma pessoa no polo, a linha do nome
ganha o prefixo **`ADQUIRENTE n:`** / **`TRANSMITENTE n:`**.

---

## 4. Formato do PDF (pdf-mini.js)

Escritor próprio, sem npm e sem CDN — o Hub é um único `index.html`.

* `new PDFMini({pagina:'A4'})`; API em **mm**, origem no **canto superior esquerdo**;
  o `y` de `texto()` é a **linha de base**.
* Métodos: `fonte(negrito, tamanhoPt)`, `larguraTexto(str[, negrito, tamanho])`,
  `quebrar(str, larguraMm)`, `texto(x, y, str, {alinhar, larguraMm, cor})`,
  `linha(x1,y1,x2,y2,{espessura,cor})`,
  `retangulo(x,y,w,h,{preencher,borda,espessura,corBorda})`,
  `imagemJpeg(base64,x,y,w,h)`, `novaPagina()`, `totalPaginas()`, `bytes()`, `blob()`.
* Fontes **Helvetica** e **Helvetica-Bold** (Standard 14, **não embutidas**),
  `/Encoding /WinAnsiEncoding`. O texto é convertido para **cp1252** (Latin-1 mais os
  pontos 0x80–0x9F: – — “ ” ‘ ’ … € •); `\ ( )` são escapados; caractere fora da
  tabela vira `?`.
* **Larguras**: duas tabelas de 256 entradas (índice = código WinAnsi) geradas dos AFM
  oficiais da Adobe (`Helvetica.afm`, `Helvetica-Bold.afm`, campo `WX` por nome de
  glifo).
* **Imagem**: o brasão de Itabaiana entra como **JPEG** (fundo branco, qualidade 92,
  186 × 210 px) embutido em base64 dentro de `itbi.js`, e no PDF como XObject
  `/Filter /DCTDecode /ColorSpace /DeviceRGB` (as dimensões saem do marcador SOF).
* O arquivo é montado **em bytes** (`Uint8Array`), com a tabela `xref` em deslocamentos
  reais — nada de `String.length` em texto não-ASCII.
* PDF 1.4, um objeto de conteúdo por página, recursos compartilhados.

**m² e m³**: o `itbi.js` desenha o expoente à parte, menor e elevado (0,68 × corpo),
porque nem todo substituto de Helvetica traz o glifo `twosuperior`. O texto extraído
continua sendo `m²`.

---

## 5. Assinatura e quadros fixos

* Quadro 5, à direita: o atesto do modelo, `DATA: dd.mm.aaaa` (hoje), a linha de
  assinatura com **“Assinatura do Tabelião ou Escrevente”** e, **sob ela, o nome e o
  cargo de quem está logado** (`SESSAO.nome` / `SESSAO.cargo`); ao lado, o quadro
  emoldurado `CARTÓRIO DE NOTAS DO 2º OFÍCIO / Avenida Ivo de Carvalho, n. 441 /
  Itabaiana-Sergipe / César Bravo / Tabelião`, com o corpo ajustado para caber.
* Quadro **6 – AVALIAÇÃO** sai **em branco**: é uso da C.C.I. da Prefeitura
  (ALÍQUOTA, Imposto a pagar, Valor Tributável, Data, Avaliador, Visto do Chefe).
* `GUIA DE ITBI Nº` imprime o número digitado ou a linha `__________`.

Nada é inventado: **NÃO CONSTA** / **NÃO DECLARADO** quando marcado, branco quando
branco.
