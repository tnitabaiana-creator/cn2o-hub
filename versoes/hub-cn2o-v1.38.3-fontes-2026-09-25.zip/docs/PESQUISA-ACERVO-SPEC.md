# 10 · Pesquisa / Acervo — especificação (v1.33)

Ferramenta interna do Hub CN2O que pesquisa no **acervo da serventia**: os **livros**
(onde cada um está guardado, se já foi digitalizado, o que falta conferir) e os **atos
lavrados** (livro, folhas, data, partes, objeto e o arquivo digital).

* Rota: `#acervo=antigo1` / `#acervo=cn2o` (`#acervo` sozinho abre o último escolhido) ·
  página `#paginaAcervo` · cartão `#cardAcervo` (10, chip **Acervo**).
* **Dois submódulos**, um por planilha do Google Sheets do Tabelião — cópias do mesmo
  modelo **“PAINEL DO ACERVO DE LIVROS”**, na conta `tnitabaiana@gmail.com`:

| fonte | submódulo (aba na tela) | planilha | id |
|---|---|---|---|
| `antigo1` | **Acervo Antigo · 1º Ofício** — incorporado ao acervo do CN2O | `Acervo 1º Ofício (Antigo ) - SÉRGIO` | `1GZtzzB2FqfnQKR18gUJ2ZKfBalhPk8riC9PZNpRVpR8` |
| `cn2o` | **Acervo · 2º Ofício** — antigo e atual *(padrão)* | `Acervo 2º Ofício (Antigo e Atual) - MILVO` | `1ZM3sEt1cCqkfvZgLQfJf0q-Zx-AVUuwRMdMvEI5OErQ` |

* As planilhas são **privadas** (regra da casa: compartilhar por conta, nunca por link),
  então **o site não as lê**: quem lê é o servidor (Railway), por um **Apps Script
  publicado como web app** na conta dele — o mesmo padrão da ponte do Google Docs
  (`backend/docs.js`). **Uma só implantação** atende as duas planilhas.
* Enquanto a ponte não for configurada, a ferramenta **existe inteira** e diz, com todas
  as letras, que a fonte ainda não foi vinculada. Nada quebra, nada dá erro.
* A fonte escolhida vai para a URL e é lembrada na aba (`sessionStorage`,
  chave `cn2o_acervo_fonte`) — é preferência de tela, não é dado de ninguém.
* Arquivos:
  * `frontend/src/corpo.html` — cartão 10 e a página `#paginaAcervo`
  * `frontend/src/app.js` — rotas `acervo` / `acervo=<fonte>`, clique do cartão e o bloco
    `10 · PESQUISA / ACERVO` no fim do arquivo
  * `frontend/src/estilo-extra.css` — blocos `v1.33 — PESQUISA / ACERVO` e
    `v1.33 — PESQUISA / ACERVO · DOIS SUBMÓDULOS` no fim
  * `backend/acervo.js` — ponte, mapeamento das duas abas e filtros
  * `backend/hub.js` — rotas `GET /hub/acervo/status` e `GET /hub/acervo`
  * `docs/apps-script/LeitorAcervo.gs` — o web app (com o passo a passo de implantação)
  * `teste/acervo-falso.js` — fake do web app (porta 3996) com as duas planilhas
  * `teste/e2e-acervo-passo.py` — cópia de referência do passo `pesquisa_acervo()`
    (já colado em `teste/e2e.py`, depois do passo `guia_itbi`)
  * `docs/auditoria-v1.33-acervo/` — capturas (claro, escuro, telefone, não vinculada)

---

## 1. As duas abas que entram na pesquisa

De cada planilha o Hub lê **duas abas** — e só elas. PAINEL, BUSCA, MOVIMENTACOES,
MAPA_FISICO, LISTAS, CHECKLIST e AJUDA são ignoradas.

### CADASTRO_LIVROS — os livros físicos
`ID_LIVRO · TIPO DE LIVRO · Nº DO LIVRO · CÓDIGO INTERNO · STATUS DO LIVRO · SALA/ARQUIVO ·
ESTANTE · PRATELEIRA · CAIXA/PASTA · LOCALIZAÇÃO COMPLETA · DIGITALIZADO? ·
LINK PASTA DIGITAL · PENDÊNCIA? · OBSERVAÇÕES · CHAVE DE BUSCA · ALERTA · MATCH_BUSCA`

### INDICE_ATOS — os atos lavrados
`ID_ATO · ID_LIVRO · TIPO DE ATO · DATA DO ATO · Nº DO LIVRO · FOLHA/INÍCIO · FOLHA/FIM ·
Nº DO ATO · PARTE 1 / OUTORGANTE · CPF/CNPJ PARTE 1 · PARTE 2 / OUTORGADO ·
CPF/CNPJ PARTE 2 · OBJETO/IMÓVEL · MATRÍCULA/REGISTRO · VALOR DO ATO/NEGÓCIO ·
TRIBUTO/GUIA · LINK DIGITAL · OBSERVAÇÕES · CHAVE DE BUSCA`

> Hoje a INDICE_ATOS das duas planilhas **só tem o cabeçalho** — a equipe vai preenchendo.
> Nesse estado o grupo “Atos” mostra: *“Nenhum ato indexado ainda nesta planilha — a aba
> INDICE_ATOS vai sendo preenchida pela equipe.”*

**CHAVE DE BUSCA, ALERTA e MATCH_BUSCA** são auxiliares da planilha: não viram coluna na
tela — aparecem só dentro do **“mais…”** de cada linha (como qualquer coluna que o Hub não
conheça). A pesquisa por “qualquer palavra” continua olhando para elas.

---

## 2. Campos da pesquisa

Todos opcionais e combináveis (E lógico). **Enter em qualquer campo pesquisa.**
Sem nenhum filtro, vêm os livros e os atos daquele acervo inteiro.

| campo | id | onde filtra | como se pesquisa |
|---|---|---|---|
| **Nº do livro** | `acvLivro` | livros **e** atos | número exato (`10` e `L-010` dão no mesmo; `1` não acha o `10`) |
| **Tipo de livro** (chips) | `#acvTipos` | só **livros** | pedaço do nome, sem acento/caixa. Valores da aba LISTAS: Notas · Procurações · Substabelecimentos · Revogações · Ata Notarial · Testamentos · Escrituras Diversas · Compra e Venda · Inventário/Partilha · Reconhecimento/Sinal Público · Outros. Clicar de novo desmarca |
| **Folhas** | `acvFolhas` | só **atos** | `12` ou faixa (`12-15`, `12 a 15`); casa quando as faixas **se cruzam** |
| **Nome das partes** | `acvPartes` | só **atos** | todas as palavras, sem acento, em qualquer ordem; **vírgula exige os dois nomes** |
| **Data — de / até** | `acvDe` / `acvAte` | só **atos** | `input type="date"`; casa quando o período cruza a data do ato |
| **… ou só o ano** | `acvAno` | só **atos** | `2025` = 01/01 a 31/12 daquele ano |
| **Tipo de ato** | `acvAto` | só **atos** | pedaço do nome (`compra` acha “Escritura de compra e venda”); `datalist` com os atos da casa |
| **Qualquer palavra** | `acvTexto` | livros **e** atos | todas as palavras, em **todas** as colunas — inclusive as auxiliares |

**Grupo que sai de cena.** Folhas, partes, data e tipo de ato são do **ato**; tipo de livro
é da **prateleira**. Quando a pesquisa usa só filtros de um lado, o outro grupo não é
listado — aparece uma nota explicando (em vez de despejar o acervo inteiro ao lado). Basta
juntar o **nº do livro** ou **qualquer palavra** para os dois grupos voltarem.

### Resultado — dois grupos

* **Livros**: Tipo · Nº · Código · Status · Localização (sala · estante · prateleira ·
  caixa) · Digitalizado (selo Sim/Parcial/Não) · **Pasta digital** (botão quando há link) ·
  Pendência / Obs. em **“mais…”**.
* **Atos**: Livro · Folhas · Data · Ato · Partes · **Arquivo** (botão *Abrir no Drive*) ·
  Observações, com Nº do ato, objeto/imóvel, matrícula, valor, tributo e CPF dentro do
  **“mais…”**.
* Cada grupo tem a sua contagem (`37 atos encontrados · mostrando 50 primeiros`) e o seu
  **Mostrar mais 50**.
* Os trechos que casaram saem em `<mark>` na linha inteira — realce feito no navegador,
  comparando sem acento e **escapando o texto antes**.
* Ordem: livros por tipo e nº; atos por livro e folhas.

### Estados da tela

| estado | o que aparece |
|---|---|
| **fonte não vinculada** | quadro pastel no alto: *“O índice do acervo ainda não foi vinculado ao Hub. Quando o Tabelião indicar a planilha do Google Sheets, a pesquisa passa a funcionar aqui mesmo.”* Campos e chips **continuam habilitados** e **Pesquisar devolve o mesmo recado** |
| **vinculada** | *“Índice vinculado. N livros catalogados · N atos indexados · lido em dd/mm às HHhMM”* + o nome do arquivo da planilha |
| **carregando** | `htmlProgresso` — relógio, barra e segundos |
| **erro do servidor** | *“Não consegui pesquisar agora.”* + a frase humana da ponte |
| **nenhum resultado** | por grupo: *“Nenhum livro/ato com esses filtros — tente menos filtros.”* |
| **INDICE_ATOS vazia** | *“Nenhum ato indexado ainda nesta planilha — a aba INDICE_ATOS vai sendo preenchida pela equipe.”* |

### Legibilidade (regra da casa — astigmatismo do Tabelião)

Abas dos submódulos, chips de tipo de livro, células e campos em **16 px ou mais**;
cabeçalhos de tabela e rótulos em **13,5 px ou mais**, em Montserrat; paleta só **vinho
#631325**, **marinho #202a3a** e **branco** (+ transparências); sem cinza-claro, sem
serifada; foco sempre visível. Em **400 px** não há rolagem horizontal: as abas empilham e
cada linha das duas tabelas vira um **cartão** com o nome da coluna à esquerda.

---

## 3. Rotas do servidor

Ambas exigem sessão (`X-Auth-Token`), como todo o resto do Hub. `fonte` inválida ou
ausente cai no padrão (`cn2o`) — nunca em erro.

### `GET /hub/acervo/status?fonte=antigo1|cn2o`
```json
{ "vinculado": true, "fonte": "cn2o",
  "fontes": [ { "chave": "antigo1", "rotulo": "…", "titulo": "…" }, { "chave": "cn2o", … } ],
  "planilha": "Acervo 2º Ofício (Antigo e Atual) - MILVO",
  "atualizado_em": "2026-09-16T12:00:00.000Z",
  "livros_total": 145, "atos_total": 0, "atos_vazio": true, "total": 145 }
```
Sem a ponte configurada: `vinculado:false` com tudo zerado — **200, não erro**.

### `GET /hub/acervo?fonte=&livro=&tipo_livro=&folhas=&partes=&de=&ate=&ato=&texto=&pagina_livros=&pagina_atos=`
```json
{ "vinculado": true, "fonte": "cn2o", "planilha": "…", "atualizado_em": "…",
  "atos_vazio": false, "totais": { "livros": 145, "atos": 37 },
  "livros": { "total": 3, "pagina": 1, "paginas": 1, "por_pagina": 50, "omitido": false,
              "itens": [ { "id": "LIV-0001", "tipo": "Compra e Venda", "numero": "10",
                           "codigo": "CV-010", "status": "Em uso", "sala": "Acervo principal",
                           "estante": "E01", "prateleira": "P01", "caixa": "",
                           "localizacao": "…", "digitalizado": "Não", "pendencia": "Não",
                           "link": "", "obs": "", "extra": { "CHAVE DE BUSCA": "…" } } ] },
  "atos":   { "total": 2, "pagina": 1, "paginas": 1, "por_pagina": 50, "omitido": false,
              "itens": [ { "id": "AT-0001", "id_livro": "LIV-0001", "livro": "10",
                           "folhas": "12 a 15", "numero_ato": "021", "data": "03/02/2025",
                           "data_br": "03/02/2025", "ato": "Escritura de compra e venda",
                           "partes": "Fulano × Beltrano", "cpf1": "…", "cpf2": "…",
                           "objeto": "…", "matricula": "35.471", "valor": "R$ 250.000,00",
                           "tributo": "ITBI 2025/1234", "link": "https://drive.google.com/…",
                           "obs": "…", "extra": {} } ] } }
```
* No máximo **50 itens por grupo por página**; `pagina_*` além do fim volta à última.
* `omitido: true` = aquele grupo não faz sentido para os filtros usados (ver acima).
* Falha real da ponte (fora do ar, segredo trocado, resposta que não é JSON): **502** com
  `{ "erro": "Acervo: …" }`. **O segredo nunca entra em log.**
* `?atualizar=1` refaz a leitura daquela fonte ignorando o cache — **só para o Tabelião**
  (admin); para os demais é ignorado em silêncio. Na tela é o botão **Reler a planilha**.

---

## 4. Contrato com o Apps Script

```
→ POST …/exec   text/plain;charset=utf-8   { "segredo": "…", "versao": 2, "fonte": "cn2o" }
← 302 → GET     { "ok": true, "fonte": "cn2o", "planilha": "<nome do arquivo>",
                  "atualizado_em": "…",
                  "livros": { "aba": "CADASTRO_LIVROS", "colunas": [...], "linhas": [[...]] },
                  "atos":   { "aba": "INDICE_ATOS",     "colunas": [...], "linhas": [[...]] } }
                { "ok": false, "erro": "segredo inválido" }
```

**Por que o segredo vai no corpo do POST** (e não no header `X-Acervo-Segredo` nem na
query): é o caminho já provado pela ponte do Docs; o Apps Script lê `e.postData.contents`
sem depender de headers personalizados (que se perdem no 302 para
`script.googleusercontent.com`); e o segredo não aparece em URL, em log de proxy nem no
`Location`. O `text/plain` evita o *preflight* que o Apps Script não responde.

`versao: 1` (planilha única, `{ colunas, linhas }`) continua aceita pelos dois lados: no
`acervo.js` ela vira a aba de **atos**.

**As abas** são achadas pelo NOME (`CADASTRO_LIVROS`, `INDICE_ATOS`) e, se a planilha usar
outro nome, pelo **cabeçalho**: a aba cuja primeira linha tem `Nº DO LIVRO` e
`TIPO DE LIVRO` é a dos livros; a que tem `PARTE 1` (ou `Nº DO ATO`) é a dos atos. As
propriedades opcionais `ABA_LIVROS` / `ABA_ATOS` forçam um nome.

**Valores**: datas saem como `dd/mm/aaaa` no fuso da planilha (nada de ISO com fuso
trocado); números formatados saem como aparecem na célula (`R$ 250.000,00`); caixas de
seleção viram `Sim`/`Não`; texto clicável e `=HYPERLINK(...)` viram a URL (é dela que saem
os botões **Pasta digital** e **Abrir no Drive**). A primeira linha de cada aba é o
cabeçalho; linhas totalmente vazias são descartadas.

### Mapeamento tolerante de colunas

O papel de cada coluna é descoberto pelo **nome normalizado** (sem acento, sem caixa, sem
pontuação), primeiro por nome exato e depois por começo do nome. Uma coluna só cumpre um
papel (a primeira que casa vence) e **tudo o que sobra vai para `extra`**, que a tela
mostra no “mais…”. Acrescentar colunas às planilhas nunca quebra nada.

| papel (livros) | nomes que valem |
|---|---|
| `id` | id livro, id |
| `tipo` | tipo de livro, tipo, espécie de livro, natureza do livro |
| `numero` | nº do livro, número do livro, livro, nº livro |
| `codigo` | código interno, código, cod |
| `status` | status do livro, status, situação |
| `sala` / `estante` / `prateleira` / `caixa` | sala/arquivo, estante, prateleira, caixa/pasta, pasta |
| `localizacao` | localização completa, localização, local |
| `digitalizado` | digitalizado?, digitalizada, digitalização |
| `link` | link pasta digital, pasta digital, link, url, drive — **ou** qualquer coluna cujos valores comecem com `http` |
| `pendencia` | pendência?, pendências, pendente |
| `obs` | observações, observação, obs, anotações, nota(s) |

| papel (atos) | nomes que valem |
|---|---|
| `id` / `id_livro` | id ato, id · id livro |
| `ato` | tipo de ato, ato, tipo, natureza, espécie |
| `data` | data do ato, data da lavratura, data |
| `livro` | nº do livro, número do livro, livro |
| `folha_inicio` / `folha_fim` | folha/início, folha inicial · folha/fim, folha final |
| `folhas` | folhas, folha, fls, fl (quando não houver início/fim) |
| `numero_ato` | nº do ato, número do ato |
| `outorgante` / `outorgado` | parte 1 / outorgante, parte 1, outorgante · parte 2 / outorgado, parte 2, outorgado — **juntados com “ × ”** |
| `cpf1` / `cpf2` | cpf/cnpj parte 1 · cpf/cnpj parte 2 |
| `partes` | partes, nome das partes, interessados (quando houver uma coluna única) |
| `objeto` / `matricula` / `valor` / `tributo` | objeto/imóvel · matrícula/registro · valor do ato/negócio · tributo/guia |
| `link` | link digital, link, arquivo, url — **ou** coluna com valores `http` |
| `obs` | observações, obs, anotações |

### Formatos aceitos nos valores

* **Folhas** — `12`, `12-15`, `12 a 15`, `fls. 30 a 34`, `12v a 15v`: valem o menor e o
  maior número da célula (ou o par FOLHA/INÍCIO + FOLHA/FIM).
* **Data** — `dd/mm/aaaa`, `aaaa-mm-dd` (com ou sem hora), `dd/mm/aa`, `mm/aaaa`,
  `aaaa-mm`, só `aaaa` e “12 de setembro de 2025”. Mês ou ano sozinhos valem como o
  período inteiro. Ato **sem data legível** não entra quando há filtro de data.
* **Link** — só `http://` ou `https://` sem espaços nem aspas vira botão; o resto sai `—`.

---

## 5. Variáveis e propriedades

**Railway (backend):**

| variável | para que serve |
|---|---|
| `HUB_ACERVO_WEBAPP_URL` | URL do web app (`…/exec`). **Sem ela, a ferramenta fica “não vinculada”** |
| `HUB_ACERVO_SECRET` | segredo combinado com o Apps Script (vai no corpo do POST; nunca em log) |
| `HUB_ACERVO_CACHE_MIN` | minutos de cache em memória **por fonte** — padrão **10**; `0` desliga |
| `HUB_ACERVO_TIMEOUT_MS` | espera máxima pelo web app — padrão **20000** |

**Apps Script (Propriedades do script):** `HUB_ACERVO_SECRET`, `PLANILHA_1_ID`,
`PLANILHA_2_ID` e, opcionais, `ABA_LIVROS` e `ABA_ATOS`. Os ids das planilhas **não** ficam
no servidor: ficam aqui, na conta do Tabelião.

O passo a passo de implantação está no cabeçalho de `docs/apps-script/LeitorAcervo.gs`.

---

## 6. Testes

* **API** (`teste/api.test.js`, seis testes no fim da lista): sessão e fontes válidas; as
  duas planilhas (12 livros / 0 atos e 15 livros / 8 atos, com `atos_vazio`); filtros por
  fonte (livro nos dois grupos, tipo de livro, folhas cruzando faixa, partes sem acento e
  por vírgula, data por ano, ato por substring, texto livre, grupo omitido); paginação e
  `?atualizar=1` só para o admin (conferindo, no registro do fake, que toda chamada levou o
  segredo certo, falou `versao: 2`, leu as duas fontes e **não** deixou o segredo no log);
  mapeamento tolerante dos **atos** e da aba **CADASTRO_LIVROS**; e o desligado por
  variável de ambiente (`ativo()` falso → `carregar()` devolve o índice vazio).
* **Fake do web app**: `teste/acervo-falso.js` (porta 3996) — responde como o Apps Script,
  com 302 e tudo, nas duas fontes e nas duas versões do contrato. Aceita `?modo=falha`.
* **Harness**: o `teste/reiniciar-real.sh` já sobe a ponte **ligada** contra o fake
  (`HUB_ACERVO_WEBAPP_URL=http://127.0.0.1:3996/exec`, `HUB_ACERVO_SECRET=segredo-acervo`,
  `HUB_ACERVO_CACHE_MIN=0`). Para ver a tela “não vinculada”:
  `EXTRA_ENV="HUB_ACERVO_WEBAPP_URL=" ./reiniciar-real.sh`.
* **E2E**: passo `pesquisa_acervo` em `teste/e2e.py` (depois de `guia_itbi`) — cópia de
  referência em `teste/e2e-acervo-passo.py`.
