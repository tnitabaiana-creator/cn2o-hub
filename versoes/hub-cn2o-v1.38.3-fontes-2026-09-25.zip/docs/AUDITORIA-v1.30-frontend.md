# Auditoria v1.30 — frontend (Gerador de Minuta em fases)

*Cartório de Notas do 2º Ofício de Itabaiana/SE · Hub CN2O · 15/09/2026 · auditor de frontend*

Escopo: as cinco mudanças da v1.30 na página `#paginaMinutas` — (1) entrevista em fases num trilho
horizontal com linha do tempo, (2) remoção do "Termo de ciência", (3) botões dos atos maiores,
(4) botão "Abrir no Google Docs" nas cores do Drive, (5) espera da IA com relógio, barra e tempo —
conferidas contra as regras da casa (texto escuro sobre claro, caixas de leitura ≥ 18 px, rótulos
≥ ~13,5 px e notas ≥ 16 px, paleta vinho/marinho/branco, tema escuro coberto, 400 px sem rolagem
horizontal). Nenhum arquivo do projeto foi alterado; este relatório e a pasta de capturas
`docs/auditoria-v1.30/` são os únicos acréscimos.

Como foi testado: o site servido em `http://127.0.0.1:8088` é byte a byte igual a um build novo dos
fontes (`cmp` com a saída de `frontend/build.py --endpoint http://127.0.0.1:3999`), portanto os
testes valem para `frontend/src/{corpo.html,app.js,estilo-extra.css}` atuais. Playwright/Chromium
headless, login `cesar.bravo`, larguras 1366, 900 e 400 px, alturas 900/768/1500, tema escuro por
`data-theme="dark"`. Contraste calculado pela fórmula WCAG a partir das cores computadas, compondo
os fundos translúcidos dos ancestrais (o único caso que o cálculo não vê é o gradiente branco do
botão do Docs, conferido à parte). O Google Fonts não é alcançável no ambiente: as capturas usam
fontes de reserva, o que não muda tamanhos nem cores. A suíte do projeto (`teste/e2e.py`, após
`RESET_DB=1 ./reiniciar-real.sh`) fechou em **57 ok / 0 falhas, 0 erros de console** — ela cobre o
caminho feliz das fases; o que segue são os casos que ela não exercita. Leitura de código: o bloco
"v1.30 — GERADOR EM FASES" do app.js (linhas 3307–3511), `faltou/validar` (2804–2828),
`reverCiencia` (2847–2856), `htmlProgresso` (2128–2140), a rolagem ao resultado (3577–3584) e o CSS a
partir de "v1.30 — GERADOR EM FASES" (estilo-extra.css 1177–1373), além do diff completo contra o
zip da v1.29 em `versoes/`.

## 1. Verificações feitas

| # | Verificação | Resultado |
|---|---|---|
| 1 | Página abre na fase 1 ("O ato"), UE por padrão, 6 passos na linha do tempo; trilho alinhado (`scrollLeft` = posição da fase) e altura do trilho = altura da fase (700 px) | OK |
| 2 | Contagem de fases por ato — PROC 8, UE 6, DISS_UE 7, DIV 8, EMANC 6 — nomes na ordem do DOM; numeração 1..n reescrita nas fases visíveis | OK |
| 3 | Vazamento de fases de outro ato: só as seções fora de `[hidden]` entram na linha do tempo e no layout (23 seções no DOM, 6/8/8 com caixa de layout conforme o ato; `[hidden]{display:none!important}` vence o `display:contents`) | OK |
| 4 | "Próxima fase →" e "← Fase anterior": alinhamento após cada passo, altura acompanhando, seção recebe o foco (`tabindex=-1`), "Anterior" desabilitado na fase 1, "Próxima" escondido na final, rótulo "Fase 6 de 6" | OK |
| 5 | Linha do tempo clicável; passos anteriores marcados `percorrida`, `aria-selected` na atual | OK |
| 6 | Alt+→ / Alt+← andam pelas fases; Alt+← não dispara o "voltar" do navegador | OK (mas ver problema 7) |
| 7 | Alt+← com o cursor num campo de texto | **problema 7** |
| 8 | Limpar (`#btnLimparMin`) volta à fase 1 alinhada, zera campos, esconde a caixa do Docs | OK |
| 9 | Condicional aberto/fechado na fase atual (UE "Filhos em comum" → sim/nenhum): altura 575 → 678 → 575, trilho acompanha | OK |
| 10 | Fase mais alta (PROC "Objeto e poderes" com "outra": 2 430 px): altura do trilho = fase; nenhuma fase vizinha aparece | OK |
| 11 | "Próxima fase" clicado no pé de uma fase alta, com a linha do tempo presa no topo | **problema 2** |
| 12 | Tab para a frente do pé de uma fase ao primeiro controle da seguinte: a fase acompanha (sem deslocamento vertical) | OK |
| 13 | Shift+Tab do primeiro controle de uma fase para o pé da anterior (mais alta) | **problema 3** |
| 14 | Redimensionar 1366 → 900 → 400 → 1366 → 400 com a fase 4 aberta: fase mantida, alinhada, altura certa; 400 px sem rolagem horizontal da página, nada dentro da fase ultrapassa a fase; linha do tempo rola e centraliza o passo atual | OK |
| 15 | Mesmo redimensionamento disparado dentro de ~20 ms após o fim da rolagem suave | **observação 12** (corrida teórica) |
| 16 | Rolagem manual do trilho (trackpad simulado por `scrollLeft`): fase mais próxima assumida, altura ajustada, `scroll-snap` encaixa | OK |
| 17 | Sair ao hub e voltar ao Gerador: fase mantida, alinhada, altura certa | OK |
| 18 | Gerar sem os nomes: toast + `faltou()` leva à fase 3 e foca `#minC1Nome`; nada é enviado | OK |
| 19 | Trocar de ato estando numa fase avançada (só por script/teclado): índice mantido | OK, mas classe `.atual` residual na seção oculta (**observação 11**) |
| 20 | Termo de ciência removido: `#minCiente1/2` inexistentes, botão Gerar nasce liberado, trava só durante a transposição e volta a liberar; backend sem dependência do termo | OK |
| 21 | Botões dos atos: `.rt-txt b` 18 px, altura ≥ 82 px, `min-height`, fundo branco no pastel | OK (17 px a ≤ 520 px — obs. 15) |
| 22 | Botão "Abrir no Google Docs": visível com `doc.url`, `target=_blank rel=noopener`, texto `#202a3a` sobre branco (14,45:1), moldura tricolor `#4285F4/#34A853/#FBBC04`, pulso `docsPulso` 3× (desligado em `prefers-reduced-motion`), mesmo desenho no tema escuro | OK |
| 23 | Espera da IA (minuta, transposição, Analisador): relógio muda a cada segundo (🕑→🕒, volta em 12 s), barra `piCorre`, tempo "N s · a IA está trabalhando — costuma levar até um minuto.", `.pi-msg` 18 px marinho, `.pi-tempo` 16 px; cabe na caixa de saída; tema escuro coberto | OK |
| 24 | Resultado entra na vista ao clicar em Gerar (`scrollIntoView` de `#minResultado`) | OK durante a espera; **problema 4** quando o resultado chega |
| 25 | Caixas de leitura ≥ 18 px: `.mc-lista li`, `.mc-ok`, `.mc-rotulo`, `.md-texto`, `.saida`, `.pi-msg` | OK |
| 26 | Rótulos novos ≥ ~13,5 px | **problema 5** (`.lt-nome` 13/12 px, `.min-fase-pos` 13 px; `.lt-falta` e `.mc-ir` 12 px) |
| 27 | Contraste dos textos principais (tabela §3): `.min-campo`, `.min-fase-tit p/h3`, `.lt-nome`, `.pi-tempo`, `.mc-lista li`, notas e botões | OK, exceto `.min-fase-pos` e a `.min-nota` solta sobre o pastel (**problema 6**) |
| 28 | Nunca texto claro sobre fundo escuro no que se lê: os únicos casos são os números das pílulas (`.lt-num`, `.min-fase-num`), o chip ativo e os botões vinho — rótulos curtos tolerados desde a v1.29 | OK |
| 29 | Paleta: `#f4eef0` é vinho a 7 % sobre branco; `#c7d2e2`, `#f2d7dc`, `#e8e4df`, `#1d2735` já eram os tons do tema escuro da v1.29; a exceção Google só no botão/caixa do Docs | OK |
| 30 | Tema escuro: as 17 regras do bloco v1.30 sob `@media (prefers-color-scheme: dark)` têm o par exato em `:root[data-theme="dark"]` | OK |
| 31 | Tema escuro na linha do tempo (fase atual, percorridas, linha percorrida) | **problema 1** |
| 32 | Conferência da fase final: uma linha por fase com "ir à fase" funcionando; "✓ Nenhum campo obrigatório…" quando zera; anexar documento tira o "1" da fase Documentos; contagem por fase na linha do tempo e `title` com a lista | OK |
| 33 | Gramática e ortografia dos textos novos (títulos e descrições das 21 fases, pé das fases, conferência, nota do Gerar, espera, saída vazia, tooltips) | OK — nada a corrigir; ver obs. 10 sobre "Forma do ato" |
| 34 | Erros de console em todos os fluxos | OK (0, fora os `ERR_FAILED` do Google Fonts bloqueado) |

## 2. Problemas encontrados

Nenhum **bloqueia**. Seis merecem correção antes de fechar a versão; os demais são cosméticos.

### Deve corrigir

**1. Tema escuro: a linha do tempo não mostra em que fase se está.** Em `estilo-extra.css`, as regras
`:root[data-theme="dark"] .lt-num{background:#1d2735;…}` (1225) e a gêmea do `@media` (1220) têm a
mesma especificidade de `.lt-passo.atual .lt-num` (1213) e `.lt-passo.percorrida .lt-num` (1211) e
vêm depois: no escuro os três estados ficam com o mesmo círculo (`rgb(29,39,53)`, borda branca a
45 %); da fase atual sobra só a sombra `rgba(99,19,37,.16)`, invisível sobre `#1d2735`. A linha entre
passos percorridos usa `var(--marinho)` (1206) sobre o fundo `#1d2735` — contraste ≈ 1,05:1, some.
Só o nome da fase atual muda de tom (`#f2d7dc` contra `#e8e4df`), diferença que quem tem
astigmatismo não separa. Reproduzir: Gerador aberto, `document.documentElement.setAttribute('data-theme','dark')`,
ir à fase 6 — captura `09-tema-escuro-linha-do-tempo.png` (comparar com `09b-tema-claro-linha-do-tempo.png`).
Correção pequena: dar às regras escuras de `.atual`/`.percorrida` a mesma forma das claras
(`:root[data-theme="dark"] .lt-passo.atual .lt-num{…}`) e trocar a cor da linha percorrida no escuro.

**2. "Próxima fase" no pé de uma fase alta deixa a fase seguinte "pelo meio".** `irFase`
(app.js 3457–3460) só rola a página quando o topo da linha do tempo está fora da vista (`topo < 0 ||
topo > 140`); como a linha é `position:sticky; top:0`, quando a escrevente já rolou a fase ela está
presa exatamente em `top = 0` e a condição não dispara. O trilho troca de fase, mas a página continua
onde estava: a nova fase aparece a partir do ponto em que a anterior terminou. Medido: PROC com 4
outorgantes (fase 4, 1 261 px) → clique em "Próxima fase" no pé → fase "Outorgados" com o topo a
**−554 px**; a escrevente vê "Outorgado 3" e "Os outorgados atuam", sem o cabeçalho nem o Outorgado 1
(`05a-…antes-de-proxima.png` e `05b-…fase-outorgados-no-meio.png`). Com "Objeto e poderes" (2 430 px)
→ "Condições": topo a −50 px. Correção pequena: rolar também quando o topo do trilho está acima da
base da linha do tempo (por exemplo `trilho.getBoundingClientRect().top < linhaTempo.offsetHeight`).

**3. Trilho deslocado verticalmente depois de um Shift+Tab (cabeçalho de todas as fases cortado).**
O trilho é `overflow: auto hidden` e sua altura é a da fase atual, mas o seu `scrollHeight` é o da
fase mais alta do ato. Quando o foco vai a um controle que está abaixo dessa altura numa fase vizinha,
o navegador rola o trilho também na vertical; `rolagemParou`/`ajustarAltura` corrigem a altura mas
nunca zeram `scrollTop`, e o deslocamento persiste em todas as fases seguintes. Reproduzir (UE):
fase 2 → foco em "Adicionar foto ou PDF" → Shift+Tab (vai ao "Próxima fase" do pé da fase 1) →
`#minTrilho.scrollTop = 89`, cabeçalho "1 · Qual é o ato?" cortado (`06-shift-tab-fase1-cortada.png`);
ir a qualquer outra fase mantém o corte (o `scrollTop` só volta a 0 quando algum relayout deixa a
fase atual como a mais alta do ato — por acaso, não por regra). Correção pequena:
`trilho.scrollTop = 0` em `ajustarAltura`/`rolagemParou`.

**4. Quando a minuta chega, a página salta para o fim: a DECISÃO DO ROTEADOR e o botão "Abrir no
Google Docs" ficam ~1 300 px acima da vista.** Ao clicar em Gerar, `scrollIntoView(#minResultado)`
(3577–3584) leva a página ao máximo de rolagem (durante a espera o painel é baixo e o rodapé fica à
vista). Quando o resultado entra (decisão 521 px + Docs 119 px + minuta 1 265 px), a âncora de rolagem
do Chrome (o nó âncora é o rodapé, abaixo do painel) empurra `scrollY` de 839 para 2 724: a escrevente
vê o fecho da minuta e o "⚠ CONFERIR"; o Docs fica a −1 303 px e a decisão a −1 137 px
(`21-resultado-1366x900.png`; igual a 1366×768; a 400×800 não ocorreu). Confirmado como âncora:
com `html{overflow-anchor:none}` injetado, `scrollY` fica em 839 e o cabeçalho do resultado permanece
à vista. O salto já existia na v1.29 (build do zip servido à parte:
mesmo comportamento com o botão Gerar centralizado), mas a v1.30 o torna sistemático em qualquer
altura de tela ≥ 768 px e é justamente ela que promete "o resultado entra na vista" e dá destaque ao
botão do Docs. Correção pequena: `overflow-anchor:none` no `html`/`#app` ou repetir o
`scrollIntoView` de `#minResultado` em `aoConcluir`.

**5. Rótulos de orientação abaixo do piso da casa (~13,5 px).** `.lt-nome` (o nome da fase na linha
do tempo) tem 13 px (1203) e **12 px** a ≤ 520 px (1319); `.min-fase-pos` ("FASE 3 DE 6") 13 px (1250).
São os dois textos que dizem à escrevente onde ela está. `.lt-falta` (o número de "sem resposta",
1216) e `.mc-ir` ("IR À FASE", 1286) têm 12 px — pílulas curtas, na faixa do `.btn-mini` da casa
(11,5 px); cosmético.

**6. Contraste abaixo de 4,5:1 sobre o quadro pastel.** `--tinta-suave` (`#5f7089`) sobre
`--fase-fundo` (`#f4eef0`) dá **4,40:1**. Atinge `.min-fase-pos` em todas as fases (junto com os
13 px do item 5) e a única `.min-nota` que fica solta na fase, fora de caixa branca: EMANC, "O registro
da emancipação é no Livro E…" (corpo.html 1135), 13,5 px. Dentro das caixas brancas a mesma cor dá
5,04:1 e passa. Correção: usar `--tinta` nesses dois casos ou mover a nota para dentro da caixa.

### Cosmético

**7. Alt+← / Alt+→ dentro de campos de texto muda de fase.** O comentário (3506) diz "fora de campos
de texto", mas o handler não olha `ev.target`. No Windows não há efeito colateral; no macOS
Option+setas é navegação por palavra dentro do campo e passa a trocar de fase. Reproduzir: fase 3,
cursor em `#minC1Nome`, Alt+← → vai à fase 2.

**8. Setas simples (sem Alt) com a seção focada trocam de fase.** `irFase` foca a `<section>`; como
o trilho é rolável na horizontal com `scroll-snap: x mandatory`, → e ← rolam o trilho e o snap pula à
fase vizinha (medido: fase 3 → ArrowRight → fase 4). Não documentado; ↓, PageDown e espaço rolam a
página normalmente.

**9. A linha do tempo continua presa no topo enquanto se lê o resultado** (89 px a 1366; 103 px a
400 px), porque o bloco sticky é `#paginaMinutas` inteira, que inclui o painel de resultado
(`19-tema-escuro-lendo-resultado-linha-presa.png`, `20-largura-400-lendo-resultado.png`). Se for
indesejado, basta envolver linha do tempo e trilho num contêiner comum (o sticky termina com ele).

**10. "Forma do ato" conta como "sem resposta"** na linha do tempo (badge "1" na fase 1) e na
conferência, enquanto a nota logo abaixo diz "Sem informar … — não vira pendência". A contagem é de
"escolhas em aberto" e está coerente com o resto, mas as duas mensagens se contradizem à primeira
leitura; a mesma tensão vale para "Averbação no registro civil" (DIV).

**11. Classe `.atual` residual.** `pintarFases` só alterna `.atual` nas seções do ato aberto; ao
trocar de ato estando numa fase avançada (só possível por script ou teclado, os botões dos atos vivem
na fase 1) a seção do ato anterior fica com `.atual` dentro do `[hidden]`. Sem efeito visual; pode
confundir testes que usam `querySelector('.min-fase.atual')` (o e2e usa).

**12. Corrida de ~20 ms no redimensionamento.** Se a largura do trilho muda antes do `scrollend`
da rolagem suave (medido: até ~17 ms depois de o trilho alinhar), `rolagemParou` lê o `scrollLeft`
antigo com a geometria nova, escolhe a fase vizinha e o `ResizeObserver` confirma com
`irFase(FASE, true)`: redimensionando no mesmo instante, fase 4 → 900 ou 1 100 px terminou na fase 5
em 6 de 7 tentativas; com 50 ms ou mais de folga, 0 de 18 (e 0 de 12 nas idas a 400 e 700 px, mesmo
sem folga — depende de onde o `scrollLeft` velho cai na geometria nova). Irreproduzível à mão; fica registrado como risco — a proteção seria descartar a
reinterpretação quando `clientWidth` mudou desde o último `irFase`.

**13. Leitor de tela.** `htmlProgresso` recria a região `role=status aria-live=polite` a cada
segundo (2 trocas de `innerHTML` em 2,5 s): um leitor de tela anuncia o texto todo segundo. Atualizar
só o `.pi-tempo` (ou tirar o `aria-live`) resolve.

**14. Sobras.** `.termo-check` continua no CSS (716 e 833) sem uso; `reverCiencia()` mantém o nome
sem "ciência"; os comentários chamam a linha do tempo de "lateral" (ela é horizontal, no topo).

**15. Nome do ato a 17 px** a ≤ 520 px (1322) — o pedido era 18 px; a 400 px o botão tem espaço.

**16. Textos a confirmar.** "costuma levar até um minuto" vale para o mock; com o Gemini Pro uma
minuta longa pode passar disso — vale conferir os tempos reais antes de manter a promessa. `#minNota`
("A minuta nasce também como Google Doc…") tem 15,5 px, meio ponto abaixo dos 16 px das notas de
leitura; a nota da transposição (`.min-transpor-linha .nota-ia`) tem 14,5 px como na v1.29.

**17. Acessibilidade da linha do tempo.** `role="tablist"/"tab"` sem `aria-controls` nem tabindex
rotativo: os passos entram todos na ordem de Tab (funciona, só não segue o padrão de abas).

## 3. Medições

Contraste (WCAG) e tamanho, tema claro / tema escuro. Fundo = cor efetiva composta.

| Texto | Claro | Escuro |
|---|---|---|
| `.min-campo` (rótulo, caixa branca) 13 px 600 | `#202a3a`/`#ffffff` **14,45** | `#c7d2e2`/`#333c48` **7,34** |
| `.min-campo.min-contagem` (sobre o pastel) | `#202a3a`/`#f4eef0` **12,61** | — |
| `.min-fase-tit p` 16 px | `#17253f`/`#f4eef0` **13,36** | `#f2f0ec`/`#293340` **11,24** |
| `.min-fase-tit h3` 20 px 800 | `#631325`/`#f4eef0` **11,11** | `#f2d7dc`/`#293340` **9,46** |
| `.lt-nome` atual / demais 13 px 700 | `#631325`/`#fdfcfa` **12,41** · `#202a3a` **14,09** | `#f2d7dc`/`#1d2735` **11,14** · `#e8e4df` **11,91** |
| `.lt-num` percorrido / atual 14,5 px (pílula) | branco/marinho **14,45** · branco/vinho **12,72** | `#e8e4df`/`#1d2735` **11,91** (os três iguais — problema 1) |
| `.lt-falta` 12 px 800 | `#631325`/`#ffffff` **12,72** | `#f2d7dc`/`#1d2735` **11,14** |
| `.mc-lista li` 18 px · `b` | `#1a2230`/`#ffffff` **15,96** · **12,72** | `#f0f3f8`/`#333c48` **10,08** · **8,29** |
| `.mc-ir` 12 px · `.mc-resumo` 16 px | **12,72** · `#631325`/`#f1eaeb` **10,72** | **8,29** · `#f2d7dc`/`#4b535e` **5,74** |
| `.min-fase-pos` 13 px 700 | `#5f7089`/`#f4eef0` **4,40** ✗ | `#a6a8ab`/`#293340` **5,37** |
| `.min-nota` solta na fase (EMANC) 13,5 px | `#5f7089`/`#f4eef0` **4,40** ✗ | **5,37** |
| `.min-nota` dentro de caixa · `.min-docs-ajuda` 15,5 px | `#5f7089`/`#ffffff` **5,04** | — |
| `#minNota` 15,5 px · `.nota-ia` da transposição 14,5 px · "← Fase anterior" 13 px | `#535966`/`#f4eef0` **6,14** | `#c6c6c6`/`#293340` **7,51** |
| `.pi-msg` 18 px 700 · `.pi-tempo` 16 px | **14,45** · `#5f7089`/`#ffffff` **5,04** | `#c7d2e2`/`#2b3444` **8,19** · `#a6a9ac` **5,29** |
| `.min-docbtn` 14 px 800 · `.min-doctitulo` 18 px · `.min-docnota` 16 px | `#202a3a`/branco **14,45** · **15,96** · **15,96** | botão idem (fundo branco por gradiente) · `#f0f3f8`/`#343d4c` **9,87** · **9,87** |
| `.md-texto` (decisão) 18 px | `#1a2230`/`#ffffff` **15,96** | `#f0f3f8`/`#343d4c` **9,87** |

Tamanhos computados (1366 px): `.mc-lista li` 18 · `.mc-ok` 18 · `.mc-rotulo` 18 · `.mc-resumo` 16 ·
`.md-texto` 18 · `.saida` 18 · `.pi-msg` 18 · `.pi-tempo` 16 · `.min-fase-tit p` 16 · `h3` 20 ·
`.min-ato b` 18 · `.min-ato small` 14 · `.min-nav` 13 · `.lt-num` 14,5 · `.lt-nome` 13 · `.lt-falta`
12 · `.min-fase-pos` 13 · `.mc-ir` 12 · `.min-campo` 13 · `.min-nota` 13,5 · `#minNota` 15,5.

## 4. Capturas (`docs/auditoria-v1.30/`)

`01-fase1-ato`, `02-fase3-conviventes`, `03-fase-final-conferencia`, `04-proc-poderes-outra-topo`,
`05a/05b` (problema 2), `06-shift-tab-fase1-cortada` (problema 3), `07/08-tema-escuro-*`,
`09/09b-linha-do-tempo` escuro × claro (problema 1), `10–13-largura-400-*` (fase 1, fase 3, final,
escuro), `14-espera-ia`, `15/15b-resultado-google-docs`, `16/16b-tema-escuro-resultado`,
`17-espera-transposicao`, `18-tema-escuro-espera-ia`, `19/20` linha presa sobre o resultado,
`21-resultado-1366x900/768/400x800` (problema 4), `22/23-espera-ia-analisador` claro/escuro,
`24-largura-400-pe-da-fase`. As capturas são do viewport (com `full_page` o Chromium relaiouta a
página e desalinha o trilho na imagem — artefato da captura, não do site).

## 5. Não coberto

Tempo real do modelo Pro (só o mock, ~1,2 s por chamada); gesto de arrastar em tela de toque (só
`scrollLeft` programático); Safari/iOS (`scrollend` não existe lá — o debounce de 90 ms cobre, não
testado); fontes Montserrat/Lato/Atkinson (bloqueadas no ambiente).

## Conclusão

A v1.30 funciona como especificada em todos os fluxos principais e a suíte do projeto passa inteira;
antes de fechar, corrigir a linha do tempo no tema escuro, o posicionamento da página ao trocar de fase
pelo pé e ao chegar o resultado, o `scrollTop` residual do trilho e os dois rótulos pequenos/pálidos —
todos ajustes de poucas linhas.
