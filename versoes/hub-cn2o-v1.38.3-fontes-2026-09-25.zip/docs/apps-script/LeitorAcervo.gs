/**
 * LeitorAcervo — Hub CN2O ← Acervo de Livros e Atos (Google Sheets) — v2.1 (Hub v1.34)
 * Cartório de Notas do 2º Ofício de Itabaiana/SE
 *
 * O QUE FAZ
 *   Entrega ao backend do Hub (Railway) o conteúdo das DUAS PLANILHAS do acervo — cópias
 *   do modelo "PAINEL DO ACERVO DE LIVROS", na conta tnitabaiana@gmail.com:
 *
 *     fonte "antigo1" → PLANILHA_1_ID → "Acervo 1º Ofício (Antigo ) - SÉRGIO"
 *                       (acervo antigo do 1º Ofício, incorporado ao acervo do CN2O)
 *     fonte "cn2o"    → PLANILHA_2_ID → "Acervo 2º Ofício (Antigo e Atual) - MILVO"
 *
 *   De cada planilha saem DUAS ABAS — e só elas:
 *     CADASTRO_LIVROS — os livros físicos: tipo, número, código, status, onde estão
 *                       guardados (sala/estante/prateleira/caixa), se estão digitalizados,
 *                       o link da pasta digital, pendências e observações.
 *     INDICE_ATOS     — os atos lavrados: livro, folhas, data, nº do ato, partes, CPF,
 *                       objeto, matrícula, valor, tributo, link do arquivo e observações.
 *   PAINEL, BUSCA, MOVIMENTACOES, MAPA_FISICO, LISTAS, CHECKLIST e AJUDA são ignoradas.
 *
 *   As abas são achadas pelo NOME; se a planilha tiver nomes diferentes, o script procura
 *   pelo CABEÇALHO: a aba cuja primeira linha tem "Nº DO LIVRO" e "TIPO DE LIVRO" é a dos
 *   livros; a que tem "PARTE 1" (ou "Nº DO ATO") é a dos atos.
 *
 *   Responde:
 *     { ok: true, fonte: "cn2o", planilha: "Acervo 2º Ofício (Antigo e Atual) - MILVO",
 *       atualizado_em: "2026-09-16T12:00:00.000Z",
 *       livros: { aba: "CADASTRO_LIVROS", colunas: [...], linhas: [[...]] },
 *       atos:   { aba: "INDICE_ATOS",     colunas: [...], linhas: [[...]] } }
 *
 *   A PRIMEIRA LINHA de cada aba é o cabeçalho e vai em `colunas`; as demais, em `linhas`.
 *   Linhas totalmente vazias são descartadas (a INDICE_ATOS, hoje só com o cabeçalho,
 *   responde `linhas: []` — o Hub mostra "nenhum ato indexado ainda"). O Hub descobre
 *   sozinho o papel de cada coluna pelo nome e guarda as que não conhece (CHAVE DE BUSCA,
 *   ALERTA, MATCH_BUSCA e qualquer coluna nova) para mostrar no "mais…". Dá para
 *   acrescentar colunas às planilhas sem mexer em nada aqui.
 *
 *   Datas, números e moeda saem COMO APARECEM NA CÉLULA (16/09/2026, R$ 250.000,00) e a
 *   caixa de seleção sai como Sim/Não.
 *
 *   COMO LÊ (v2.1): pela API do Google Sheets (serviço avançado "Sheets", v4), e não pelo
 *   SpreadsheetApp — porque o SpreadsheetApp.openById exige o escopo COMPLETO de edição das
 *   planilhas, e este script só precisa (e só tem) o escopo somente-leitura
 *   https://www.googleapis.com/auth/spreadsheets.readonly. Menos permissão, mesmo resultado.
 *
 * =====================================================================================
 * IMPLANTAÇÃO — PASSO A PASSO (uma vez, na conta tnitabaiana@gmail.com)
 * =====================================================================================
 *  1. Abra script.google.com (logado como tnitabaiana@gmail.com) → "Novo projeto".
 *  2. Renomeie o projeto (canto superior esquerdo) para: LeitorAcervo — Hub CN2O
 *  3. Apague o conteúdo do arquivo Code.gs, cole ESTE arquivo inteiro e salve (Ctrl+S).
 *  3a. No menu da esquerda, em "Serviços", clique no "+" e adicione "Google Sheets API"
 *     (símbolo Sheets, versão v4) → "Adicionar". Depois, na engrenagem "Configurações do
 *     projeto", marque "Mostrar o arquivo de manifesto appsscript.json" e confira que ele
 *     tem o serviço e SÓ o escopo somente-leitura:
 *        "dependencies": { "enabledAdvancedServices": [ { "userSymbol": "Sheets",
 *                            "version": "v4", "serviceId": "sheets" } ] },
 *        "oauthScopes": [ "https://www.googleapis.com/auth/spreadsheets.readonly" ],
 *        "webapp": { "executeAs": "USER_DEPLOYING", "access": "ANYONE_ANONYMOUS" }
 *  4. Engrenagem "Configurações do projeto" (menu da esquerda) → role até "Propriedades
 *     do script" → "Adicionar propriedade do script" e crie TRÊS:
 *         HUB_ACERVO_SECRET  →  uma senha longa, inventada por você (ex.: 40 caracteres).
 *                               Guarde: ela vai igualzinha no Railway, no passo 8.
 *         PLANILHA_1_ID      →  1GZtzzB2FqfnQKR18gUJ2ZKfBalhPk8riC9PZNpRVpR8
 *         PLANILHA_2_ID      →  1ZM3sEt1cCqkfvZgLQfJf0q-Zx-AVUuwRMdMvEI5OErQ
 *     (Opcionais, só se as abas tiverem outro nome: ABA_LIVROS e ABA_ATOS.)
 *     Clique em "Salvar propriedades do script".
 *  5. Volte ao editor (ícone "<>"). Na barra de cima, no seletor de função, escolha
 *     testarLeitura e clique em "Executar".
 *  6. O Google vai pedir autorização: "Revisar permissões" → escolha a conta
 *     tnitabaiana@gmail.com → a tela avisa que o app não é verificado: clique em
 *     "Avançado" → "Acessar LeitorAcervo — Hub CN2O (não seguro)" → "Permitir".
 *     (É o seu próprio script lendo as suas próprias planilhas.)
 *  7. Veja o registro de execução (Ctrl+Enter). Deve aparecer, para cada planilha, o nome
 *     do arquivo, as abas encontradas, as colunas e quantas linhas foram lidas. Se disser
 *     "aba não encontrada", confira os nomes CADASTRO_LIVROS e INDICE_ATOS.
 *  8. "Implantar" (botão azul, canto superior direito) → "Nova implantação" →
 *     na engrenagem "Selecionar tipo", escolha "Aplicativo da Web" →
 *        Descrição: v1
 *        Executar como: Eu (tnitabaiana@gmail.com)
 *        Quem pode acessar: Qualquer pessoa
 *     → "Implantar" → copie a "URL do app da Web" (termina em /exec).
 *  9. Railway → projeto do Hub → serviço cn2o-hub-backend → aba "Variables" →
 *     "New Variable", duas vezes:
 *        HUB_ACERVO_WEBAPP_URL  →  a URL /exec do passo 8
 *        HUB_ACERVO_SECRET      →  a MESMA senha do passo 4
 *     (Opcional: HUB_ACERVO_CACHE_MIN = 10 — minutos de cache no servidor.)
 *     O Railway refaz o deploy sozinho; se não refizer, clique em "Deploy".
 * 10. No Hub, abra o quadro "10 · Pesquisa / Acervo": as duas abas do alto devem dizer
 *     "Índice vinculado", com a contagem de livros e de atos de cada planilha.
 *
 * SE PRECISAR MUDAR O CÓDIGO DEPOIS: cole a versão nova, salve e vá em
 * "Implantar" → "Gerenciar implantações" → lápis (editar) → Versão: "Nova versão" →
 * "Implantar". A URL continua a mesma (não mexa no Railway).
 * SE MUDAR SÓ A PLANILHA OU A ABA: troque a propriedade do passo 4 — não precisa
 * reimplantar nada.
 * =====================================================================================
 *
 * CONFERÊNCIA RÁPIDA
 *   Abra a URL /exec no navegador: deve responder { ok: true, servico: … } e NADA das
 *   planilhas — dado só sai com o segredo, e o segredo só viaja no corpo do POST.
 *
 * SEGURANÇA
 *   O web app é público por necessidade (o Railway não tem conta Google), mas só devolve
 *   as planilhas quando o pedido traz o segredo, que vai no CORPO do POST — nunca na URL,
 *   nunca em log, nunca nas respostas. O script só LÊ as duas planilhas configuradas; não
 *   escreve, não apaga e não toca em nenhum outro arquivo do Drive.
 */

var VERSAO = 'LeitorAcervo 2.1.1 — Hub CN2O v1.34';
var MAX_LINHAS = 20000;     // teto de linhas por aba (planilha grande não estoura a resposta)
var MAX_CELULA = 500;       // teto de caracteres por célula

// fonte → propriedade com o id da planilha
var FONTES = {
  antigo1: 'PLANILHA_1_ID',
  cn2o: 'PLANILHA_2_ID'
};
var FONTE_PADRAO = 'cn2o';

// Como achar cada aba: pelo nome e, se não houver, pelo cabeçalho.
var ABAS = {
  livros: {
    nomes: ['CADASTRO_LIVROS', 'CADASTRO LIVROS', 'LIVROS'],
    propriedade: 'ABA_LIVROS',
    exige: [['n do livro', 'no do livro', 'numero do livro'], ['tipo de livro']]
  },
  atos: {
    nomes: ['INDICE_ATOS', 'INDICE ATOS', 'ÍNDICE_ATOS', 'ATOS'],
    propriedade: 'ABA_ATOS',
    exige: [['parte 1 outorgante', 'parte 1', 'n do ato', 'no do ato', 'numero do ato']]
  }
};

function doGet() {
  return saida({ ok: true, servico: VERSAO });
}

function doPost(e) {
  var pedido;
  try {
    pedido = JSON.parse((e && e.postData && e.postData.contents) || '{}');
  } catch (err) {
    return saida({ ok: false, erro: 'corpo inválido (esperava JSON)' });
  }
  var props = PropertiesService.getScriptProperties();
  var segredo = props.getProperty('HUB_ACERVO_SECRET') || '';
  if (!segredo) return saida({ ok: false, erro: 'HUB_ACERVO_SECRET não configurado nas propriedades do script' });
  if (String(pedido.segredo || '') !== segredo) return saida({ ok: false, erro: 'segredo inválido' });

  try {
    // versao 1 (contrato antigo, planilha única) continua respondida: uma aba só,
    // em { colunas, linhas }. Serve aos testes e a qualquer versão antiga do backend.
    if (Number(pedido.versao) === 1) return saida(lerUmaAbaSo(props));
    return saida(lerFonte(props, escolherFonte(pedido.fonte)));
  } catch (err) {
    // A mensagem do erro do Apps Script pode citar a planilha, nunca o segredo.
    return saida({ ok: false, erro: String((err && err.message) || err).slice(0, 300) });
  }
}

function escolherFonte(v) {
  var k = String(v == null ? '' : v).trim().toLowerCase();
  return FONTES[k] ? k : FONTE_PADRAO;
}

// ------------------------------------------------------------------ leitura
// Tudo pela API do Sheets (serviço avançado "Sheets" v4): metadados da planilha (nome, fuso,
// abas), valores formatados de cada aba e, para os links, os dados de grade só com os campos
// de hyperlink. Funciona com o escopo somente-leitura.
function lerFonte(props, fonte) {
  var id = (props.getProperty(FONTES[fonte]) || '').trim();
  if (!id) throw new Error(FONTES[fonte] + ' não configurado nas propriedades do script');
  var planilha = abrirPlanilha(id);
  var livros = lerAba(props, planilha, 'livros');
  var atos = lerAba(props, planilha, 'atos');
  return {
    ok: true,
    fonte: fonte,
    planilha: planilha.nome,
    atualizado_em: new Date().toISOString(),   // instante da LEITURA (é o que o Hub mostra)
    livros: livros,
    atos: atos
  };
}

// Contrato antigo: uma planilha, uma aba (a de atos, ou a primeira que houver).
function lerUmaAbaSo(props) {
  var id = (props.getProperty('PLANILHA_ID') || props.getProperty(FONTES[FONTE_PADRAO]) || '').trim();
  if (!id) throw new Error('PLANILHA_ID não configurado nas propriedades do script');
  var planilha = abrirPlanilha(id);
  var r = lerAba(props, planilha, 'atos');
  if (!r.colunas.length && planilha.abas.length) r = conteudoDaAba(planilha, planilha.abas[0]);
  return { ok: true, aba: r.aba, colunas: r.colunas, linhas: r.linhas,
    planilha: planilha.nome, atualizado_em: new Date().toISOString() };
}

// { id, nome, fuso, abas: [nomes] } — uma chamada leve, só com os campos necessários.
function abrirPlanilha(id) {
  var meta = Sheets.Spreadsheets.get(id, { fields: 'properties(title,timeZone),sheets(properties(title))' });
  var abas = [];
  (meta.sheets || []).forEach(function (s) { if (s.properties && s.properties.title) abas.push(s.properties.title); });
  return { id: id, nome: (meta.properties && meta.properties.title) || '', fuso: (meta.properties && meta.properties.timeZone) || 'America/Maceio', abas: abas };
}

function lerAba(props, planilha, qual) {
  var cfg = ABAS[qual];
  var nome = (props.getProperty(cfg.propriedade) || '').trim();
  var aba = (nome && planilha.abas.indexOf(nome) !== -1) ? nome : '';
  for (var i = 0; i < cfg.nomes.length && !aba; i++) if (planilha.abas.indexOf(cfg.nomes[i]) !== -1) aba = cfg.nomes[i];
  if (!aba) aba = abaPeloCabecalho(planilha, cfg.exige);
  if (!aba) return { aba: '', colunas: [], linhas: [] };
  return conteudoDaAba(planilha, aba);
}

// Procura a aba cuja PRIMEIRA LINHA tem as colunas exigidas (uma de cada grupo).
function abaPeloCabecalho(planilha, exige) {
  for (var i = 0; i < planilha.abas.length; i++) {
    var cab = (lerValores(planilha.id, faixaDaAba(planilha.abas[i], '1:1'))[0] || []).map(chave);
    if (!cab.length) continue;
    var ok = true;
    for (var g = 0; g < exige.length && ok; g++) {
      var achou = false;
      for (var k = 0; k < exige[g].length && !achou; k++) if (cab.indexOf(exige[g][k]) !== -1) achou = true;
      ok = achou;
    }
    if (ok) return planilha.abas[i];
  }
  return '';
}

// "'CADASTRO_LIVROS'!1:1" — o nome da aba entre aspas simples (aspas internas dobradas).
function faixaDaAba(aba, faixa) {
  return "'" + String(aba).replace(/'/g, "''") + "'" + (faixa ? '!' + faixa : '');
}

// Valores como aparecem na célula (data no formato da planilha, moeda formatada, TRUE/FALSE).
function lerValores(id, faixa) {
  var r = Sheets.Spreadsheets.Values.get(id, faixa, { valueRenderOption: 'FORMATTED_VALUE', dateTimeRenderOption: 'FORMATTED_STRING' });
  return (r && r.values) || [];
}

function conteudoDaAba(planilha, aba) {
  var valores = lerValores(planilha.id, faixaDaAba(aba, ''));
  if (!valores.length) return { aba: aba, colunas: [], linhas: [] };
  var largura = 0;
  for (var i = 0; i < valores.length; i++) if (valores[i].length > largura) largura = valores[i].length;
  var texto = [];
  for (var r = 0; r < valores.length; r++) {
    var linha = [];
    for (var j = 0; j < largura; j++) linha.push(celula(valores[r][j]));
    texto.push(linha);
  }
  aplicarLinks(planilha.id, aba, texto);            // texto clicável / =HYPERLINK → a URL

  var colunas = (texto[0] || []).map(function (c) { return recortar(c, 120); });
  var linhas = [];
  for (var k = 1; k < texto.length && linhas.length < MAX_LINHAS; k++) {
    var l = texto[k].map(function (c) { return recortar(c, MAX_CELULA); });
    if (l.join('').trim() === '') continue;        // linha em branco no meio ou no fim
    linhas.push(l);
  }
  return { aba: aba, colunas: colunas, linhas: linhas };
}

// Um valor de célula vira texto: a API já entrega data/moeda como aparecem na célula;
// a caixa de seleção (TRUE/FALSE) vira Sim/Não.
function celula(valor) {
  if (valor === null || valor === undefined) return '';
  var s = String(valor);
  if (s === 'TRUE') return 'Sim';
  if (s === 'FALSE') return 'Não';
  return s;
}

// Onde a célula é um link clicável (ou um =HYPERLINK) e o texto visível não é a própria
// URL, devolve a URL: é dela que o Hub monta os botões "Pasta digital" e "Abrir no Drive".
// Só as COLUNAS DE LINK (cabeçalho com "link", "url", "pasta digital", "arquivo" ou "drive")
// e só as linhas usadas — pedir a grade inteira da aba (1000 × 26 células, quase todas
// vazias) levava dezenas de segundos. Dentro de try: se a API não cooperar, ficam os
// textos visíveis e a pesquisa continua funcionando, só sem o botão.
function aplicarLinks(id, aba, texto) {
  if (texto.length < 2) return;
  var cab = texto[0] || [], colunasLink = [];
  for (var j = 0; j < cab.length; j++) if (/link|url|pasta digital|arquivo|drive/i.test(String(cab[j]))) colunasLink.push(j);
  if (!colunasLink.length) return;
  var ranges = colunasLink.map(function (c) { var L = letraColuna(c); return faixaDaAba(aba, L + '2:' + L + texto.length); });
  var blocos;
  try {
    var r = Sheets.Spreadsheets.get(id, {
      ranges: ranges, includeGridData: true,
      fields: 'sheets.data(startRow,startColumn,rowData.values(hyperlink,userEnteredValue.formulaValue,textFormatRuns.format.link.uri))'
    });
    blocos = (r.sheets && r.sheets[0] && r.sheets[0].data) || [];
  } catch (err) { return; }
  for (var b = 0; b < blocos.length; b++) {
    var col = blocos[b].startColumn || 0, linha0 = blocos[b].startRow || 0, rows = blocos[b].rowData || [];
    for (var i = 0; i < rows.length; i++) {
      var linha = linha0 + i;
      if (linha >= texto.length || col >= texto[linha].length) continue;
      var visivel = String(texto[linha][col] == null ? '' : texto[linha][col]);
      if (/^https?:\/\//i.test(visivel.replace(/^\s+/, ''))) continue;
      var c = (rows[i] && rows[i].values && rows[i].values[0]) || {};
      var url = c.hyperlink || '';
      if (!url && c.textFormatRuns) {
        for (var k = 0; k < c.textFormatRuns.length && !url; k++) {
          var f = c.textFormatRuns[k] && c.textFormatRuns[k].format;
          url = (f && f.link && f.link.uri) || '';
        }
      }
      if (!url && c.userEnteredValue && c.userEnteredValue.formulaValue) {
        var m = /=\s*HYPERLINK\s*\(\s*"([^"]+)"/i.exec(String(c.userEnteredValue.formulaValue));
        if (m) url = m[1];
      }
      if (url && /^https?:\/\//i.test(url)) texto[linha][col] = url;
    }
  }
}
// 0 → A, 25 → Z, 26 → AA
function letraColuna(j) {
  var s = ''; j += 1;
  while (j > 0) { var m = (j - 1) % 26; s = String.fromCharCode(65 + m) + s; j = Math.floor((j - 1) / 26); }
  return s;
}

// ------------------------------------------------------------------ auxiliares
function recortar(v, max) {
  return String(v == null ? '' : v).replace(/[\r\n\t]+/g, ' ').replace(/\s{2,}/g, ' ').trim().slice(0, max);
}
// "Nº DO LIVRO" → "n do livro" (sem acento, sem caixa, sem pontuação)
function chave(v) {
  return String(v == null ? '' : v)
    .normalize('NFD').replace(/[̀-ͯ]/g, '')
    .toLowerCase().replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim();
}
function saida(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

// ------------------------------------------------------------------ conferência
// Rode esta função no editor (Executar) para ver se as duas planilhas estão sendo lidas.
// Não expõe o segredo; imprime só nomes de arquivo, abas, colunas e contagens.
function testarLeitura() {
  var props = PropertiesService.getScriptProperties();
  Logger.log('segredo configurado: %s', props.getProperty('HUB_ACERVO_SECRET') ? 'sim' : 'NÃO');
  Object.keys(FONTES).forEach(function (fonte) {
    Logger.log('--------------------------------------------------');
    var id = (props.getProperty(FONTES[fonte]) || '').trim();
    if (!id) { Logger.log('%s (%s): NÃO configurado', fonte, FONTES[fonte]); return; }
    try {
      var r = lerFonte(props, fonte);
      Logger.log('%s → %s', fonte, r.planilha);
      Logger.log('  livros: aba "%s" · %s colunas · %s linhas', r.livros.aba, r.livros.colunas.length, r.livros.linhas.length);
      Logger.log('  colunas de livros: %s', r.livros.colunas.join(' | '));
      Logger.log('  atos:   aba "%s" · %s colunas · %s linhas', r.atos.aba, r.atos.colunas.length, r.atos.linhas.length);
      Logger.log('  colunas de atos:   %s', r.atos.colunas.join(' | '));
      if (r.livros.linhas.length) Logger.log('  1º livro: %s', r.livros.linhas[0].join(' | '));
      if (r.atos.linhas.length) Logger.log('  1º ato:   %s', r.atos.linhas[0].join(' | '));
    } catch (err) {
      Logger.log('%s → ERRO: %s', fonte, err.message);
    }
  });
}
