/**
 * CriadorDeMinutas — Hub CN2O → Google Docs (v1.30)
 * Cartório de Notas do 2º Ofício de Itabaiana/SE
 *
 * O QUE FAZ
 *   Recebe do backend do Hub (Railway) a minuta que o Gerador acabou de produzir e a
 *   grava como Google Doc na pasta do Gerador de Minutas (Drive do Tabelião), com a
 *   formatação da casa — a mesma das minutas da base "05 · BASE — CLAUDE IA":
 *     · página A4, margens de 2,54 cm, Arial 11, corpo justificado;
 *     · espaçamento entre linhas ZERO em todo o corpo do texto (v1.30, ordem do Tabelião):
 *       entrelinha simples (1,0) e 0 pt antes/depois em TODOS os parágrafos — cabeçalho,
 *       PRIMEIRO TRASLADO, ementa, corpo, alertas e linha de origem;
 *     · cabeçalho "Livro: …  Folha: …" (à direita);
 *     · "PRIMEIRO TRASLADO" em negrito;
 *     · ementa (título) recuada 7 cm, com o nome do ato e os nomes das partes em negrito;
 *     · corpo em TEXTO CORRIDO (um só parágrafo, como nas escrituras da serventia):
 *       "SAIBAM" e os rótulos das partes em negrito, nomes em CAIXA ALTA em negrito,
 *       título de cada cláusula ("1. DA FINALIDADE…") em negrito e sublinhado, marcadores
 *       (i)/(ii)/a)/b) e valores em reais em negrito, placeholders entre colchetes
 *       ([LAVRATURA: …], [FALTA: …], [CONFERIR …]) em vermelho;
 *     · depois do corpo, a "SEÇÃO ALERTAS — NÃO INTEGRA O CORPO LAVRÁVEL" com a decisão
 *       do roteador, as pendências, o ⚠ CONFERIR e o rodapé de rascunho — para a
 *       escrevente conferir e APAGAR antes do lançamento no Extra Digital.
 *   Devolve { ok: true, id, url, titulo } — o Hub mostra o botão "Abrir no Google Docs".
 *
 * IMPLANTAÇÃO (uma vez)
 *   1. script.google.com → Novo projeto → cole este arquivo (Code.gs) → salve.
 *   2. Configurações do projeto → Propriedades do script:
 *        HUB_DOCS_SECRET  → uma senha longa (a MESMA que vai no Railway)
 *        PASTA_ID         → (opcional) id da pasta de destino; padrão: "Minutas Geradas — Casos"
 *        COMPARTILHAR     → (opcional) "link" → qualquer pessoa com o link edita;
 *                           ou e-mails separados por vírgula → viram editores;
 *                           vazio → herda o compartilhamento da pasta.
 *   3. Implantar → Nova implantação → Aplicativo da Web →
 *        Executar como: EU (o Tabelião) · Quem tem acesso: QUALQUER PESSOA → Implantar.
 *      Copie a URL "…/exec".
 *   4. Railway (cn2o-hub-backend) → Variables:
 *        HUB_DOCS_WEBAPP_URL → a URL …/exec
 *        HUB_DOCS_SECRET     → a mesma senha do passo 2
 *   A cada alteração do código: Implantar → Gerenciar implantações → editar → Nova versão.
 *
 * SEGURANÇA
 *   O web app é público por necessidade (o Railway não tem conta Google), mas só cria
 *   documento quando o pedido traz o segredo. Nada é lido do Drive; o script só cria
 *   arquivos na pasta configurada. O segredo nunca sai nas respostas.
 */

var VERSAO = 'CriadorDeMinutas 1.1 — Hub CN2O v1.30';
var PASTA_PADRAO = '1eHtGC_PbwcMc9Jid0stOAS5pc1QhQYwN';   // "Minutas Geradas — Casos"
var FONTE = 'Arial';
var TAMANHO = 11;
var VERMELHO = '#ff0000';
var VINHO = '#631325';
var RECUO_EMENTA_PT = 198.4;      // 7 cm, como nas minutas da base
var A4_LARGURA_PT = 595.3;
var A4_ALTURA_PT = 841.9;
var MARGEM_PT = 72;               // 2,54 cm

function doGet() {
  return saida({ ok: true, servico: VERSAO });
}

function doPost(e) {
  var pedido;
  try {
    pedido = JSON.parse((e && e.postData && e.postData.contents) || '{}');
  } catch (err) {
    return saida({ ok: false, erro: 'corpo inválido (esperava JSON)' });
  }
  var props = PropertiesService.getScriptProperties();
  var segredo = props.getProperty('HUB_DOCS_SECRET') || '';
  if (!segredo) return saida({ ok: false, erro: 'HUB_DOCS_SECRET não configurado nas propriedades do script' });
  if (String(pedido.segredo || '') !== segredo) return saida({ ok: false, erro: 'segredo inválido' });
  var minuta = String(pedido.minuta || '').replace(/\r\n?/g, '\n').trim();
  if (!minuta) return saida({ ok: false, erro: 'minuta vazia' });
  if (minuta.length > 400000) return saida({ ok: false, erro: 'minuta grande demais' });
  try {
    var r = criarDocumento(pedido, minuta, props);
    return saida({ ok: true, id: r.id, url: r.url, titulo: r.titulo, pasta: r.pasta });
  } catch (err) {
    return saida({ ok: false, erro: String((err && err.message) || err).slice(0, 300) });
  }
}

function saida(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

// ------------------------------------------------------------------ documento
function criarDocumento(p, minuta, props) {
  var titulo = String(p.titulo || 'MINUTA — Hub CN2O').replace(/[\r\n\t]+/g, ' ').replace(/\s{2,}/g, ' ').trim().slice(0, 200);
  var doc = DocumentApp.create(titulo);
  var body = doc.getBody();
  body.setPageWidth(A4_LARGURA_PT).setPageHeight(A4_ALTURA_PT);
  body.setMarginTop(MARGEM_PT).setMarginBottom(MARGEM_PT).setMarginLeft(MARGEM_PT).setMarginRight(MARGEM_PT);

  var partes = separarMinuta(minuta);

  // cabeçalho Livro/Folha — placeholders de lavratura em vermelho
  var cab = doc.addHeader();
  var pCab = cab.getParagraphs().length ? cab.getParagraphs()[0] : cab.appendParagraph('');
  pCab.setText(partes.livroFolha || 'Livro: [LAVRATURA: livro]  Folha: [LAVRATURA: folhas]');
  estiloBase(pCab);
  pCab.setAlignment(DocumentApp.HorizontalAlignment.RIGHT);
  pintarPlaceholders(pCab);

  // PRIMEIRO TRASLADO (o documento nasce com um parágrafo vazio: é ele que vira o primeiro)
  var p0 = body.getParagraphs()[0];
  p0.setText('PRIMEIRO TRASLADO');
  estiloBase(p0);
  p0.editAsText().setBold(true);

  // ementa: recuada 7 cm, nome do ato e nomes das partes (CAIXA ALTA) em negrito
  var p1 = body.appendParagraph(partes.titulo || '[FALTA: título da minuta]');
  estiloBase(p1);
  p1.setIndentStart(RECUO_EMENTA_PT).setIndentFirstLine(RECUO_EMENTA_PT);
  negritarCaixaAlta(p1);
  pintarPlaceholders(p1);

  // corpo em texto corrido
  var p2 = body.appendParagraph(partes.corpo || '[FALTA: corpo da minuta]');
  estiloBase(p2);
  formatarCorpo(p2);

  // anotações do Gerador (não integram o corpo lavrável)
  var anotacoes = String(p.anotacoes || '').replace(/\r\n?/g, '\n').trim();
  var rotuloAto = String(p.ato || '').trim();
  var estado = String(p.estado || '').trim();
  estiloBase(body.appendParagraph(''));   // a linha em branco também sem espaçamento extra
  var pt = body.appendParagraph('SEÇÃO ALERTAS — NÃO INTEGRA O CORPO LAVRÁVEL — apague antes do lançamento' +
    (rotuloAto ? ' — ' + rotuloAto : '') + ' · Hub CN2O');
  estiloBase(pt);
  pt.editAsText().setBold(true).setForegroundColor(VINHO);
  if (estado && !/^\s*-?\s*Estado\s*:/m.test(anotacoes)) {
    var pe = body.appendParagraph('Estado: ' + estado);
    estiloBase(pe);
    pe.editAsText().setBold(0, 6, true);
  }
  escreverAnotacoes(body, anotacoes);
  var origem = 'Gerada por ' + (String(p.escrevente || '').trim() || 'escrevente não identificada') +
    ' em ' + dataHoraMaceio(p.gerada_em) + ' pelo Gerador de Minuta do Hub CN2O' +
    (p.modelo ? ' (modelo ' + String(p.modelo).trim() + ')' : '') +
    (p.protocolo ? ' · protocolo ' + String(p.protocolo).trim() : '') + '.';
  var po = body.appendParagraph(origem);
  estiloBase(po);
  po.editAsText().setItalic(true).setForegroundColor(VINHO);

  doc.saveAndClose();

  // pasta de destino + compartilhamento
  var arquivo = DriveApp.getFileById(doc.getId());
  var pasta = 'raiz';
  var pastaId = (props.getProperty('PASTA_ID') || PASTA_PADRAO).trim();
  try {
    var alvo = DriveApp.getFolderById(pastaId);
    arquivo.moveTo(alvo);
    pasta = alvo.getName();
  } catch (err) {
    pasta = 'raiz (pasta ' + pastaId + ' inacessível: ' + String((err && err.message) || err).slice(0, 80) + ')';
  }
  var compartilhar = (props.getProperty('COMPARTILHAR') || '').trim();
  if (compartilhar) {
    try {
      if (compartilhar.toLowerCase() === 'link') {
        arquivo.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.EDIT);
      } else {
        var emails = compartilhar.split(',').map(function (s) { return s.trim(); }).filter(function (s) { return /@/.test(s); });
        if (emails.length) arquivo.addEditors(emails);
      }
    } catch (err2) {
      // compartilhamento é conveniência: falhar aqui não pode derrubar a criação do Doc
    }
  }
  return { id: doc.getId(), url: 'https://docs.google.com/document/d/' + doc.getId() + '/edit', titulo: titulo, pasta: pasta };
}

// Recorta a minuta em: linha "Livro/Folha" (cabeçalho), título (ementa) e corpo (texto
// corrido). Linhas em branco, separadores e restos de markdown caem.
function separarMinuta(minuta) {
  var linhas = minuta.split('\n').map(function (l) {
    return l.replace(/\*\*/g, '').replace(/^#{1,6}\s+/, '').replace(/\s+/g, ' ').trim();
  }).filter(function (l) {
    return l && !/^[-=_*—–]{3,}$/.test(l) && !/^===\s*(MINUTA_COPIAVEL|FIM_MINUTA)\s*===$/.test(l);
  });
  var r = { livroFolha: '', titulo: '', corpo: '' };
  var i = 0;
  // cabeçalho Livro/Folha (nas 3 primeiras linhas)
  for (var k = 0; k < Math.min(3, linhas.length); k++) {
    if (/^Livro\s*:/i.test(linhas[k])) { r.livroFolha = linhas[k]; linhas.splice(k, 1); break; }
  }
  // PRIMEIRO TRASLADO (nas 3 primeiras linhas) — o documento escreve o seu
  for (var j = 0; j < Math.min(3, linhas.length); j++) {
    if (/^PRIMEIRO TRASLADO$/i.test(linhas[j])) { linhas.splice(j, 1); break; }
  }
  if (!linhas.length) return r;
  // ementa: a primeira linha; o corpo começa em "SAIBAM" quando ele vier na mesma linha
  var primeira = linhas[0];
  var mSaibam = /\sSAIBAM\s/.exec(primeira);
  if (mSaibam && mSaibam.index > 20) {
    r.titulo = primeira.slice(0, mSaibam.index).trim();
    linhas[0] = primeira.slice(mSaibam.index + 1).trim();
    i = 0;
  } else {
    r.titulo = primeira;
    i = 1;
  }
  r.corpo = linhas.slice(i).join(' ').replace(/\s{2,}/g, ' ').trim();
  return r;
}

function estiloBase(par) {
  var st = {};
  st[DocumentApp.Attribute.FONT_FAMILY] = FONTE;
  st[DocumentApp.Attribute.FONT_SIZE] = TAMANHO;
  st[DocumentApp.Attribute.FOREGROUND_COLOR] = '#000000';
  st[DocumentApp.Attribute.BOLD] = false;
  st[DocumentApp.Attribute.ITALIC] = false;
  st[DocumentApp.Attribute.UNDERLINE] = false;
  par.setAttributes(st);
  par.setAlignment(DocumentApp.HorizontalAlignment.JUSTIFY);
  par.setIndentStart(0).setIndentFirstLine(0).setIndentEnd(0);
  // v1.30 — espaçamento entre linhas ZERO em todo o corpo do texto: entrelinha simples
  // (1,0) e nenhum espaço antes ou depois do parágrafo (0 pt). Só isto mudou na formatação.
  par.setLineSpacing(1).setSpacingBefore(0).setSpacingAfter(0);
  return par;
}

// ------------------------------------------------------------------ formatação do corpo
// Todas as regras trabalham sobre offsets do texto do parágrafo (fim INCLUSIVO, como a
// API do Apps Script pede). Cada regra só liga o seu atributo: negrito, sublinhado ou cor.
var RE_CAIXA_ALTA = /(?<![A-Za-zÀ-ÿ])[A-ZÁÀÂÃÉÊÍÓÔÕÚÜÇ][A-ZÁÀÂÃÉÊÍÓÔÕÚÜÇ'’\-]+(?:\s+(?:[A-ZÁÀÂÃÉÊÍÓÔÕÚÜÇ][A-ZÁÀÂÃÉÊÍÓÔÕÚÜÇ'’\-]+|D[AEO]S?|E))+(?![A-Za-zÀ-ÿ])/g;
var RE_PLACEHOLDER = /\[[^\[\]\n]{1,300}\]/g;
var RE_CLAUSULA = /(^|\s)(\d{1,2})\.\s+(\S[^\n]{2,140}?)\.(?=\s|$)/g;
var RE_SUBCLAUSULA = /(^|\s)(\d{1,2}\.\d{1,2})\.\s+((?:Da|Do|Das|Dos|De|D[AEO]S?)\s[^\n]{3,140}?)\.(?=\s|$)/g;
// rótulos: "OUTORGANTE:", "PRIMEIRO(A) CONVIVENTE:", "ADVOGADO(A)/DEFENSOR(A) ASSISTENTE:", "EMOLUMENTOS:"
var PALAVRA_ROTULO = "[A-ZÁÀÂÃÉÊÍÓÔÕÚÜÇ][A-ZÁÀÂÃÉÊÍÓÔÕÚÜÇ0-9º'\\-]*(?:\\([A-Z]{1,2}\\))?(?:\\/[A-ZÁÀÂÃÉÊÍÓÔÕÚÜÇ][A-ZÁÀÂÃÉÊÍÓÔÕÚÜÇ0-9º'\\-]*(?:\\([A-Z]{1,2}\\))?)?";
var RE_ROTULO = new RegExp('(^|\\s)(' + PALAVRA_ROTULO + '(?:\\s+' + PALAVRA_ROTULO + '){0,4}):(?=\\s)', 'g');
var RE_MARCADOR = /(^|\s)(\((?:i|ii|iii|iv|v|vi|vii|viii|ix|x|xi|xii)\)|[a-z]\))(?=\s)/g;
var RE_VALOR = /R\$\s?\d{1,3}(?:\.\d{3})*,\d{2}(?:\s\([^)]{3,160}\))?/g;

function formatarCorpo(par) {
  var t = par.editAsText();
  var s = t.getText();
  var m;

  if (/^SAIBAM/.test(s)) t.setBold(0, 5, true);

  // nomes e expressões em CAIXA ALTA (duas ou mais palavras)
  negritarCaixaAlta(par);

  // rótulos "OUTORGANTE:", "OUTORGADO COMPRADOR:", "EMOLUMENTOS:"
  RE_ROTULO.lastIndex = 0;
  while ((m = RE_ROTULO.exec(s)) !== null) {
    var ini = m.index + m[1].length;
    t.setBold(ini, ini + m[2].length, true);   // inclui os dois-pontos
  }

  // marcadores (i) (ii) a) b)
  RE_MARCADOR.lastIndex = 0;
  while ((m = RE_MARCADOR.exec(s)) !== null) {
    var im = m.index + m[1].length;
    t.setBold(im, im + m[2].length - 1, true);
  }

  // valores em reais, com o extenso entre parênteses
  RE_VALOR.lastIndex = 0;
  while ((m = RE_VALOR.exec(s)) !== null) t.setBold(m.index, m.index + m[0].length - 1, true);

  // títulos das cláusulas: "1. DA FINALIDADE E DO OBJETO DO MANDATO." → negrito + sublinhado
  // (só quando o título é de fato CAIXA ALTA — evita "art. 5. Da" e números soltos)
  RE_CLAUSULA.lastIndex = 0;
  while ((m = RE_CLAUSULA.exec(s)) !== null) {
    if (!ehTituloCaixaAlta(m[3])) continue;
    var ic = m.index + m[1].length;
    var fc = ic + m[2].length + 2 + m[3].length - 1;     // até a última letra do título
    t.setBold(ic, fc + 1, true);                          // o ponto final também em negrito
    t.setUnderline(ic, fc, true);
  }
  // subtítulos "8.1. Da dispensa das certidões forenses." (Adendo R-030)
  RE_SUBCLAUSULA.lastIndex = 0;
  while ((m = RE_SUBCLAUSULA.exec(s)) !== null) {
    var isc = m.index + m[1].length;
    var fsc = isc + m[2].length + 2 + m[3].length - 1;
    t.setBold(isc, fsc + 1, true);
    t.setUnderline(isc, fsc, true);
  }

  // placeholders entre colchetes em vermelho ([FALTA…] também em negrito) — por último,
  // para a cor prevalecer sobre qualquer regra anterior
  pintarPlaceholders(par);
}

function ehTituloCaixaAlta(txt) {
  var letras = txt.replace(/[^A-Za-zÀ-ÿ]/g, '');
  if (letras.length < 3) return false;
  var maius = letras.replace(/[^A-ZÁÀÂÃÉÊÍÓÔÕÚÜÇ]/g, '').length;
  return maius / letras.length >= 0.85 && /\s/.test(txt.trim());
}

function negritarCaixaAlta(par) {
  var t = par.editAsText();
  var s = t.getText();
  var m;
  RE_CAIXA_ALTA.lastIndex = 0;
  while ((m = RE_CAIXA_ALTA.exec(s)) !== null) t.setBold(m.index, m.index + m[0].length - 1, true);
}

function pintarPlaceholders(par) {
  var t = par.editAsText();
  var s = t.getText();
  var m;
  RE_PLACEHOLDER.lastIndex = 0;
  while ((m = RE_PLACEHOLDER.exec(s)) !== null) {
    var fim = m.index + m[0].length - 1;
    t.setForegroundColor(m.index, fim, VERMELHO);
    if (/^\[FALTA/i.test(m[0])) t.setBold(m.index, fim, true);
  }
}

// ------------------------------------------------------------------ anotações
// Uma linha por parágrafo. Título em CAIXA ALTA (DECISÃO DO ROTEADOR, PENDÊNCIAS,
// ⚠ CONFERIR…) em negrito; "- Chave: valor" com a chave em negrito; o rodapé de
// rascunho em itálico.
function escreverAnotacoes(body, anotacoes) {
  if (!anotacoes) return;
  var linhas = anotacoes.split('\n').map(function (l) { return l.replace(/\*\*/g, '').replace(/\s+$/, ''); });
  for (var i = 0; i < linhas.length; i++) {
    var l = linhas[i].trim();
    if (!l || /^[-=_*—–]{3,}$/.test(l)) continue;
    var par = body.appendParagraph(l);
    estiloBase(par);
    var t = par.editAsText();
    if (/^(?:⚠\s*)?[A-ZÁÀÂÃÉÊÍÓÔÕÚÜÇ][A-ZÁÀÂÃÉÊÍÓÔÕÚÜÇ0-9 _\/()·—–-]{4,}:?$/.test(l)) {
      t.setBold(true);
      continue;
    }
    if (/^Minuta de rascunho gerada pelo Hub CN2O/.test(l)) { t.setItalic(true); continue; }
    var mm = /^(?:[-•*]\s*)?([A-Za-zÀ-ú][A-Za-zÀ-ú0-9 _?]{1,40}):\s/.exec(l);
    if (mm) {
      var ini = l.indexOf(mm[1]);
      t.setBold(ini, ini + mm[1].length, true);   // inclui os dois-pontos
    }
    pintarPlaceholders(par);
  }
}

function dataHoraMaceio(iso) {
  var d = iso ? new Date(iso) : new Date();
  if (isNaN(d.getTime())) d = new Date();
  return Utilities.formatDate(d, 'America/Maceio', 'dd/MM/yyyy HH:mm');
}

// ------------------------------------------------------------------ teste manual
// Rode `testar()` no editor (Executar) para gerar um Doc de exemplo na pasta configurada.
function testar() {
  var r = criarDocumento({
    titulo: 'TESTE — CriadorDeMinutas — ' + dataHoraMaceio(),
    ato: 'PROC', estado: 'PRELIMINAR COM PENDÊNCIAS (PRELIMINARY_WITH_PENDING_ITEMS) — 1 pendência',
    escrevente: 'Teste do Tabelião', modelo: 'teste', gerada_em: new Date().toISOString(),
    anotacoes: 'DECISÃO DO ROTEADOR\n- Ato: PROC\n- Estado: PRELIMINAR COM PENDÊNCIAS — 1 pendência\n\nPENDÊNCIAS\n- B1 · SUBSTABELECIMENTO · não informado · marcar na entrevista\n\n⚠ CONFERIR\n- minuta preliminar — não apta à assinatura: 1 pendência\n\nMinuta de rascunho gerada pelo Hub CN2O — sujeita à conferência e ao aperfeiçoamento do Tabelião.'
  }, 'Livro: [LAVRATURA: livro]  Folha: [LAVRATURA: folhas]\nPRIMEIRO TRASLADO\nPÚBLICO INSTRUMENTO DE PROCURAÇÃO que faz MARIA DAS GRAÇAS SANTOS em favor de JOÃO PEDRO SANTOS, na forma a seguir.\nSAIBAM quantos este público instrumento de procuração virem que, aos [LAVRATURA: data por extenso] ([LAVRATURA: data dd/mm/aaaa]), nesta cidade de Itabaiana, Estado de Sergipe, República Federativa do Brasil, neste Cartório de Notas do 2º Ofício (CN2O), sito à Avenida Ivo de Carvalho, nº 441, Centro, perante mim, [LAVRATURA: escrevente ou tabelião que lavra e assina], compareceu como OUTORGANTE: MARIA DAS GRAÇAS SANTOS, brasileira, viúva, aposentada, portadora da cédula de identidade RG nº 1.234.567 – SSP/SE, inscrita no CPF/MF sob o nº 123.456.789-00, residente e domiciliada na Rua das Flores, nº 45, Centro, Itabaiana/SE; e, como OUTORGADO: JOÃO PEDRO SANTOS, brasileiro, solteiro, comerciante, inscrito no CPF/MF sob o nº 987.654.321-00.\n1. DA FINALIDADE E DO OBJETO DO MANDATO. A presente procuração é outorgada com a finalidade específica de administrar o imóvel da matrícula 12.345 do 1º Ofício de Registro de Imóveis de Itabaiana/SE.\n2. DOS PODERES ADMINISTRATIVOS. O Outorgado poderá representar a Outorgante perante repartições públicas, podendo (i) apresentar e retirar documentos; (ii) protocolar requerimentos; a) pagar taxas; b) dar quitação.\n3. DO SUBSTABELECIMENTO. [FALTA: substabelecimento — vedado, com reserva ou sem reserva].\n4. DA PROTEÇÃO DE DADOS PESSOAIS. Os dados pessoais serão tratados pela serventia para a prática da função pública notarial. EMOLUMENTOS: [LAVRATURA: emolumentos e selo]. Eu, [LAVRATURA: preposto que digitou e função], digitei; Eu, César Augusto Pereira de Macedo Bravo, Tabelião, lavrei, subscrevo e assino, encerrando o presente ato.',
  PropertiesService.getScriptProperties());
  Logger.log(JSON.stringify(r));
}
