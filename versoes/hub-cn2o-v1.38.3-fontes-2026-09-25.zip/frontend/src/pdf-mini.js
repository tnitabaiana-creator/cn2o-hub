/* ============================================================
   PDF-MINI  ·  v1.33  —  escritor de PDF sem dependência externa
   ------------------------------------------------------------
   O Hub é um único index.html: não há npm nem CDN. Este arquivo
   escreve um PDF válido (1.4) direto em bytes, com as fontes
   padrão Helvetica / Helvetica-Bold (Standard 14, NÃO embutidas,
   /Encoding /WinAnsiEncoding) e imagens JPEG (/DCTDecode).

   API em MILÍMETROS, origem no CANTO SUPERIOR ESQUERDO.
   O "y" de texto() é a LINHA DE BASE (baseline) da escrita.

     var p = new PDFMini({pagina:'A4'});
     p.fonte(true, 12);                      // negrito, 12 pt
     p.texto(11, 20, 'PREFEITURA', {alinhar:'centro', larguraMm:188});
     p.retangulo(11, 24, 188, 5, {preencher:'#A6A6A6', borda:true});
     p.linha(11, 30, 199, 30, {espessura:0.35});
     p.imagemJpeg(base64, 12, 12, 18, 20);
     p.novaPagina();
     p.bytes();  p.blob();

   As tabelas de largura têm 256 entradas (índice = código WinAnsi)
   e vieram dos AFM oficiais da Adobe (campo WX por nome de glifo).
============================================================ */
(function (raiz) {
  'use strict';

  var MM = 72 / 25.4;                 /* 1 mm em pontos PostScript */

  /* larguras Helvetica (regular) por código WinAnsi, em 1/1000 em */
  var LARG_REG = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,278,278,355,556,556,889,667,191,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,278,278,584,584,584,556,1015,667,667,722,722,667,611,778,722,278,500,667,556,833,722,778,667,778,722,667,611,722,667,944,667,667,611,278,278,278,469,556,333,556,556,500,556,556,278,556,556,222,222,500,222,833,556,556,556,556,333,500,278,556,500,722,500,500,500,334,260,334,584,0,556,0,222,556,333,1000,556,556,333,1000,667,333,1000,0,611,0,0,222,222,333,333,350,556,1000,333,1000,500,333,944,0,500,667,278,333,556,556,556,556,260,556,333,737,370,556,584,333,737,333,400,584,333,333,333,556,537,278,333,333,365,556,834,834,834,611,667,667,667,667,667,667,1000,722,667,667,667,667,278,278,278,278,722,722,778,778,778,778,778,584,778,722,722,722,722,667,667,611,556,556,556,556,556,556,889,500,556,556,556,556,278,278,278,278,556,556,556,556,556,556,556,584,611,556,556,556,556,500,556,500];
  /* larguras Helvetica-Bold */
  var LARG_NEG = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,278,333,474,556,556,889,722,238,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,333,333,584,584,584,611,975,722,722,722,722,667,611,778,722,278,556,722,611,833,722,778,667,778,722,667,611,722,667,944,667,667,611,333,278,333,584,556,333,556,611,556,611,556,333,611,611,278,278,556,278,889,611,611,611,611,389,556,333,611,556,778,556,556,500,389,280,389,584,0,556,0,278,556,500,1000,556,556,333,1000,667,333,1000,0,611,0,0,278,278,500,500,350,556,1000,333,1000,556,333,944,0,500,667,278,333,556,556,556,556,280,556,333,737,370,556,584,333,737,333,400,584,333,333,333,611,556,278,333,333,365,556,834,834,834,611,722,722,722,722,722,722,1000,722,667,667,667,667,278,278,278,278,722,722,778,778,778,778,778,584,778,722,722,722,722,667,667,611,556,556,556,556,556,556,889,556,556,556,556,556,278,278,278,278,611,611,611,611,611,611,611,584,611,611,611,611,611,556,611,556];

  /* os 32 pontos do cp1252 que NÃO são Latin-1 (0x80–0x9F) */
  var ESPECIAIS = {
    0x20AC: 0x80, 0x201A: 0x82, 0x0192: 0x83, 0x201E: 0x84, 0x2026: 0x85, 0x2020: 0x86,
    0x2021: 0x87, 0x02C6: 0x88, 0x2030: 0x89, 0x0160: 0x8A, 0x2039: 0x8B, 0x0152: 0x8C,
    0x017D: 0x8E, 0x2018: 0x91, 0x2019: 0x92, 0x201C: 0x93, 0x201D: 0x94, 0x2022: 0x95,
    0x2013: 0x96, 0x2014: 0x97, 0x02DC: 0x98, 0x2122: 0x99, 0x0161: 0x9A, 0x203A: 0x9B,
    0x0153: 0x9C, 0x017E: 0x9E, 0x0178: 0x9F
  };

  /* texto -> array de códigos WinAnsi (fora da tabela vira "?") */
  function paraWinAnsi(txt) {
    var s = String(txt == null ? '' : txt), out = [], i, c;
    for (i = 0; i < s.length; i++) {
      c = s.charCodeAt(i);
      if (c === 10 || c === 13 || c === 9) { out.push(32); continue; }
      if (c < 32) continue;
      if (c < 127) { out.push(c); continue; }
      if (c >= 0xA0 && c <= 0xFF) { out.push(c); continue; }
      if (ESPECIAIS[c] !== undefined) { out.push(ESPECIAIS[c]); continue; }
      out.push(63);                                   /* ? */
    }
    return out;
  }

  /* string literal do PDF, já em latin1, com \ ( ) escapados */
  function literal(codigos) {
    var out = '(', i, c;
    for (i = 0; i < codigos.length; i++) {
      c = codigos[i];
      if (c === 0x5C || c === 0x28 || c === 0x29) out += '\\';
      out += String.fromCharCode(c);
    }
    return out + ')';
  }

  function num(v) {
    var n = Math.round(v * 1000) / 1000;
    if (!isFinite(n)) n = 0;
    return String(n);
  }

  function corPdf(hex) {
    var h = String(hex || '#000000').replace('#', '');
    if (h.length === 3) h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
    var r = parseInt(h.substring(0, 2), 16) / 255,
        g = parseInt(h.substring(2, 4), 16) / 255,
        b = parseInt(h.substring(4, 6), 16) / 255;
    if (isNaN(r) || isNaN(g) || isNaN(b)) { r = g = b = 0; }
    return num(r) + ' ' + num(g) + ' ' + num(b);
  }

  /* base64 -> Uint8Array (sem depender de atob em ambiente sem window) */
  var B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  function deBase64(b64) {
    var s = String(b64 || '').replace(/[^A-Za-z0-9+/=]/g, ''), n = s.length, i, j = 0;
    var pad = s.charAt(n - 1) === '=' ? (s.charAt(n - 2) === '=' ? 2 : 1) : 0;
    var out = new Uint8Array(Math.floor(n / 4) * 3 - pad), acc = 0, bits = 0;
    for (i = 0; i < n; i++) {
      var c = s.charAt(i);
      if (c === '=') break;
      acc = (acc << 6) | B64.indexOf(c); bits += 6;
      if (bits >= 8) { bits -= 8; out[j++] = (acc >> bits) & 0xFF; }
    }
    return out;
  }

  /* dimensões do JPEG (marcadores SOF0..SOF15, menos DHT/JPG/DAC) */
  function tamanhoJpeg(bytes) {
    var i = 2, n = bytes.length;
    while (i < n - 9) {
      if (bytes[i] !== 0xFF) { i++; continue; }
      var m = bytes[i + 1];
      if (m === 0xD8 || m === 0x01 || (m >= 0xD0 && m <= 0xD7)) { i += 2; continue; }
      var tam = (bytes[i + 2] << 8) | bytes[i + 3];
      if (m >= 0xC0 && m <= 0xCF && m !== 0xC4 && m !== 0xC8 && m !== 0xCC) {
        return { altura: (bytes[i + 5] << 8) | bytes[i + 6], largura: (bytes[i + 7] << 8) | bytes[i + 8] };
      }
      i += 2 + tam;
    }
    return { largura: 1, altura: 1 };
  }

  var PAPEIS = { A4: [595.28, 841.89], OFICIO: [612, 1008], CARTA: [612, 792] };

  function PDFMini(op) {
    op = op || {};
    var papel = PAPEIS[String(op.pagina || 'A4').toUpperCase()] || PAPEIS.A4;
    this.larguraPt = papel[0];
    this.alturaPt = papel[1];
    this.larguraMm = this.larguraPt / MM;
    this.alturaMm = this.alturaPt / MM;
    this.paginas = [''];
    this.atual = 0;
    this.negrito = false;
    this.tamanho = 10;
    this.imagens = [];          /* {chave, bytes, largura, altura} */
    this._corTexto = '#000000';
  }

  PDFMini.prototype._add = function (s) { this.paginas[this.atual] += s + '\n'; };
  PDFMini.prototype._x = function (mm) { return mm * MM; };
  PDFMini.prototype._y = function (mm) { return this.alturaPt - mm * MM; };

  PDFMini.prototype.novaPagina = function () {
    this.paginas.push('');
    this.atual = this.paginas.length - 1;
    return this;
  };
  PDFMini.prototype.totalPaginas = function () { return this.paginas.length; };

  PDFMini.prototype.fonte = function (negrito, tamanhoPt) {
    this.negrito = !!negrito;
    if (tamanhoPt) this.tamanho = tamanhoPt;
    return this;
  };
  PDFMini.prototype.corTexto = function (hex) { this._corTexto = hex || '#000000'; return this; };

  /* largura do texto, em mm, na fonte e no corpo correntes */
  PDFMini.prototype.larguraTexto = function (txt, negrito, tamanhoPt) {
    var neg = (negrito === undefined) ? this.negrito : !!negrito;
    var tam = tamanhoPt || this.tamanho;
    var tab = neg ? LARG_NEG : LARG_REG;
    var cods = paraWinAnsi(txt), soma = 0, i;
    for (i = 0; i < cods.length; i++) soma += tab[cods[i]] || 0;
    return (soma / 1000) * tam / MM;
  };

  /* quebra em linhas que cabem em larguraMm (palavra longa é partida) */
  PDFMini.prototype.quebrar = function (txt, larguraMm, negrito, tamanhoPt) {
    var self = this;
    var bruto = String(txt == null ? '' : txt).replace(/\r\n?/g, '\n');
    var paragrafos = bruto.split('\n'), saida = [];
    paragrafos.forEach(function (par) {
      var palavras = par.split(/\s+/).filter(function (p) { return p !== ''; });
      if (!palavras.length) { saida.push(''); return; }
      var linha = '';
      palavras.forEach(function (p) {
        var tenta = linha ? linha + ' ' + p : p;
        if (self.larguraTexto(tenta, negrito, tamanhoPt) <= larguraMm) { linha = tenta; return; }
        if (linha) { saida.push(linha); linha = ''; }
        if (self.larguraTexto(p, negrito, tamanhoPt) <= larguraMm) { linha = p; return; }
        /* palavra sozinha maior que a caixa: parte no caractere */
        var pedaco = '';
        for (var i = 0; i < p.length; i++) {
          if (pedaco && self.larguraTexto(pedaco + p.charAt(i), negrito, tamanhoPt) > larguraMm) {
            saida.push(pedaco); pedaco = '';
          }
          pedaco += p.charAt(i);
        }
        linha = pedaco;
      });
      saida.push(linha);
    });
    return saida;
  };

  /* y = LINHA DE BASE, em mm desde o topo da página */
  PDFMini.prototype.texto = function (x, y, txt, op) {
    op = op || {};
    var s = String(txt == null ? '' : txt);
    if (s === '') return this;
    var px = x;
    if (op.alinhar === 'centro' || op.alinhar === 'dir') {
      var larg = this.larguraTexto(s);
      var caixa = op.larguraMm || 0;
      px = op.alinhar === 'centro' ? x + (caixa - larg) / 2 : x + caixa - larg;
    }
    var cor = op.cor || this._corTexto;
    this._add('BT ' + (cor === '#000000' ? '0 g' : corPdf(cor) + ' rg') +
      ' /' + (this.negrito ? 'F2' : 'F1') + ' ' + num(this.tamanho) + ' Tf' +
      ' 1 0 0 1 ' + num(this._x(px)) + ' ' + num(this._y(y)) + ' Tm ' +
      literal(paraWinAnsi(s)) + ' Tj ET');
    return this;
  };

  PDFMini.prototype.linha = function (x1, y1, x2, y2, op) {
    op = op || {};
    this._add('q ' + corPdf(op.cor || '#000000') + ' RG ' + num((op.espessura || 0.35) * MM) + ' w ' +
      num(this._x(x1)) + ' ' + num(this._y(y1)) + ' m ' +
      num(this._x(x2)) + ' ' + num(this._y(y2)) + ' l S Q');
    return this;
  };

  PDFMini.prototype.retangulo = function (x, y, w, h, op) {
    op = op || {};
    var temBorda = op.borda !== false && (op.borda === true || op.preencher == null);
    var pinta = !!op.preencher;
    if (!temBorda && !pinta) return this;
    var cmd = 'q ';
    if (pinta) cmd += corPdf(op.preencher) + ' rg ';
    if (temBorda) cmd += corPdf(op.corBorda || '#000000') + ' RG ' + num((op.espessura || 0.35) * MM) + ' w ';
    cmd += num(this._x(x)) + ' ' + num(this._y(y + h)) + ' ' + num(w * MM) + ' ' + num(h * MM) + ' re ';
    cmd += (pinta && temBorda) ? 'B' : (pinta ? 'f' : 'S');
    this._add(cmd + ' Q');
    return this;
  };

  PDFMini.prototype.imagemJpeg = function (base64, x, y, w, h) {
    var chave = String(base64).substring(0, 64) + ':' + String(base64).length;
    var achou = -1, i;
    for (i = 0; i < this.imagens.length; i++) if (this.imagens[i].chave === chave) { achou = i; break; }
    if (achou < 0) {
      var bytes = deBase64(base64), dim = tamanhoJpeg(bytes);
      this.imagens.push({ chave: chave, bytes: bytes, largura: dim.largura, altura: dim.altura });
      achou = this.imagens.length - 1;
    }
    this._add('q ' + num(w * MM) + ' 0 0 ' + num(h * MM) + ' ' +
      num(this._x(x)) + ' ' + num(this._y(y + h)) + ' cm /Im' + (achou + 1) + ' Do Q');
    return this;
  };

  /* ---------- montagem do arquivo ---------- */
  function bytesDeLatin1(s) {
    var b = new Uint8Array(s.length), i;
    for (i = 0; i < s.length; i++) b[i] = s.charCodeAt(i) & 0xFF;
    return b;
  }

  PDFMini.prototype.bytes = function () {
    var self = this;
    var nPag = this.paginas.length;
    var objetos = [];                       /* cada item: {cabeca:'string', fluxo:Uint8Array|null} */
    function obj(txt, fluxo) { objetos.push({ cabeca: txt, fluxo: fluxo || null }); return objetos.length; }

    /* 1 catálogo, 2 páginas — reservados */
    objetos.push(null); objetos.push(null);
    var idFonte1 = obj('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
    var idFonte2 = obj('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
    var idImagens = this.imagens.map(function (im) {
      return obj('<< /Type /XObject /Subtype /Image /Width ' + im.largura + ' /Height ' + im.altura +
        ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ' + im.bytes.length + ' >>', im.bytes);
    });
    var recursos = '<< /Font << /F1 ' + idFonte1 + ' 0 R /F2 ' + idFonte2 + ' 0 R >>';
    if (idImagens.length) {
      recursos += ' /XObject << ' + idImagens.map(function (id, i) { return '/Im' + (i + 1) + ' ' + id + ' 0 R'; }).join(' ') + ' >>';
    }
    recursos += ' >>';

    var idsPagina = [];
    for (var p = 0; p < nPag; p++) {
      var corpo = bytesDeLatin1(self.paginas[p]);
      var idFluxo = obj('<< /Length ' + corpo.length + ' >>', corpo);
      var idPag = obj('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + num(self.larguraPt) + ' ' + num(self.alturaPt) + ']' +
        ' /Resources ' + recursos + ' /Contents ' + idFluxo + ' 0 R >>');
      idsPagina.push(idPag);
    }
    objetos[0] = { cabeca: '<< /Type /Catalog /Pages 2 0 R >>', fluxo: null };
    objetos[1] = { cabeca: '<< /Type /Pages /Kids [' + idsPagina.map(function (i) { return i + ' 0 R'; }).join(' ') +
      '] /Count ' + idsPagina.length + ' >>', fluxo: null };

    /* serializa contando bytes */
    var partes = [], total = 0, deslocamentos = [];
    function pedaco(x) {
      var b = (typeof x === 'string') ? bytesDeLatin1(x) : x;
      partes.push(b); total += b.length;
    }
    pedaco('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n');
    objetos.forEach(function (o, i) {
      deslocamentos[i] = total;
      pedaco((i + 1) + ' 0 obj\n' + o.cabeca + '\n');
      if (o.fluxo) { pedaco('stream\n'); pedaco(o.fluxo); pedaco('\nendstream\n'); }
      pedaco('endobj\n');
    });
    var inicioXref = total;
    var xref = 'xref\n0 ' + (objetos.length + 1) + '\n0000000000 65535 f \n';
    objetos.forEach(function (o, i) {
      var d = String(deslocamentos[i]);
      while (d.length < 10) d = '0' + d;
      xref += d + ' 00000 n \n';
    });
    pedaco(xref);
    pedaco('trailer\n<< /Size ' + (objetos.length + 1) + ' /Root 1 0 R >>\nstartxref\n' + inicioXref + '\n%%EOF\n');

    var saida = new Uint8Array(total), pos = 0;
    partes.forEach(function (b) { saida.set(b, pos); pos += b.length; });
    return saida;
  };

  PDFMini.prototype.blob = function () {
    var b = this.bytes();
    return new Blob([b], { type: 'application/pdf' });
  };

  PDFMini.MM = MM;
  PDFMini.paraWinAnsi = paraWinAnsi;
  raiz.PDFMini = PDFMini;
})(typeof window !== 'undefined' ? window : this);
