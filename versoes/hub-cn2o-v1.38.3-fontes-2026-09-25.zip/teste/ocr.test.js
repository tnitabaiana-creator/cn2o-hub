// Testes do MÓDULO REAL backend/ocr.js (o resto da suíte usa um mock).
// Aqui o fetch global é substituído para conferir, sem sair da máquina:
// como a confiança palavra a palavra é lida, como o PDF é fatiado em blocos de
// 5 páginas, e — o mais importante — que a CHAVE DE API nunca vaza em erro.
'use strict';
const assert = require('assert');
const path = require('path');

process.env.GCP_VISION_KEY = 'AIza-CHAVE-SECRETA-DE-TESTE';
delete process.env.GCP_SA_JSON;
delete process.env.DOCAI_PROCESSOR;

const ocr = require(path.join(__dirname, '..', 'backend', 'ocr.js'));

let chamadas = [];
function fingirFetch(responder) {
  chamadas = [];
  global.fetch = async function (url, opcoes) {
    const corpo = JSON.parse(opcoes.body);
    chamadas.push({ url: String(url), corpo: corpo });
    const r = responder(String(url), corpo, chamadas.length);
    return {
      ok: r.ok !== false,
      status: r.status || (r.ok === false ? 400 : 200),
      text: async () => JSON.stringify(r.json !== undefined ? r.json : {})
    };
  };
}

// Monta um fullTextAnnotation com as palavras e confianças pedidas.
function anotacao(palavras) {
  return {
    text: palavras.map(p => p[0]).join(' '),
    pages: [{
      blocks: [{
        paragraphs: [{
          words: palavras.map(function (p) {
            return { confidence: p[1], symbols: p[0].split('').map(ch => ({ text: ch })) };
          })
        }]
      }]
    }]
  };
}

const testes = [];
function t(nome, fn) { testes.push([nome, fn]); }

t('motor: com GCP_VISION_KEY o motor é o Vision e ativo() é verdadeiro', () => {
  assert.strictEqual(ocr.motor(), 'vision');
  assert.strictEqual(ocr.ativo(), true);
  assert.strictEqual(ocr.nomeMotor(), 'Google Cloud Vision');
});

t('imagem: palavras abaixo do limiar entram no bloco; as confiáveis, não', async () => {
  const base = [['Coronel', 0.98], ['Sebastiao', 0.62], ['156', 0.41], ['e', 0.30]];
  for (let i = 0; i < 60; i++) base.push(['texto' + i, 0.97]);
  fingirFetch(() => ({ json: { responses: [{ fullTextAnnotation: anotacao(base) }] } }));
  const r = await ocr.lerArquivos([{ nome: 'rg.png', mime: 'image/png', base64: 'AAAA' }]);
  assert.strictEqual(chamadas.length, 1);
  assert.ok(/images:annotate/.test(chamadas[0].url), chamadas[0].url);
  assert.strictEqual(chamadas[0].corpo.requests[0].features[0].type, 'DOCUMENT_TEXT_DETECTION');
  assert.strictEqual(r.resumo.ativo, true);
  assert.strictEqual(r.resumo.motor, 'vision');
  assert.strictEqual(r.resumo.palavras_incertas, 2, JSON.stringify(r.resumo));
  assert.ok(r.bloco.includes('Google Cloud Vision'), r.bloco.slice(0, 120));
  assert.ok(r.bloco.includes('"Sebastiao"') && r.bloco.includes('confiança 0,62'), r.bloco);
  assert.ok(r.bloco.includes('"156"'), 'número lido com dúvida precisa ser sinalizado');
  assert.ok(!r.bloco.includes('"Coronel"'), 'palavra confiável não devia ser listada');
  assert.ok(!r.bloco.includes('"e"'), 'ruído de 1 caractere não vira apontamento');
});

t('PDF: totalPages manda parar — 7 páginas viram 2 chamadas (5 + 2)', async () => {
  fingirFetch((url, corpo) => {
    const pags = corpo.requests[0].pages;
    return { json: { responses: [{
      totalPages: 7,
      responses: pags.map(n => ({ context: { pageNumber: n }, fullTextAnnotation: anotacao([['pag' + n, 0.99], ['duvida' + n, 0.5]]) }))
    }] } };
  });
  const r = await ocr.lerArquivos([{ nome: 'matricula.pdf', mime: 'application/pdf', base64: 'AAAA' }]);
  assert.strictEqual(chamadas.length, 2, 'esperava 2 chamadas, houve ' + chamadas.length);
  assert.deepStrictEqual(chamadas[0].corpo.requests[0].pages, [1, 2, 3, 4, 5]);
  assert.deepStrictEqual(chamadas[1].corpo.requests[0].pages, [6, 7]);
  assert.ok(/files:annotate/.test(chamadas[0].url), chamadas[0].url);
  assert.strictEqual(r.resumo.paginas, 7);
  assert.strictEqual(r.resumo.palavras_incertas, 7);
  assert.ok(r.bloco.includes('pág. 7'), 'a numeração das páginas tem de seguir o PDF');
});

t('PDF sem totalPages: o bloco encolhe até achar o fim do documento', async () => {
  fingirFetch((url, corpo) => {
    const pags = corpo.requests[0].pages;
    if (pags.some(n => n > 3)) return { ok: false, status: 400, json: { error: { message: 'Invalid pages' } } };
    return { json: { responses: [{ responses: pags.map(n => ({ context: { pageNumber: n }, fullTextAnnotation: anotacao([['p' + n, 0.99]]) })) }] } };
  });
  const r = await ocr.lerArquivos([{ nome: 'curto.pdf', mime: 'application/pdf', base64: 'AAAA' }]);
  assert.strictEqual(r.resumo.ativo, true, JSON.stringify(r.resumo));
  assert.strictEqual(r.resumo.paginas, 3, 'devia ter lido exatamente as 3 páginas');
  assert.ok(chamadas.length >= 2 && chamadas.length <= 6, 'chamadas demais: ' + chamadas.length);
});

t('PDF que falha já na 1ª página: arquivo é PULADO com motivo, sem derrubar nada', async () => {
  fingirFetch(() => ({ ok: false, status: 403, json: { error: { message: 'Cloud Vision API has not been used' } } }));
  const r = await ocr.lerArquivos([{ nome: 'ruim.pdf', mime: 'application/pdf', base64: 'AAAA' }]);
  assert.strictEqual(r.resumo.ativo, false);
  assert.strictEqual(r.bloco, '');
  assert.ok(/falha no OCR/.test(r.resumo.motivo), r.resumo.motivo);
});

t('A CHAVE DE API nunca aparece na mensagem de erro', async () => {
  fingirFetch(() => ({ ok: false, status: 400, json: { error: { message: 'pedido inválido para key=AIza-CHAVE-SECRETA-DE-TESTE' } } }));
  const r = await ocr.lerArquivos([{ nome: 'x.png', mime: 'image/png', base64: 'AAAA' }]);
  const tudo = JSON.stringify(r);
  assert.ok(!tudo.includes('AIza-CHAVE-SECRETA-DE-TESTE'), 'A CHAVE VAZOU: ' + tudo.slice(0, 300));
  assert.ok(tudo.includes('key=***'), 'o endereço devia sair higienizado: ' + tudo.slice(0, 300));
});

t('tipo não suportado é pulado antes de qualquer chamada', async () => {
  fingirFetch(() => ({ json: {} }));
  const r = await ocr.lerArquivos([{ nome: 'planilha.xlsx', mime: 'application/vnd.ms-excel', base64: 'AAAA' }]);
  assert.strictEqual(chamadas.length, 0, 'não podia chamar o Google para um tipo não suportado');
  assert.strictEqual(r.resumo.ativo, false);
  assert.ok(/tipo não suportado/.test(r.resumo.motivo), r.resumo.motivo);
});

t('v1.23: a resposta traz o denominador e a proporção, não só o número solto', async () => {
  const palavras = [];
  for (let i = 0; i < 90; i++) palavras.push(['palavra' + i, 0.99]);
  palavras.push(['Sebastiao', 0.62], ['33.765', 0.55]);
  fingirFetch(() => ({ json: { responses: [{ fullTextAnnotation: anotacao(palavras) }] } }));
  const r = await ocr.lerArquivos([{ nome: 'ok.png', mime: 'image/png', base64: 'AAAA' }]);
  assert.strictEqual(r.resumo.palavras_lidas, 92, JSON.stringify(r.resumo));
  assert.strictEqual(r.resumo.palavras_incertas, 2);
  assert.strictEqual(r.resumo.leitura_dificil, false);
  assert.ok(r.resumo.proporcao > 0.02 && r.resumo.proporcao < 0.03, String(r.resumo.proporcao));
  assert.ok(/2 de 92 palavras lidas = 2,2%/.test(r.bloco), r.bloco.slice(0, 400));
});

t('v1.23: ordena por consequência — número na frente, prosa atrás', async () => {
  const p4 = [['ao', 0.30], ['sua', 0.35], ['ANDRADE', 0.50], ['8.229.175-6', 0.70]];
  for (let i = 0; i < 60; i++) p4.push(['linha' + i, 0.98]);
  fingirFetch(() => ({ json: { responses: [{ fullTextAnnotation: anotacao(p4) }] } }));
  const r = await ocr.lerArquivos([{ nome: 'm.png', mime: 'image/png', base64: 'AAAA' }]);
  const ordem = r.bloco.split('\n').filter(l => l.startsWith('- "')).map(l => l.split('"')[1]);
  assert.deepStrictEqual(ordem, ['8.229.175-6', 'ANDRADE', 'ao', 'sua'], JSON.stringify(ordem));
});

t('v1.23: leitura ruim vira veredito honesto — e a prosa comum fica de fora', async () => {
  const palavras = [];
  for (let i = 0; i < 40; i++) palavras.push(['boa' + i, 0.99]);
  for (let i = 0; i < 70; i++) palavras.push(['ruido' + String.fromCharCode(97 + (i % 20)), 0.40]);
  palavras.push(['265.039.006.297-5', 0.44], ['NIRF', 0.41]);
  fingirFetch(() => ({ json: { responses: [{ fullTextAnnotation: anotacao(palavras) }] } }));
  const r = await ocr.lerArquivos([{ nome: 'ruim.png', mime: 'image/png', base64: 'AAAA' }]);
  assert.strictEqual(r.resumo.leitura_dificil, true, JSON.stringify(r.resumo));
  assert.ok(/LEITURA GLOBALMENTE DIFÍCIL/.test(r.bloco), r.bloco.slice(0, 500));
  assert.ok(/confer[êe]ncia precisa ser integral/i.test(r.bloco), 'faltou mandar conferir o documento inteiro');
  assert.ok(r.bloco.includes('"265.039.006.297-5"'), 'o número tem de aparecer mesmo na lista curta');
  assert.ok(!/"ruidoa"/.test(r.bloco), 'prosa comum não podia entrar na lista curta');
  const listadas = r.bloco.split('\n').filter(l => l.startsWith('- "')).length;
  assert.ok(listadas <= 20, 'lista curta demais longa: ' + listadas);
});

t('v1.23: documento bom não é rotulado de difícil', async () => {
  const palavras = [];
  for (let i = 0; i < 300; i++) palavras.push(['ok' + i, 0.97]);
  for (let i = 0; i < 10; i++) palavras.push(['duvida' + i, 0.50]);
  fingirFetch(() => ({ json: { responses: [{ fullTextAnnotation: anotacao(palavras) }] } }));
  const r = await ocr.lerArquivos([{ nome: 'bom.png', mime: 'image/png', base64: 'AAAA' }]);
  assert.strictEqual(r.resumo.leitura_dificil, false, JSON.stringify(r.resumo));
  assert.ok(!/GLOBALMENTE DIFÍCIL/.test(r.bloco));
});

t('sem chave nenhuma, o OCR fica desligado e o hub segue só com o Gemini', () => {
  const guardada = process.env.GCP_VISION_KEY;
  delete process.env.GCP_VISION_KEY;
  assert.strictEqual(ocr.motor(), null);
  assert.strictEqual(ocr.ativo(), false);
  process.env.GCP_VISION_KEY = guardada;
});

(async () => {
  let ok = 0, falhas = 0;
  for (const [nome, fn] of testes) {
    try { await fn(); console.log('  ✓ ' + nome); ok++; }
    catch (e) { console.log('  ✗ ' + nome + ' → ' + e.message); falhas++; }
  }
  console.log('\n' + ok + ' ok, ' + falhas + ' falha(s)');
  process.exit(falhas ? 1 : 0);
})();
