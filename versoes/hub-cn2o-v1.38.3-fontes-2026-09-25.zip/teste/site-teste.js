// Serve o site (dist do Netlify) + um protocolo.html de mentira que lê a mesma sessão.
'use strict';
const express = require('express');
const path = require('path');
const app = express();
app.use(express.static(path.join(__dirname, 'site')));
const porta = Number(process.env.PORTA || 8088);
app.listen(porta, () => console.log('site de teste em', porta));
