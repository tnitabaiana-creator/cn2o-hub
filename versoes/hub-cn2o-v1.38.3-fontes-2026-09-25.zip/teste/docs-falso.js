// FAKE do web app do Apps Script (ponte Minuta → Google Docs, v1.29) para os testes.
// Só o módulo http do Node: o express da pasta de teste é um shim mínimo, e o fake
// precisa de duas coisas que ele não tem (corpo em texto e redirecionamento).
//
// Imita o comportamento que importa do Apps Script publicado como web app:
//   POST /exec        → lê o corpo (JSON serializado em text/plain, como o hub manda),
//                       guarda a chamada em /tmp/docs-chamadas.json (lista) e responde
//                       302 Location: /resultado?k=<n> — o Google faz exatamente isso
//                       (redireciona o POST para script.googleusercontent.com), e o
//                       fetch do backend/docs.js precisa seguir o redirecionamento
//                       (POST → 302 → GET) para ler a resposta de verdade.
//   GET  /resultado   → o JSON da resposta correspondente à chamada <n>:
//                       segredo ≠ 'segredo-teste'      → { ok: false, erro: 'segredo inválido' }
//                       titulo contendo 'FALHA-DOCS'   → HTTP 500 em texto (Apps Script caído)
//                       senão                           → { ok: true, id: 'doc-teste-<n>',
//                                                           url: 'https://docs.google.com/document/d/doc-teste-<n>/edit' }
// Porta 3997 (fixa, como as 3999/8088). Sobe e cai pelo reiniciar-real.sh.
'use strict';
const fs = require('fs');
const http = require('http');
const { URL } = require('url');

const ARQ = process.env.DOCS_LOG || '/tmp/docs-chamadas.json';
const PORTA = Number(process.env.PORTA || 3997);
const respostas = new Map();   // n → o que /resultado?k=n devolve
let n = 0;

function registrar(chamada) {
  let lista = [];
  try { lista = JSON.parse(fs.readFileSync(ARQ, 'utf8')); } catch (e) { lista = []; }
  lista.push(chamada);
  fs.writeFileSync(ARQ, JSON.stringify(lista));
}
function responderJson(res, status, obj) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(obj));
}
function responderTexto(res, status, texto) {
  res.writeHead(status, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end(texto);
}

const servidor = http.createServer((req, res) => {
  const u = new URL(req.url, 'http://127.0.0.1:' + PORTA);
  if (req.method === 'POST' && u.pathname === '/exec') {
    const partes = [];
    req.on('data', c => partes.push(c));
    req.on('end', () => {
      const corpo = Buffer.concat(partes).toString('utf8');
      let pedido = null;
      try { pedido = JSON.parse(corpo); } catch (e) { pedido = null; }
      n += 1;
      registrar(Object.assign({ n, content_type: req.headers['content-type'] || '' },
        pedido && typeof pedido === 'object' ? pedido : { _corpo_invalido: corpo.slice(0, 200) }));
      if (!pedido || pedido.segredo !== 'segredo-teste') {
        respostas.set(n, { status: 200, json: { ok: false, erro: 'segredo inválido' } });
      } else if (/FALHA-DOCS/.test(String(pedido.titulo || ''))) {
        respostas.set(n, { status: 500, texto: 'Apps Script: falha simulada ao criar o documento' });
      } else {
        respostas.set(n, { status: 200, json: { ok: true, id: 'doc-teste-' + n, url: 'https://docs.google.com/document/d/doc-teste-' + n + '/edit' } });
      }
      // Location absoluta, como a do Google (outro host); aqui o mesmo servidor serve as duas pontas.
      res.writeHead(302, { Location: 'http://127.0.0.1:' + PORTA + '/resultado?k=' + n, 'Content-Type': 'text/html; charset=utf-8' });
      res.end('<html><body>Moved Temporarily</body></html>');
    });
    return;
  }
  if (req.method === 'GET' && u.pathname === '/resultado') {
    const r = respostas.get(Number(u.searchParams.get('k')));
    if (!r) return responderTexto(res, 404, 'resultado desconhecido');
    if (r.json) return responderJson(res, r.status, r.json);
    return responderTexto(res, r.status, r.texto);
  }
  responderTexto(res, 404, 'nada aqui: ' + req.method + ' ' + u.pathname);
});

servidor.listen(PORTA, () => console.log('docs falso (Apps Script) em', PORTA));
