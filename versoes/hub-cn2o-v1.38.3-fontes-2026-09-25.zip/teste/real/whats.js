// MOCK do whats.js (teste local): não dispara WhatsApp.
// Monta, porém, as MESMAS variáveis do recibo pelo módulo REAL (recibo.js), para
// que a suíte confira o que o cliente receberia — não só que o disparo ocorreu.
'use strict';
const fs = require('fs');
const { variaveisDoRecibo } = require('./recibo');
async function dispararRecibos(p, numero) {
  let l = [];
  try { l = JSON.parse(fs.readFileSync('/tmp/whats-chamadas.json', 'utf8')); } catch (e) {}
  // v1.36.1 (teste): registra também os telefones que o disparo recebeu, para a suíte
  // conferir que no CERT o telefone da pessoa do ato (terceiro) nunca chega aqui.
  l.push({ numero, ato: p.ato, dest: p.recibo_destinatarios, vars: variaveisDoRecibo(p, numero),
           tel_apresentante: (p.apresentante && p.apresentante.telefone) || null,
           tel_parte: p.parte_envolvida ? (p.parte_envolvida.telefone === undefined ? null : p.parte_envolvida.telefone) : null });
  fs.writeFileSync('/tmp/whats-chamadas.json', JSON.stringify(l));
}
// v1.37.1 (teste): o server.js também importa enviarTemplate (recibo próprio do CERT e
// /whats/testar), statusWhatsApp e normalizaTelefone. Nada sai para a Meta: só registro.
async function enviarTemplate(telefone, vars, template) {
  let l = [];
  try { l = JSON.parse(fs.readFileSync('/tmp/whats-chamadas.json', 'utf8')); } catch (e) {}
  l.push({ nome: 'enviarTemplate', telefone, template, vars });
  fs.writeFileSync('/tmp/whats-chamadas.json', JSON.stringify(l));
  return { ok: true, simulado: true, template, variaveis: vars.length };
}
function normalizaTelefone(t) { const d = String(t || '').replace(/\D/g, ''); return d ? (d.startsWith('55') ? d : '55' + d) : ''; }
function statusWhatsApp() { return { configurado: false, simulado: true }; }
module.exports = { dispararRecibos, enviarTemplate, normalizaTelefone, statusWhatsApp, ATO_NOME: {} };
