// MOCK do trello.js (teste local): mesmas exportações; grava as chamadas, não toca o Trello real.
'use strict';
const fs = require('fs');
const ARQ = '/tmp/trello-chamadas.json';
function reg(nome, args) { let l = []; try { l = JSON.parse(fs.readFileSync(ARQ, 'utf8')); } catch (e) {} l.push({ nome, args }); fs.writeFileSync(ARQ, JSON.stringify(l)); }
let seq = 0;
// v1.37.1 (teste): estado em memória dos campos personalizados e das etiquetas, para as
// rotas de instalação do Tabelião (POST /hub/admin/trello/...). Começa sem "Preço ajustado";
// o quadro 04 nasce com seis etiquetas SEM nome (como no Trello real).
const camposPorQuadro = {};
const etiquetasPorQuadro = {};
let seqCampo = 0, seqEtiqueta = 0;
const etiquetasIniciais = () => ['green', 'yellow', 'orange', 'red', 'purple', 'blue'].map((color, i) => ({ id: 'lbl-sem-nome-' + (i + 1), name: '', color }));
module.exports = {
  t: async (method, path, corpo) => {
    reg('t', corpo === undefined ? [method, path] : [method, path, corpo]);
    let m;
    if (method === 'GET' && (m = /^\/boards\/([^/]+)\/customFields(\?|$)/.exec(path))) {
      return (camposPorQuadro[m[1]] || []).map(c => ({ id: c.id, name: c.name, type: c.type }));
    }
    if (method === 'POST' && path === '/customFields') {
      const b = corpo || {};
      if (!b.idModel || !b.name || !b.type) throw new Error('mock customFields: idModel, name e type são obrigatórios');
      const novo = { id: 'cf-' + (++seqCampo), name: b.name, type: b.type, idModel: b.idModel };
      (camposPorQuadro[b.idModel] = camposPorQuadro[b.idModel] || []).push(novo);
      return novo;
    }
    if (method === 'GET' && (m = /^\/boards\/([^/]+)\/labels(\?|$)/.exec(path))) {
      return (etiquetasPorQuadro[m[1]] = etiquetasPorQuadro[m[1]] || etiquetasIniciais()).slice();
    }
    if (method === 'POST' && (m = /^\/boards\/([^/]+)\/labels$/.exec(path))) {
      const b = corpo || {};
      if (!b.name) throw new Error('mock labels: name é obrigatório');
      const nova = { id: 'lbl-nova-' + (++seqEtiqueta), name: b.name, color: b.color || null };
      (etiquetasPorQuadro[m[1]] = etiquetasPorQuadro[m[1]] || etiquetasIniciais()).push(nova);
      return nova;
    }
    if (method === 'GET' && /^\/cards\/[^/]+\?/.test(path)) {
      return {
        name: 'Prot. (CV-Urbano) 1400 - COMPRADOR TESTE DE SOUZA', desc: '',
        url: 'https://trello.com/c/TESTE1/prot-1400', shortUrl: 'https://trello.com/c/TESTE1',
        due: '2026-09-21T23:59:00.000Z', dateLastActivity: '2026-09-12T14:10:00.000Z', closed: false,
        idBoard: 'b-tab', idList: 'l-conf',
        list: { name: 'Aguardando última conferência' },
        board: { name: '02 · TABELIÃO' },
        members: [{ fullName: 'César Bravo' }]
      };
    }
    if (method === 'GET' && /\/actions\?/.test(path)) {
      return [
        { type: 'moveCardToBoard', date: '2026-09-12T14:10:00.000Z', data: { board: { name: '02 · TABELIÃO' }, boardSource: { name: '03 · LARA' } } },
        { type: 'updateCard', date: '2026-09-11T16:40:00.000Z', data: { listAfter: { name: 'Preparação de minuta' }, listBefore: { name: 'Checklist' } } },
        { type: 'updateCard', date: '2026-09-10T09:05:00.000Z', data: { listAfter: { name: 'Curadoria de documentos' }, listBefore: { name: 'Digitalização' } } },
        { type: 'createCard', date: '2026-09-09T08:30:00.000Z', data: { list: { name: 'Protocolo / Entrada' } } }
      ];
    }
    if (method === 'GET' && /\/checklists\?/.test(path)) {
      return [{ name: 'DOSSIÊ', checkItems: [
        { name: 'Certidão de ônus atualizada', state: 'incomplete' },
        { name: 'RG/CPF do comprador', state: 'complete' }
      ] }];
    }
    if (method === 'GET' && /^\/search\?/.test(path)) return { cards: [] };
    throw new Error('mock t sem resposta para: ' + method + ' ' + path);
  },
  camposDoQuadro: async () => ({}),
  labelsDoQuadro: async (b) => { reg('labelsDoQuadro', [b]); return { 'Urgente': 'lbl-urg', 'Doc. pendente': 'lbl-doc', 'Santa Mônica': 'lbl-sm', 'Construtor': 'lbl-con', 'Corretor': 'lbl-cor', 'Advogado': 'lbl-adv', 'Loteador/Incorporador': 'lbl-lot' }; },
  criarCartao: async (x) => { reg('criarCartao', [x]); seq++; return { id: 'card-teste-' + seq, shortUrl: 'https://trello.com/c/TESTE' + seq }; },
  // v1.37 (teste): um campo com o valor 'FORCAR-ERRO-CAMPO' simula o Trello recusando o
  // campo personalizado (ex.: tipo número no quadro) — o /protocolo não pode cair por isso
  aplicarCampos: async (...a) => { reg('aplicarCampos', a); if (Object.values(a[2] || {}).includes('FORCAR-ERRO-CAMPO')) throw new Error('mock: campo personalizado recusado pelo Trello'); },
  criarChecklistDossie: async (...a) => { reg('criarChecklistDossie', a); },
  temPendenciaDossie: async () => false,
  aplicarLabelsPorNome: async (...a) => { reg('aplicarLabelsPorNome', a); },
  aplicarCapa: async (...a) => { reg('aplicarCapa', a); },
  cartoesDaLista: async () => [],
  obterCartao: async () => ({})
};
