# -*- coding: utf-8 -*-
"""Auditoria do Hub de Protocolo (protocolo.html).

1) DADOS: extrai perguntasDoAto(ato) do próprio app e aplica as regras
   documentais (pacto antenupcial em regime convencional etc.).
2) UI: para cada ato, clica TODAS as opções de TODAS as perguntas visíveis
   e confere que cada documento 'inj' declarado aparece no checklist do
   dossiê; vigia erros de console.

Saída: auditoria-protocolo.json + resumo no stdout.
"""
import json, os, sys, time, urllib.request
from playwright.sync_api import sync_playwright

SITE = os.environ.get('SITE', 'http://127.0.0.1:8088/')
API = os.environ.get('API', 'http://127.0.0.1:3999')
SAIDA = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'auditoria-protocolo.json')

def api(caminho, corpo=None, token=None):
    req = urllib.request.Request(API + caminho, method='POST' if corpo is not None else 'GET')
    if corpo is not None:
        req.add_header('Content-Type', 'application/json'); req.data = json.dumps(corpo).encode()
    if token: req.add_header('X-Auth-Token', token)
    try:
        with urllib.request.urlopen(req) as r: return r.status, json.loads(r.read() or b'null')
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b'null')

# sessão real do harness
st, r = api('/login', {'login': 'cesar.bravo', 'senha': 'senha-cesar-123'})
if st == 200 and r.get('primeiro_acesso'):
    st, r = api('/definir-senha', {'login': 'cesar.bravo', 'senha': 'senha-cesar-123'})
assert st == 200, (st, r)
TOKEN, NOME = r['token'], r.get('nome', 'César Bravo')

ATOS = ['CV-Urbano', 'CV-Rural', 'CDP', 'CDH', 'DOA', 'PER', 'TEST', 'INV',
        'DIV', 'UE', 'DUE', 'RERRAT', 'ATA-U', 'ATA-W/A']

REGIMES_COM_PACTO = ('comunhão universal', 'separação convencional', 'participação final')
def exige_pacto(op_v):
    v = op_v.lower()
    if 'antes da lei' in v: return False          # regime legal da época
    if 'regra legal' in v or 'art. 1.725' in v: return False
    return any(k in v for k in REGIMES_COM_PACTO)

def eh_pergunta_regime(qid, titulo):
    t = (titulo or '').lower()
    return 'regime' in (qid or '') or 'regime de bens' in t

relatorio = {'quando': time.strftime('%d/%m/%Y %H:%M'), 'atos': {}, 'violacoes_pacto': [],
             'falhas_inj_ui': [], 'erros_console': [], 'regimes_ue_sem_pacto_ok': []}

with sync_playwright() as p:
    nav = p.chromium.launch()
    ctx = nav.new_context(viewport={'width': 1440, 'height': 940}, locale='pt-BR', reduced_motion='reduce')
    ctx.route('**/*', lambda rt: rt.abort() if ('fonts.g' in rt.request.url) else rt.continue_())
    pg = ctx.new_page()
    pg.set_default_timeout(12000)
    pg.add_init_script(f"localStorage.setItem('cn2o_token','{TOKEN}');localStorage.setItem('cn2o_nome','{NOME}');localStorage.setItem('cn2o_cargo','Tabelião');localStorage.setItem('cn2o_hub_key','teste');")
    erros = []
    pg.on('console', lambda m: erros.append(m.text) if m.type == 'error' else None)
    pg.on('pageerror', lambda e: erros.append('pageerror: ' + str(e)))
    pg.goto(SITE + 'protocolo.html')
    pg.wait_for_selector('.chips .chip')

    # -------- 1) AUDITORIA DE DADOS --------
    dados = pg.evaluate("""(atos) => atos.map(a => {
      let qs = [];
      try { qs = perguntasDoAto(a) || []; } catch (e) { return {ato: a, erro: String(e)}; }
      return {ato: a, base: dossieBase(a), perguntas: qs.filter(q => q.ops).map(q => ({
        id: q.id, titulo: q.titulo, multi: !!q.multi, dependeDe: q.dependeDe || null,
        ops: q.ops.map(o => ({v: o.v, inj: o.inj || []}))
      }))};
    })""", ATOS)

    for d in dados:
        ato = d['ato']
        relatorio['atos'][ato] = {'perguntas': len(d.get('perguntas', [])), 'ops_total': 0, 'ops_clicadas_ui': 0, 'inj_conferidos_ui': 0}
        for q in d.get('perguntas', []):
            relatorio['atos'][ato]['ops_total'] += len(q['ops'])
            if eh_pergunta_regime(q['id'], q['titulo']):
                for o in q['ops']:
                    tem_pacto = any('pacto' in i.lower() for i in o['inj'])
                    if exige_pacto(o['v']) and not tem_pacto:
                        # regime da própria união estável (contrato na escritura) não usa pacto
                        if ato in ('UE', 'DUE'):
                            relatorio['regimes_ue_sem_pacto_ok'].append(f"{ato} · {q['id']} · {o['v']}")
                        else:
                            relatorio['violacoes_pacto'].append({'ato': ato, 'pergunta': q['id'], 'opcao': o['v']})

    # -------- 2) AUDITORIA DE UI (clique real em todas as opções visíveis) --------
    for ato in ATOS:
        pg.evaluate("""(a) => {
          S.ato = null; S.respostas = {}; S.dossie = {}; S.qual = {};
          S.qtest = {civil: null, regime: null, benefNat: null, benefQtd: '1', enot: null};
          const chip = [...document.querySelectorAll('.chips .chip')].find(c => c.textContent.trim().startsWith(a) || c.textContent.includes(a));
          chip.click();
        }""", ato)
        pg.wait_for_timeout(120)
        # até 3 varreduras: respostas novas revelam perguntas dependentes
        for _ in range(3):
            paineis = pg.evaluate("""() => {
              const qs = [];
              document.querySelectorAll('#perguntas .pergunta').forEach((div, di) => {
                const ops = [...div.querySelectorAll('.op')].map(o => o.textContent.trim());
                if (ops.length) qs.push({di, ops});
              });
              return qs;
            }""")
            for q in paineis:
                for i in range(len(q['ops'])):
                    r = pg.evaluate("""([di, oi]) => {
                      const div = document.querySelectorAll('#perguntas .pergunta')[di];
                      if (!div) return {pulou: true};
                      const op = div.querySelectorAll('.op')[oi];
                      if (!op) return {pulou: true};
                      op.click();
                      const doss = [...document.querySelectorAll('#listaDossie li')].map(li => li.dataset.item);
                      return {clicou: op.textContent.trim(), doss};
                    }""", [q['di'], i])
                    if r.get('pulou'): continue
                    relatorio['atos'][ato]['ops_clicadas_ui'] += 1
            pg.wait_for_timeout(60)
        # conferência dos inj declarados × dossiê real, por resposta persistida
        conf = pg.evaluate("""() => {
          const falhas = [], okc = {n: 0};
          const qs = perguntasDoAto(S.ato).filter(q => q.ops);
          const doss = () => [...document.querySelectorAll('#listaDossie li')].map(li => li.dataset.item);
          qs.forEach(q => {
            q.ops.forEach(o => {
              if (!(o.inj && o.inj.length)) return;
              // aplica a resposta diretamente e re-renderiza (independe de visibilidade encadeada)
              const guardado = S.respostas[q.id];
              S.respostas[q.id] = q.multi ? [o.v] : o.v;
              if (q.dependeDe) {
                const [dep, val] = q.dependeDe;
                S.respostas[dep] = Array.isArray(val) ? val[0] : val;
              }
              renderPerguntas(); renderDossie();
              const d = doss();
              o.inj.forEach(item => {
                const esta = d.includes(item);
                if (!esta) falhas.push({pergunta: q.id, opcao: o.v, item});
                else okc.n++;
              });
              S.respostas[q.id] = guardado;
            });
          });
          renderPerguntas(); renderDossie();
          return {falhas, ok: okc.n};
        }""")
        relatorio['atos'][ato]['inj_conferidos_ui'] = conf['ok']
        for f in conf['falhas']:
            f['ato'] = ato
            relatorio['falhas_inj_ui'].append(f)

    relatorio['erros_console'] = [e for e in erros if 'favicon' not in e]
    ctx.close(); nav.close()

with open(SAIDA, 'w', encoding='utf-8') as f:
    json.dump(relatorio, f, ensure_ascii=False, indent=1)

print('=== AUDITORIA DO PROTOCOLO ===')
tot_ops = sum(a['ops_total'] for a in relatorio['atos'].values())
tot_cli = sum(a['ops_clicadas_ui'] for a in relatorio['atos'].values())
tot_inj = sum(a['inj_conferidos_ui'] for a in relatorio['atos'].values())
print(f"atos: {len(relatorio['atos'])} · opções mapeadas: {tot_ops} · cliques de UI: {tot_cli} · docs inj conferidos: {tot_inj}")
print(f"VIOLAÇÕES DE PACTO: {len(relatorio['violacoes_pacto'])}")
for v in relatorio['violacoes_pacto']:
    print('  ✗', v['ato'], '·', v['pergunta'], '·', v['opcao'])
print(f"FALHAS INJ×DOSSIÊ (UI): {len(relatorio['falhas_inj_ui'])}")
for f in relatorio['falhas_inj_ui'][:12]:
    print('  ✗', f['ato'], '·', f['pergunta'], '·', f['opcao'], '→ faltou:', f['item'])
print(f"ERROS DE CONSOLE: {len(relatorio['erros_console'])}")
for e in relatorio['erros_console'][:6]:
    print('  !', e[:160])
