// FAKE do web app do Apps Script que lê as PLANILHAS DO ACERVO (10 · Pesquisa / Acervo, v1.33).
// Mesmo espírito do docs-falso.js: só o módulo http do Node, porque o fake precisa de duas
// coisas que o shim de express da pasta de teste não tem — corpo em texto e redirecionamento.
//
// Imita o que importa do LeitorAcervo.gs publicado como web app:
//   POST /exec        → lê o corpo (JSON serializado em text/plain, como o backend/acervo.js
//                       manda), guarda a chamada em /tmp/acervo-chamadas.json e responde
//                       302 Location: /resultado?k=<n> — o Google faz exatamente isso, e o
//                       fetch do acervo.js precisa seguir o redirecionamento (POST → 302 → GET).
//   GET  /resultado   → o JSON da chamada <n>:
//                       segredo ≠ 'segredo-acervo'  → { ok:false, erro:'segredo inválido' }
//                       /exec?modo=falha            → HTTP 500 em texto (Apps Script caído)
//                       versao 2 → { ok:true, fonte, planilha, atualizado_em,
//                                    livros:{colunas,linhas}, atos:{colunas,linhas} }
//                       versao 1 → { ok:true, colunas, linhas, aba } (planilha única, legado)
// Porta 3996 (fixa, como as 3999/8088/3997). Sobe e cai pelo reiniciar-real.sh.
//
// AS DUAS FONTES imitam as planilhas de verdade (cópias do modelo "PAINEL DO ACERVO DE
// LIVROS"), inclusive nas colunas auxiliares (CHAVE DE BUSCA, ALERTA, MATCH_BUSCA), que o
// Hub não conhece e manda para o "mais…":
//   antigo1 → "Acervo 1º Ofício (Antigo ) - SÉRGIO"   — 12 livros e NENHUM ato
//             (a aba INDICE_ATOS só tem o cabeçalho, como hoje)
//   cn2o    → "Acervo 2º Ofício (Antigo e Atual) - MILVO" — 15 livros e 8 atos, com
//             acentos, faixas de folhas, datas em quatro formatos, atos sem link,
//             observação longa, livro sem número (só CAIXA/PASTA) e "Parcial"/"A conferir".
'use strict';
const fs = require('fs');
const http = require('http');
const { URL } = require('url');

const ARQ = process.env.ACERVO_LOG || '/tmp/acervo-chamadas.json';
const PORTA = Number(process.env.PORTA || 3996);
const SEGREDO = process.env.ACERVO_SEGREDO || 'segredo-acervo';

const COL_LIVROS = ['ID_LIVRO', 'TIPO DE LIVRO', 'Nº DO LIVRO', 'CÓDIGO INTERNO', 'STATUS DO LIVRO',
  'SALA/ARQUIVO', 'ESTANTE', 'PRATELEIRA', 'CAIXA/PASTA', 'LOCALIZAÇÃO COMPLETA', 'DIGITALIZADO?',
  'LINK PASTA DIGITAL', 'PENDÊNCIA?', 'OBSERVAÇÕES', 'CHAVE DE BUSCA', 'ALERTA', 'MATCH_BUSCA'];
const COL_ATOS = ['ID_ATO', 'ID_LIVRO', 'TIPO DE ATO', 'DATA DO ATO', 'Nº DO LIVRO', 'FOLHA/INÍCIO',
  'FOLHA/FIM', 'Nº DO ATO', 'PARTE 1 / OUTORGANTE', 'CPF/CNPJ PARTE 1', 'PARTE 2 / OUTORGADO',
  'CPF/CNPJ PARTE 2', 'OBJETO/IMÓVEL', 'MATRÍCULA/REGISTRO', 'VALOR DO ATO/NEGÓCIO', 'TRIBUTO/GUIA',
  'LINK DIGITAL', 'OBSERVAÇÕES', 'CHAVE DE BUSCA'];

const PASTA = 'https://drive.google.com/drive/folders/';
const ARQUIVO = 'https://drive.google.com/file/d/';

// ---------------------------------------------------------------- planilha 1 (antigo1)
const LIVROS_1 = [
  ['LIV-0001', 'Notas', '1', 'NOT-001', 'Arquivado', 'Arquivo morto', 'E03', 'P01', 'CX-001', 'Arquivo morto | E03 | P01', 'Sim', PASTA + 'antigo-not-001', 'Não', 'Livro do 1º Ofício, incorporado em 2019', 'notas 1', '', ''],
  ['LIV-0002', 'Notas', '2', 'NOT-002', 'Arquivado', 'Arquivo morto', 'E03', 'P01', 'CX-001', 'Arquivo morto | E03 | P01', 'Sim', PASTA + 'antigo-not-002', 'Não', '', 'notas 2', '', ''],
  ['LIV-0003', 'Procurações', '5', 'PRO-005', 'Arquivado', 'Arquivo morto', 'E03', 'P02', 'CX-002', 'Arquivo morto | E03 | P02', 'Não', '', 'Sim', 'Capa danificada — restaurar antes de digitalizar', 'procuracoes 5', 'ATENÇÃO', ''],
  ['LIV-0004', 'Procurações', '6', 'PRO-006', 'Arquivado', 'Arquivo morto', 'E03', 'P02', 'CX-002', 'Arquivo morto | E03 | P02', 'Parcial', PASTA + 'antigo-pro-006', 'A conferir', 'Faltam as folhas 40 a 48 na digitalização', 'procuracoes 6', '', ''],
  ['LIV-0005', 'Substabelecimentos', '1', 'SUB-001', 'Arquivado', 'Arquivo morto', 'E03', 'P03', '', 'Arquivo morto | E03 | P03', 'Não', '', 'Não', '', 'substabelecimentos 1', '', ''],
  ['LIV-0006', 'Revogações', '1', 'REV-001', 'Arquivado', 'Arquivo morto', 'E03', 'P03', '', 'Arquivo morto | E03 | P03', 'Não', '', 'Não', '', 'revogacoes 1', '', ''],
  ['LIV-0007', 'Ata Notarial', '3', 'ATA-003', 'Arquivado', 'Arquivo morto', 'E04', 'P01', '', 'Arquivo morto | E04 | P01', 'Sim', PASTA + 'antigo-ata-003', 'Não', '', 'ata notarial 3', '', ''],
  ['LIV-0008', 'Testamentos', '1', 'TES-001', 'Arquivado', 'Cofre', 'C01', 'P01', '', 'Cofre | C01 | P01', 'Não', '', 'Não', 'Guarda no cofre — retirada só com o Tabelião', 'testamentos 1', 'ATENÇÃO', ''],
  ['LIV-0009', 'Escrituras Diversas', '12', 'ESD-012', 'Arquivado', 'Arquivo morto', 'E04', 'P02', 'CX-003', 'Arquivo morto | E04 | P02', 'Sim', PASTA + 'antigo-esd-012', 'Não', '', 'escrituras diversas 12', '', ''],
  ['LIV-0010', 'Compra e Venda', '7', 'CV-007', 'Arquivado', 'Arquivo morto', 'E04', 'P02', 'CX-003', 'Arquivo morto | E04 | P02', 'Sim', PASTA + 'antigo-cv-007', 'Não', 'Índice antigo em fichas de papel', 'compra e venda 7', '', ''],
  ['LIV-0011', 'Inventário/Partilha', '2', 'INV-002', 'Arquivado', 'Arquivo morto', 'E04', 'P03', '', 'Arquivo morto | E04 | P03', 'Não', '', 'Sim', 'Conferir se está completo', 'inventario partilha 2', '', ''],
  ['LIV-0012', 'Reconhecimento/Sinal Público', '4', 'REC-004', 'Arquivado', 'Arquivo morto', 'E05', 'P01', 'CX-004', 'Arquivo morto | E05 | P01', 'Não', '', 'Não', '', 'reconhecimento sinal publico 4', '', '']
];
const ATOS_1 = [];   // a aba INDICE_ATOS desta planilha só tem o cabeçalho

// ---------------------------------------------------------------- planilha 2 (cn2o)
const LIVROS_2 = [
  ['LIV-0001', 'Compra e Venda', '10', 'CV-010', 'Em uso', 'Acervo principal', 'E01', 'P01', '', 'Acervo principal | E01 | P01', 'Não', '', 'Não', '', 'compra e venda 10', '', ''],
  ['LIV-0002', 'Compra e Venda', '9', 'CV-009', 'Arquivado', 'Acervo principal', 'E01', 'P01', '', 'Acervo principal | E01 | P01', 'Sim', PASTA + 'cn2o-cv-009', 'Não', '', 'compra e venda 9', '', ''],
  ['LIV-0003', 'Notas', '20', 'NOT-020', 'Em uso', 'Acervo principal', 'E01', 'P02', '', 'Acervo principal | E01 | P02', 'Parcial', PASTA + 'cn2o-not-020', 'Não', 'Digitalização em andamento pela equipe', 'notas 20', '', ''],
  ['LIV-0004', 'Notas', '19', 'NOT-019', 'Arquivado', 'Acervo principal', 'E01', 'P02', '', 'Acervo principal | E01 | P02', 'Sim', PASTA + 'cn2o-not-019', 'Não', '', 'notas 19', '', ''],
  ['LIV-0005', 'Notas', '18', 'NOT-018', 'Arquivado', 'Acervo principal', 'E01', 'P03', '', 'Acervo principal | E01 | P03', 'Sim', PASTA + 'cn2o-not-018', 'Não', '', 'notas 18', '', ''],
  ['LIV-0006', 'Procurações', '21', 'PRO-021', 'Em uso', 'Acervo principal', 'E02', 'P01', '', 'Acervo principal | E02 | P01', 'Não', '', 'Não', '', 'procuracoes 21', '', ''],
  ['LIV-0007', 'Procurações', '20', 'PRO-020', 'Arquivado', 'Acervo principal', 'E02', 'P01', '', 'Acervo principal | E02 | P01', 'Sim', PASTA + 'cn2o-pro-020', 'Não', '', 'procuracoes 20', '', ''],
  ['LIV-0008', 'Ata Notarial', '13', 'ATA-013', 'Em uso', 'Acervo principal', 'E02', 'P02', '', 'Acervo principal | E02 | P02', 'Sim', PASTA + 'cn2o-ata-013', 'Não', 'Atas de constatação digital', 'ata notarial 13', '', ''],
  ['LIV-0009', 'Testamentos', '2', 'TES-002', 'Em uso', 'Cofre', 'C01', 'P01', '', 'Cofre | C01 | P01', 'Não', '', 'Não', 'Guarda no cofre', 'testamentos 2', 'ATENÇÃO', ''],
  ['LIV-0010', 'Inventário/Partilha', '12', 'INV-012', 'Em uso', 'Acervo principal', 'E02', 'P03', '', 'Acervo principal | E02 | P03', 'Não', '', 'Sim', 'Aguardando conferência das guias de ITCMD', 'inventario partilha 12', '', ''],
  ['LIV-0011', 'Escrituras Diversas', '21', 'ESD-021', 'Em uso', 'Acervo principal', 'E02', 'P03', '', 'Acervo principal | E02 | P03', 'Não', '', 'Não', '', 'escrituras diversas 21', '', ''],
  ['LIV-0012', 'Substabelecimentos', '3', 'SUB-003', 'Arquivado', 'Acervo principal', 'E03', 'P01', '', 'Acervo principal | E03 | P01', 'Sim', PASTA + 'cn2o-sub-003', 'Não', '', 'substabelecimentos 3', '', ''],
  ['LIV-0013', 'Revogações', '2', 'REV-002', 'Arquivado', 'Acervo principal', 'E03', 'P01', '', 'Acervo principal | E03 | P01', 'Não', '', 'Não', '', 'revogacoes 2', '', ''],
  ['LIV-0014', 'Reconhecimento/Sinal Público', '8', 'REC-008', 'Arquivado', 'Acervo principal', 'E03', 'P02', '', 'Acervo principal | E03 | P02', 'Não', '', 'Não', '', 'reconhecimento sinal publico 8', '', ''],
  // livro sem número, guardado em caixa — existe assim na planilha de verdade
  ['LIV-0015', 'Outros', '', '', 'Em tratamento', 'Acervo principal', '', '', 'CX-001', 'Acervo principal | CX-001', 'Parcial', '', 'A conferir', 'Livro sem numeração visível — avaliar com o Tabelião antes de catalogar', 'outros', 'ATENÇÃO', '']
];
const ATOS_2 = [
  ['AT-0001', 'LIV-0001', 'Escritura de compra e venda', '03/02/2025', '10', '12', '15', '021', 'José Antônio da Conceição', '005.588.865-82', 'Maria Aparecida Souza', '111.222.333-44', 'Casa na Rua B, Bairro Marianga', '35.471', 'R$ 250.000,00', 'ITBI 2025/1234', ARQUIVO + 'ato-10-12/view', 'Imóvel urbano — guia de ITBI conferida', 'compra e venda 10 12 15'],
  ['AT-0002', 'LIV-0001', 'Procuração', '10/02/2025', '10', '16', '16', '022', 'Antônio Carlos Menezes', '222.333.444-55', 'Vera Lúcia Menezes', '333.444.555-66', '', '', '', '', ARQUIVO + 'ato-10-16/view', '', 'procuracao 10 16'],
  ['AT-0003', 'LIV-0003', 'União estável', '2025-03-14', '20', '2', '9', '003', 'Inácio Brandão', '444.555.666-77', 'Eunice Silva Brandão', '555.666.777-88', '', '', '', '', '', 'Regime da comunhão parcial de bens', 'uniao estavel 20 2 9'],
  ['AT-0004', 'LIV-0010', 'Inventário e partilha', '15/04/2025', '12', '30', '34', '007', 'Espólio de Sebastião Andrade', '666.777.888-99', 'Herdeiros de Sebastião Andrade', '', 'Sítio Serra Negra, com 3,5 hectares', '12.998', 'R$ 480.000,00', 'ITCMD 2025/77', ARQUIVO + 'ato-12-30/view', 'Guia de ITCMD anexa · aguardando registro no 1º Ofício de Itabaiana · certidão negativa da Receita Federal juntada em 20/04/2025', 'inventario 12 30 34'],
  ['AT-0005', 'LIV-0008', 'Ata notarial', '05/2025', '13', '101', '101', '015', 'Cartório de Notas do 2º Ofício', '', '', '', 'Constatação de conversas em aplicativo', '', '', '', ARQUIVO + 'ato-13-101/view', 'Ata de constatação digital (WhatsApp)', 'ata notarial 13 101'],
  ['AT-0006', 'LIV-0003', 'Escritura de doação', '2025', '20', '12', '15', '030', 'Fulano de Tal', '777.888.999-00', 'Beltrano de Tal', '888.999.000-11', 'Lote 12, Quadra D, Loteamento Alto do Chiara', '41.002', 'R$ 90.000,00', 'ITCMD 2025/90', ARQUIVO + 'ato-20-12/view', '', 'doacao 20 12 15'],
  ['AT-0007', 'LIV-0003', 'Escritura de compra e venda', '20/07/2025', '20', '16', '20', '031', 'Marcos Vinícius Côrtes', '070.922.075-84', 'Júnior César Ferreira Moura', '005.588.865-82', 'Apartamento 402, Edifício Solar', '58.113', 'R$ 320.000,00', 'ITBI 2025/2210', ARQUIVO + 'ato-20-16/view', 'Financiamento CEF', 'compra e venda 20 16 20'],
  ['AT-0008', 'LIV-0009', 'Emancipação', '30/09/2024', '2', '55', '55', '002', 'Rita de Cássia Vieira', '999.000.111-22', 'Lucas Vieira', '000.111.222-33', '', '', '', '', ARQUIVO + 'ato-2-55/view', 'Anuência de ambos os pais', 'emancipacao 2 55']
];

const PLANILHAS = {
  antigo1: { nome: 'Acervo 1º Ofício (Antigo ) - SÉRGIO', livros: LIVROS_1, atos: ATOS_1 },
  cn2o: { nome: 'Acervo 2º Ofício (Antigo e Atual) - MILVO', livros: LIVROS_2, atos: ATOS_2 }
};

// planilha única do contrato antigo (versao 1) — mantida só para provar a compatibilidade
const COL_V1 = ['Livro', 'Fls.', 'Data do ato', 'Natureza', 'Outorgante', 'Outorgado', 'Arquivo no Drive', 'Observações'];
const LINHAS_V1 = [
  ['L-793', '12 a 15', '03/02/2025', 'Escritura de compra e venda', 'José Antônio da Conceição', 'Maria Aparecida Souza', ARQUIVO + 'v1-793/view', 'Imóvel rural'],
  ['L-800', '16 a 20', '20/07/2025', 'Escritura de compra e venda', 'Marcos Vinícius Côrtes', 'Júnior César Ferreira Moura', ARQUIVO + 'v1-800/view', 'Financiamento CEF']
];

const respostas = new Map();   // n → o que /resultado?k=n devolve
let n = 0;

function registrar(chamada) {
  let lista = [];
  try { lista = JSON.parse(fs.readFileSync(ARQ, 'utf8')); } catch (e) { lista = []; }
  lista.push(chamada);
  fs.writeFileSync(ARQ, JSON.stringify(lista));
}
function responderJson(res, status, obj) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(obj));
}
function responderTexto(res, status, texto) {
  res.writeHead(status, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end(texto);
}

const servidor = http.createServer((req, res) => {
  const u = new URL(req.url, 'http://127.0.0.1:' + PORTA);
  if (req.method === 'POST' && u.pathname === '/exec') {
    const partes = [];
    req.on('data', c => partes.push(c));
    req.on('end', () => {
      const corpo = Buffer.concat(partes).toString('utf8');
      let pedido = null;
      try { pedido = JSON.parse(corpo); } catch (e) { pedido = null; }
      n += 1;
      const modo = u.searchParams.get('modo') || '';
      const fonte = PLANILHAS[String((pedido && pedido.fonte) || '')] ? pedido.fonte : 'cn2o';
      // O log guarda que a chamada veio, com que Content-Type e para que fonte —
      // NUNCA o segredo em claro.
      registrar({ n, modo, content_type: req.headers['content-type'] || '',
        versao: pedido && pedido.versao, fonte: (pedido && pedido.fonte) || '',
        segredo_ok: !!(pedido && pedido.segredo === SEGREDO) });
      if (!pedido || pedido.segredo !== SEGREDO) {
        respostas.set(n, { status: 200, json: { ok: false, erro: 'segredo inválido' } });
      } else if (modo === 'falha') {
        respostas.set(n, { status: 500, texto: 'Apps Script: falha simulada ao abrir a planilha' });
      } else if (Number(pedido.versao) === 1) {
        respostas.set(n, { status: 200, json: { ok: true, colunas: COL_V1, linhas: LINHAS_V1,
          aba: 'Acervo', atualizado_em: new Date().toISOString() } });
      } else {
        const p = PLANILHAS[fonte];
        respostas.set(n, { status: 200, json: { ok: true, fonte: fonte, planilha: p.nome,
          atualizado_em: new Date().toISOString(),
          livros: { colunas: COL_LIVROS, linhas: p.livros.concat([COL_LIVROS.map(() => '')]) },
          atos: { colunas: COL_ATOS, linhas: p.atos.slice() } } });
      }
      // Location absoluta, como a do Google (outro host); aqui o mesmo servidor serve as duas pontas.
      res.writeHead(302, { Location: 'http://127.0.0.1:' + PORTA + '/resultado?k=' + n, 'Content-Type': 'text/html; charset=utf-8' });
      res.end('<html><body>Moved Temporarily</body></html>');
    });
    return;
  }
  if (req.method === 'GET' && u.pathname === '/resultado') {
    const r = respostas.get(Number(u.searchParams.get('k')));
    if (!r) return responderTexto(res, 404, 'resultado desconhecido');
    if (r.json) return responderJson(res, r.status, r.json);
    return responderTexto(res, r.status, r.texto);
  }
  if (req.method === 'GET' && u.pathname === '/exec') {
    return responderJson(res, 200, { ok: true, servico: 'LeitorAcervo (falso) — use POST' });
  }
  responderTexto(res, 404, 'nada aqui: ' + req.method + ' ' + u.pathname);
});

servidor.listen(PORTA, () => console.log('acervo falso (Apps Script) em', PORTA));
