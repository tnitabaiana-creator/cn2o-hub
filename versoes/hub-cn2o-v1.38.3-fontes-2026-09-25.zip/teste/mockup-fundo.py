# mockup-fundo.py — duas sugestões de pano de fundo do dashboard (v1.35, para o Tabelião
# escolher ANTES de aplicar). Sobe o site de teste já construído, entra como cesar.bravo,
# injeta o CSS de cada sugestão e tira as capturas. Nada é gravado no projeto.
import os, sys, json, time, urllib.request
from playwright.sync_api import sync_playwright

SITE = os.environ.get('SITE', 'http://127.0.0.1:8088/')
API = os.environ.get('API', 'http://127.0.0.1:3999')
SRC = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'frontend', 'src')
SAIDA = os.environ.get('SAIDA', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'docs', 'sugestoes-fundo-v1.35'))
os.makedirs(SAIDA, exist_ok=True)

def api(caminho, corpo=None):
    req = urllib.request.Request(API + caminho, method='POST' if corpo is not None else 'GET')
    if corpo is not None:
        req.add_header('Content-Type', 'application/json'); req.data = json.dumps(corpo).encode()
    try:
        with urllib.request.urlopen(req) as r: return r.status, json.loads(r.read() or b'null')
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b'null')

def garantir_senha(login, senha):
    st, r = api('/login', {'login': login, 'senha': senha})
    if st == 200 and r.get('primeiro_acesso'):
        api('/definir-senha', {'login': login, 'senha': senha})

ARTE = open(os.path.join(SRC, 'arte-login.b64'), encoding='utf-8').read().strip()
MARMORE = open(os.path.join(SRC, 'marmore.b64'), encoding='utf-8').read().strip()

# ---------------------------------------------------------------- Sugestão A — "Galeria"
# O que há de espaço livre no dashboard é pouco (o conteúdo ocupa quase toda a coluna), então
# o pano de fundo trabalha nos três lugares que ficam à vista: (1) o mármore marfim da home
# em toda a coluna, bem suave; (2) atrás do cabeçalho "Olá", os arcos superiores da arte,
# como marca d'água; (3) o NICHO — a célula vazia da grade de ferramentas (o 8º lugar, que
# sobra em qualquer largura com mais de uma coluna) vira uma "peça de galeria": o recorte
# fotográfico do arco com o cubo vinho, emoldurado como um cartão, com a legenda da home.
NICHO = open('/tmp/nicho.b64').read().strip()
TOPO = open('/tmp/topo.b64').read().strip()
CSS_A = """
.hub-conteudo{position:relative;isolation:isolate;background:#f7f3ee url('%(marmore)s') center/cover no-repeat}
.hub-conteudo::after{content:"";position:absolute;inset:0;z-index:0;pointer-events:none;
  background:linear-gradient(180deg,rgba(250,247,243,0) 0%%,rgba(250,247,243,.35) 30%%,rgba(250,247,243,.55) 100%%)}
.hub-conteudo > *{position:relative;z-index:1}
.card-arte{position:relative;overflow:hidden;border-radius:10px;border:2px solid rgba(32,42,58,.14);box-shadow:0 4px 14px rgba(32,42,58,.10);
  background:#efe9e1 url('%(nicho)s') center/cover no-repeat;min-height:220px}
.card-arte::after{content:"CN2O · Ambiente interno";position:absolute;left:18px;bottom:14px;font-family:'Montserrat',sans-serif;font-weight:600;
  font-size:11px;letter-spacing:.26em;text-transform:uppercase;color:#202a3a;background:rgba(250,247,243,.82);padding:4px 8px;border-radius:4px}
@media (max-width:560px){.card-arte{display:none}}
""" % {'marmore': MARMORE, 'topo': TOPO, 'nicho': NICHO}

# ---------------------------------------------------------------- Sugestão B — "Escultura"
# Os mesmos elementos redesenhados em vetor, como peças de mármore encostadas na coluna:
# um arco marinho grande saindo pela esquerda atrás do cabeçalho e do alto do mural, a
# barra vertical marinho na margem direita (do topo até a faixa Ferramentas), o arco menor
# no rodapé; e, no NICHO da grade, o cubo vinho em perspectiva sobre uma base de mármore —
# uma peça escultórica, não uma foto. Superfície com os veios do mármore, suave.
SVG_B = """
<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1400 1200' preserveAspectRatio='xMidYMin slice'>
  <defs>
    <linearGradient id='mar' x1='0' y1='0' x2='1' y2='1'>
      <stop offset='0' stop-color='#33405a'/><stop offset='.55' stop-color='#202a3a'/><stop offset='1' stop-color='#131a27'/>
    </linearGradient>
    <linearGradient id='aresta' x1='0' y1='0' x2='0' y2='1'>
      <stop offset='0' stop-color='#ffffff' stop-opacity='.6'/><stop offset='1' stop-color='#ffffff' stop-opacity='0'/>
    </linearGradient>
    <filter id='sombra' x='-30%' y='-30%' width='160%' height='160%'>
      <feDropShadow dx='0' dy='14' stdDeviation='14' flood-color='#202a3a' flood-opacity='.28'/>
    </filter>
  </defs>
  <g filter='url(#sombra)'>
    <path d='M -140 520 A 470 470 0 0 1 330 50 L 330 140 A 380 380 0 0 0 -50 520 Z' fill='url(#mar)'/>
    <path d='M 330 50 L 330 62 A 458 458 0 0 0 -128 520 L -140 520 A 470 470 0 0 1 330 50 Z' fill='url(#aresta)'/>
  </g>
  <g filter='url(#sombra)'>
    <rect x='1346' y='0' width='54' height='470' fill='url(#mar)'/>
    <rect x='1346' y='0' width='54' height='12' fill='url(#aresta)'/>
  </g>
</svg>
""".strip().replace('\n', ' ')
SVG_RODAPE = """
<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 600 400' preserveAspectRatio='xMaxYMax slice'>
  <defs>
    <linearGradient id='mar2' x1='0' y1='0' x2='1' y2='1'>
      <stop offset='0' stop-color='#33405a'/><stop offset='1' stop-color='#131a27'/>
    </linearGradient>
  </defs>
  <path d='M 620 40 A 360 360 0 0 0 260 400 L 340 400 A 280 280 0 0 1 620 120 Z' fill='url(#mar2)' opacity='.95'/>
</svg>
""".strip().replace('\n', ' ')
SVG_CUBO = """
<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 300 260'>
  <defs>
    <linearGradient id='topo' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='#8a1f37'/><stop offset='1' stop-color='#6a1529'/></linearGradient>
    <linearGradient id='esq' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='#631325'/><stop offset='1' stop-color='#3e0b17'/></linearGradient>
    <linearGradient id='dir' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='#4f0e1d'/><stop offset='1' stop-color='#2c0710'/></linearGradient>
    <filter id='s' x='-30%' y='-30%' width='160%' height='160%'><feDropShadow dx='0' dy='16' stdDeviation='12' flood-color='#202a3a' flood-opacity='.35'/></filter>
  </defs>
  <ellipse cx='150' cy='214' rx='118' ry='16' fill='#202a3a' opacity='.10'/>
  <g filter='url(#s)'>
    <polygon points='150,48 236,92 150,136 64,92' fill='url(#topo)'/>
    <polygon points='64,92 150,136 150,224 64,180' fill='url(#esq)'/>
    <polygon points='150,136 236,92 236,180 150,224' fill='url(#dir)'/>
    <polygon points='150,48 236,92 150,136 64,92' fill='none' stroke='#ffffff' stroke-opacity='.35' stroke-width='1.5'/>
  </g>
</svg>
""".strip().replace('\n', ' ')
import urllib.parse
def svg_url(s): return 'data:image/svg+xml;utf8,' + urllib.parse.quote(s, safe="~()*!.'-_:/=,; ")
CSS_B = """
#app{background:#e6e1da url('%(marmore)s') center/cover fixed no-repeat}
.hub-conteudo{position:relative;isolation:isolate;background:#faf7f3}
.hub-conteudo::before{content:"";position:absolute;inset:0;z-index:0;pointer-events:none;
  background:url('%(marmore)s') center/cover no-repeat;opacity:.5}
.hub-conteudo::after{content:"";position:absolute;inset:0;z-index:0;pointer-events:none;
  background:url("%(svg)s") center top / 100%% auto no-repeat, url("%(rodape)s") right bottom / 420px auto no-repeat;opacity:.27}
.hub-conteudo > *{position:relative;z-index:1}
.card-arte{position:relative;border-radius:10px;border:2px solid rgba(32,42,58,.14);box-shadow:0 4px 14px rgba(32,42,58,.10);
  background:#f1ece5 url('%(marmore)s') center/cover no-repeat;min-height:220px;display:grid;place-items:center}
.card-arte::before{content:"";width:72%%;aspect-ratio:300/260;background:url("%(cubo)s") center/contain no-repeat}
.card-arte::after{content:"CN2O · Ambiente interno";position:absolute;left:18px;bottom:14px;font-family:'Montserrat',sans-serif;font-weight:600;
  font-size:11px;letter-spacing:.26em;text-transform:uppercase;color:#202a3a}
@media (max-width:560px){.card-arte{display:none}}
""" % {'marmore': MARMORE, 'svg': svg_url(SVG_B), 'rodape': svg_url(SVG_RODAPE), 'cubo': svg_url(SVG_CUBO)}

# ---------------------------------------------------------------- captura
def capturar(pg, nome, css, largura=1366, altura=900, cheia=True):
    pg.set_viewport_size({'width': largura, 'height': altura})
    pg.evaluate("(css) => { const s = document.createElement('style'); s.id = 'mockup'; s.textContent = css; document.head.appendChild(s); }", css)
    pg.wait_for_timeout(500)
    pg.screenshot(path=os.path.join(SAIDA, nome), full_page=cheia)
    pg.evaluate("document.getElementById('mockup') && document.getElementById('mockup').remove()")

garantir_senha('cesar.bravo', 'senha-cesar-123')
with sync_playwright() as p:
    nav = p.chromium.launch()
    ctx = nav.new_context(viewport={'width': 1366, 'height': 900}, device_scale_factor=1)
    pg = ctx.new_page()
    pg.goto(SITE); pg.wait_for_selector('#campoLogin')
    pg.fill('#campoLogin', 'cesar.bravo'); pg.fill('#campoSenha', 'senha-cesar-123'); pg.click('#btnEntrar')
    pg.wait_for_selector('#app:not([hidden])'); pg.wait_for_timeout(1200)
    # fecha o toast e espera o mural carregar
    pg.wait_for_selector('#secFerramentas .card'); pg.wait_for_timeout(600)
    pg.screenshot(path=os.path.join(SAIDA, '00-atual-1366.png'), full_page=True)
    pg.evaluate("() => { const d = document.createElement('div'); d.className = 'card-arte'; d.setAttribute('aria-hidden', 'true'); document.querySelector('#secFerramentas .cards').appendChild(d); }")
    capturar(pg, 'A-galeria-1366.png', CSS_A)
    capturar(pg, 'B-escultura-1366.png', CSS_B)
    # recortes do topo (primeira dobra), para comparar lado a lado
    capturar(pg, 'A-galeria-dobra.png', CSS_A, cheia=False)
    capturar(pg, 'B-escultura-dobra.png', CSS_B, cheia=False)
    nav.close()
print('capturas em', SAIDA, os.listdir(SAIDA))
