# ============================================================================
# 10 · PESQUISA / ACERVO — passo do e2e (v1.33, dois submódulos)
# ----------------------------------------------------------------------------
# JÁ COLADO em teste/e2e.py, logo depois do passo `guia_itbi`. Este arquivo fica
# como cópia de referência do bloco (mesma indentação de lá: 4 espaços, dentro do
# `with sync_playwright()`), usando os mesmos auxiliares: pg, passo, esperar, SHOTS,
# SITE. Neste ponto do e2e o `pg` já está logado como cesar.bravo.
#
# O harness já sobe a ponte do acervo ligada contra o teste/acervo-falso.js (3996),
# que imita as duas planilhas do Tabelião:
#   antigo1 → "Acervo 1º Ofício (Antigo ) - SÉRGIO"   — 12 livros, 0 atos
#   cn2o    → "Acervo 2º Ofício (Antigo e Atual) - MILVO" — 15 livros, 8 atos
# Os dois estados que não dependem do harness — paginação com muitos livros e
# "fonte ainda não vinculada" — são simulados com page.route.
# ============================================================================

    def pesquisa_acervo():
        # --- entra pelo cartão 10 -------------------------------------------------
        if pg.locator('[data-voltar]:visible').count():
            pg.locator('[data-voltar]:visible').first.click()
            pg.wait_for_selector('#paginaHub:not([hidden])')
        assert pg.inner_text('#cardAcervo h3').strip() == 'Pesquisa / Acervo'
        assert pg.inner_text('#cardAcervo .card-num').strip() == '10'
        assert pg.inner_text('#cardAcervo .chip-acervo').strip().upper() == 'ACERVO'   # o CSS põe em versalete
        pg.click('#cardAcervo')
        pg.wait_for_selector('#paginaAcervo:not([hidden])')
        # a fonte escolhida vai para o endereço, como o #minuta=ID do Gerador
        esperar(lambda: pg.evaluate('location.hash') == '#acervo=cn2o', msg='#acervo=cn2o no endereço')

        # --- os dois submódulos ---------------------------------------------------
        abas = pg.evaluate("Array.from(document.querySelectorAll('#acvFontes .acv-aba')).map(b => b.dataset.fonte)")
        assert abas == ['antigo1', 'cn2o'], abas
        assert '1º Ofício' in pg.inner_text('#acvAbaAntigo1')
        assert 'incorporado' in pg.inner_text('#acvAbaAntigo1')
        assert '2º Ofício' in pg.inner_text('#acvAbaCn2o')
        assert pg.get_attribute('#acvAbaCn2o', 'aria-selected') == 'true', 'o 2º Ofício é o padrão'
        assert pg.evaluate("Math.round(parseFloat(getComputedStyle(document.querySelector('#acvAbaCn2o .acv-aba-nome')).fontSize))") >= 16, \
            'as abas dos submódulos são grandes (≥ 16 px)'

        # --- campos e chips de tipo de livro --------------------------------------
        for c in ['acvLivro', 'acvFolhas', 'acvPartes', 'acvDe', 'acvAte', 'acvAno', 'acvAto', 'acvTexto']:
            assert pg.locator('#' + c).count() == 1, 'faltou o campo ' + c
        assert pg.get_attribute('#acvDe', 'type') == 'date' and pg.get_attribute('#acvAte', 'type') == 'date'
        assert pg.evaluate("document.getElementById('acvAto').getAttribute('list')") == 'acvAtos'
        tipos = pg.evaluate("Array.from(document.querySelectorAll('#acvTipos .ed-chip')).map(c => c.dataset.tipo)")
        assert tipos == ['Notas', 'Procurações', 'Substabelecimentos', 'Revogações', 'Ata Notarial', 'Testamentos',
                         'Escrituras Diversas', 'Compra e Venda', 'Inventário/Partilha',
                         'Reconhecimento/Sinal Público', 'Outros'], tipos
        assert pg.evaluate("Math.round(parseFloat(getComputedStyle(document.querySelector('#acvTipos .ed-chip')).fontSize))") >= 16, \
            'chips de tipo de livro em 16 px ou mais'
        assert pg.evaluate("Math.round(parseFloat(getComputedStyle(document.getElementById('acvLivro')).fontSize))") >= 16
        assert pg.evaluate("""Math.round(parseFloat(getComputedStyle(
            document.querySelector('#paginaAcervo .min-campo span')).fontSize) * 10) / 10""") >= 13.5

        # --- a planilha do 2º Ofício está vinculada --------------------------------
        esperar(lambda: not pg.is_hidden('#acvFonte'), msg='quadro do estado da fonte')
        fonte = pg.inner_text('#acvFonte')
        assert 'Índice vinculado' in fonte, fonte
        assert '15 livros catalogados' in fonte and '8 atos indexados' in fonte, fonte
        assert 'MILVO' in fonte, 'o nome da planilha aparece'

        # --- pesquisa por nº do livro: casa nos DOIS grupos ------------------------
        pg.fill('#acvLivro', '10')
        pg.click('#btnAcvPesquisar')
        pg.wait_for_selector('#acvGrupoLivros .acv-tabela tbody tr')
        esperar(lambda: pg.locator('#acvGrupoLivros .acv-tabela tbody tr').count() == 1, msg='1 livro nº 10')
        esperar(lambda: pg.locator('#acvGrupoAtos .acv-tabela tbody tr').count() == 2, msg='2 atos no livro 10')
        assert pg.inner_text('#acvGrupoLivros .acv-grupo-tit').strip() == 'Livros'
        assert pg.inner_text('#acvGrupoAtos .acv-grupo-tit').strip() == 'Atos'
        assert '1 livro encontrado' in pg.inner_text('#acvGrupoLivros .acv-conta')
        assert '2 atos encontrados' in pg.inner_text('#acvGrupoAtos .acv-conta')
        assert 'CV-010' in pg.inner_text('#acvGrupoLivros tbody')
        assert pg.locator('.acv-tabela mark').count() >= 2, 'o nº do livro sai marcado nos dois grupos'
        colL = pg.evaluate("Array.from(document.querySelectorAll('#acvGrupoLivros th')).map(t => t.textContent.trim())")
        assert colL == ['Tipo', 'Nº', 'Código', 'Status', 'Localização', 'Digitalizado', 'Pasta digital', 'Pendência / Obs.'], colL
        colA = pg.evaluate("Array.from(document.querySelectorAll('#acvGrupoAtos th')).map(t => t.textContent.trim())")
        assert colA == ['Livro', 'Folhas', 'Data', 'Ato', 'Partes', 'Arquivo', 'Observações'], colA
        assert 'Acervo principal · E01 · P01' in pg.inner_text('#acvGrupoLivros .acv-c-onde'), pg.inner_text('#acvGrupoLivros .acv-c-onde')
        assert pg.evaluate("Math.round(parseFloat(getComputedStyle(document.querySelector('.acv-tabela td')).fontSize))") >= 16
        assert pg.evaluate("""Math.round(parseFloat(getComputedStyle(
            document.querySelector('.acv-tabela th')).fontSize) * 10) / 10""") >= 13.5
        pg.screenshot(path=SHOTS + '/28-acervo-dois-grupos.png', full_page=True)

        # "Abrir no Drive" no ato; o livro 10 não está digitalizado (sem pasta)
        href = pg.get_attribute('#acvGrupoAtos tbody tr:first-child .acv-abrir', 'href')
        assert href == 'https://drive.google.com/file/d/ato-10-12/view', href
        assert pg.get_attribute('#acvGrupoAtos tbody tr:first-child .acv-abrir', 'target') == '_blank'
        assert pg.locator('#acvGrupoLivros .acv-abrir').count() == 0, 'livro sem pasta digital não ganha botão'
        assert 'NÃO' in pg.inner_text('#acvGrupoLivros .acv-c-dig').upper()   # o selo sai em versalete

        # --- tipo de livro: filtro de prateleira (o grupo Atos sai de cena) --------
        pg.fill('#acvLivro', '')
        pg.click('#acvTipos .ed-chip[data-tipo="Notas"]')
        assert pg.evaluate("Array.from(document.querySelectorAll('#acvTipos .ed-chip')).some(c => c.dataset.tipo === 'Notas' && c.classList.contains('ativo'))")
        pg.click('#btnAcvPesquisar')
        esperar(lambda: pg.locator('#acvGrupoLivros .acv-tabela tbody tr').count() == 3, msg='3 livros de Notas')
        assert '3 livros encontrados' in pg.inner_text('#acvGrupoLivros .acv-conta')
        nota = pg.inner_text('#acvGrupoAtos .acv-recado-nota')
        assert 'Tipo de livro' in nota and 'prateleira' in nota, nota
        assert pg.locator('#acvGrupoAtos .acv-tabela').count() == 0, 'sem tabela de atos nesta busca'
        # "Pasta digital" do livro digitalizado
        pasta = pg.get_attribute('#acvGrupoLivros .acv-abrir', 'href')
        assert pasta.startswith('https://drive.google.com/drive/folders/'), pasta
        assert 'Pasta digital' in pg.inner_text('#acvGrupoLivros .acv-abrir')
        assert 'PARCIAL' in pg.inner_text('#acvGrupoLivros tbody').upper(), 'o selo "Parcial" de DIGITALIZADO?'
        pg.click('#acvTipos .ed-chip[data-tipo="Notas"]')          # clicar de novo desmarca
        assert pg.locator('#acvTipos .ed-chip.ativo').count() == 0

        # --- filtros que são do ATO: o grupo Livros sai de cena --------------------
        pg.fill('#acvFolhas', '14')
        pg.click('#btnAcvPesquisar')
        esperar(lambda: pg.locator('#acvGrupoAtos .acv-tabela tbody tr').count() == 2, msg='folha 14 dentro de "12 a 15"')
        folhas = pg.evaluate("Array.from(document.querySelectorAll('#acvGrupoAtos .acv-c-folhas')).map(t => t.textContent.trim())")
        assert folhas == ['12 a 15', '12 a 15'], folhas
        notaL = pg.inner_text('#acvGrupoLivros .acv-recado-nota')
        assert 'Folhas, partes, data e tipo de ato' in notaL, notaL
        pg.fill('#acvFolhas', '')

        # --- partes sem acento, em outra ordem, e por vírgula ----------------------
        pg.fill('#acvPartes', 'conceicao jose')
        pg.click('#btnAcvPesquisar')
        esperar(lambda: pg.locator('#acvGrupoAtos .acv-tabela tbody tr').count() == 1, msg='partes sem acento')
        assert 'José Antônio da Conceição' in pg.inner_text('#acvGrupoAtos tbody')
        marcas = pg.evaluate("Array.from(document.querySelectorAll('#acvGrupoAtos mark')).map(m => m.textContent)")
        assert 'José' in marcas and 'Conceição' in marcas, marcas
        pg.fill('#acvPartes', 'cortes, junior')
        pg.click('#btnAcvPesquisar')
        esperar(lambda: pg.locator('#acvGrupoAtos .acv-tabela tbody tr').count() == 1, msg='vírgula: os dois nomes')
        pg.fill('#acvPartes', '')

        # --- data: só o ano -------------------------------------------------------
        pg.fill('#acvAno', '2024')
        pg.click('#btnAcvPesquisar')
        esperar(lambda: pg.locator('#acvGrupoAtos .acv-tabela tbody tr').count() == 1, msg='1 ato em 2024')
        assert '30/09/2024' in pg.inner_text('#acvGrupoAtos .acv-c-data')
        pg.fill('#acvAno', '')

        # --- Enter pesquisa; "mais…" abre o resto do ato --------------------------
        pg.fill('#acvTexto', 'serra')
        pg.press('#acvTexto', 'Enter')
        esperar(lambda: pg.locator('#acvGrupoAtos .acv-tabela tbody tr').count() == 1, msg='Enter pesquisa (texto livre)')
        assert 'Inventário' in pg.inner_text('#acvGrupoAtos .acv-c-ato')
        assert pg.locator('#acvGrupoAtos .acv-mais').count() == 1
        assert pg.is_hidden('#acvGrupoAtos .acv-obs-tudo')
        pg.click('#acvGrupoAtos .acv-mais')
        esperar(lambda: not pg.is_hidden('#acvGrupoAtos .acv-obs-tudo'), msg='"mais…" abre')
        tudo = pg.inner_text('#acvGrupoAtos .acv-obs-tudo')
        for alvo in ['certidão negativa da Receita Federal', 'Nº do ato', '007', 'Objeto / imóvel',
                     'Matrícula / registro', '12.998', 'Valor', 'CHAVE DE BUSCA']:
            assert alvo in tudo, 'faltou no "mais…": ' + alvo + ' → ' + tudo[:300]
        pg.click('#acvGrupoAtos .acv-mais')
        esperar(lambda: pg.is_hidden('#acvGrupoAtos .acv-obs-tudo'), msg='"mais…" fecha')
        pg.fill('#acvTexto', '')

        # --- nada encontrado e Limpar ---------------------------------------------
        pg.fill('#acvLivro', '999')
        pg.click('#btnAcvPesquisar')
        pg.wait_for_selector('#acvGrupoLivros .acv-recado-vazio')
        assert 'Nenhum livro com esses filtros' in pg.inner_text('#acvGrupoLivros .acv-recado-vazio')
        assert 'Nenhum ato com esses filtros' in pg.inner_text('#acvGrupoAtos .acv-recado-vazio')
        pg.fill('#acvPartes', 'x'); pg.fill('#acvAno', '2020')
        pg.click('#btnAcvLimpar')
        for c in ['acvLivro', 'acvFolhas', 'acvPartes', 'acvDe', 'acvAte', 'acvAno', 'acvAto', 'acvTexto']:
            assert pg.input_value('#' + c) == '', c + ' continuou preenchido'
        assert pg.inner_text('#acvResultado').strip() == '', 'o resultado sai da tela'

        # --- sem filtro: o acervo inteiro deste submódulo --------------------------
        pg.click('#btnAcvPesquisar')
        esperar(lambda: pg.locator('#acvGrupoLivros .acv-tabela tbody tr').count() == 15, msg='15 livros do 2º Ofício')
        esperar(lambda: pg.locator('#acvGrupoAtos .acv-tabela tbody tr').count() == 8, msg='8 atos do 2º Ofício')
        assert 'MILVO' in pg.inner_text('.acv-quando-pe'), pg.inner_text('.acv-quando-pe')

        # --- troca de submódulo: o outro acervo, com a INDICE_ATOS ainda vazia -----
        pg.click('#acvAbaAntigo1')
        esperar(lambda: pg.get_attribute('#acvAbaAntigo1', 'aria-selected') == 'true', msg='aba do 1º Ofício ativa')
        esperar(lambda: pg.evaluate('location.hash') == '#acervo=antigo1', msg='#acervo=antigo1 no endereço')
        esperar(lambda: 'SÉRGIO' in pg.inner_text('#acvFonte'), msg='planilha do 1º Ofício')
        assert '12 livros catalogados' in pg.inner_text('#acvFonte'), pg.inner_text('#acvFonte')
        assert '0 atos indexados' in pg.inner_text('#acvFonte')
        # a pesquisa é repetida sozinha no acervo recém-escolhido
        esperar(lambda: pg.locator('#acvGrupoLivros .acv-tabela tbody tr').count() == 12, msg='12 livros do acervo antigo')
        vazio = pg.inner_text('#acvGrupoAtos .acv-recado-vazio')
        assert 'Nenhum ato indexado ainda nesta planilha' in vazio, vazio
        assert 'INDICE_ATOS' in vazio, vazio
        assert pg.locator('#acvGrupoAtos .acv-tabela').count() == 0
        pg.screenshot(path=SHOTS + '/29-acervo-antigo-sem-atos.png', full_page=True)
        # e a sessão lembra do submódulo: voltando pelo cartão, é este que abre
        pg.click('#paginaAcervo [data-voltar]')
        pg.wait_for_selector('#paginaHub:not([hidden])')
        pg.click('#cardAcervo')
        pg.wait_for_selector('#paginaAcervo:not([hidden])')
        esperar(lambda: pg.evaluate('location.hash') == '#acervo=antigo1', msg='a aba lembra o último acervo')

        # --- rota direta #acervo=cn2o ---------------------------------------------
        pg.goto(SITE + '#acervo=cn2o')
        pg.wait_for_selector('#paginaAcervo:not([hidden])')
        esperar(lambda: pg.get_attribute('#acvAbaCn2o', 'aria-selected') == 'true', msg='rota direta escolhe o submódulo')
        esperar(lambda: 'MILVO' in pg.inner_text('#acvFonte'), msg='planilha do 2º Ofício pela rota')

        # --- telefone (400 px): sem rolagem lateral, tabelas em cartões ------------
        pg.click('#btnAcvPesquisar')
        esperar(lambda: pg.locator('#acvGrupoAtos .acv-tabela tbody tr').count() == 8, msg='atos do 2º Ofício')
        pg.set_viewport_size({'width': 400, 'height': 860})
        pg.wait_for_timeout(350)
        larg = pg.evaluate("[document.documentElement.scrollWidth, document.documentElement.clientWidth]")
        assert larg[0] <= larg[1] + 1, 'rolagem horizontal no telefone: %s' % larg
        assert pg.evaluate("getComputedStyle(document.querySelector('.acv-tabela td')).display") == 'flex', \
            'no telefone cada linha vira um cartão empilhado'
        assert 'Tipo' in pg.evaluate("getComputedStyle(document.querySelector('#acvGrupoLivros .acv-tabela td'), '::before').content")
        pg.evaluate("document.querySelector('#acvGrupoLivros .acv-tabela tbody tr').scrollIntoView({block:'start'})")
        pg.wait_for_timeout(250)
        pg.screenshot(path=SHOTS + '/30-acervo-telefone.png', full_page=False)
        pg.set_viewport_size({'width': 1366, 'height': 900})
        pg.wait_for_timeout(250)

        # --- "Mostrar mais 50" (simulado: um acervo com 120 livros) ----------------
        muitos = {'vinculado': True, 'fonte': 'cn2o', 'rotulo': 'Acervo · 2º Ofício',
                  'titulo': 'Acervo do 2º Ofício (antigo e atual)', 'planilha': 'Planilha grande',
                  'atualizado_em': '2026-09-16T12:00:00.000Z', 'atos_vazio': True,
                  'totais': {'livros': 120, 'atos': 0},
                  'atos': {'total': 0, 'itens': [], 'pagina': 1, 'paginas': 1, 'por_pagina': 50, 'omitido': False}}
        def pagina_de_livros(rota):
            pag = 2 if 'pagina_livros=2' in rota.request.url else 1
            itens = [{'id': 'LIV-%04d' % k, 'tipo': 'Notas', 'numero': str(k), 'codigo': 'NOT-%03d' % k,
                      'status': 'Arquivado', 'sala': 'Acervo principal', 'estante': 'E01', 'prateleira': 'P01',
                      'caixa': '', 'localizacao': '', 'digitalizado': 'Não', 'pendencia': 'Não',
                      'link': '', 'obs': '', 'extra': {}}
                     for k in range((pag - 1) * 50 + 1, min(pag * 50, 120) + 1)]
            corpo = dict(muitos)
            corpo['livros'] = {'total': 120, 'itens': itens, 'pagina': pag, 'paginas': 3, 'por_pagina': 50, 'omitido': False}
            rota.fulfill(status=200, content_type='application/json; charset=utf-8', body=json.dumps(corpo))
        pg.route('**/hub/acervo?**', pagina_de_livros)
        pg.click('#btnAcvPesquisar')
        esperar(lambda: pg.locator('#acvGrupoLivros .acv-tabela tbody tr').count() == 50, msg='os 50 primeiros livros')
        assert '120 livros encontrados · mostrando 50 primeiros' in pg.inner_text('#acvGrupoLivros .acv-conta')
        assert 'MOSTRAR MAIS 50' in pg.inner_text('#btnAcvMaisLivros').upper()
        pg.click('#btnAcvMaisLivros')
        esperar(lambda: pg.locator('#acvGrupoLivros .acv-tabela tbody tr').count() == 100, msg='mais 50 livros')
        assert '120 livros encontrados · mostrando 100 primeiros' in pg.inner_text('#acvGrupoLivros .acv-conta')
        pg.unroute('**/hub/acervo?**')

        # --- estado "fonte ainda não vinculada" (simulado) ------------------------
        SEM_FONTE = json.dumps({'vinculado': False, 'fonte': 'cn2o', 'planilha': '', 'atualizado_em': None,
                                'atos_vazio': True,
                                'livros': {'total': 0, 'itens': [], 'pagina': 1, 'paginas': 1, 'por_pagina': 50, 'omitido': False},
                                'atos': {'total': 0, 'itens': [], 'pagina': 1, 'paginas': 1, 'por_pagina': 50, 'omitido': False}})
        pg.route('**/hub/acervo**', lambda r: r.fulfill(status=200, content_type='application/json; charset=utf-8', body=SEM_FONTE))
        pg.goto(SITE + '#acervo=cn2o')
        pg.reload()                      # recarrega de verdade: a tela volta a perguntar pela fonte
        pg.wait_for_selector('#paginaAcervo:not([hidden])')
        esperar(lambda: 'não foi vinculad' in pg.inner_text('#acvFonte'), msg='aviso de fonte não vinculada')
        aviso = pg.inner_text('#acvFonte')
        assert 'O índice do acervo ainda não foi vinculado ao Hub.' in aviso, aviso
        assert 'planilha do Google Sheets' in aviso, aviso
        for c in ['acvLivro', 'acvPartes', 'acvAto']:
            assert not pg.evaluate("document.getElementById('%s').disabled" % c), c + ' deveria continuar habilitado'
        assert not pg.evaluate("document.querySelector('#acvTipos .ed-chip').disabled"), 'os chips continuam clicáveis'
        pg.fill('#acvLivro', '10')
        pg.click('#btnAcvPesquisar')
        pg.wait_for_selector('.acv-recado-aviso')
        assert 'O índice do acervo ainda não foi vinculado ao Hub.' in pg.inner_text('.acv-recado-aviso')
        pg.screenshot(path=SHOTS + '/31-acervo-nao-vinculado.png', full_page=True)
        pg.unroute('**/hub/acervo**')
        pg.goto(SITE)
        pg.wait_for_selector('#app:not([hidden])')
    passo('10 · Pesquisa / Acervo: dois submódulos (1º e 2º Ofício), grupos Livros e Atos, nº e tipo de livro, folhas/partes/data/ato com <mark>, "Pasta digital" e "Abrir no Drive", "mais…", INDICE_ATOS vazia, "Mostrar mais 50", telefone 400 px e o estado "ainda não vinculada"', pesquisa_acervo)
