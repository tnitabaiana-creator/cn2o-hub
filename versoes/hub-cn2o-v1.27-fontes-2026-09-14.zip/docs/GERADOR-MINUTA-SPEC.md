# Gerador de Minuta — especificação do roteador (v1.27)

*Cartório de Notas do 2º Ofício de Itabaiana/SE · Hub CN2O · 14/09/2026*

## 0. Origem e propósito

O Tabelião entregou o `QUALITY_ASSURANCE_ENGINE` (Arquitetura 1.0) — a camada de TESTES de um
gerador de minutas — e pediu que o card 05 do Hub ("Gerador PROC / UE") vire **"Gerador de
Minuta"**, com botões e sub-botões pelos quais a escrevente informa o caso, e que o próprio
gerador **decida** o tipo/modelo/variante da minuta. Objetivo declarado: *retirar da escrevente,
ao máximo, o poder decisório sobre tipo/modelo/variável.*

Princípio de desenho que decorre disso: **a escrevente informa FATOS e a VONTADE do cliente;
o roteador escolhe o modelo.** Nenhum botão da tela se chama "modelo X". Os botões capturam
(a) o ato pretendido, (b) a finalidade em linguagem de balcão, (c) fatos com consequência
jurídica — e, onde o QA exige, a opção **"não sabemos / não informado"** (UNKNOWN ≠ FALSE).

## 1. Atos cobertos (catálogo do QA, §94–§98)

| Código | Ato | Fonte dos golden cases |
|---|---|---|
| `PROC` | Procuração pública | §94 |
| `UE` | Escritura declaratória de união estável | §95 |
| `DISS_UE` | Escritura de dissolução (extinção consensual) de união estável | §96 |
| `DIV` | Escritura de divórcio consensual **sem partilha / partilha diferida** | §97 |
| `EMANC` | Escritura de emancipação voluntária | §98 |

Fora desses cinco: `FORA_DO_ESCOPO` → o gerador **não aproxima** (QA §74). Em especial:
divórcio/dissolução **com partilha** de bens no mesmo ato; inventário; compra e venda; doação;
cessão de direitos; testamento; pacto antenupcial.

## 2. Contrato da ficha (o que a tela manda ao servidor)

A tela compõe um bloco de texto, uma chave por linha. Valores ausentes viajam como
`nao_informado` — nunca são omitidos em silêncio, para o modelo enxergar o UNKNOWN. Por isso
**toda enumeração abaixo admite `nao_informado`**, mesmo quando não listado; as exceções
`nao_se_aplica` estão marcadas. Texto livre (OBSERVACOES, FINALIDADE_DESCRICAO, FILHOS) é
achatado em uma linha ou recuado, para que nunca vire chave falsa da ficha. Nenhum chip com
consequência jurídica nasce pré-marcado (inclusive REGIME da UE): a escrevente escolhe.

```
=== ENTREVISTA DIRIGIDA — GERADOR DE MINUTA ===
ATO: PROC | UE | DISS_UE | DIV | EMANC
<chaves do ato, abaixo>
OBSERVACOES: <texto livre da escrevente>
```

O servidor acrescenta, por conta própria: `=== HOJE ===` (data), `=== QUEM ESTÁ MINUTANDO ===`
(escrevente da sessão) e, com anexos, a `=== LEITURA OCR DEDICADA ===`.

### 2.1 PROC

```
FINALIDADE: imovel_administrar | imovel_vender | imovel_comprar | bancaria | financiamento |
            veiculo_regularizar | veiculo_vender | inventario | previdenciaria | ad_judicia |
            casamento | divorcio_ue | outra
FINALIDADE_DESCRICAO: <o que o cliente quer, nas palavras da escrevente>
OUTORGANTES: <n>
OUTORGANTE_<i>: <nome> · <PF|PJ> · <estado civil> · <regime, se casado> · <capaz|representado por …>
OUTORGADOS: <n>
OUTORGADO_<i>: <nome> · <parentesco/vínculo, se informado>
ATUACAO: conjunta | separadamente | nao_informado
OBJETO: <imóvel: matrícula + CRI | veículo: placa/RENAVAM | conta: banco/agência | espólio: autor da herança | processo: nº/juízo> | nao_informado
PODERES_ALTO_RISCO: <lista separada por vírgula, SOMENTE os marcados> entre
   vender, receber_preco, dar_quitacao, doar, hipotecar_gravar, contrair_emprestimo,
   confessar_divida, transigir, renunciar, receber_citacao, ceder_direitos_hereditarios, substabelecer
   e, só para ad_judicia (CPC 105): confessar, reconhecer_procedencia, desistir,
   firmar_compromisso, declarar_hipossuficiencia
   (vazio = nenhum)
AUTOCONTRATO: sim | nao | nao_informado
PRECO: livre | fixado: R$ … | nao_se_aplica
PRAZO: indeterminado | ate dd/mm/aaaa | nao_informado
SUBSTABELECIMENTO: vedado | com_reserva | sem_reserva | nao_informado
```

### 2.2 UE

```
CONVIVENTE_1: <nome> · <estado civil registral> · <data de nascimento, se informada>
CONVIVENTE_2: idem
INICIO_CONVIVENCIA: dd/mm/aaaa | nao_sabem_precisar | nao_informado
REGIME: legal_comunhao_parcial | convencao: <regime escolhido> | nao_informado
MAIOR_70: sim (<quem>) | nao | nao_informado
FILHOS: nenhum | sim: <nome (dd/mm/aaaa)…> | nao_informado
NOME: ninguem_altera | convivente_1_acrescenta: <novo nome> | convivente_2_acrescenta: <novo nome> | ambos: convivente 1 → <novo nome>; convivente 2 → <novo nome>
TITULO_ANTERIOR: nenhum | escritura_anterior: <serventia, livro, folhas, data> | contrato_particular | nao_informado
LIVRO_E: registrada | nao_registrada | nao_informado
ENDERECO_COMUM: <endereço>
```

### 2.3 DISS_UE

```
CONVIVENTE_1 / CONVIVENTE_2: <nome> · <estado civil registral>
TITULO_ANTERIOR: nenhum | escritura: <dados> | contrato_particular | nao_informado
LIVRO_E: registrada | nao_registrada | nao_informado
BENS_COMUNS: nao | sim | nao_informado
PARTILHA: nenhuma_a_fazer | diferida | agora            (agora ⇒ FORA_DO_ESCOPO)
FILHOS: nenhum | capazes | incapazes | nao_informado
DECISAO_JUDICIAL_FILHOS: cobre_guarda_convivencia_alimentos: <juízo, autos, data> | parcial: <o que falta> | nao_ha | nao_se_aplica
GRAVIDEZ: nao | sim | desconhece
ALIMENTOS_ENTRE_CONVIVENTES: dispensa_reciproca | fixados: <valor/forma> | nao_informado
NOME: cada_um_mantem | retoma_nome_anterior: <quem>
ADVOGADO: <nome · OAB> | nao_informado
REPRESENTACAO: pessoal | por_procuracao: <data da outorga, serventia>
```

### 2.4 DIV

```
CONJUGE_1 / CONJUGE_2: <nome>
CASAMENTO: <data · serventia · matrícula> · certidão emitida em dd/mm/aaaa | nao_informado
REGIME: <regime>
BENS_COMUNS: nao | sim | nao_informado
PARTILHA: nenhuma_a_fazer | diferida | agora            (agora ⇒ FORA_DO_ESCOPO)
FILHOS: nenhum | maiores_capazes | menores_ou_incapazes | nao_informado
DECISAO_JUDICIAL_FILHOS: cobre_guarda_convivencia_alimentos: <…> | parcial: <…> | nao_ha | nao_se_aplica
GRAVIDEZ: nao | sim | desconhece
PENSAO_ENTRE_CONJUGES: dispensa_reciproca | fixada: <…> | nao_informado
NOME: cada_um_mantem | retoma_nome_de_solteiro: <quem>
ADVOGADO: <nome · OAB> | nao_informado
REPRESENTACAO: pessoal | por_procuracao: <data da outorga, serventia>
```

### 2.5 EMANC

```
MENOR: <nome> · nascido em dd/mm/aaaa
QUEM_OUTORGA: ambos_os_pais | um_dos_pais: <qual> | tutor
MOTIVO_UM_SO: outro_falecido | filiacao_unica | destituido_ou_suspenso_por_decisao: <dados> | outro_nao_localizado | outro_discorda | nao_informado
GUARDA: compartilhada | unilateral: <quem> | nao_informado
EMANCIPACAO_ANTERIOR: nao | sim: <como> | nao_informado
FINALIDADE: <opcional>
```

## 3. Roteamento — regras por ato

Regra prévia — **correção do ato marcado**: o campo `ATO` é hipótese da escrevente. Se o conteúdo mostrar inequivocamente outro dos cinco atos, o roteador declara o ato correto e **BLOQUEIA** ("entrevista preenchida para X; o ato é Y"), pedindo que a entrevista seja refeita no ato certo — nunca minuta o ato corrigido com chaves que a tela não perguntou. Conteúdo ambíguo ⇒ CONFLITADO ⇒ BLOQUEIO.

Notação: `BLOQUEIO` = não minutar; devolver a qualificação ao Tabelião com o motivo e o que
destravaria. `ALERTA` = minutar e apontar no ⚠ CONFERIR. Toda citação normativa da minuta
também vai ao ⚠ CONFERIR.

### 3.1 PROC

Regra-mãe: **mandato em termos gerais só confere administração; alienar, hipotecar, transigir
ou exorbitar da administração ordinária exige poderes especiais e expressos** (CC art. 661,
§1º; o poder de transigir não importa o de firmar compromisso, §2º). Logo: **nenhum poder de
alto risco entra na minuta se não estiver em `PODERES_ALTO_RISCO`** — nem por "praxe", nem
porque o modelo de referência o traz (POISON PROC-01/02/03).

| Finalidade | Variante | Poderes mínimos | Exige/Alerta |
|---|---|---|---|
| imovel_administrar | `PROC.IMOVEL.ADMIN` | administrar, locar, receber aluguéis, representar em condomínio, pagar tributos | `vender`, `hipotecar_gravar` só se marcados |
| imovel_vender | `PROC.IMOVEL.VENDA` | vender (e só o que estiver marcado: receber_preco, dar_quitacao) | OBJETO com matrícula — sem individualização: `ALERTA ESPECIALIDADE_PENDENTE` (§166); PRECO livre ⇒ alerta de risco; outorgante casado ⇒ alerta de vênia (CC 1.647, I) |
| imovel_comprar | `PROC.IMOVEL.COMPRA` | comprar, pagar, assinar escritura | `financiamento` só se marcado hipotecar_gravar/contrair_emprestimo |
| bancaria | `PROC.BANCARIA` | movimentar conta (sacar, depositar, emitir cheques, extratos) | empréstimo/financiamento/confissão de dívida **só se marcados** (POISON PROC-03) |
| financiamento | `PROC.FINANCIAMENTO` | contratar financiamento, dar o imóvel em garantia | R5: exige `hipotecar_gravar` e `contrair_emprestimo` marcados; senão `BLOQUEIO` |
| veiculo_regularizar | `PROC.VEICULO.REGULARIZE` | transferir para o nome do outorgante, licenciar, DETRAN, multas | **proibido** transferir a terceiro ou ao procurador (POISON PROC-02) |
| veiculo_vender | `PROC.VEICULO.VENDA` | vender, assinar CRV/ATPV | OBJETO com placa/RENAVAM; AUTOCONTRATO só se `sim` |
| inventario | `PROC.INVENTARIO` | representar em inventário, requerer, assinar escritura de inventário, receber quinhão | **cessão de direitos hereditários só com `ceder_direitos_hereditarios`** (POISON SUCCESSION-01); a cessão exige escritura pública (CC 1.793) ⇒ poderes especiais e expressos |
| previdenciaria | `PROC.PREVIDENCIARIA` | requerer/receber benefício, INSS | `receber` de valores é alto risco: alertar |
| ad_judicia | `PROC.AD_JUDICIA` | cláusula ad judicia et extra (CPC 105) | os 10 poderes especiais do art. 105 só se marcados (receber_citacao, transigir, renunciar, dar_quitacao…) |
| casamento | `PROC.CASAMENTO` | representar no casamento com <nubente> | instrumento público, poderes especiais, **eficácia 90 dias** (CC 1.542, §3º) — PRAZO forçado |
| divorcio_ue | `PROC.DIVORCIO_UE` | representar no divórcio/extinção de UE, com as **cláusulas essenciais** descritas | pública, poderes especiais, **validade 30 dias** (Res. CNJ 35, art. 36; art. 46-A para UE) — PRAZO forçado; se as cláusulas essenciais não vierem em OBSERVACOES ⇒ `BLOQUEIO` |
| outra | classificar pela descrição; se não couber em nenhuma ⇒ `PROC.ESPECIAL` restrita ao descrito | se a descrição pedir "poderes amplos/gerais para tudo" ⇒ `ALERTA` e minuta só com administração (CC 661) |

Transversais:
- `AUTOCONTRATO = sim` ⇒ cláusula expressa autorizando o negócio consigo mesmo (CC 117); `nao`
  ⇒ cláusula de vedação; `nao_informado` e finalidade de alienação ⇒ `ALERTA SELF_CONTRACT_CHECK`
  (§42, §167) — nunca presumir.
- `SUBSTABELECIMENTO`: a modalidade só produz cláusula se `substabelecer` estiver em `PODERES_ALTO_RISCO`; `vedado`, `nao_informado` ou modalidade sem a marcação ⇒ cláusula de vedação + ALERTA (UNKNOWN não é autorização).
- Poder marcado que **não** se relaciona com a finalidade (ex.: `doar` numa procuração de
  regularização de veículo) ⇒ `ALERTA` de incongruência; incluir só com nota.
- OUTORGANTE `PJ` ⇒ exigir representante e fundamento (contrato social/ata); ausência ⇒ [FALTA].
- Outorgante que assina a rogo/analfabeto ⇒ ALERTA de formalidade (duas testemunhas).

### 3.2 UE

- Estado civil `casado` de qualquer convivente ⇒ a escritura é lícita se separado de fato
  (CC 1.723, §1º), **mas não é registrável no Livro E** (Lei 6.015, art. 94-A, §1º) ⇒ variante
  `UE.SEPARADO_DE_FATO`: cláusula de declaração da separação de fato + advertência de
  irregistrabilidade + **NOME não pode ser alterado** (LRP 57, §2º exige UE registrada). A separação de fato só entra se DECLARADA pelas partes (em OBSERVACOES); casado sem essa declaração ⇒ `BLOQUEIO` (impedimento, CC 1.723 §1º c/c 1.521, VI);
  se `NOME ≠ ninguem_altera` ⇒ `BLOQUEIO` desse pedido (minutar sem a cláusula de nome).
- `REGIME = convencao` ⇒ cláusula de regime **com efeitos a partir desta data, sem retroação**;
  até então vigorou a comunhão parcial (CC 1.725; STJ REsp 1.597.675/SP e 1.845.416/MS; CNN
  art. 547, §4º). Qualquer pedido de retroação ⇒ `RETROACTIVITY_ALERT` e recusa da cláusula
  (POISON UE-02).
- `MAIOR_70 = sim` ⇒ regime legal é separação obrigatória (CC 1.641, II; Súmula 655/STJ);
  pode ser afastado **por expressa manifestação em escritura pública** (STF, Tema 1236, ARE
  1.309.642, j. 01/02/2024), com efeitos ex nunc ⇒ variante `UE.SEPTUAGENARIO`: se as partes
  escolheram regime diverso, cláusula expressa invocando o Tema 1236; se não escolheram,
  consignar a separação obrigatória.
- `TITULO_ANTERIOR = escritura_anterior` ⇒ variante `UE.TITULO_ANTERIOR`: referenciar o título
  e a finalidade da nova escritura (ratificação/alteração); `LIVRO_E = registrada` ⇒ prever
  averbação; `nao_informado` ⇒ **UNKNOWN**: não afirmar registro nem inexistência (§24).
- `NOME` com acréscimo ⇒ cláusula condicionada ao registro no Livro E (LRP 57, §2º; 94-A, VIII).
- `FILHOS = nao_informado` ⇒ escrever "não há informação sobre filhos" e [FALTA]; nunca
  "não têm filhos" (§14).
- `INICIO_CONVIVENCIA = nao_sabem_precisar` ⇒ cláusula sem data precisa ("há cerca de …"
  somente se informado) + ALERTA.

### 3.3 DISS_UE

- `PARTILHA = agora` ⇒ `FORA_DO_ESCOPO`. `BENS_COMUNS = sim` ⇒ `PARTILHA_DIFERIDA` obrigatória
  (cláusula: os bens serão partilhados em ato próprio; **sem** atribuição, transferência ou
  quitação patrimonial — P5, §33, §35). `BENS_COMUNS = nao` ⇒ cláusula de inexistência **só com
  declaração das partes como fonte**. `nao_informado` ⇒ `ASSET_ROUTE = UNKNOWN`: cláusula
  neutra ("nada declaram sobre bens neste ato") + [FALTA] (§23).
- `FILHOS = incapazes` ⇒ exige `DECISAO_JUDICIAL_FILHOS = cobre_guarda_convivencia_alimentos`
  (Res. CNJ 35, art. 34, §2º, red. Res. 571/2024, aplicável pelo art. 46-A; CNN art. 537,
  §6º, red. Prov. 202/2025); `parcial` ou `nao_ha` ⇒ `BLOQUEIO` (§17, §173). `FILHOS = nao_informado` ⇒ `BLOQUEIO` (pressuposto do CPC 733). Consignar os
  dados da decisão no corpo. ALERTA fixo: o CPC, art. 733, fala em "não havendo nascituro ou
  filhos incapazes" — divergência apontada pelo Colégio Notarial; decisão do Tabelião.
- `GRAVIDEZ = sim` ⇒ `BLOQUEIO` (CPC 733); `desconhece` ⇒ declaração do art. 34, §1º
  ("não tem conhecimento") + ALERTA.
- `TITULO_ANTERIOR = nenhum` ⇒ proibido mencionar averbação à margem de título (§170);
  `LIVRO_E = registrada` ⇒ prever averbação da extinção (LRP 57, §3º-A para o nome).
- `ADVOGADO = nao_informado` ⇒ [FALTA] + ALERTA: a lavratura exige assistência de advogado ou
  defensor (CPC 733, §2º; Res. 35, art. 8º) — pode ser comum às partes (prática admitida; sem
  texto expresso vigente).
- `REPRESENTACAO = por_procuracao` ⇒ conferir: pública, poderes especiais, cláusulas
  essenciais, **30 dias** da outorga (Res. 35, art. 36) — vencida ⇒ `BLOQUEIO`.
- Vocabulário: partes são **conviventes/companheiros**; jamais "divorciandos" (§60).

### 3.4 DIV

- Idem 3.3 quanto a bens (CC 1.581; Súmula 197/STJ; CPC 731, p.ú.), filhos (Res. 35, art. 34,
  §2º), gravidez (CPC 733; Res. 35, art. 34, §1º), advogado, procuração (art. 36).
- `CASAMENTO` sem certidão ⇒ [FALTA]; certidão emitida há mais de 90 dias ⇒ ALERTA.
- `NOME = retoma_nome_de_solteiro` ⇒ cláusula própria.
- Vocabulário: **cônjuges/divorciandos**; jamais tratar as partes como "conviventes" (§61).
- Fecho registral: averbação no assento de casamento (LRP 100, §… conforme praxe) — citar sem
  número de parágrafo se houver dúvida.

### 3.5 EMANC

- `AGE_CHECK`: menor com **16 anos completos** na data de hoje (CC 5º, p.ú., I). Menos ⇒
  `BLOQUEIO`; 18 ou mais ⇒ `ACT_UNNECESSARY` (§9–§11).
- `QUEM_OUTORGA = tutor` ⇒ `BLOQUEIO`: emancipação por tutor é **judicial** ("por sentença do
  juiz, ouvido o tutor").
- `QUEM_OUTORGA = um_dos_pais`: só é "na falta do outro" se `MOTIVO_UM_SO` ∈ {outro_falecido
  (certidão), filiacao_unica, destituido_ou_suspenso_por_decisao}. `outro_discorda` ⇒
  `BLOQUEIO` (suprimento judicial, CC 1.631, p.ú.); `outro_nao_localizado` ⇒ `BLOQUEIO`
  (não é "falta"); `nao_informado` ⇒ `BLOQUEIO`.
- `GUARDA = unilateral` **não** retira o poder familiar do outro genitor (CC 1.579; 1.632;
  1.634, caput) ⇒ nunca concluir poder familiar exclusivo (§25, §174).
- `EMANCIPACAO_ANTERIOR = sim` ⇒ `ACT_UNNECESSARY`.
- Cláusula obrigatória: **a emancipação só produz efeitos após o registro** no RCPN do 1º
  Ofício da comarca do domicílio do menor, Livro E (CC 9º, II; LRP 89–91; art. 91, p.ú.:
  "antes do registro, a emancipação, em qualquer caso, não produzirá efeito"). Proibido
  "efeitos imediatos" (§175).
- Vocabulário: o menor é **emancipando/emancipado**, jamais "outorgado" (§62).

## 4. Invariantes de execução (do QA para o redator)

P1 `NO_SOURCE → NO_FACT` · P2 `UNKNOWN ≠ FALSE` · P3 `WRONG_ACT → BLOCK` ·
P4 `NO_AUTHORIZATION → NO_HIGH_RISK_EFFECT` · P5 `NO_PARTITION_MODULE → NO_ASSET_ALLOCATION` ·
P9 `MODEL_ERROR → MUST_NOT_OVERRIDE_CURRENT_LAW` · P10 `CLAUSE_NOT_IN_PLAN → MUST_NOT_APPEAR`.

Erros fatais (nunca): fato inventado; ato errado; transferência patrimonial não autorizada;
poder de alto risco não autorizado; representação inválida aceita; bloqueio ignorado; minuta
contraditória; parte/identidade errada; norma superada; contaminação entre atos.

## 5. Formato de saída (lido pela tela)

```
DECISÃO DO ROTEADOR
- Ato: …
- Variante: <código> — <nome>
- Por quê: <fatos determinantes, um por linha>
- Descartadas: <variantes próximas e o motivo>
- Estado: PRONTA PARA MINUTA | BLOQUEADA — <motivo> | FORA DO ESCOPO — <motivo>

===MINUTA_COPIAVEL===
<minuta integral, só quando PRONTA PARA MINUTA>
===FIM_MINUTA===

⚠ CONFERIR
- <um item por linha>

Minuta de rascunho gerada pelo Hub CN2O — sujeita à conferência e ao aperfeiçoamento do Tabelião.
```

Quando BLOQUEADA ou FORA DO ESCOPO: sem bloco de minuta; em seu lugar, a seção
`QUALIFICAÇÃO DEVOLVIDA AO TABELIÃO` com (a) o que impede, (b) o fundamento, (c) o que
destravaria (documento, decisão judicial, comparecimento, ato diverso).

## 6. Auditoria adversarial (14/09/2026)

O prompt foi submetido a um agente red-team com 26 casos do QA (poison, adversarial, mutation,
routing, hallucination, false certainty). Resultado: 12 brechas PARCIAIS e 5 contradições
internas, todas corrigidas no prompt v1.27 — entre elas: texto livre não é marcação de poder
(P4); correção do ato marcado sem inventar a entrevista do outro ato; modelo/matriz não
acrescenta cláusula nem fato; sinônimos de quitação e atribuição disfarçada (P5); certidão
antiga não prova estado atual; FILHOS desconhecido bloqueia divórcio/dissolução; substabelecimento
desconhecido = vedado; estados de saída fechados em três valores e marcadores só em PRONTA.

Segunda passagem (confirmação): 10 pendências residuais aplicadas — entre elas, fato documental
de risco não roteia sozinho (bloqueia em pressuposto); proibidos por variante listados; os dez
poderes do CPC 105 viraram marcações individuais. Decisão consciente mantida: declaração de
"bem particular" em DIV/DISS_UE é tratada como atribuição patrimonial (FORA DO ESCOPO) — o
Tabelião pode abrir exceção expressa se quiser admiti-la como fundamento da inexistência de
bens comuns.

Auditoria da tela (14/09/2026): 16 fichas geradas por Playwright, 37 verificações; contrato §2
conforme em todos os atos; quatro defeitos corrigidos — texto livre com quebra de linha podia
virar chave falsa da ficha (burlava P4/P5), resposta sem linha "Estado:" com QUALIFICAÇÃO
DEVOLVIDA era tratada como pronta, quadro da decisão montado por innerHTML (trocado por DOM),
fonte do quadro abaixo dos 18 px da casa; e o regime da UE deixou de nascer pré-marcado.

## 7. Fora deste documento

As **matrizes institucionais** (textos-modelo do CN2O por ato) não foram fornecidas nesta
rodada. Enquanto não vierem, o redator escreve pelo padrão da casa (Arial 11, cláusulas
tituladas, costura contínua) e registra no ⚠ CONFERIR: "matriz institucional não fornecida
para este ato — texto pelo padrão geral". Quando o Tabelião entregar as matrizes, elas entram
como bloco `=== MATRIZ INSTITUCIONAL — <ATO> ===` e passam a mandar na redação (mas nunca
na regra jurídica: P9).
