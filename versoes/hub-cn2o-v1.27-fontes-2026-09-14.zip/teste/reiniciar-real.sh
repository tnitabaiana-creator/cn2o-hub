#!/bin/bash
# Sobe o server.js REAL (com hub.js) + o site de teste. Mocks: só o gemini.js.
# RESET_DB=1 recria o banco "cn2o" do zero.
cd /home/claude/hub-definitivo/teste
ps -eo pid,args | awk '/node (server|site-teste|servidor-teste)\.js/ && !/awk/ {print $1}' | xargs -r kill 2>/dev/null
for i in 1 2 3 4 5 6 7 8 9 10; do
  (ss -ltn 2>/dev/null | grep -qE ':(3999|8088) ') || break; sleep 0.3
done
if [ "$RESET_DB" = "1" ]; then
  psql -h 127.0.0.1 -p 54329 -U postgres -q -c "DROP DATABASE IF EXISTS cn2o WITH (FORCE);" -c "CREATE DATABASE cn2o;"
fi
rm -f /tmp/gemini-chamadas.json /tmp/trello-chamadas.json /tmp/whats-chamadas.json
(cd real && exec env PORT=3999 DATABASE_URL=postgres://postgres@127.0.0.1:54329/cn2o GEMINI_API_KEY=${GEMINI_API_KEY-chave-de-teste} HUB_IA_ESPERA_MS=25 HUB_MODELO_MINUTAS=gemini-inexistente-teste GCP_VISION_KEY=AIza-chave-de-teste DOCAI_PROCESSOR=projects/teste/locations/us/processors/teste GCP_SA_JSON=e30= WHATS_TEMPLATE_RECIBO=recibo_protocolo_3 PROTOCOLO_INICIAL=1400 BOARD_00=quadro00 LISTA_ENTRADA=lista-entrada ${EXTRA_ENV} node server.js > /tmp/real.log 2>&1) &
(exec node site-teste.js > /tmp/site-teste.log 2>&1) &
sleep 2
cat /tmp/real.log /tmp/site-teste.log
