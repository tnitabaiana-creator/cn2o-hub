"""Gera os arquivos de teste do E2E (certidão em PNG, PDF de 2 páginas e foto grande de celular)."""
import os, random
from PIL import Image, ImageDraw, ImageFont
AQUI = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'arquivos'); os.makedirs(AQUI, exist_ok=True)
try: f = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 28)
except Exception: f = ImageFont.load_default()
img = Image.new('RGB', (1200, 1600), 'white'); d = ImageDraw.Draw(img)
for i, l in enumerate(['REGISTRO DE IMÓVEIS — ITABAIANA/SE', 'MATRÍCULA 8.412 — FICHA 01', 'R.1/8.412 — COMPRA E VENDA', 'R.4/8.412 — PENHORA']):
    d.text((60, 80 + i * 60), l, fill='black', font=f)
img.save(os.path.join(AQUI, 'certidao-p1.png'))
p2 = Image.new('RGB', (1200, 1600), 'white'); ImageDraw.Draw(p2).text((60, 80), 'AV.5/8.412 — ÓBITO', fill='black', font=f)
img.save(os.path.join(AQUI, 'certidao.pdf'), save_all=True, append_images=[p2])
random.seed(1); Image.effect_noise((3000, 4000), 60).convert('RGB').save(os.path.join(AQUI, 'foto-celular.jpg'), quality=95)
print('arquivos de teste gerados em', AQUI)
