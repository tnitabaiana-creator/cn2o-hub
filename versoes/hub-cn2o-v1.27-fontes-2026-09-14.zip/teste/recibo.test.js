// Testes do MÓDULO REAL backend/recibo.js — as variáveis do recibo de WhatsApp.
// O que se guarda aqui é a promessa feita ao cliente no balcão: o recibo tem de
// sair com o protocolo, o ato por extenso e as três pessoas, na ordem do extrato
// do T-Consulta, e NUNCA pode falhar por causa de um campo que veio vazio ou sujo.
'use strict';
const assert = require('assert');
const path = require('path');

process.env.WHATS_TEMPLATE_RECIBO = 'recibo_protocolo_3'; // a suíte afere o template novo
const { variaveisDoRecibo, campo, quantasVariaveis, LIMITE_PARAMETRO } =
  require(path.join(__dirname, '..', 'backend', 'recibo.js'));
const { NOMES_ATO } = require(path.join(__dirname, '..', 'backend', 'atos.js'));

const testes = [];
function t(nome, fn) { testes.push([nome, fn]); }

const CHEIO = {
  ato: 'CV-Rural',
  apresentante: { nome: 'João Batista de Oliveira', telefone: '79999990000' },
  parte_envolvida: { nome: 'MARIA DE FÁTIMA SANTOS' },
  vendedor: { nome: 'Antônio Carlos Menezes' }
};

t('são exatamente 5 variáveis, na ordem do extrato do T-Consulta', () => {
  const v = variaveisDoRecibo(CHEIO, '1369');
  assert.strictEqual(v.length, 5);
  assert.deepStrictEqual(v, [
    '1369',
    'Compra e venda — imóvel rural',
    'João Batista de Oliveira',
    'MARIA DE FÁTIMA SANTOS',
    'Antônio Carlos Menezes'
  ]);
});

t('o protocolo vai como texto e preserva os zeros à esquerda', () => {
  assert.strictEqual(variaveisDoRecibo(CHEIO, '0007')[0], '0007');
  assert.strictEqual(variaveisDoRecibo(CHEIO, 1369)[0], '1369');
});

t('o ato vai por extenso — o cliente não recebe o código interno', () => {
  for (const codigo of Object.keys(NOMES_ATO)) {
    const v = variaveisDoRecibo({ ...CHEIO, ato: codigo }, '1');
    assert.strictEqual(v[1], NOMES_ATO[codigo], codigo);
    assert.ok(!/^[A-Z-]+$/.test(v[1]), 'vazou o código de ' + codigo);
  }
});

t('ato desconhecido não derruba o recibo: vai o próprio código', () => {
  assert.strictEqual(variaveisDoRecibo({ ato: 'XPTO' }, '1')[1], 'XPTO');
});

t('ato ausente vira "não informado", nunca string vazia', () => {
  assert.strictEqual(variaveisDoRecibo({}, '1')[1], 'não informado');
});

t('ato sem vendedor (testamento, união estável, pacto) diz "não se aplica"', () => {
  for (const codigo of ['TEST', 'DUE', 'PACTO', 'INV']) {
    const v = variaveisDoRecibo({ ato: codigo, apresentante: { nome: 'Hellen' }, parte_envolvida: { nome: 'Fulano' } }, '9');
    assert.strictEqual(v[4], 'não se aplica', codigo);
  }
});

t('NENHUMA variável sai vazia — a Meta recusa parâmetro em branco', () => {
  const casos = [{}, { ato: 'DOA' }, { apresentante: {} }, { vendedor: { nome: '   ' } }, null];
  for (const caso of casos) {
    for (const v of variaveisDoRecibo(caso, '1')) {
      assert.ok(typeof v === 'string' && v.trim().length > 0, JSON.stringify(caso));
    }
  }
});

t('quebra de linha, tabulação e espaços em rajada são achatados', () => {
  const v = variaveisDoRecibo({
    ato: 'DOA',
    apresentante: { nome: '  João \n\t Batista     de   Oliveira  ' },
    parte_envolvida: { nome: 'Ana\nPaula' },
    vendedor: { nome: 'Zé' }
  }, ' 42 ');
  assert.strictEqual(v[0], '42');
  assert.strictEqual(v[2], 'João Batista de Oliveira');
  assert.strictEqual(v[3], 'Ana Paula');
  for (const x of v) {
    assert.ok(!/[\n\t]/.test(x), 'sobrou quebra de linha em: ' + x);
    assert.ok(!/ {5}/.test(x), 'sobraram 5+ espaços em: ' + x);
  }
});

t('nome quilométrico é cortado no limite, com reticências', () => {
  const gigante = 'MARIA '.repeat(80).trim();
  const v = variaveisDoRecibo({ ato: 'DOA', parte_envolvida: { nome: gigante } }, '1');
  assert.ok(v[3].length <= LIMITE_PARAMETRO, v[3].length);
  assert.ok(v[3].endsWith('…'));
});

t('acento e travessão do nome do ato passam intactos', () => {
  const v = variaveisDoRecibo({ ato: 'CV-Urbano' }, '1');
  assert.ok(v[1].includes('—'), v[1]);
  assert.ok(v[1].includes('imóvel'), v[1]);
});

t('campo() devolve a reserva pedida e nunca a string vazia', () => {
  assert.strictEqual(campo('', 'não se aplica'), 'não se aplica');
  assert.strictEqual(campo(null), 'não informado');
  assert.strictEqual(campo(0), '0');
});

t('todos os 11 atos do formulário estão no mapa compartilhado', () => {
  const doFormulario = ['CV-Urbano', 'CV-Rural', 'DOA', 'PER', 'INV', 'CDH', 'CDP', 'TEST', 'DUE', 'PACTO', 'RERRAT'];
  for (const a of doFormulario) assert.ok(NOMES_ATO[a], 'faltou ' + a);
});

t('a quantidade de variáveis segue o template configurado (troca sem parada)', () => {
  assert.strictEqual(quantasVariaveis('recibo_protocolo_2'), 1);
  assert.strictEqual(quantasVariaveis('recibo_protocolo_3'), 5);
  assert.strictEqual(quantasVariaveis('template_que_ninguem_cadastrou'), 5); // padrão: o formato novo
});

t('com o template antigo ainda ativo, sai SÓ o número — a Meta não recusa (132000)', () => {
  const v = variaveisDoRecibo(CHEIO, '1369', 'recibo_protocolo_2');
  assert.deepStrictEqual(v, ['1369']);
});

t('a virada é uma linha na Railway: o mesmo protocolo vira 5 variáveis', () => {
  const antigo = variaveisDoRecibo(CHEIO, '1369', 'recibo_protocolo_2');
  const novo = variaveisDoRecibo(CHEIO, '1369', 'recibo_protocolo_3');
  assert.strictEqual(antigo.length, 1);
  assert.strictEqual(novo.length, 5);
  assert.strictEqual(antigo[0], novo[0]); // o número é o mesmo nos dois
});

(async () => {
  let ok = 0, falhas = 0;
  for (const [nome, fn] of testes) {
    try { await fn(); console.log('  ✓ ' + nome); ok++; }
    catch (e) { console.log('  ✗ ' + nome + ' → ' + e.message); falhas++; }
  }
  console.log('\n' + ok + ' ok, ' + falhas + ' falha(s)');
  process.exit(falhas ? 1 : 0);
})();
