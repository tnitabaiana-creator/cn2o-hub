// MOCK do whats.js (teste local): não dispara WhatsApp.
// Monta, porém, as MESMAS variáveis do recibo pelo módulo REAL (recibo.js), para
// que a suíte confira o que o cliente receberia — não só que o disparo ocorreu.
'use strict';
const fs = require('fs');
const { variaveisDoRecibo } = require('./recibo');
async function dispararRecibos(p, numero) {
  let l = [];
  try { l = JSON.parse(fs.readFileSync('/tmp/whats-chamadas.json', 'utf8')); } catch (e) {}
  l.push({ numero, ato: p.ato, dest: p.recibo_destinatarios, vars: variaveisDoRecibo(p, numero) });
  fs.writeFileSync('/tmp/whats-chamadas.json', JSON.stringify(l));
}
module.exports = { dispararRecibos, ATO_NOME: {} };
