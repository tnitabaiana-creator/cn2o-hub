// MOCK do gemini.js (teste local): mesmas exportações do real; executar() simulado.
'use strict';
const fs = require('fs');
const ARQ = process.env.GEMINI_LOG || '/tmp/gemini-chamadas.json';
const MODELO_REDACAO = 'gemini-3.8-flash', MODELO_EXTRACAO = 'gemini-3.5-flash-lite';
const PRECOS = { 'gemini-3.8-flash': [0.75, 3.75] };
function registrar(x) { let l = []; try { l = JSON.parse(fs.readFileSync(ARQ, 'utf8')); } catch (e) {} l.push(x); fs.writeFileSync(ARQ, JSON.stringify(l)); }
async function executar({ agente, arquivos = [], campos = {}, observacoes, modelo }) {
  if (!process.env.GEMINI_API_KEY) throw new Error('GEMINI_API_KEY não configurada nas variáveis do serviço');
  registrar({ prompt: agente.prompt_sistema, temperatura: agente.temperatura, usa_busca: agente.usa_busca,
    arquivos: arquivos.map(a => ({ mime: a.mime, tam: Buffer.from(a.base64, 'base64').length, cabeca: Buffer.from(a.base64, 'base64').slice(0, 5).toString('latin1') })),
    observacoes, modelo: modelo || null });
  await new Promise(r => setTimeout(r, Number(process.env.MOCK_ATRASO_MS || 1200)));
  if (/inexistente/.test(modelo || '')) throw new Error('Gemini ' + modelo + ' 404: {"error":{"code":404,"message":"models/' + modelo + ' is not found for API version v1beta, or is not supported for generateContent.","status":"NOT_FOUND"}}');
  if (/FORCAR_ERRO/.test(observacoes || '')) throw new Error('Gemini gemini-3.8-flash 500: {"error":{"message":"falha simulada"}}');
  // v1.21 — simulação do congestionamento do Google (503 UNAVAILABLE)
  const nomes = arquivos.map(a => String(a.nome || '')).join(' ');
  if (/FORCAR_503_SEMPRE/.test(observacoes || '') || /forcar-503/i.test(nomes)) throw new Error('Gemini ' + (modelo || '?') + ' 503: {"error":{"code":503,"message":"This model is currently experiencing high demand. Spikes in demand are usually temporary. Please try again later.","status":"UNAVAILABLE"}}');
  if (/FORCAR_503_UMA/.test(observacoes || '')) {
    global.__cn2o503 = (global.__cn2o503 || 0) + 1;
    if (global.__cn2o503 === 1) throw new Error('Gemini ' + (modelo || '?') + ' 503: {"error":{"code":503,"message":"The model is overloaded. Please try again later.","status":"UNAVAILABLE"}}');
  }
  // Gerador de Minuta (prompt v1.27 — docs/prompt-gerador-minuta.txt). O mock decide
  // pela FICHA da entrevista dirigida que vem nas observações e responde no FORMATO
  // FIXO da spec §5: DECISÃO DO ROTEADOR → (minuta entre marcadores | QUALIFICAÇÃO
  // DEVOLVIDA) → ⚠ CONFERIR → rodapé. Marcadores só quando PRONTA PARA MINUTA.
  const ehMinuta = /GERADOR DE MINUTA do Cartório/.test(agente.prompt_sistema || '');
  if (ehMinuta) {
    const obs = observacoes || '';
    const ato = ((/^ATO:\s*(\S+)/m.exec(obs) || [])[1] || '').toUpperCase();
    const RODAPE = 'Minuta de rascunho gerada pelo Hub CN2O — sujeita à conferência e ao aperfeiçoamento do Tabelião.';
    const decisao = (linhas) => 'DECISÃO DO ROTEADOR\n' + linhas.map(l => '- ' + l).join('\n');
    const devolvida = (impede, fundamento, destrava) => 'QUALIFICAÇÃO DEVOLVIDA AO TABELIÃO\n- O que impede: ' + impede + '\n- Fundamento: ' + fundamento + '\n- O que destravaria: ' + destrava;
    const conferir = (itens) => '⚠ CONFERIR\n' + itens.map(i => '- ' + i).join('\n');
    const minuta = (corpo) => '===MINUTA_COPIAVEL===\n' + corpo + '\n===FIM_MINUTA===';
    let texto;
    if (/^PARTILHA:\s*agora\b/m.test(obs)) {
      texto = [
        decisao(['Ato: nenhum', 'Variante: nenhuma — partilha de bens no mesmo ato', 'Por quê: PARTILHA: agora (entrevista) — as partes querem partilhar os bens nesta escritura', 'Descartadas: ' + (ato || 'DIV') + ' sem partilha / partilha diferida — não é o que as partes querem', 'Estado: FORA DO ESCOPO — partilha no mesmo ato']),
        devolvida('divórcio ou dissolução COM partilha de bens no mesmo ato', 'escopo do Gerador (cinco atos, sem módulo de partilha — P5)', 'partilha diferida (ato próprio) ou lavratura do ato completo pelo Tabelião, fora do Hub'),
        conferir(['[PARTITION_EFFECT] as partes querem atribuir bens neste ato.']),
        RODAPE
      ].join('\n\n');
    } else if (/^MOTIVO_UM_SO:\s*outro_discorda\b/m.test(obs) || /^QUEM_OUTORGA:\s*tutor\b/m.test(obs)) {
      const tutor = /^QUEM_OUTORGA:\s*tutor\b/m.test(obs);
      texto = [
        decisao(['Ato: EMANC', 'Variante: EMANC.VOLUNTARIA — emancipação voluntária', 'Por quê: ' + (tutor ? 'QUEM_OUTORGA: tutor (entrevista)' : 'MOTIVO_UM_SO: outro_discorda (entrevista)'), 'Descartadas: nenhuma', 'Estado: BLOQUEADA — suprimento judicial']),
        devolvida(tutor ? 'emancipação por tutor não se faz em cartório' : 'o outro genitor discorda da emancipação', tutor ? 'CC, art. 5º, parágrafo único, I — "por sentença do juiz, ouvido o tutor"' : 'CC, art. 1.631, parágrafo único — divergência entre os pais resolve-se pelo juiz', 'decisão judicial (suprimento) ou comparecimento de ambos os pais'),
        conferir(['[HARD_BLOCKER] emancipação exige ' + (tutor ? 'sentença judicial, ouvido o tutor' : 'a concordância de ambos os pais ou suprimento judicial') + '.', 'CC, art. 5º, parágrafo único, I; CC, art. 1.631, parágrafo único — dispositivos a confirmar.']),
        RODAPE
      ].join('\n\n');
    } else if (ato === 'UE') {
      texto = [
        decisao(['Ato: UE', 'Variante: UE.PADRAO — união estável, regime legal', 'Por quê: ambos os conviventes sem impedimento (entrevista); REGIME legal_comunhao_parcial (entrevista)', 'Descartadas: UE.SEPARADO_DE_FATO — ninguém é casado; UE.SEPTUAGENARIO — MAIOR_70 não informado como sim', 'Estado: PRONTA PARA MINUTA']),
        minuta('MINUTA — ESCRITURA PÚBLICA DE DECLARAÇÃO DE UNIÃO ESTÁVEL\n\nSAIBAM quantos esta virem que comparecem FULANA DE TAL e BELTRANO DE TAL, que declaram conviver em UNIÃO ESTÁVEL desde a data informada, sob o regime da comunhão parcial de bens (CC, art. 1.725).\n\nCLÁUSULA DO NOME — a convivente passará a assinar FULANA DE TAL SILVA, ficando os efeitos da alteração do nome condicionados ao registro desta escritura no Livro E do Registro Civil das Pessoas Naturais competente (Lei 6.015/73, art. 57, §2º).\n\nItabaiana/SE, [FALTA: data da lavratura].\n\n____________________ FULANA DE TAL\n\n____________________ BELTRANO DE TAL'),
        conferir(['Nada a apontar.']),
        RODAPE
      ].join('\n\n');
    } else if (ato === 'PROC') {
      texto = [
        decisao(['Ato: PROC', 'Variante: PROC.VEICULO.REGULARIZE — regularização de veículo', 'Por quê: FINALIDADE veiculo_regularizar (entrevista)', 'Descartadas: PROC.VEICULO.VENDA — não há vender em PODERES_ALTO_RISCO', 'Estado: PRONTA PARA MINUTA']),
        minuta('MINUTA — PROCURAÇÃO PÚBLICA\n\nOUTORGANTE: JOSÉ RAIMUNDO SANTOS BISPO. OUTORGADO: MARCOS BISPO SANTOS. PODERES: transferir o veículo para o nome do outorgante, licenciar, representar no DETRAN, pagar e contestar multas. Vedado o substabelecimento.\n\n____________________ JOSÉ RAIMUNDO SANTOS BISPO'),
        conferir(['CC, art. 661, §1º — dispositivo a confirmar.', 'matriz institucional não fornecida para este ato — texto pelo padrão geral']),
        RODAPE
      ].join('\n\n');
    } else if (ato === 'DISS_UE' || ato === 'DIV' || ato === 'EMANC') {
      const nomes = { DISS_UE: 'EXTINÇÃO CONSENSUAL DE UNIÃO ESTÁVEL', DIV: 'DIVÓRCIO CONSENSUAL', EMANC: 'EMANCIPAÇÃO VOLUNTÁRIA' };
      texto = [
        decisao(['Ato: ' + ato, 'Variante: ' + ato + '.PADRAO — ' + nomes[ato].toLowerCase(), 'Por quê: ATO ' + ato + ' (entrevista), sem bloqueio', 'Descartadas: nenhuma', 'Estado: PRONTA PARA MINUTA']),
        minuta('MINUTA — ESCRITURA PÚBLICA DE ' + nomes[ato] + '\n\nSAIBAM quantos esta virem que comparecem as partes qualificadas na entrevista.\n\n____________________ JOSÉ RAIMUNDO SANTOS BISPO'),
        conferir(['matriz institucional não fornecida para este ato — texto pelo padrão geral']),
        RODAPE
      ].join('\n\n');
    } else if (ato && !['PROC', 'UE', 'DISS_UE', 'DIV', 'EMANC'].includes(ato)) {
      // ato fora dos cinco (INVENTARIO, CV…): o Gerador não aproxima (spec §1)
      texto = [
        decisao(['Ato: nenhum', 'Variante: nenhuma', 'Por quê: ATO ' + ato + ' não está entre PROC | UE | DISS_UE | DIV | EMANC', 'Descartadas: nenhuma', 'Estado: FORA DO ESCOPO — ato não coberto pelo Gerador']),
        devolvida('ato ' + ato + ' fora dos cinco atos do Gerador', 'escopo do Gerador de Minuta (spec §1)', 'lavratura pelo fluxo próprio do ato, fora do Hub'),
        conferir(['ato fora do escopo: ' + ato]),
        RODAPE
      ].join('\n\n');
    } else {
      // ficha sem ATO reconhecido (tela antiga ou texto solto): o Gerador não adivinha o ato
      texto = [
        decisao(['Ato: nenhum', 'Variante: nenhuma', 'Por quê: a entrevista não traz ATO entre PROC | UE | DISS_UE | DIV | EMANC', 'Descartadas: nenhuma', 'Estado: BLOQUEADA — entrevista sem ATO']),
        devolvida('ficha sem o campo ATO', 'P3 — o roteamento é pelo conteúdo, nunca por adivinhação', 'refazer a entrevista dirigida na tela do Gerador de Minuta'),
        conferir(['[FALTA: ATO da entrevista]']),
        RODAPE
      ].join('\n\n');
    }
    const uso = { texto, modelo: modelo || MODELO_REDACAO, tokens_entrada: 2000, tokens_saida: 500, custo_usd: 0.004, finish: 'STOP' };
    return { texto, uso };
  }
  const ehDescricao = /extrator de DESCRIÇÃO DE IMÓVEL/.test(agente.prompt_sistema || '');
  if (ehDescricao) {
    const texto = 'DESCRIÇÃO ATUALIZADA DO IMÓVEL — MATRÍCULA Nº 8.412 (CRI de Itabaiana/SE)\n\nUma casa residencial situada na Rua Coronel Sebastião, nº 156, Bairro Centro, nesta cidade, com área total de 240,00m².\n\nORIGEM DA DESCRIÇÃO\n- Abertura da matrícula; AV.3 de 10/04/2019 (retificação de área).\n\n⚠ CONFERIR\n- Nada a apontar.';
    const uso = { texto, modelo: modelo || MODELO_REDACAO, tokens_entrada: 1500, tokens_saida: 260, custo_usd: 0.0018, finish: 'STOP' };
    return { texto, uso };
  }
  const ehRedator = /REDATOR CN2O/.test(agente.prompt_sistema || '');
  if (ehRedator) {
    const pend = /aviso_pendencia/i.test(observacoes || '');
    const texto = pend
      ? 'AVISO DE PENDÊNCIA — Documento faltante no protocolo 1400\n\n===TEXTO_COPIAVEL===\nAssunto: CN2O — Protocolo 1400 — documento pendente\n\nPrezado Senhor,\n\nPara concluirmos a lavratura, ainda precisamos de:\n- Certidão de ônus atualizada (exigida pela lei do ato)\n\nAtenciosamente,\nCamily\nEscrevente — Cartório de Notas do 2º Ofício de Itabaiana/SE\n===FIM_TEXTO===\n\n===WHATSAPP_COPIAVEL===\nBom dia! Aqui é do Cartório de Notas do 2º Ofício de Itabaiana. Sobre o protocolo *1400*, ainda falta a certidão de ônus atualizada. Qualquer dúvida, estamos à disposição.\n===FIM_WHATSAPP===\n\n⚠ CONFERIR\n- Nada a apontar.'
      : 'OFÍCIO — Comunicação de teste\n\n===TEXTO_COPIAVEL===\nOfício nº ____/2026 — CN2O\n\nItabaiana/SE, 13 de setembro de 2026.\n\nExcelentíssimo Senhor Doutor Juiz de Direito,\n\nAssunto: teste\n\nO Cartório de Notas do 2º Ofício de Itabaiana/SE, por seu Tabelião que esta subscreve, vem respeitosamente à presença de Vossa Excelência prestar a informação requisitada.\n\nSendo o que se apresenta para o momento, renovamos protestos de elevada estima e distinta consideração.\n\nCésar Bravo\nTabelião de Notas\nCartório de Notas do 2º Ofício de Itabaiana/SE\n===FIM_TEXTO===\n\n⚠ CONFERIR\n- Numerar o ofício pelo livro da serventia.';
    const uso = { texto, modelo: modelo || MODELO_REDACAO, tokens_entrada: 1800, tokens_saida: 400, custo_usd: 0.0021, finish: 'STOP' };
    return { texto, uso };
  }
  const ehMatricula = /Analista de Matrículas/.test(agente.prompt_sistema || '');
  const texto = ehMatricula
    ? 'EXTRATO DA SITUAÇÃO JURÍDICA DO IMÓVEL — MATRÍCULA Nº 8.412\n\n1. IDENTIFICAÇÃO — Matrícula 8.412 (teste).\n2. TITULARIDADE ATUAL — JOSÉ RAIMUNDO SANTOS BISPO.\n10. CONCLUSÃO — APTO COM RESSALVAS (penhora vigente).\n\n===DESCRICAO_COPIAVEL===\nUma casa residencial situada na Rua Coronel Sebastião, nº 156, Bairro Centro, nesta cidade, com área total de 240,00m².\n===FIM_DESCRICAO==='
    : 'QUALIFICAÇÃO PRONTA\n\nMARÍLIA FONTES DE JESUS, brasileira, solteira, maior, farmacêutica, portadora da cédula de identidade RG nº 3.845.216 – SSP/SE, inscrita no CPF/MF sob o nº 054.318.276-90.\n\n⚠ CONFERIR\n- Nada a apontar nos textos fornecidos.';
  const uso = { texto, modelo: modelo || MODELO_REDACAO, tokens_entrada: 1234 + arquivos.length * 1000, tokens_saida: 321, custo_usd: 0.0021, finish: 'STOP' };
  return { texto, uso };
}
const naoUsado = async () => { throw new Error('mock: não usado nos testes do hub'); };
module.exports = { extrair: naoUsado, redigir: naoUsado, revisar: naoUsado, executar, listarModelos: naoUsado,
  custoUsd: () => 0, MODELO_EXTRACAO, MODELO_REDACAO, PRECOS };
