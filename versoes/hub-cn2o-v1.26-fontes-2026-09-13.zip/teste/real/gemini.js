// MOCK do gemini.js (teste local): mesmas exportações do real; executar() simulado.
'use strict';
const fs = require('fs');
const ARQ = process.env.GEMINI_LOG || '/tmp/gemini-chamadas.json';
const MODELO_REDACAO = 'gemini-3.8-flash', MODELO_EXTRACAO = 'gemini-3.5-flash-lite';
const PRECOS = { 'gemini-3.8-flash': [0.75, 3.75] };
function registrar(x) { let l = []; try { l = JSON.parse(fs.readFileSync(ARQ, 'utf8')); } catch (e) {} l.push(x); fs.writeFileSync(ARQ, JSON.stringify(l)); }
async function executar({ agente, arquivos = [], campos = {}, observacoes, modelo }) {
  if (!process.env.GEMINI_API_KEY) throw new Error('GEMINI_API_KEY não configurada nas variáveis do serviço');
  registrar({ prompt: agente.prompt_sistema, temperatura: agente.temperatura, usa_busca: agente.usa_busca,
    arquivos: arquivos.map(a => ({ mime: a.mime, tam: Buffer.from(a.base64, 'base64').length, cabeca: Buffer.from(a.base64, 'base64').slice(0, 5).toString('latin1') })),
    observacoes, modelo: modelo || null });
  await new Promise(r => setTimeout(r, Number(process.env.MOCK_ATRASO_MS || 1200)));
  if (/inexistente/.test(modelo || '')) throw new Error('Gemini ' + modelo + ' 404: {"error":{"code":404,"message":"models/' + modelo + ' is not found for API version v1beta, or is not supported for generateContent.","status":"NOT_FOUND"}}');
  if (/FORCAR_ERRO/.test(observacoes || '')) throw new Error('Gemini gemini-3.8-flash 500: {"error":{"message":"falha simulada"}}');
  // v1.21 — simulação do congestionamento do Google (503 UNAVAILABLE)
  const nomes = arquivos.map(a => String(a.nome || '')).join(' ');
  if (/FORCAR_503_SEMPRE/.test(observacoes || '') || /forcar-503/i.test(nomes)) throw new Error('Gemini ' + (modelo || '?') + ' 503: {"error":{"code":503,"message":"This model is currently experiencing high demand. Spikes in demand are usually temporary. Please try again later.","status":"UNAVAILABLE"}}');
  if (/FORCAR_503_UMA/.test(observacoes || '')) {
    global.__cn2o503 = (global.__cn2o503 || 0) + 1;
    if (global.__cn2o503 === 1) throw new Error('Gemini ' + (modelo || '?') + ' 503: {"error":{"code":503,"message":"The model is overloaded. Please try again later.","status":"UNAVAILABLE"}}');
  }
  const ehMinutaUe = /GERADOR PROC \/ UE no modo UNIÃO ESTÁVEL/.test(agente.prompt_sistema || '');
  if (ehMinutaUe) {
    const texto = 'MINUTA — ESCRITURA PÚBLICA DE DECLARAÇÃO DE UNIÃO ESTÁVEL\n\nSAIBAM quantos esta virem que comparecem FULANA DE TAL e BELTRANO DE TAL, que declaram conviver em união estável desde a data informada, sob o regime da comunhão parcial de bens.\n\nCLÁUSULA DO NOME — a convivente passará a assinar FULANA DE TAL SILVA, ficando os efeitos da alteração do nome condicionados ao registro desta escritura no Livro E do Registro Civil das Pessoas Naturais competente.\n\n⚠ CONFERIR\n- Nada a apontar.\n\nMinuta de rascunho gerada pelo Hub CN2O — sujeita à conferência e ao aperfeiçoamento do Tabelião.';
    const uso = { texto, modelo: modelo || MODELO_REDACAO, tokens_entrada: 2000, tokens_saida: 500, custo_usd: 0.004, finish: 'STOP' };
    return { texto, uso };
  }
  const ehDescricao = /extrator de DESCRIÇÃO DE IMÓVEL/.test(agente.prompt_sistema || '');
  if (ehDescricao) {
    const texto = 'DESCRIÇÃO ATUALIZADA DO IMÓVEL — MATRÍCULA Nº 8.412 (CRI de Itabaiana/SE)\n\nUma casa residencial situada na Rua Coronel Sebastião, nº 156, Bairro Centro, nesta cidade, com área total de 240,00m².\n\nORIGEM DA DESCRIÇÃO\n- Abertura da matrícula; AV.3 de 10/04/2019 (retificação de área).\n\n⚠ CONFERIR\n- Nada a apontar.';
    const uso = { texto, modelo: modelo || MODELO_REDACAO, tokens_entrada: 1500, tokens_saida: 260, custo_usd: 0.0018, finish: 'STOP' };
    return { texto, uso };
  }
  const ehRedator = /REDATOR CN2O/.test(agente.prompt_sistema || '');
  if (ehRedator) {
    const pend = /aviso_pendencia/i.test(observacoes || '');
    const texto = pend
      ? 'AVISO DE PENDÊNCIA — Documento faltante no protocolo 1400\n\n===TEXTO_COPIAVEL===\nAssunto: CN2O — Protocolo 1400 — documento pendente\n\nPrezado Senhor,\n\nPara concluirmos a lavratura, ainda precisamos de:\n- Certidão de ônus atualizada (exigida pela lei do ato)\n\nAtenciosamente,\nCamily\nEscrevente — Cartório de Notas do 2º Ofício de Itabaiana/SE\n===FIM_TEXTO===\n\n===WHATSAPP_COPIAVEL===\nBom dia! Aqui é do Cartório de Notas do 2º Ofício de Itabaiana. Sobre o protocolo *1400*, ainda falta a certidão de ônus atualizada. Qualquer dúvida, estamos à disposição.\n===FIM_WHATSAPP===\n\n⚠ CONFERIR\n- Nada a apontar.'
      : 'OFÍCIO — Comunicação de teste\n\n===TEXTO_COPIAVEL===\nOfício nº ____/2026 — CN2O\n\nItabaiana/SE, 13 de setembro de 2026.\n\nExcelentíssimo Senhor Doutor Juiz de Direito,\n\nAssunto: teste\n\nO Cartório de Notas do 2º Ofício de Itabaiana/SE, por seu Tabelião que esta subscreve, vem respeitosamente à presença de Vossa Excelência prestar a informação requisitada.\n\nSendo o que se apresenta para o momento, renovamos protestos de elevada estima e distinta consideração.\n\nCésar Bravo\nTabelião de Notas\nCartório de Notas do 2º Ofício de Itabaiana/SE\n===FIM_TEXTO===\n\n⚠ CONFERIR\n- Numerar o ofício pelo livro da serventia.';
    const uso = { texto, modelo: modelo || MODELO_REDACAO, tokens_entrada: 1800, tokens_saida: 400, custo_usd: 0.0021, finish: 'STOP' };
    return { texto, uso };
  }
  const ehMatricula = /Analista de Matrículas/.test(agente.prompt_sistema || '');
  const texto = ehMatricula
    ? 'EXTRATO DA SITUAÇÃO JURÍDICA DO IMÓVEL — MATRÍCULA Nº 8.412\n\n1. IDENTIFICAÇÃO — Matrícula 8.412 (teste).\n2. TITULARIDADE ATUAL — JOSÉ RAIMUNDO SANTOS BISPO.\n10. CONCLUSÃO — APTO COM RESSALVAS (penhora vigente).\n\n===DESCRICAO_COPIAVEL===\nUma casa residencial situada na Rua Coronel Sebastião, nº 156, Bairro Centro, nesta cidade, com área total de 240,00m².\n===FIM_DESCRICAO==='
    : 'QUALIFICAÇÃO PRONTA\n\nMARÍLIA FONTES DE JESUS, brasileira, solteira, maior, farmacêutica, portadora da cédula de identidade RG nº 3.845.216 – SSP/SE, inscrita no CPF/MF sob o nº 054.318.276-90.\n\n⚠ CONFERIR\n- Nada a apontar nos textos fornecidos.';
  const uso = { texto, modelo: modelo || MODELO_REDACAO, tokens_entrada: 1234 + arquivos.length * 1000, tokens_saida: 321, custo_usd: 0.0021, finish: 'STOP' };
  return { texto, uso };
}
const naoUsado = async () => { throw new Error('mock: não usado nos testes do hub'); };
module.exports = { extrair: naoUsado, redigir: naoUsado, revisar: naoUsado, executar, listarModelos: naoUsado,
  custoUsd: () => 0, MODELO_EXTRACAO, MODELO_REDACAO, PRECOS };
