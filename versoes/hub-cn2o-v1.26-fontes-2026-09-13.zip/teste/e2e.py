"""E2E do Hub dos Escreventes (Chromium headless) contra o servidor de teste.

Roda o fluxo completo: login e primeiro acesso, mural, modo do Tabelião com o
editor de texto rico, aniversariantes, metas, histórico, Extrator e Analista com
anexos (foto, PDF, print colado), erros, sessão expirada, ferramenta embutida.
"""
import json, os, sys, time, urllib.request
from playwright.sync_api import sync_playwright

SITE = os.environ.get('SITE', 'http://127.0.0.1:8088/')
API = os.environ.get('API', 'http://127.0.0.1:3999')
SHOTS = os.environ.get('SHOTS', '/tmp/claude-0/-home-claude/1420be19-29c6-5b17-b90b-a63024aaf784/scratchpad/shots')
ARQ = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'arquivos')
os.makedirs(SHOTS, exist_ok=True)
ok = falhas = 0
erros_console = []

PAGINA = {}
def passo(nome, fn):
    global ok, falhas
    try:
        fn(); ok += 1; print('  ✓', nome)
    except Exception as e:
        falhas += 1; print('  ✗', nome, '→', repr(e)[:400])
        pg = PAGINA.get('pg')
        if pg:
            try:
                pg.screenshot(path=SHOTS + '/falha-' + str(falhas) + '.png')
                pg.evaluate("document.querySelectorAll('.veu.aberto').forEach(v => v.classList.remove('aberto'))")
            except Exception:
                pass

def api(caminho, corpo=None, token=None):
    req = urllib.request.Request(API + caminho, method='POST' if corpo is not None else 'GET')
    if corpo is not None:
        req.add_header('Content-Type', 'application/json'); req.data = json.dumps(corpo).encode()
    if token: req.add_header('X-Auth-Token', token)
    try:
        with urllib.request.urlopen(req) as r: return r.status, json.loads(r.read() or b'null')
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b'null')

import subprocess
def sql(comando):
    return subprocess.run(['psql', '-h', '127.0.0.1', '-p', '54329', '-U', 'postgres', '-d', 'cn2o', '-At', '-c', comando], capture_output=True, text=True, check=True).stdout
def chamadas():
    with open('/tmp/gemini-chamadas.json', encoding='utf-8') as f: return json.load(f)
def garantir_senha(login, senha):
    st, r = api('/login', {'login': login, 'senha': senha})
    if st == 200 and r.get('primeiro_acesso'):
        st, r = api('/definir-senha', {'login': login, 'senha': senha})
    return st

def esperar(cond, seg=8, msg='condição'):
    fim = time.time() + seg
    while time.time() < fim:
        if cond(): return
        time.sleep(0.1)
    raise AssertionError('tempo esgotado: ' + msg)

with sync_playwright() as p:
    nav = p.chromium.launch()
    ctx = nav.new_context(viewport={'width': 1366, 'height': 900}, locale='pt-BR', reduced_motion='reduce')
    # o container não alcança o Google Fonts: corta na hora para não travar o carregamento
    CSV_FRASES_TESTE = ('"frase","autor","fixar"\n'
        '"A frase fixada do teste vale para todos.","Equipe de Teste","HOJE"\n'
        '"Outra frase qualquer para a roleta.","",""\n')
    def rotear(r):
        u = r.request.url
        if 'fonts.googleapis' in u or 'fonts.gstatic' in u or 'calendar.google.com' in u:
            return r.abort()
        if 'docs.google.com/spreadsheets' in u:
            return r.fulfill(status=200, content_type='text/csv; charset=utf-8', body=CSV_FRASES_TESTE)
        r.continue_()
    ctx.route('**/*', rotear)
    ctx.grant_permissions(['clipboard-read', 'clipboard-write'], origin=SITE.rstrip('/'))
    pg = ctx.new_page()
    pg.set_default_timeout(15000)
    PAGINA['pg'] = pg
    pg.on('console', lambda m: erros_console.append(m.text) if m.type == 'error' else None)
    pg.on('pageerror', lambda e: erros_console.append('pageerror: ' + str(e)))

    print('E2E — login e primeiro acesso')
    pg.goto(SITE); pg.wait_for_selector('#telaLogin:not([hidden])')
    def login_errado():
        # a senha da Camily é criada pelo teste de API; aqui usamos um usuário que já tem senha
        garantir_senha('camily.jesus', 'senha-camily-1')
        pg.fill('#campoLogin', 'camily.jesus'); pg.fill('#campoSenha', 'errada'); pg.click('#btnEntrar')
        pg.wait_for_selector('#msgLogin:not([hidden])')
        assert 'não conferem' in pg.inner_text('#msgLogin')
    passo('senha errada → "Usuário ou senha não conferem"', login_errado)

    def primeiro_acesso():
        pg.fill('#campoLogin', 'Josi.Silva '); pg.fill('#campoSenha', ''); pg.click('#btnEntrar')
        pg.wait_for_selector('#formPrimeiro:not([hidden])')
        assert pg.inner_text('#nomePrimeiro') == 'josi.silva'
        pg.fill('#senhaNova', 'curta'); pg.fill('#senhaConf', 'curta'); pg.click('#btnCriarSenha')
        assert '8 caracteres' in pg.inner_text('#msgPrimeiro')
        pg.fill('#senhaNova', 'senha-josi-2026'); pg.fill('#senhaConf', 'senha-josi-2027'); pg.click('#btnCriarSenha')
        assert 'não são iguais' in pg.inner_text('#msgPrimeiro')
        pg.fill('#senhaConf', 'senha-josi-2026'); pg.click('#btnCriarSenha')
        pg.wait_for_selector('#app:not([hidden])')
        assert 'Josilene' in pg.inner_text('#saudacao')
        assert pg.is_hidden('#btnEditarMural')
    passo('primeiro acesso cria senha (valida tamanho e confirmação) e entra', primeiro_acesso)

    def mural_inicial():
        pg.wait_for_selector('#muralAvisos .aviso-row')
        carimbo = pg.evaluate("(s => s && getComputedStyle(s).transform)(document.querySelector('#muralMetas .carimbo-breve span'))")
        assert carimbo and carimbo != 'none', 'carimbo EM BREVE ausente ou sem inclinação'
        assert pg.evaluate("document.querySelector('[data-sub=metas]').hidden"), 'em breve: Ver mais das metas deveria sumir'
        pg.evaluate("abrirSub('metas')")
        assert pg.locator('#veuMural.aberto').count() == 0, 'em breve: metas não podem abrir subpágina'
        assert 'Comunicado Geral' in pg.inner_text('#muralAvisos')
        assert pg.locator('#muralAvisos .aviso-row.novo').count() == 1, 'sem marca de novo'
        assert '1 novo' in pg.text_content('#pillAvisos'), pg.text_content('#pillAvisos')
        pg.click('#muralAvisos .aviso-row')
        pg.wait_for_selector('#veuMural.aberto .sub-texto.rico b')
        assert 'Bem-vindo' in pg.inner_text('.sub-texto.rico b')
        assert 'César Bravo' in pg.inner_text('.sub-assina')
        pg.screenshot(path=SHOTS + '/01-aviso-aberto.png')
        pg.keyboard.press('Escape')
        esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='fechar subpágina')
        assert pg.locator('#muralAvisos .aviso-row.novo').count() == 0, 'continua novo'
        assert 'Em destaque' in pg.text_content('#pillAvisos'), pg.text_content('#pillAvisos')
    passo('mural: aviso "novo", abre subpágina rica, some o "novo" depois de lido', mural_inicial)

    def sessao_persistida():
        pg.reload(); pg.wait_for_selector('#app:not([hidden])')
        assert 'Josilene' in pg.inner_text('#saudacao')
    passo('recarregar a página mantém a sessão', sessao_persistida)

    def sair_e_entrar_cesar():
        pg.click('#btnSair'); pg.wait_for_selector('#telaLogin:not([hidden])')
        garantir_senha('cesar.bravo', 'senha-cesar-123')
        pg.fill('#campoLogin', 'cesar.bravo'); pg.fill('#campoSenha', 'senha-cesar-123'); pg.click('#btnEntrar')
        pg.wait_for_selector('#app:not([hidden])')
        assert pg.is_visible('#btnEditarMural')
    passo('sair → entrar como Tabelião → botão "Editar mural" aparece', sair_e_entrar_cesar)

    print('E2E — modo do Tabelião e editor de texto rico')
    def novo_aviso_formatado():
        pg.click('#btnEditarMural'); pg.wait_for_selector('#veuMural.aberto .ed-abas')
        pg.click('#edNovoAviso'); pg.wait_for_selector('#edAvEditor .rico-area')
        pg.fill('#edAvTitulo', 'Plantão de sábado')
        pg.click('[data-estilo="importante"]'); pg.check('#edAvFixado')
        area = pg.locator('#edAvEditor .rico-area')
        area.click()
        pg.keyboard.type('Atenção equipe: plantão neste sábado das 8h às 12h.')
        # seleciona "plantão" e aplica negrito
        def selecionar(palavra):
            pg.evaluate('''(p) => { const a = document.querySelector('#edAvEditor .rico-area');
              const w = document.createTreeWalker(a, NodeFilter.SHOW_TEXT); let n;
              while ((n = w.nextNode())) { const i = n.nodeValue.indexOf(p);
                if (i >= 0) { const r = document.createRange(); r.setStart(n, i); r.setEnd(n, i + p.length);
                  const s = getSelection(); s.removeAllRanges(); s.addRange(r); a.dispatchEvent(new Event('mouseup')); return; } } }''', palavra)
        selecionar('plantão'); pg.click('#edAvEditor [data-cmd="bold"]')
        selecionar('8h às 12h'); pg.click('#edAvEditor [data-acao="marca"]')
        selecionar('Atenção equipe'); pg.click('#edAvEditor [data-acao="vinho"]')
        pg.keyboard.press('End'); pg.keyboard.press('Enter')
        pg.click('#edAvEditor [data-cmd="insertUnorderedList"]')
        pg.keyboard.type('Trazer crachá'); pg.keyboard.press('Enter'); pg.keyboard.type('Chegar 7h50')
        pg.click('#edAvEditor [data-acao="emoji"]'); pg.click('#edAvEditor [data-emoji="📌"]')
        pg.screenshot(path=SHOTS + '/02-editor-rico.png')
        pg.click('#edAvSalvar')
        pg.wait_for_selector('.ed-item.fixado')
        assert 'pendente' in pg.get_attribute('#edStatus', 'class')
        pg.click('#edPublicar')
        esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='publicar fecha o editor')
        pg.wait_for_selector('#toast:not([hidden])')
        assert 'publicado' in pg.inner_text('#toast')
    passo('cria aviso Importante + fixado com negrito, destaque, cor vinho, lista e emoji; publica', novo_aviso_formatado)

    def conferir_html_salvo():
        tok = pg.evaluate("localStorage.getItem('cn2o_token')")
        st, r = api('/hub/mural', token=tok)
        av = r['dados']['avisos'][0]
        h = av['html']
        assert av['titulo'] == 'Plantão de sábado' and av['estilo'] == 'importante' and av['fixado'] is True, av
        assert '<b>plantão</b>' in h, h
        assert '<mark>8h às 12h</mark>' in h, h
        assert 't-vinho' in h, h
        assert '<ul><li>Trazer crachá</li><li>Chegar 7h50📌</li></ul>' in h or ('<li>Trazer crachá</li>' in h and '📌' in h), h
        assert 'style=' not in h and 'font' not in h, h
        print('     html salvo:', h[:220])
    passo('HTML gravado no servidor: só tags/classes permitidas (b, mark, t-vinho, ul/li)', conferir_html_salvo)

    def foto_e_imagem_no_mural():
        # jpgs gerados na hora (rosto pequeno e imagem de aviso maior)
        import io as _io
        from PIL import Image as _Img
        def jpg(l, cor):
            b = _io.BytesIO(); _Img.new('RGB', (l, l), cor).save(b, 'JPEG', quality=88); return b.getvalue()
        pg.click('#btnEditarMural'); pg.wait_for_selector('#veuMural.aberto .ed-abas')
        pg.click('.ed-aba[data-aba="aniversariantes"]'); pg.wait_for_selector('#edAnFoto', state='attached')
        # ainda não há ninguém na lista neste ponto do fluxo: cadastra um para receber a foto
        pg.fill('#edAnNome', 'Foto Teste'); pg.fill('#edAnDia', '25')
        pg.select_option('#edAnMes', str(time.localtime().tm_mon))
        pg.click('#edAnAdd')
        pg.wait_for_selector('[data-foto]')
        pg.locator('[data-foto]').first.click()
        pg.set_input_files('#edAnFoto', files=[{'name': 'rosto.jpg', 'mimeType': 'image/jpeg', 'buffer': jpg(400, (180, 90, 60))}])
        esperar(lambda: pg.locator('.ed-item-foto img.aniv-foto').count() >= 1, msg='thumb da foto no editor')
        # aviso com imagem
        pg.click('.ed-aba[data-aba="avisos"]'); pg.wait_for_selector('[data-edita]')
        pg.locator('[data-edita]').first.click(); pg.wait_for_selector('#edAvImg', state='attached')
        pg.set_input_files('#edAvImg', files=[{'name': 'quadro.jpg', 'mimeType': 'image/jpeg', 'buffer': jpg(1600, (40, 70, 120))}])
        esperar(lambda: pg.locator('#edAvImgPrev:visible').count() == 1, msg='prévia da imagem do aviso')
        pg.click('#edAvSalvar'); pg.wait_for_selector('#edPublicar')
        pg.click('#edPublicar')
        esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='publicar fecha o editor')
        pg.wait_for_selector('#toast:not([hidden])')
        # no mural: foto redonda no aniversariante e miniatura no aviso
        esperar(lambda: pg.locator('#muralAniversariantes img.aniv-foto').count() >= 1, msg='foto no cartão Agenda Cn2o')
        assert pg.locator('#muralAvisos .aviso-doc img').count() >= 1, 'miniatura da imagem no aviso'
        pg.click('#muralAvisos .aviso-row')
        pg.wait_for_selector('#veuMural.aberto .sub-imagem')
        assert pg.evaluate("(i => i.naturalWidth > 200)(document.querySelector('.sub-imagem'))"), 'imagem grande na subpágina'
        pg.keyboard.press('Escape')
        esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='fechar subpágina')
        # servidor guardou foto e imagem
        tok = pg.evaluate("localStorage.getItem('cn2o_token')")
        st, r = api('/hub/mural', token=tok)
        assert any(str(a.get('foto', '')).startswith('data:image/jpeg') for a in r['dados']['aniversariantes']), 'foto não persistiu'
        assert any(str(a.get('imagem', '')).startswith('data:image/jpeg') for a in r['dados']['avisos']), 'imagem não persistiu'
    passo('foto do aniversariante + imagem no aviso: editor do Tabelião → publica → aparece no mural e persiste', foto_e_imagem_no_mural)

    def mural_mostra_fixado():
        first = pg.locator('#muralAvisos .aviso-row').first
        assert 'Plantão de sábado' in first.inner_text()
        assert 'fixado' in first.get_attribute('class') and 'importante' in first.get_attribute('class')
        first.click(); pg.wait_for_selector('.sub-selo.importante')
        assert pg.locator('.sub-texto.rico mark').count() == 1
        assert pg.locator('.sub-texto.rico .t-vinho').count() >= 1
        pg.screenshot(path=SHOTS + '/03-aviso-formatado.png')
        pg.keyboard.press('Escape')
    passo('mural: aviso fixado vem primeiro, selo "Importante" e formatação renderizada', mural_mostra_fixado)

    def editar_aviso_existente():
        pg.click('#btnEditarMural'); pg.wait_for_selector('.ed-abas')
        pg.click('[data-edita="0"]'); pg.wait_for_selector('#edAvEditor .rico-area')
        assert pg.input_value('#edAvTitulo') == 'Plantão de sábado', pg.input_value('#edAvTitulo')
        nb = pg.locator('#edAvEditor .rico-area b').count()
        assert nb == 1, 'negritos no editor: %d · %s' % (nb, pg.inner_html('#edAvEditor .rico-area'))
        pg.wait_for_timeout(150)  # o formulário foca o editor 30 ms depois de abrir; deixa assentar
        pg.fill('#edAvTitulo', 'Plantão de sábado (confirmado)')
        pg.click('#edAvSalvar')
        try:
            pg.wait_for_selector('.ed-item:has-text("(confirmado)")', timeout=6000)
        except Exception:
            if pg.locator('#edAvSalvar').count():
                pg.click('#edAvSalvar')
            pg.wait_for_selector('.ed-item:has-text("(confirmado)")', timeout=9000)
        pg.click('#edPublicar')
        esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='publicar')
        assert 'confirmado' in pg.text_content('#muralAvisos'), pg.text_content('#muralAvisos')
    passo('edita aviso existente mantendo a formatação e republica', editar_aviso_existente)

    def aniversariantes_lote():
        pg.click('#btnEditarMural'); pg.click('[data-aba="aniversariantes"]')
        hoje = time.localtime()
        pg.fill('#edAnLote', f'Josilene - {hoje.tm_mday:02d}/{hoje.tm_mon:02d}\nCamily – 28/{hoje.tm_mon:02d}\nLara: 05/{(hoje.tm_mon % 12) + 1:02d}\nlinha ruim')
        pg.click('#edAnLoteAdd')
        assert pg.locator('.ed-item').count() == 4  # 3 do lote + "Foto Teste" (do teste da foto)
        pg.click('#edPublicar'); esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='publicar')
        assert pg.locator('#muralAniversariantes li.hoje').count() == 1
        assert 'Camily' in pg.inner_text('#muralAniversariantes')
        pg.click('[data-sub="aniversariantes"]'); pg.wait_for_selector('#veuMural.aberto')
        assert 'Lara' in pg.inner_text('#subConteudo')
        pg.keyboard.press('Escape')
    passo('aniversariantes colados em lote (linha ruim avisada); "hoje!" destacado; próximo mês na subpágina', aniversariantes_lote)

    def metas_ativas():
        pg.click('#btnEditarMural'); pg.click('[data-aba="metas"]')
        pg.fill('#edMtTitulo', '120 atos lavrados em setembro'); pg.fill('#edMtProg', '65'); pg.fill('#edMtPremio', 'Almoço da equipe')
        pg.click('#edMtAdd'); pg.uncheck('#edMtBreve')
        pg.click('#edPublicar'); esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='publicar')
        assert pg.locator('#muralMetas .meta-item').count() == 1
        assert '65%' in pg.inner_text('#muralMetas')
        w = pg.evaluate("document.querySelector('#muralMetas .meta-barra i').style.width")
        assert w == '65%', w
    passo('metas: cadastra meta com prêmio, tira o "EM BREVE" e a barra aparece no cartão', metas_ativas)

    def historico_e_conflito():
        pg.click('#btnEditarMural'); pg.click('[data-aba="historico"]')
        pg.wait_for_selector('[data-carrega]')
        n = pg.locator('[data-carrega]').count(); assert n >= 4, n
        # alguém publica "por fora" enquanto o editor está aberto → 409 tratado
        tok = pg.evaluate("localStorage.getItem('cn2o_token')")
        st, atual = api('/hub/mural', token=tok)
        st2, _ = api('/hub/mural', {'dados': atual['dados'], 'base': atual['atualizado_em']}, token=tok)
        assert st2 == 200
        pg.click('[data-aba="avisos"]'); pg.click('[data-fixa="0"]'); pg.click('#edPublicar')
        pg.wait_for_function("document.getElementById('edStatus') && /alterado em outro lugar/.test(document.getElementById('edStatus').textContent)")
        pg.keyboard.press('Escape')
        pg.keyboard.press('Escape')
    passo('histórico lista as publicações; conflito de edição avisado e mural recarregado', historico_e_conflito)

    def fechar_com_alteracao_pendente():
        pg.click('#btnEditarMural'); pg.click('[data-fixa="0"]')
        pg.click('#subConteudo [data-fechar-sub]')
        assert pg.locator('#veuMural.aberto').count() == 1
        assert 'descartar' in pg.inner_text('#edStatus')
        pg.click('#subConteudo [data-fechar-sub]')
        esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='descartar')
    passo('fechar o editor com alteração pendente pede um segundo clique', fechar_com_alteracao_pendente)

    def equipe_admin():
        pg.click('#btnEditarMural'); pg.click('[data-aba="equipe"]')
        pg.wait_for_selector('#edEqNome')
        pg.fill('#edEqNome', 'Sérgio Luiz')
        assert pg.input_value('#edEqLogin') == 'sergio.luiz', pg.input_value('#edEqLogin')
        pg.fill('#edEqCargo', 'Cadastro e Protocolo'); pg.click('#edEqAdd')
        pg.wait_for_selector('.ed-item:has-text("Sérgio Luiz")')
        assert 'aguardando o primeiro acesso' in pg.text_content('.ed-item:has-text("Sérgio Luiz")')
        st, r = api('/login', {'login': 'sergio.luiz', 'senha': ''})
        assert r.get('primeiro_acesso') is True, r
        b = pg.locator('[data-zera="josi.silva"]')
        b.click(); assert (b.text_content() or '').strip() == 'Confirmar?'
        b.click()
        pg.wait_for_function("/Senha zerada/.test(document.getElementById('toast').textContent)")
        st, r = api('/login', {'login': 'josi.silva', 'senha': 'senha-josi-2026'})
        assert r.get('primeiro_acesso') is True, r
        pg.screenshot(path=SHOTS + '/09-equipe.png')
        pg.keyboard.press('Escape')
        esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='fechar editor')
    passo('Equipe: cadastra colaborador (usuário sugerido do nome) e zera a senha de outra pessoa', equipe_admin)

    def tema():
        assert pg.get_attribute('html', 'data-theme') == 'light'
        pg.click('#btnTema'); assert pg.get_attribute('html', 'data-theme') == 'dark'
        pg.reload(); pg.wait_for_selector('#app:not([hidden])')
        assert pg.get_attribute('html', 'data-theme') == 'dark', 'tema escuro não persistiu'
        pg.click('#btnTema'); assert pg.get_attribute('html', 'data-theme') == 'light'
    passo('tema claro por padrão; escuro só por escolha e lembrado', tema)

    def xss_nao_renderiza():
        tok = pg.evaluate("localStorage.getItem('cn2o_token')")
        st, atual = api('/hub/mural', token=tok)
        d = atual['dados']
        d['avisos'].insert(0, {'titulo': 'Teste de segurança', 'html': '<p>ok<img src="x"><table><tr><td>célula</td></tr></table><a href="http://exemplo.com">link</a><video src="x"></video><font face="Comic Sans">fonte</font></p>'})
        st2, r = api('/hub/mural', {'dados': d, 'base': atual['atualizado_em']}, token=tok)
        assert st2 == 200, r
        pg.reload(); pg.wait_for_selector('#muralAvisos .aviso-row')
        pg.click('#muralAvisos .aviso-row:has-text("Teste de segurança")')
        pg.wait_for_selector('#veuMural.aberto .sub-texto.rico')
        assert pg.locator('.sub-texto.rico img, .sub-texto.rico table, .sub-texto.rico video, .sub-texto.rico font').count() == 0
        assert 'célula' in pg.text_content('.sub-texto.rico')
        a = pg.locator('.sub-texto.rico a')
        assert a.get_attribute('target') == '_blank' and 'noopener' in a.get_attribute('rel')
        assert pg.is_visible('body')
        pg.keyboard.press('Escape')
    passo('HTML indesejado gravado por fora não é renderizado (img/style/object caem; link seguro)', xss_nao_renderiza)

    print('E2E — ferramentas de IA')
    def extrator_texto():
        pg.click('#cardExtrator'); pg.wait_for_selector('#paginaExtrator:not([hidden])')
        assert pg.evaluate('location.hash') == '#extrator'
        esperar(lambda: 'IA ativa' in (pg.text_content('#paginaExtrator [data-chip-ia]') or ''), msg='chip IA ativa')
        # v1.19: sem campo de texto na interface e sem "Ver exemplo" — só documento
        assert pg.evaluate("document.getElementById('entradaExtrator').hidden"), 'o campo de colar texto deveria estar oculto'
        assert pg.evaluate("document.getElementById('btnExemploExt').hidden"), '"Ver exemplo" deveria estar oculto'
        assert 'cole o texto' not in pg.inner_text('#paginaExtrator'), 'não deveria convidar a colar texto'
        # pisca-pisca verde no selo IA ativa
        # o contexto de teste roda com prefers-reduced-motion, que desliga o pisca de
        # propósito: confere-se o verde do ponto e a existência da animação na folha
        piscando = pg.evaluate('''() => { const c = document.querySelector('#paginaExtrator [data-chip-ia]');
          const e = getComputedStyle(c, '::before');
          return { cor: e.color, temKeyframes: document.documentElement.outerHTML.indexOf('@keyframes pulsoIA') > -1,
                   temRegra: /\.chip-ia\.ok::before\{[^}]*animation:pulsoIA/.test(document.documentElement.outerHTML) }; }''')
        assert piscando['cor'] == 'rgb(34, 161, 92)', piscando
        assert piscando['temKeyframes'] and piscando['temRegra'], piscando
        pg.set_input_files('#paginaExtrator .zona-anexos input[type=file]', os.path.join(ARQ, 'certidao-p1.png'))
        pg.wait_for_selector('#paginaExtrator .anexo-item')
        # v1.20: barra verde de carregamento e campo compactado com arquivo na lista
        carga = pg.evaluate('''() => { const b = document.querySelector('#paginaExtrator .anexo-drop .dc-barra');
          if (!b) return { falta: true };
          const e = getComputedStyle(b);
          return { fundo: e.backgroundImage, temFundoVerde: !!document.querySelector('#paginaExtrator .anexo-drop .dc-fundo'),
                   compacto: document.querySelector('#paginaExtrator .zona-anexos').classList.contains('tem-itens') }; }''')
        assert not carga.get('falta'), 'barra de carregamento não foi montada'
        assert '34, 161, 92' in carga['fundo'], carga['fundo']
        assert carga['temFundoVerde'] and carga['compacto'], carga
        pg.click('#btnGerar')
        pg.wait_for_selector('#saidaExtrator .giro')
        pg.wait_for_function("document.getElementById('saidaExtrator').textContent.startsWith('QUALIFICAÇÃO PRONTA')", timeout=20000)
        assert pg.is_visible('#btnCopiarExt')
        meta = pg.inner_text('#metaExt'); assert 'Gemini Pro (vigente)' in meta and 'César' in meta, meta
    passo('Extrator: documento → Extrair qualificação → resultado, assinatura e Copiar (selo IA piscando)', extrator_texto)

    def leitura_clara():
        fundo = pg.evaluate("getComputedStyle(document.querySelector('#paginaExtrator .painel')).backgroundColor")
        cor = pg.evaluate("getComputedStyle(document.querySelector('#saidaExtrator')).color")
        tam = pg.evaluate("getComputedStyle(document.querySelector('#saidaExtrator')).fontSize")
        fam = pg.evaluate("getComputedStyle(document.querySelector('#saidaExtrator')).fontFamily")
        assert fundo == 'rgb(255, 255, 255)', fundo
        assert cor == 'rgb(26, 34, 48)', cor
        assert tam == '18px', tam
        assert 'Atkinson Hyperlegible' in fam, fam
        ent = pg.evaluate("""() => { const c = getComputedStyle(document.querySelector('#paginaExtrator .col-entrada'));
          return { fundo: c.backgroundColor, tarja: c.borderTopColor }; }""")
        assert ent['fundo'] == 'rgb(246, 239, 231)', ent
        assert ent['tarja'] == 'rgb(32, 42, 58)', ent
    passo('v1.15: leitura Atkinson Hyperlegible 18 px quase-preta em quadro branco; entrada marfim com tarja marinho', leitura_clara)

    def extrator_foto_grande():
        pg.click('#btnLimparExt')
        pg.set_input_files('#paginaExtrator .zona-anexos input[type=file]', os.path.join(ARQ, 'foto-celular.jpg'))
        pg.wait_for_selector('#paginaExtrator .anexo-item')
        tam = pg.inner_text('#paginaExtrator .anexo-tam')
        assert 'MB' in tam or 'KB' in tam
        info = pg.inner_text('#paginaExtrator .cont-anexos'); print('     foto 11 MB comprimida para:', info)
        pg.click('#btnGerar')
        pg.wait_for_function("document.getElementById('saidaExtrator').textContent.startsWith('QUALIFICAÇÃO PRONTA')", timeout=20000)
        ult = chamadas()[-1]
        assert ult['arquivos'][0]['mime'] == 'image/jpeg' and ult['arquivos'][0]['tam'] < 6 * 1024 * 1024, ult['arquivos']
        assert ult['observacoes'].startswith('(Sem texto colado')
        assert 'LEITURA OCR DEDICADA' in ult['observacoes'], 'dupla leitura ausente das observações'
        assert 'Dupla leitura OCR: 1 de 120 palavra(s) com leitura incerta' in pg.inner_text('#metaExt'), pg.inner_text('#metaExt')
        assert 'leitura difícil' not in pg.inner_text('#metaExt'), 'documento bom não pode ser rotulado de difícil'
    passo('Extrator: foto de celular de 11 MB é reduzida (≤ 2400 px) e chega como JPEG ao modelo — com dupla leitura OCR', extrator_foto_grande)

    def extrator_botao_descricao():
        pg.click('#btnLimparExt')
        pg.set_input_files('#paginaExtrator .zona-anexos input[type=file]', os.path.join(ARQ, 'certidao-p1.png'))
        pg.wait_for_selector('#paginaExtrator .anexo-item')
        pg.click('#btnDescricao')
        pg.wait_for_function("/DESCRIÇÃO ATUALIZADA DO IMÓVEL/.test(document.getElementById('saidaExtrator').textContent)", timeout=20000)
        assert pg.inner_text('#rotuloSaidaExt').strip().lower() == 'descrição do imóvel', pg.inner_text('#rotuloSaidaExt')
        assert 'Descrição extraída para' in pg.inner_text('#metaExt'), pg.inner_text('#metaExt')
        ch = chamadas()[-1]
        assert 'extrator de DESCRIÇÃO DE IMÓVEL' in ch['prompt'], ch['prompt'][:120]
        assert 'ipsis litteris' in ch['prompt']
        pg.screenshot(path=SHOTS + '/18-extrator-botoes.png')
        # o outro botão continua funcionando na mesma página
        pg.click('#btnLimparExt')
        assert pg.inner_text('#rotuloSaidaExt').strip().lower() == 'resultado da extração'
    passo('Extrator por botões: "Extrair descrição do imóvel" chama o prompt certo e rotula o painel', extrator_botao_descricao)

    def congestionamento_503():
        # v1.21 — quando o provedor da IA congestiona (503 UNAVAILABLE), o servidor
        # insiste e troca de modelo sozinho; se ainda assim não vier, o balcão recebe
        # um recado em português, nunca o JSON cru do Google.
        antes = len(chamadas())
        pg.set_input_files('#paginaExtrator .zona-anexos input[type=file]', os.path.join(ARQ, 'forcar-503.png'))
        pg.wait_for_selector('#paginaExtrator .anexo-item')
        pg.click('#btnGerar')
        pg.wait_for_function("/congestionado/.test(document.getElementById('saidaExtrator').textContent)", timeout=40000)
        recado = pg.inner_text('#saidaExtrator')
        assert 'UNAVAILABLE' not in recado and '{' not in recado, recado
        assert 'seus anexos continuam aqui' in recado.lower(), recado
        assert pg.evaluate("document.querySelectorAll('#paginaExtrator .anexo-item').length") == 1, 'o anexo não podia sumir'
        usados = [x.get('modelo') for x in chamadas()[antes:]]
        assert len(usados) == 4, usados          # preferido 2x + socorro 2x
        assert len(set(usados)) == 2, usados     # o socorro é outro modelo
        pg.screenshot(path=SHOTS + '/19-extrator-congestionado.png')
        pg.click('#btnLimparExt')
    passo('v1.21: modelo congestionado (503) → retentativa, socorro em outro modelo e recado humano', congestionamento_503)

    def analista_pdf_foto_print():
        pg.locator('[data-voltar]:visible').first.click(); pg.click('#cardAnalisador'); pg.wait_for_selector('#paginaAnalisador:not([hidden])')
        assert pg.evaluate("document.getElementById('entradaAnalisador').hidden"), 'o campo de texto do Analista deveria estar oculto (só upload)'
        assert pg.evaluate("document.getElementById('btnExemploAna').hidden"), 'Ver exemplo deveria estar oculto no Analista'
        assert 'cole o texto' not in pg.inner_text('#paginaAnalisador'), 'não deveria haver convite a colar texto'
        pg.set_input_files('#paginaAnalisador .zona-anexos input[type=file]', [os.path.join(ARQ, 'certidao.pdf'), os.path.join(ARQ, 'certidao-p1.png')])
        esperar(lambda: pg.locator('#paginaAnalisador .anexo-item').count() == 2, msg='2 anexos')
        assert pg.locator('#paginaAnalisador .anexo-thumb.pdf').count() == 1
        # print colado (Ctrl+V) com imagem no clipboard
        pg.evaluate('''async () => {
          const c = document.createElement('canvas'); c.width = 300; c.height = 120;
          const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0,0,300,120); g.fillStyle = '#000'; g.fillText('R.4/8.412 PENHORA', 20, 60);
          const b = await new Promise(r => c.toBlob(r, 'image/png'));
          const dt = new DataTransfer(); dt.items.add(new File([b], 'image.png', { type: 'image/png' }));
          document.body.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
        }''')
        esperar(lambda: pg.locator('#paginaAnalisador .anexo-item').count() == 3, msg='print colado')
        assert 'print colado' in pg.inner_text('#paginaAnalisador .anexo-lista')
        pg.screenshot(path=SHOTS + '/04-analista-anexos.png')
        pg.click('#btnAnalisar')
        pg.wait_for_selector('#descBox:not([hidden])', timeout=20000)
        assert 'Rua Coronel Sebastião' in pg.inner_text('#descTexto')
        assert '===DESCRICAO' not in pg.inner_text('#saidaAnalisador')
        ult = chamadas()[-1]
        assert [a['mime'] for a in ult['arquivos']] == ['application/pdf', 'image/png', 'image/png'], ult['arquivos']
        assert ult['arquivos'][0]['cabeca'] == '%PDF-'
        pg.screenshot(path=SHOTS + '/05-analista-resultado.png')
    passo('Analista: PDF + foto + print colado → extrato e "Descrição do imóvel" destacada', analista_pdf_foto_print)

    def colar_texto_nao_vira_anexo():
        n = pg.locator('#paginaAnalisador .anexo-item').count()
        pg.evaluate('''() => { const dt = new DataTransfer(); dt.setData('text/plain', 'MATRÍCULA 123 texto');
          document.body.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true })); }''')
        time.sleep(0.4)
        assert pg.locator('#paginaAnalisador .anexo-item').count() == n
    passo('colar TEXTO (sem imagem) não cria anexo no Analista', colar_texto_nao_vira_anexo)

    def analista_sem_anexo_avisa():
        pg.click('#btnLimparAna'); pg.click('#btnAnalisar')
        pg.wait_for_selector('#toast:not([hidden])')
        assert 'foto, print ou PDF' in pg.inner_text('#toast'), pg.inner_text('#toast')
    passo('Analista sem anexo: aviso pede a certidão em foto, print ou PDF', analista_sem_anexo_avisa)

    def erro_do_modelo():
        pg.locator('[data-voltar]:visible').first.click(); pg.click('#cardExtrator'); pg.wait_for_selector('#paginaExtrator:not([hidden])')
        pg.click('#btnLimparExt'); pg.evaluate("document.getElementById('entradaExtrator').value = 'FORCAR_ERRO'")
        pg.click('#btnGerar')
        pg.wait_for_function("/A IA não conseguiu concluir/.test(document.getElementById('saidaExtrator').textContent)", timeout=15000)
        assert 'extrair qualificação' in (pg.inner_text('#btnGerar') or '').lower(), pg.inner_text('#btnGerar')
    passo('falha do modelo mostra mensagem clara e libera o botão', erro_do_modelo)

    def interromper():
        pg.evaluate("document.getElementById('entradaExtrator').value = 'qualquer'"); pg.click('#btnGerar')
        pg.wait_for_selector('#saidaExtrator .giro'); pg.click('#btnGerar')
        pg.wait_for_function("document.getElementById('saidaExtrator').textContent === 'Interrompido.'")
    passo('botão Interromper cancela a análise em andamento', interromper)

    print('E2E — ferramentas embutidas, rotas e sessão')
    def protocolo_embutido():
        pg.locator('[data-voltar]:visible').first.click(); pg.click('#cardProtocolo')
        pg.wait_for_selector('#paginaEmbutida:not([hidden]) iframe')
        fr = pg.frame_locator('#molduraEmbutida iframe:not([hidden])')
        txt = fr.locator('#sessaoInfo').inner_text(timeout=8000)
        assert 'César Bravo' in txt and 'Tabelião' in txt and 'Hub dos Escreventes' not in txt, txt
        assert pg.get_attribute('#embutidaNovaAba', 'href') == 'protocolo.html'
        assert pg.evaluate('location.hash') == '#protocolo'
        pg.screenshot(path=SHOTS + '/06-protocolo-embutido.png')
        pg.go_back(); pg.wait_for_selector('#paginaHub:not([hidden])')
    passo('Protocolo abre embutido com a MESMA sessão; Voltar do navegador retorna ao hub', protocolo_embutido)

    def agenda_embutida():
        pg.evaluate("document.querySelector('[data-nav=calendario]').click()")
        pg.wait_for_selector('#paginaEmbutida:not([hidden])')
        assert pg.evaluate('location.hash') == '#agenda'
        assert (pg.text_content('#embutidaTitulo') or '').strip() == 'Agenda do Tabelião'
        src = pg.evaluate("document.querySelector('#molduraEmbutida iframe:not([hidden])').src")
        assert src.startswith('https://calendar.google.com/calendar/embed?src=tnitabaiana%40gmail.com'), src
        assert 'ctz=America%2FMaceio' in src and 'hl=pt_BR' in src, src
        ab = pg.get_attribute('#embutidaNovaAba', 'href')
        assert ab == 'https://calendar.google.com/calendar/u/0?cid=dG5pdGFiYWlhbmFAZ21haWwuY29t', ab
        pg.go_back(); pg.wait_for_selector('#paginaHub:not([hidden])')
    passo('Agenda do Tabelião abre embutida (Google Agenda) e "nova aba" leva ao link do Tabelião', agenda_embutida)

    def home_igual_a_foto():
        est = pg.evaluate("""() => { const c = getComputedStyle(document.querySelector('.login-caixa'));
          const img = document.querySelector('.login-arte img');
          return { fundo: c.backgroundImage, raio: c.borderRadius, sombra: c.boxShadow,
                   arte: img && img.src.slice(0, 22), frase: document.querySelector('.arte-frase').textContent,
                   titulo: document.querySelector('.login-titulo').textContent,
                   sub: document.querySelector('.login-sub').textContent,
                   botao: document.getElementById('btnEntrar').textContent.trim(),
                   nota: document.querySelector('.login-nota-pe').textContent }; }""")
        assert 'gradient' in est['fundo'] and est['raio'] == '16px' and est['sombra'] != 'none', est
        assert est['arte'] == 'data:image/jpeg;base64', est['arte']
        assert 'Boas ferramentas' in est['frase'] and 'transformam.' in est['frase'], est['frase']
        assert est['titulo'] == 'Hub CN2O' and est['sub'] == 'Seu ambiente de trabalho.', est
        assert est['botao'] == 'Entrar no Hub', est['botao']
        assert 'e-Protocolo' in est['nota'] and 'redefinição ao Tabelião' in est['nota'], est['nota']
    passo('home igual à foto: escultura + frase à esquerda, cartão "Hub CN2O" à direita', home_igual_a_foto)

    def olho_da_senha():
        assert pg.evaluate("document.getElementById('campoSenha').type") == 'password'
        pg.evaluate("document.querySelector('[data-olho=campoSenha]').click()")
        assert pg.evaluate("document.getElementById('campoSenha').type") == 'text'
        pg.evaluate("document.querySelector('[data-olho=campoSenha]').click()")
        assert pg.evaluate("document.getElementById('campoSenha').type") == 'password'
    passo('olho da senha mostra e volta a ocultar', olho_da_senha)

    def links_uteis_com_logos():
        dados = pg.evaluate("""() => Array.from(document.querySelectorAll('#linksUteis .link-item')).map(li => ({
          nome: li.querySelector('.link-nome').textContent,
          logo: !!li.querySelector('.link-logo img') && li.querySelector('.link-logo img').src.startsWith('data:image/png'),
          href: (li.querySelector('a') || {}).href || null }))""")
        nomes = [d['nome'] for d in dados]
        assert nomes == ['TJSE — Guia de emolumentos', 'e-Notariado', 'RI Digital', 'Links CNJ',
            'Receita Federal — CND', 'Sefaz/SE — Portal do ITCMD', 'Prefeitura de Itabaiana/SE'], nomes
        assert all(d['logo'] for d in dados), dados
        assert any(d['href'] and 'e-notariado.org.br' in d['href'] for d in dados)
        assert any(d['href'] and 'ridigital.org.br' in d['href'] for d in dados)
        assert any(d['href'] and 'itabaiana.se.gov.br' in d['href'] for d in dados)
        pg.click('#linkCnj')
        pg.wait_for_selector('#veuCnj.aberto')
        cnj = pg.evaluate("""() => Array.from(document.querySelectorAll('#veuCnj a')).map(a => a.href)""")
        assert len(cnj) == 3 and any('179' in u for u in cnj) and any('5243' in u for u in cnj) and any('justicaaberta' in u for u in cnj), cnj
        pg.keyboard.press('Escape')
        pg.wait_for_selector('#veuCnj', state='hidden')
        faixa = pg.evaluate("(f => f && f.textContent.trim())(document.querySelector('#linksUteis .faixa-titulo.faixa-clara .faixa-palavra'))")
        assert faixa == 'Links úteis', faixa
    passo('Links úteis: 7 entradas com mini-logos, faixa clara própria e a sobreposição Links CNJ', links_uteis_com_logos)

    def cartoes_numerados():
        nomes = pg.evaluate("Array.from(document.querySelectorAll('#secFerramentas .card h3')).map(h => h.textContent.trim())")
        assert nomes == ['e-Protocolo', 'Calculadora de Emolumentos', 'Extrator', 'e-Analista', 'Gerador PROC / UE', 'Cláusulas CN2O', 'T-Consulta', 'Redator CN2O'], nomes
        nums = pg.evaluate("Array.from(document.querySelectorAll('#secFerramentas .card-num')).map(n => n.textContent)")
        assert nums == ['01', '02', '03', '04', '05', '06', '07', '08'], nums
        chips = pg.evaluate("""Array.from(document.querySelectorAll('#secFerramentas .card')).map(c => {
          const ch = c.querySelector('.chip-ia'); return ch ? ch.textContent.trim() : null })""")
        assert chips == [None, None, 'IA', 'IA', 'IA', 'Guia', 'Trello', 'IA'], chips
        icones = pg.evaluate("document.querySelectorAll('#secFerramentas .card .card-ico svg').length")
        assert icones == 8, icones
        descr = pg.evaluate("document.querySelectorAll('#secFerramentas .card p').length")
        assert descr == 8, descr
        cols = pg.evaluate("getComputedStyle(document.querySelector('#secFerramentas .cards')).gridTemplateColumns.split(' ').length")
        assert cols == 4, 'grade deveria ter 4 colunas na tela larga: %s' % cols
        trello = pg.evaluate("(a => ({href: a.href, gira: !!a.querySelector('.t3d-gira'), cn2o: !!a.querySelector('.t3d-cn2o'), seta: !!a.querySelector('.t3d-seta')}))(document.getElementById('atalhoTrello'))")
        assert trello['href'].startswith('https://trello.com') and trello['gira'] and not trello['cn2o'] and not trello['seta'], trello
        pg.click('#cardMinutas')
        pg.wait_for_selector('#paginaMinutas:not([hidden])')
        assert pg.evaluate("document.getElementById('btnGerarMinuta').disabled"), 'botão deveria nascer travado'
        assert pg.locator('#paginaMinutas .termo-check').count() == 2, 'faltam as 2 caixas de ciência'
        assert 'responsabilidade disciplinar' in pg.inner_text('#paginaMinutas'), 'termo disciplinar ausente'
        pg.check('#minCiente1'); pg.check('#minCiente2')
        assert not pg.evaluate("document.getElementById('btnGerarMinuta').disabled"), 'os 2 checks deveriam liberar o botão'
        pg.locator('#paginaMinutas [data-voltar]').click()
        pg.wait_for_selector('#paginaHub:not([hidden])')
    passo('Ferramentas 01–08 com descrições, chips IA/Guia/Trello e o atalho 3D do Trello', cartoes_numerados)

    def gerador_ue_fluxo_completo():
        import io as _io
        from PIL import Image as _Img
        def jpg(l, cor):
            b = _io.BytesIO(); _Img.new('RGB', (l, l), cor).save(b, 'JPEG', quality=85); return b.getvalue()
        pg.click('#cardMinutas'); pg.wait_for_selector('#paginaMinutas:not([hidden])')
        pg.check('#minCiente1'); pg.check('#minCiente2')
        pg.fill('#minC1Nome', 'Fulana de Tal'); pg.fill('#minC1Cpf', '054.318.276-90')
        pg.fill('#minC2Nome', 'Beltrano de Tal')
        pg.click('[data-min-chips="c1civil"] [data-v="Solteiro(a)"]')
        pg.click('[data-min-chips="c2civil"] [data-v="Divorciado(a)"]')
        pg.fill('#minEndereco', 'Rua Boanerges Pinheiro, 214, Centro, Itabaiana/SE')
        pg.fill('#minInicio', '2021-05-10')
        pg.click('[data-min-chips="filhos"] [data-v="Sim"]')
        assert pg.locator('#minFilhosBox:visible').count() == 1, 'campo de filhos deveria abrir'
        pg.fill('#minFilhos', 'Maria (12/03/2022)')
        pg.click('[data-min-chips="nome"] [data-v="Convivente 1 acrescenta"]')
        assert pg.locator('#minNome1Box:visible').count() == 1, 'campo do nome novo deveria abrir'
        assert pg.locator('#minAvisoLivroE:visible').count() == 1, 'aviso do Livro E deveria aparecer'
        assert 'Livro E' in pg.inner_text('#minAvisoLivroE')
        pg.fill('#minNome1', 'Fulana de Tal Silva')
        pg.set_input_files('#paginaMinutas .zona-anexos input[type=file]', files=[{'name': 'certidao.jpg', 'mimeType': 'image/jpeg', 'buffer': jpg(900, (200, 190, 170))}])
        esperar(lambda: pg.locator('#paginaMinutas .anexo-item').count() == 1, msg='anexo listado')
        entrevista = pg.evaluate("document.getElementById('minPedido').value")  # ainda vazio; texto sai do obterTexto
        pg.click('#btnGerarMinuta')
        pg.wait_for_selector('#saidaMinuta:not(.vazia)')
        esperar(lambda: 'UNIÃO ESTÁVEL' in pg.inner_text('#saidaMinuta'), seg=20, msg='minuta do mock chegar')
        texto = pg.inner_text('#saidaMinuta')
        assert 'Livro E' in texto, 'minuta sem a ressalva do Livro E'
        assert 'rascunho' in texto, 'minuta sem o rodapé de rascunho'
        esperar(lambda: pg.locator('#minutaLinkBox:visible').count() == 1, msg='link permanente aparecer')
        link = pg.evaluate("document.getElementById('minutaLinkA').textContent")
        assert '#minuta=' in link, link
        # a entrevista enviada ao servidor levou os dados e a ressalva
        ch = chamadas()[-1]
        assert 'ENTREVISTA — ESCRITURA DE UNIÃO ESTÁVEL' in ch['observacoes']
        assert 'Fulana de Tal Silva' in ch['observacoes'] and 'Livro E do RCPN' in ch['observacoes']
        assert ch['arquivos'] and ch['arquivos'][0]['mime'] == 'image/jpeg'
        # link permanente abre a minuta guardada
        pg.goto(link); pg.wait_for_selector('#paginaMinutas:not([hidden])')
        esperar(lambda: 'UNIÃO ESTÁVEL' in pg.inner_text('#saidaMinuta'), msg='minuta pelo link')
        assert 'guardada por' in pg.inner_text('#metaMin')
        pg.goto(SITE); pg.wait_for_selector('#app:not([hidden])')
    passo('Gerador PROC / UE: entrevista + anexo → minuta com Livro E + link permanente que reabre', gerador_ue_fluxo_completo)

    def pacto_no_dossie_do_protocolo():
        pg2 = ctx.new_page()
        pg2.set_default_timeout(12000)
        tok = pg.evaluate("localStorage.getItem('cn2o_token')")
        pg2.add_init_script("localStorage.setItem('cn2o_token','%s');localStorage.setItem('cn2o_nome','César Bravo');localStorage.setItem('cn2o_hub_key','teste');" % tok)
        pg2.goto(SITE + 'protocolo.html'); pg2.wait_for_selector('.chips .chip')
        pg2.evaluate("[...document.querySelectorAll('.chips .chip')].find(c => c.textContent.includes('CV-Urbano')).click()")
        def op(pg_, pergunta_titulo, valor):
            js = ("([t, v]) => { const div = [...document.querySelectorAll('#perguntas .pergunta')]"
                  ".find(d => d.querySelector('.titulo-p') && d.querySelector('.titulo-p').textContent.includes(t));"
                  " const o = [...div.querySelectorAll('.op')].find(x => x.textContent.trim() === v); o.click(); }")
            pg_.evaluate(js, [pergunta_titulo, valor])
        op(pg2, 'pessoa', 'Pessoa física')
        op(pg2, 'estado civil', 'Casado(a)')
        op(pg2, 'regime de bens', 'Comunhão universal')
        doss = pg2.evaluate("[...document.querySelectorAll('#listaDossie li')].map(li => li.dataset.item)")
        assert any('Pacto antenupcial — escritura ou certidão do registro no RI' in d for d in doss), doss
        assert any('Certidão de casamento (transmitente)' in d for d in doss), doss
        op(pg2, 'regime de bens', 'Separação obrigatória (art. 1.641 CC)')
        doss = pg2.evaluate("[...document.querySelectorAll('#listaDossie li')].map(li => li.dataset.item)")
        assert not any('Pacto antenupcial' in d for d in doss), 'separação obrigatória não tem pacto'
        assert any('Súmula 377' in d for d in doss), doss
        pg2.close()
    passo('Protocolo: comunhão universal exige o pacto no dossiê; separação obrigatória não (Súmula 377 por cautela)', pacto_no_dossie_do_protocolo)


    def dashboard_mural():
        assert 'Olá' in pg.inner_text('#saudacao'), pg.inner_text('#saudacao')
        titulo = pg.inner_text('.mural-titulo').upper().strip()
        assert titulo == 'MURAL', titulo
        fonte = pg.evaluate("getComputedStyle(document.querySelector('.mural-titulo')).fontFamily")
        assert 'Caveat' in fonte, fonte
        sem_frases = pg.evaluate("document.querySelectorAll('.mural-citacao, .mural-frase, .mural-script, .mural-linha2, .mural-rodape-frases').length")
        assert sem_frases == 0, 'frases ainda no mural: %s' % sem_frases
        nav = pg.evaluate("Array.from(document.querySelectorAll('.lat-nav .nav-item')).map(b => b.textContent.trim())")
        assert nav == ['Início', 'Ferramentas', 'Links úteis', 'Avisos', 'Metas', 'Agenda do Tabelião', 'Documentos', 'Ajuda'], nav
        assert pg.evaluate("document.getElementById('avatarIni').textContent.trim().length >= 1"), 'avatar vazio'
        marca = pg.evaluate("""() => { const m = document.querySelector('.lat-avatar.avatar-m'), b = document.querySelector('.lat-avatar.avatar-b');
          return m && m.naturalWidth > 50 && m.src.startsWith('data:image/png') &&
                 getComputedStyle(m).display !== 'none' && getComputedStyle(b).display === 'none'; }""")
        assert marca, 'avatar oficial (marinho) deveria aparecer na lateral clara'
        lateral = pg.evaluate("getComputedStyle(document.querySelector('.lateral')).backgroundImage")
        assert '247' in lateral, 'lateral não está clara (marfim): %s' % lateral
        pino = pg.evaluate("() => getComputedStyle(document.querySelector('.mural-cards .ficha-luz'), '::before').backgroundImage.includes('radial-gradient')")
        assert pino, 'alfinete (pin) ausente nos papéis do mural'
        inclinacao = pg.evaluate("getComputedStyle(document.querySelectorAll('.mural-cards .ficha-luz')[0]).transform")
        assert inclinacao not in ('none', ''), 'papel sem inclinação de alfinete'
        assert pg.evaluate("/^\\d\\d$/.test(document.getElementById('seloDia').textContent)"), pg.evaluate("document.getElementById('seloDia').textContent")
        fichas = pg.evaluate("document.querySelectorAll('.mural-cards .ficha-luz').length")
        assert fichas == 3, fichas
        # metas ativas neste ponto do fluxo: o Ver mais aparece; em breve ele some (testado no mural inicial)
        esperar(lambda: 'frase fixada do teste' in pg.inner_text('#fraseTexto'), msg='frase da planilha (fixada) chegar')
        frase = pg.evaluate("""() => ({ texto: document.getElementById('fraseTexto').textContent.trim(),
          autor: document.getElementById('fraseAutor').textContent.trim(),
          fecho: document.querySelector('#fraseDia .fd-fecho').textContent,
          cursiva: getComputedStyle(document.getElementById('saudacao')).fontFamily })""")
        assert frase['texto'] == 'A frase fixada do teste vale para todos.', frase
        assert frase['autor'] == '— Equipe de Teste', frase
        assert 'César Bravo, Tabelião' in frase['fecho'] and 'Dr.' not in frase['fecho'] and 'ótimo dia de trabalho' in frase['fecho'], frase['fecho']
        assert 'Caveat' in frase['cursiva'], frase['cursiva']
        agenda = pg.evaluate("""() => { const t = document.querySelector('.mural-cards .ficha-luz .ficha-titulo');
          return { texto: t.textContent.trim(), transf: getComputedStyle(t).textTransform }; }""")
        assert agenda['texto'] == 'Agenda Cn2o' and agenda['transf'] == 'none', agenda
        pg.evaluate("document.querySelector('[data-nav=avisos]').click()")
        pg.wait_for_selector('#veuMural.aberto')
        pg.keyboard.press('Escape')
        esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='fechar avisos')
        pg.evaluate("document.querySelector('[data-nav=ajuda]').click()")
        pg.wait_for_selector('#veuAjuda.aberto')
        pg.keyboard.press('Escape')
        pg.wait_for_selector('#veuAjuda', state='hidden')
        aberto = pg.evaluate("""() => { let url = null; const velho = window.open; window.open = u => { url = u; return null; };
          document.querySelector('[data-nav=documentos]').click(); window.open = velho; return url; }""")
        assert aberto and '17jiEqA5ufl4L_7fKKvHzvWF23wvDnlWT' in aberto, aberto
        pg.evaluate("document.querySelector('[data-nav=inicio]').click()")
    passo('dashboard: avatar oficial na lateral + Mural CN2O sem frases, com alfinetes e Agenda do Tabelião no menu', dashboard_mural)


    def protocolar_de_verdade():
        pg.locator('[data-voltar]:visible').first.click() if pg.locator('[data-voltar]:visible').count() else None
        pg.click('#cardProtocolo'); pg.wait_for_selector('#paginaEmbutida:not([hidden])')
        fr = pg.frame_locator('#molduraEmbutida iframe:not([hidden])')
        fr.locator('.chip[data-ato="CV-Urbano"]').click()
        fr.locator('#veuCheck.aberto').wait_for()
        itens = fr.locator('#checkLista .ck-it.tick')
        n = itens.count()
        for i in range(min(3, n)): itens.nth(i).click()
        fr.locator('#veuCheck .fechar').click()
        fr.locator('#apresNome').fill('Corretor Teste da Silva')
        fr.locator('#apresTel').fill('(79) 99999-0000')
        fr.locator('#parteNome').fill('Comprador Teste de Souza')
        fr.locator('#enotT .op', has_text='Não').click()
        fr.locator('#enotA .op', has_text='Não').click()
        btn = fr.locator('#btnProt')
        esperar(lambda: btn.is_enabled(), msg='botão Protocolizar habilitar')
        btn.click()
        fr.locator('#veu.aberto').wait_for(timeout=15000)
        recibo = fr.locator('#reciboTxt').inner_text()
        assert 'Nº do protocolo: 1400' in recibo, recibo
        pg.screenshot(path=SHOTS + '/08-protocolo-recibo.png')
        num = sql("SELECT numero || '|' || usuario || '|' || coalesce(card_id,'') FROM protocolos ORDER BY numero DESC LIMIT 1").strip()
        assert num.startswith('1400|cesar.bravo|card-teste-'), num
        with open('/tmp/trello-chamadas.json', encoding='utf-8') as f: tr = json.load(f)
        cartao = [c for c in tr if c['nome'] == 'criarCartao'][-1]['args'][0]
        assert cartao['name'] == 'Prot. (CV-Urbano) 1400 - COMPRADOR TESTE DE SOUZA', cartao['name']
        campos = [c for c in tr if c['nome'] == 'aplicarCampos'][-1]['args'][2]
        assert campos['Escrevente'] == 'César Bravo', campos
        with open('/tmp/whats-chamadas.json', encoding='utf-8') as f: wa = json.load(f)
        v = wa[-1]['vars']
        assert len(v) == 5, v
        assert v[0] == '1400', v
        assert v[1] == 'Compra e venda — imóvel urbano', v            # ato por extenso, nunca o código
        assert v[2] == 'CORRETOR TESTE DA SILVA', v                   # apresentante (o formulário sobe para caixa alta)
        assert v[3] == 'COMPRADOR TESTE DE SOUZA', v                  # parte / comprador(a)
        assert v[4] == 'não se aplica', v                             # sem vendedor no formulário
        assert all(isinstance(x, str) and x.strip() for x in v), v    # a Meta recusa parâmetro vazio
        print('     recibo do WhatsApp:', ' | '.join(v))
        print('     protocolo 1400 registrado; cartão:', cartao['name'], '· escrevente (da sessão):', campos['Escrevente'])
        fr.locator('#veu .fechar').click()
        pg.locator('[data-voltar]:visible').first.click()
    passo('PROTOCOLO de ponta a ponta dentro do Hub: CV-Urbano → nº 1400 no banco, cartão (simulado) e escrevente da sessão', protocolar_de_verdade)

    def consulta_trello_extrato():
        pg.click('#cardConsulta'); pg.wait_for_selector('#paginaConsulta:not([hidden])')
        pg.fill('#conNumero', '1400')
        pg.click('#btnConsultar')
        pg.wait_for_selector('#conResultado:not([hidden])')
        txt = pg.inner_text('#conResultado')
        assert 'COMPRADOR TESTE DE SOUZA' in txt, txt[:400]            # título do cartão (mock)
        assert 'CORRETOR TESTE DA SILVA' in txt, txt[:400]            # apresentante vindo do registro do banco (o e-Protocolo grava em caixa alta)
        assert 'Compra e venda' in txt, txt[:400]                      # tipo de ato traduzido
        assert 'Aguardando última conferência' in txt, txt[:400]       # fase atual
        assert 'César Bravo' in txt, txt[:400]                         # com quem está
        assert 'Protocolo / Entrada' in txt and 'Curadoria de documentos' in txt and 'Preparação de minuta' in txt, txt[:700]
        assert 'Certidão de ônus atualizada' in txt, txt[:700]         # pendência do dossiê
        link = pg.evaluate("(document.querySelector('#conResultado a.con-link') || {}).href || ''")
        assert link.startswith('https://trello.com'), link
        pg.screenshot(path=SHOTS + '/14-t-consulta.png', full_page=True)
        pg.fill('#conNumero', '999444'); pg.click('#btnConsultar')
        esperar(lambda: 'não encontrado' in pg.inner_text('#conNota'), msg='recado de protocolo inexistente')
        pg.locator('#paginaConsulta [data-voltar]').click()
        pg.wait_for_selector('#paginaHub:not([hidden])')
    passo('T-Consulta: protocolo 1400 → extrato com partes, fases, fase atual com o Tabelião e link do cartão', consulta_trello_extrato)

    def redator_oficio_e_aviso():
        pg.locator('[data-voltar]:visible').first.click() if pg.locator('[data-voltar]:visible').count() else None
        pg.click('#cardRedator'); pg.wait_for_selector('#paginaRedator:not([hidden])')
        assert pg.evaluate('location.hash') == '#redator'
        # o tipo padrão é e-mail: cargo/órgão e texto recebido ficam escondidos
        assert not pg.is_visible('#paginaRedator [data-campo="cargo"]'), 'cargo não deveria aparecer no e-mail'
        assert not pg.is_visible('#paginaRedator [data-campo="recebido"]'), 'texto recebido não deveria aparecer no e-mail'
        assert pg.inner_text('#redRotuloBtn').lower() == 'escrever o e-mail', pg.inner_text('#redRotuloBtn')
        # WhatsApp esconde o assunto e o anexo
        pg.click('.red-tipo[data-tipo="whatsapp"]')
        assert not pg.is_visible('#paginaRedator [data-campo="assunto"]'), 'assunto não cabe no WhatsApp'
        assert not pg.is_visible('#paginaRedator [data-campo="anexo"]'), 'anexo não cabe no WhatsApp'
        # ofício exige cargo e órgão
        pg.click('.red-tipo[data-tipo="oficio"]')
        assert pg.is_visible('#paginaRedator [data-campo="cargo"]'), 'ofício precisa do cargo e órgão'
        assert pg.inner_text('#redRotuloBtn').lower() == 'escrever o ofício', pg.inner_text('#redRotuloBtn')
        pg.fill('#redDest', 'Juízo da 2ª Vara Cível da Comarca de Itabaiana/SE')
        pg.click('#btnRedigir')
        esperar(lambda: 'cargo e o órgão' in (pg.inner_text('#toast') if pg.is_visible('#toast') else ''),
                msg='aviso de cargo obrigatório')
        pg.fill('#redCargo', 'Juiz de Direito')
        pg.fill('#redContexto', 'informar que a escritura foi lavrada em 10/09/2026')
        pg.click('#btnRedigir')
        pg.wait_for_selector('#saidaRedator .giro')
        pg.wait_for_function("document.getElementById('saidaRedator').textContent.indexOf('TEXTO PRONTO') > -1", timeout=20000)
        saida = pg.inner_text('#saidaRedator')
        assert '===TEXTO_COPIAVEL===' not in saida, 'os marcadores não podem aparecer na tela'
        assert 'Ofício nº ____/2026' in saida, saida[:200]
        assert '⚠ CONFERIR' in saida
        assert pg.is_visible('#btnCopiarRed')
        assert not pg.is_visible('#btnCopiarZap'), 'ofício não tem versão de WhatsApp'
        # o botão Copiar leva só o texto, sem o bloco de conferência
        assert pg.is_visible('#redAjusteBox'), 'a caixa de ajuste deveria aparecer depois do primeiro texto'
        assert pg.inner_text('#redRotuloBtn').lower() == 'escrever o ofício', 'o botão voltou ao rótulo errado: ' + pg.inner_text('#redRotuloBtn')
        meta = pg.inner_text('#metaRed'); assert 'Redigido por' in meta and 'César' in meta, meta
        # aviso de pendência: sai também a versão curta para WhatsApp
        pg.click('.red-tipo[data-tipo="aviso_pendencia"]')
        pg.fill('#redDest', 'Corretor Teste da Silva')
        pg.fill('#redProtocolo', '1400')
        pg.click('#btnRedigir')
        pg.wait_for_function("document.getElementById('saidaRedator').textContent.indexOf('WHATSAPP') > -1", timeout=20000)
        assert pg.is_visible('#btnCopiarZap'), 'o aviso de pendência precisa do botão da versão curta'
        assert 'VERSÃO CURTA PARA WHATSAPP' in pg.inner_text('#saidaRedator')
        with open('/tmp/gemini-chamadas.json', encoding='utf-8') as f: ch = json.load(f)[-1]
        assert 'REDATOR CN2O' in ch['prompt'], 'prompt do Redator não chegou ao modelo'
        assert 'TIPO: aviso_pendencia' in ch['observacoes'], ch['observacoes'][:300]
        assert 'DADOS DO PROTOCOLO 1400' in ch['observacoes'], 'o Hub deveria ter lido o protocolo 1400'
        assert 'Escrevente que está redigindo: César Bravo' in ch['observacoes'], 'quem assina tem de vir da sessão'
        pg.screenshot(path=SHOTS + '/26-redator.png')
        pg.locator('[data-voltar]:visible').first.click()
    passo('Redator CN2O: tipo muda os campos, ofício exige cargo, aviso de pendência sai com versão de WhatsApp e lê o protocolo', redator_oficio_e_aviso)

    def calculadora_embutida():
        pg.click('#cardCalculadora')
        pg.wait_for_selector('#paginaEmbutida:not([hidden])')
        fr = pg.frame_locator('#molduraEmbutida iframe:not([hidden])')
        assert fr.locator('body').inner_text(timeout=8000).strip() != ''
        pg.click('#paginaEmbutida [data-voltar]')
    passo('Calculadora abre embutida', calculadora_embutida)

    def rota_direta():
        pg.goto(SITE + '#analista'); pg.wait_for_selector('#paginaAnalisador:not([hidden])')
        pg.goto(SITE + '#protocolo'); pg.wait_for_selector('#paginaEmbutida:not([hidden])')
        pg.goto(SITE)
        pg.wait_for_selector('#paginaHub:not([hidden])')
    passo('atalhos diretos (#analista, #protocolo) abrem a ferramenta certa', rota_direta)

    def clausulas():
        pg.click('#cardClausulas'); pg.wait_for_selector('#veuClausulas.aberto')
        pg.click('.tema-cab >> nth=0'); pg.click('.clausula >> nth=0')
        pg.wait_for_selector('#toast:not([hidden])'); assert 'copiada' in pg.inner_text('#toast')
        pg.keyboard.press('Escape')
    passo('Cláusulas do Guia: abre tema e copia', clausulas)

    def sessao_expirada():
        sql('DELETE FROM sessoes')
        pg.click('#cardExtrator'); pg.evaluate("document.getElementById('entradaExtrator').value = 'sessao'"); pg.click('#btnGerar')
        pg.wait_for_selector('#telaLogin:not([hidden])', timeout=10000)
        assert 'expirou' in pg.inner_text('#msgLogin')
        assert pg.evaluate("localStorage.getItem('cn2o_token')") is None
    passo('sessão derrubada no servidor → volta ao login com "Sua sessão expirou"', sessao_expirada)

    def celular():
        m = nav.new_context(viewport={'width': 400, 'height': 860}, locale='pt-BR')
        m.route('**/*', lambda r: r.abort() if 'fonts.g' in r.request.url else r.continue_())
        mp = m.new_page(); mp.goto(SITE); mp.wait_for_selector('#telaLogin:not([hidden])')
        mp.fill('#campoLogin', 'cesar.bravo'); mp.fill('#campoSenha', 'senha-cesar-123'); mp.click('#btnEntrar')
        mp.wait_for_selector('#app:not([hidden])'); mp.wait_for_selector('#muralAvisos .aviso-row')
        larg = mp.evaluate('document.documentElement.scrollWidth')
        assert larg <= 402, larg
        mp.screenshot(path=SHOTS + '/07-celular.png', full_page=True)
        m.close()
    passo('tela de celular (400 px) sem rolagem horizontal', celular)

    pg.goto(SITE); pg.wait_for_selector('#telaLogin:not([hidden])')
    pg.fill('#campoLogin', 'cesar.bravo'); pg.fill('#campoSenha', 'senha-cesar-123'); pg.click('#btnEntrar')
    pg.wait_for_selector('#muralAvisos .aviso-row')
    pg.screenshot(path=SHOTS + '/00-hub-desktop.png', full_page=True)
    nav.close()

relevantes = [e for e in erros_console if 'Failed to load resource' not in e and 'fonts.g' not in e]
print(f'\n{ok} ok, {falhas} falha(s); erros de console relevantes: {len(relevantes)}')
for e in relevantes[:10]: print('   console:', e[:200])
sys.exit(1 if falhas else 0)
