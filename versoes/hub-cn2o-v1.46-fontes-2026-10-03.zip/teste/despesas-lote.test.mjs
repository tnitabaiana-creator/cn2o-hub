import test from 'node:test';
import assert from 'node:assert/strict';
globalThis.document={getElementById:()=>({})};
const {importBatch,checkManifest}=await import('../frontend/src/despesas/batch-import.mjs');
const file=new File(['%PDF-1.7 original'],'recibo.pdf',{type:'application/pdf'});
const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',await file.arrayBuffer()))].map(n=>n.toString(16).padStart(2,'0')).join('');
const id='00000000-0000-4000-8000-000000000001';
const make=()=>({format:'cn2o-expenses-1',documents:[{name:file.name,hash,size:file.size,period:'2026-06',ocr:{status:'complete'}}],entries:[{id,documentHashes:[hash],reviewed:false,description:'Original',fieldSources:{amount:{documentHash:hash,documentName:file.name,method:'filename'}}}]});
test('seleção incompleta ou original adulterado bloqueia todas as escritas',async()=>{
 let writes=0;for(const files of [[],[new File(['outro original!!'],file.name)]])await assert.rejects(()=>importBatch(make(),files,{refresh:async()=>({documents:[],entries:[]}),put:async()=>writes++}),/original correspondente/);assert.equal(writes,0);
});
test('reimportação conserva lançamento existente e documentos, sem sobrescrever revisão humana',async()=>{
 let writes=0;const result=await importBatch(make(),[],{refresh:async()=>({documents:[{hash,id:'doc-existente'}],entries:[{id,reviewed:true}]}),put:async()=>writes++});assert.equal(writes,0);assert.equal(result.documentsReused,1);assert.equal(result.entriesReused,1);
});
test('original recebido é vinculado ao lançamento e à origem de cada campo',async()=>{
 const calls=[];const result=await importBatch(make(),[file],{refresh:async()=>({documents:[],entries:[]}),put:async(name,record)=>{if(name==='documents'){record.version=1;record.id='documento-confirmado';}calls.push([name,structuredClone({...record,blob:undefined})]);}});assert.equal(result.entriesAdded,1);assert.deepEqual(calls[2][1].docIds,['documento-confirmado']);assert.equal(calls[2][1].fieldSources.amount.documentId,'documento-confirmado');assert.equal(calls[2][1].reviewed,false);
});
test('falha de envio impede lançamento sem original; falhas parciais são rastreáveis',async()=>{
 const result=await importBatch(make(),[file],{refresh:async()=>({documents:[],entries:[]}),put:async()=>{throw Error('falha de rede');}});assert.equal(result.entriesAdded,0);assert.equal(result.failures.length,2);
});
test('duplicidade concorrente recupera a identidade do original já salvo',async()=>{
 let refreshed=0,entry;const result=await importBatch(make(),[file],{refresh:async()=>({documents:refreshed++?[{hash,id:'doc-real'}]:[],entries:[]}),put:async(name,r)=>{if(name==='documents')throw Object.assign(Error('já recebido'),{code:'DOCUMENT_EXISTS'});entry=r;}});assert.equal(result.documentsReused,1);assert.deepEqual(entry.docIds,['doc-real']);
});
test('manifesto não pode aprovar revisão fiscal nem ligar documento inexistente',()=>{const m=make();m.entries[0].reviewed=true;assert.throws(()=>checkManifest(m));m.entries[0].reviewed=false;m.entries[0].documentHashes=['f'.repeat(64)];assert.throws(()=>checkManifest(m));});
