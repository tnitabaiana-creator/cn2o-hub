"""E2E focado na v1.42 — Calculadora ITCMD/SE: botão "Extrair dados do dossiê" (PDF → campos).

Contra o servidor real com o mock do Gemini (real/gemini.js responde pelo NOME do arquivo:
dossie-inventario-*, dossie-cumulativo-*, dossie-doacao-*, *sem-json*).

Uso: EXTRA_ENV="HUB_CODIGO_ADMIN=codigo-emergencia-teste-2026 CORS_ORIGENS=http://127.0.0.1:8088 HUB_IA_LIMITE=200" RESET_DB=1 ./reiniciar-real.sh
     python3 gerar-dossie-itcmd.py && python3 e2e-v1.42.py
"""
import base64, json, os, shutil, sys, time, urllib.request
from playwright.sync_api import sync_playwright

SITE = os.environ.get('SITE', 'http://127.0.0.1:8088/')
API = os.environ.get('API', 'http://127.0.0.1:3999')
CODIGO = os.environ.get('HUB_CODIGO_ADMIN', 'codigo-emergencia-teste-2026')
SENHA = 'Escrituras#2026xy'
AQUI = os.path.dirname(os.path.abspath(__file__))
ARQ = os.path.join(AQUI, 'arquivos')
SHOTS = os.path.join(AQUI, '..', 'docs', 'itcmd-dossie-v1.42'); os.makedirs(SHOTS, exist_ok=True)
ok = 0; falhas = []

def api(caminho, corpo=None, token=None):
    req = urllib.request.Request(API + caminho, method='POST' if corpo is not None else 'GET')
    if corpo is not None:
        req.add_header('Content-Type', 'application/json'); req.data = json.dumps(corpo).encode()
    if token: req.add_header('X-Auth-Token', token)
    try:
        with urllib.request.urlopen(req) as r: return r.status, json.loads(r.read() or b'null')
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b'null')

def passo(nome, fn):
    global ok
    try:
        fn(); ok += 1; print('  ✓', nome)
    except Exception as e:
        import traceback; tb = traceback.extract_tb(e.__traceback__)[-1]
        falhas.append(nome); print('  ✗', nome, '→', repr(e)[:500], '(linha %d)' % tb.lineno)

def esperar(cond, tempo=10.0, msg=''):
    fim = time.time() + tempo
    while time.time() < fim:
        try:
            if cond(): return True
        except Exception: pass
        time.sleep(0.15)
    raise AssertionError('esperando: ' + msg)

def b64(nome):
    with open(os.path.join(ARQ, nome), 'rb') as f: return base64.b64encode(f.read()).decode()

st, r = api('/login', {'login': 'cesar.bravo', 'senha': SENHA})
if st != 200:
    st, r = api('/definir-senha', {'login': 'cesar.bravo', 'codigo': CODIGO, 'senha': SENHA})
    assert st == 200 and r.get('token'), ('não deu para criar a senha do Tabelião', st, r)
TOKEN = r['token']

# ---------------------------------------------------------------- API
def api_forma_fixa():
    st, r = api('/hub/ia/itcmd', {'arquivos': [{'nome': 'dossie-inventario-silva.pdf', 'mime': 'application/pdf', 'base64': b64('dossie-inventario-silva.pdf')}]}, token=TOKEN)
    assert st == 200, (st, r)
    d = r['dados']
    assert d['operacao'] == 'inventario' and len(d['falecidos']) == 1
    f = d['falecidos'][0]
    assert f['nome'] == 'JOSÉ DA SILVA' and f['data_obito'] == '12/04/2019' and f['estado_civil_no_obito'] == 'casado'
    assert f['conjuge']['regime'] == 'parcial' and f['conjuge']['sobrevivente'] is True   # "comunhão parcial de bens" por extenso → código
    assert [x['situacao'] for x in f['filhos']] == ['vivo', 'renunciou', 'falecido'] and [x['nome'] for x in f['filhos'][2]['representantes']] == ['LUCAS DA SILVA', 'JÚLIA DA SILVA']
    assert f['bens'][0]['valor_referencia'] == '180000' and f['bens'][0]['fonte_valor'] == 'IPTU 2026' and f['bens'][1]['fracao_do_falecido'] == '50'
    assert 'valor' not in f['bens'][0], 'o valor declarado NUNCA vem do servidor'
    assert f['inventario_requerido_em'] == '15/09/2026' and len(d['alertas']) == 2
    assert set(d.keys()) == {'operacao', 'advogado', 'requerimento', 'falecidos', 'doacao', 'alertas'}
    assert r['modelo'] and r['ms'] >= 0 and isinstance(r['alertas'], list)
    # entrou na trilha como ferramenta itcmd com o resumo
    time.sleep(1.0)
    st2, tr = api('/hub/admin/auditoria', token=TOKEN)
    assert st2 == 200
    linhas = tr if isinstance(tr, list) else tr.get('linhas') or tr.get('itens') or []
    assert any('itcmd' in json.dumps(l, ensure_ascii=False) and '1 falecido' in json.dumps(l, ensure_ascii=False) for l in linhas), linhas[:3]
passo('API /hub/ia/itcmd: forma fixa, enumerações, regime por extenso, sem valor declarado, trilha', api_forma_fixa)

def api_cerca_e_sem_json():
    st, r = api('/hub/ia/itcmd', {'texto': 'FORCAR_CERCA', 'arquivos': [{'nome': 'dossie-doacao-pereira.pdf', 'mime': 'application/pdf', 'base64': b64('dossie-doacao-pereira.pdf')}]}, token=TOKEN)
    assert st == 200 and r['dados']['operacao'] == 'doacao' and r['dados']['doacao']['reserva_usufruto'] is True and r['dados']['doacao']['bens'][1]['destino'] == 'CARLA PEREIRA', (st, r)
    st, r = api('/hub/ia/itcmd', {'arquivos': [{'nome': 'dossie-sem-json.pdf', 'mime': 'application/pdf', 'base64': b64('dossie-inventario-silva.pdf')}]}, token=TOKEN)
    assert st == 502 and r.get('motivo') == 'json', (st, r)
    st, r = api('/hub/ia/itcmd', {'texto': 'só texto'}, token=TOKEN)
    assert st == 400 and 'anexe' in r['erro'], (st, r)
    st, r = api('/hub/ia/itcmd', {'arquivos': []})
    assert st == 401
passo('API: cerca ```json tolerada; resposta sem JSON → 502 motivo json; sem anexos → 400; sem sessão → 401', api_cerca_e_sem_json)

# ---------------------------------------------------------------- Tela
with sync_playwright() as p:
    nav = p.chromium.launch()
    ctx = nav.new_context(viewport={'width': 1366, 'height': 900}, locale='pt-BR', reduced_motion='reduce')
    pg = ctx.new_page()
    erros = []
    pg.on('pageerror', lambda e: erros.append(str(e)))
    pg.on('console', lambda m: erros.append(m.text) if m.type == 'error' and 'ERR_' not in m.text and 'Failed to load' not in m.text else None)

    def entrar():
        pg.goto(SITE); pg.wait_for_selector('#campoLogin')
        pg.fill('#campoLogin', 'cesar.bravo'); pg.fill('#campoSenha', SENHA); pg.click('#btnEntrar')
        pg.wait_for_selector('#muralRodizio li', timeout=20000); pg.wait_for_timeout(500)
        pg.click('#cardItcmd'); pg.wait_for_selector('#paginaItcmd:not([hidden])'); pg.wait_for_timeout(400)
        assert pg.is_visible('#itcmdImportar') and pg.is_visible('#btExtrairDossie'), 'zona de importação montada dentro do Hub'
        assert 'só o valor declarado' in pg.inner_text('#itcmdImportar').lower()
    passo('login, abrir 08 · Calculadora: bloco "Importar do dossiê" presente', entrar)

    def importar(nome):
        while pg.locator('#itcmdImportar .anexo-x').count(): pg.click('#itcmdImportar .anexo-x >> nth=0'); pg.wait_for_timeout(100)
        pg.set_input_files('#itcmdImportar input[type=file]', os.path.join(ARQ, nome)); pg.wait_for_timeout(400)
        pg.evaluate("document.getElementById('itcmdImportado').classList.add('oculto')")   # some para o teste esperar a NOVA leitura
        pg.click('#btExtrairDossie')
        esperar(lambda: not pg.evaluate("document.getElementById('itcmdImportado').classList.contains('oculto')"), 15, 'painel de importação')
        pg.wait_for_timeout(400)

    def inventario_ok():
        importar('dossie-inventario-silva.pdf')
        S = pg.evaluate('window.ITCMD_UI.estado')
        assert S['modo'] == 'inventario'
        f = S['inv'][0]
        assert f['nome'] == 'JOSÉ DA SILVA' and f['obito'] == '2019-04-12' and f['estadoCivil'] == 'casado' and f['regime'] == 'parcial' and f['conjuge']['nome'] == 'MARIA DA SILVA'
        assert [d['condicao'] for d in f['descendentes']] == ['vivo', 'renuncia', 'premorto'] and len(f['descendentes'][2]['representantes']) == 2
        assert f['filhosComuns'] == 'sim'
        assert [b['valor'] for b in f['bens']] == [0, 0], 'valores ficam para lançar à mão'
        assert f['bens'][0]['valorRef'] == 180000 and f['bens'][0]['natureza'] == 'comum' and f['bens'][1]['natureza'] == 'particular' and f['bens'][1]['fracao'] == 50
        assert '12.345' in f['bens'][0]['descricao']
        assert f['multaAtraso'] is True, 'pedido em 15/09/2026 com óbito em 2019 está fora dos 120 dias: multa fica ligada'
        # marcas na tela: "do dossiê" nos campos importados; "lançar o valor" nos valores; referência como dica
        assert pg.locator('#itcmdRaiz .campo.importado').count() >= 10
        assert pg.locator('#itcmdRaiz .campo.pendente').count() == 2
        assert 'ref. R$ 180.000,00 (IPTU 2026)' in pg.inner_text('[data-path="inv.0.bens.0.valor"] >> xpath=..')
        txt = pg.inner_text('#itcmdImportado')
        assert 'Dados importados do dossiê' in txt and '2 valor(es) a lançar' in txt and 'DRA. HELENA COSTA' in txt and 'Apontamentos do leitor' in txt and 'CARLOS DA SILVA' in txt
        assert 'Sítio Boa Vista' in txt   # aviso de valor sem documento
        # nenhum texto < 14 px no painel e nas marcas
        peq = pg.evaluate("[...document.querySelectorAll('#itcmdImportar *, #itcmdRaiz .campo.importado *')].filter(e => e.offsetParent && [...e.childNodes].some(n => n.nodeType === 3 && n.textContent.trim()) && parseFloat(getComputedStyle(e).fontSize) < 14).map(e => e.className + ':' + getComputedStyle(e).fontSize)")
        assert not peq, peq
        pg.screenshot(path=SHOTS + '/01-inventario-importado.png', full_page=True)
        # resultado calculado com valores zerados não quebra; lança o valor → recalcula e tira o realce
        pg.click('#btLancarValores'); pg.wait_for_timeout(400)
        assert pg.evaluate("document.activeElement.dataset.path") == 'inv.0.bens.0.valor'
        pg.keyboard.type('180000'); pg.wait_for_timeout(400)
        assert pg.locator('#itcmdRaiz .campo.pendente').count() == 1
        pg.keyboard.press('Tab'); pg.wait_for_timeout(500)
        assert pg.evaluate('window.ITCMD_UI.ultimo.inv.pat.monteMor') == 180000
        assert '1 valor(es) a lançar' in pg.inner_text('#itcmdImportado')
        # quem digita por cima tira a marca "do dossiê"
        pg.fill('[data-path="inv.0.nome"]', 'JOSÉ RAIMUNDO DA SILVA'); pg.dispatch_event('[data-path="inv.0.nome"]', 'change'); pg.wait_for_timeout(400)
        assert not pg.evaluate("document.querySelector('[data-path=\"inv.0.nome\"]').closest('.campo').classList.contains('importado')")
        # o rascunho guarda a origem e volta com as marcas
        pg.reload(); pg.wait_for_selector('#paginaItcmd:not([hidden])', timeout=20000); pg.wait_for_timeout(800)
        pg.click('#btRestaurar'); pg.wait_for_timeout(500)
        assert pg.locator('#itcmdRaiz .campo.importado').count() >= 9 and 'Dados importados' in pg.inner_text('#itcmdImportado')
    passo('tela: inventário importado (viúva, regime, renúncia, representação, bens sem valor, multa, marcas, painel, lançar valor, rascunho)', inventario_ok)

    def desfazer():
        pg.click('#btDesfazerImportacao'); pg.wait_for_timeout(500)
        assert pg.evaluate("document.getElementById('itcmdImportado').classList.contains('oculto')")
        # depois de recarregar a página o "antes" não existe mais: Desfazer limpa o formulário
        assert pg.evaluate("window.ITCMD_UI.estado.inv[0].nome") == '' and pg.evaluate("window.ITCMD_UI.estado.origem") is None
        assert pg.locator('#itcmdRaiz .campo.importado').count() == 0
    passo('Desfazer importação devolve o estado anterior e apaga as marcas', desfazer)

    def cumulativo():
        importar('dossie-cumulativo-silva.pdf')
        S = pg.evaluate('window.ITCMD_UI.estado')
        assert S['modo'] == 'cumulativo', (S['modo'], pg.inner_text('#itcmdImportado')[:300])
        assert S['inv'][0]['nome'] == 'JOSÉ DA SILVA' and S['inv'][1]['nome'] == 'MARIA DA SILVA'
        assert S['inv'][1]['estadoCivil'] == 'solteiro' and S['inv'][1]['obito'] == '2026-02-03'
        assert S['inv'][1]['bens'][0]['tipo'] == 'dinheiro' and S['inv'][1]['bens'][0]['valorRef'] == 18500
        assert pg.evaluate("window.ITCMD_UI.ultimo.modo") == 'cumulativo'
        txt = pg.inner_text('#itcmdImportado')
        assert '1º falecido: JOSÉ DA SILVA' in txt and '2º falecido: MARIA DA SILVA' in txt and 'sem viúvo(a)' in txt and '3 valor(es) a lançar' in txt
        pg.screenshot(path=SHOTS + '/02-cumulativo-importado.png', full_page=True)
    passo('tela: cumulativo importado (dois falecidos em ordem, 2º sem viúvo, bem próprio)', cumulativo)

    def doacao():
        importar('dossie-doacao-pereira.pdf')
        S = pg.evaluate('window.ITCMD_UI.estado')
        assert S['modo'] == 'doacao' and [x['nome'] for x in S['doa']['doadores']] == ['ANTÔNIO PEREIRA', 'RITA PEREIRA'] and [x['nome'] for x in S['doa']['donatarios']] == ['BRUNO PEREIRA', 'CARLA PEREIRA']
        assert S['doa']['reservaUsufruto'] is True and S['doa']['bens'][0]['destino'] == 'todos' and S['doa']['bens'][1]['destino'] == S['doa']['donatarios'][1]['uid']
        assert [b['valor'] for b in S['doa']['bens']] == [0, 0]
        assert pg.evaluate("window.ITCMD_UI.ultimo.d.total") == 0, pg.evaluate("window.ITCMD_UI.ultimo.d.total")
        assert pg.locator('#itcmdRaiz .campo.pendente').count() == 2, pg.evaluate("[...document.querySelectorAll('#formDoacao .campo')].map(c => c.className).join(' | ')")
        pg.screenshot(path=SHOTS + '/03-doacao-importada.png', full_page=True)
    passo('tela: doação importada (doadores, donatários, destino por nome, usufruto, valores a lançar)', doacao)

    def cenarios_auditoria():
        # os arquivos são cópias do dossiê: o mock decide pelo NOME (real/gemini.js)
        for n in ['dossie-viuva-em-filhos.pdf', 'dossie-separado.pdf', 'dossie-casada-feminino.pdf', 'dossie-filiacao-nula.pdf', 'dossie-cumulativo-repetido.pdf', 'dossie-cumulativo-invertido.pdf']:
            shutil.copy(os.path.join(ARQ, 'dossie-inventario-silva.pdf'), os.path.join(ARQ, n))
        # G2 — viúva repetida na lista de filhos sai da lista, com aviso
        importar('dossie-viuva-em-filhos.pdf'); S = pg.evaluate('window.ITCMD_UI.estado')
        assert [d['nome'] for d in S['inv'][0]['descendentes']] == ['ANA DA SILVA', 'CARLOS DA SILVA', 'PEDRO DA SILVA'] and 'cônjuge sobrevivente e veio também como filho' in pg.inner_text('#itcmdImportado')
        # M1 + G3 — "separado" mantém meação sem herdar; Súmula 377 marcada; regime separação obrigatória (não aquestos)
        importar('dossie-separado.pdf'); S = pg.evaluate('window.ITCMD_UI.estado'); f = S['inv'][0]
        assert f['estadoCivil'] == 'casado' and f['conjuge']['separadoFato'] is True and f['regime'] == 'separacao_obrig' and f['conjuge']['sumula377'] is True
        txt = pg.inner_text('#itcmdImportado'); assert 'separado(a)' in txt and 'Súmula 377' in txt
        assert pg.locator('#itcmdRaiz label.marcar.importado').count() >= 2 and pg.locator('#itcmdRaiz .opcoes.importado').count() >= 1, 'marcas nas caixas e nos botões de opção'
        # M2 — feminino/acentos nas enumerações
        importar('dossie-casada-feminino.pdf'); S = pg.evaluate('window.ITCMD_UI.estado'); f = S['inv'][0]
        assert f['estadoCivil'] == 'casado' and f['descendentes'][2]['condicao'] == 'premorto'
        # M3 — filiação comum desconhecida: aviso e sem marca em filhosComuns
        importar('dossie-filiacao-nula.pdf'); S = pg.evaluate('window.ITCMD_UI.estado')
        assert S['inv'][0]['filhosComuns'] == 'sim' and 'reserva de 1/4' in pg.inner_text('#itcmdImportado') and 'inv.0.filhosComuns' not in S['origem']['paths']
        # G1 — bem repetido nos dois falecidos sai do 2º, com aviso
        importar('dossie-cumulativo-repetido.pdf'); S = pg.evaluate('window.ITCMD_UI.estado')
        assert len(S['inv'][1]['bens']) == 1 and S['inv'][1]['bens'][0]['tipo'] == 'dinheiro' and 'constava nos dois falecidos' in pg.inner_text('#itcmdImportado')
        # M10 — ordem invertida é corrigida
        importar('dossie-cumulativo-invertido.pdf'); S = pg.evaluate('window.ITCMD_UI.estado')
        assert S['inv'][0]['nome'] == 'JOSÉ DA SILVA' and S['inv'][1]['nome'] == 'MARIA DA SILVA' and 'fora da ordem cronológica' in pg.inner_text('#itcmdImportado')
        # M4 — clicar numa opção por cima apaga a origem
        pg.click('#itcmdRaiz [data-opcao="inv.0.estadoCivil"][data-valor="uniao"]'); pg.wait_for_timeout(400)
        assert 'inv.0.estadoCivil' not in pg.evaluate('window.ITCMD_UI.estado.origem.paths')
        # M7 — trocar de modo depois de importar: painel explica e oferece voltar
        pg.click('#segModo button[data-modo=doacao]'); pg.wait_for_timeout(400)
        assert 'volte a esse modo' in pg.inner_text('#itcmdImportado') and pg.locator('#btLancarValores').count() == 0
        pg.click('#btVoltarModoImportado'); pg.wait_for_timeout(400)
        assert pg.evaluate('window.ITCMD_UI.estado.modo') == 'cumulativo' and pg.locator('#btLancarValores').count() == 1
        # M5 — depois da importação o título do painel não fica sob a barra viva
        importar('dossie-inventario-silva.pdf'); pg.wait_for_timeout(600)
        topo = pg.evaluate("document.querySelector('#itcmdImportado h3').getBoundingClientRect().top"); barra = pg.evaluate("document.getElementById('barraViva').getBoundingClientRect().bottom")
        assert topo >= barra, (topo, barra)
        # M6 — o botão de anexar tem borda
        assert pg.evaluate("getComputedStyle(document.querySelector('#itcmdImportar .btn-fantasma')).borderTopWidth") != '0px'
    passo('cenários da auditoria: viúva em filhos, separado + Súmula 377, feminino, filiação nula, bem repetido, ordem invertida, marcas em opções, troca de modo, barra viva, botão', cenarios_auditoria)

    def erro_sem_json():
        pg.set_input_files('#itcmdImportar input[type=file]', os.path.join(ARQ, 'dossie-inventario-silva.pdf'))
        pg.evaluate("(() => { const li = document.querySelector('#itcmdImportar .anexo-lista li .anexo-nome'); })()")
        # renomeia o item pela lista: o mock decide pelo nome → usa um arquivo copiado com "sem-json"
        alvo = os.path.join(ARQ, 'dossie-sem-json.pdf'); shutil.copy(os.path.join(ARQ, 'dossie-inventario-silva.pdf'), alvo)
        antes = pg.evaluate('JSON.stringify(window.ITCMD_UI.estado)')
        # limpa a lista e anexa só o "sem-json"
        while pg.locator('#itcmdImportar .anexo-x').count(): pg.click('#itcmdImportar .anexo-x >> nth=0'); pg.wait_for_timeout(100)
        pg.set_input_files('#itcmdImportar input[type=file]', alvo); pg.wait_for_timeout(300)
        pg.click('#btExtrairDossie')
        esperar(lambda: 'não devolveu dados estruturados' in pg.inner_text('#itcmdImportarStatus'), 15, 'mensagem de erro')
        assert pg.evaluate('JSON.stringify(window.ITCMD_UI.estado)') == antes, 'os campos não mudam quando a leitura falha'
        assert pg.inner_text('#btExtrairDossie').strip() == 'Extrair dados do dossiê'
    passo('leitura sem JSON: mensagem clara, campos intactos, botão volta', erro_sem_json)

    def sem_anexo_e_mobile():
        while pg.locator('#itcmdImportar .anexo-x').count(): pg.click('#itcmdImportar .anexo-x >> nth=0'); pg.wait_for_timeout(100)
        pg.click('#btExtrairDossie'); pg.wait_for_timeout(300)
        assert pg.evaluate("document.getElementById('itcmdImportarStatus').innerHTML") == ''
        pg.set_viewport_size({'width': 400, 'height': 860}); pg.wait_for_timeout(300)
        assert pg.evaluate('document.documentElement.scrollWidth') <= 400
        pg.screenshot(path=SHOTS + '/04-importar-400px.png')
        pg.set_viewport_size({'width': 1366, 'height': 900})
        pg.evaluate("document.documentElement.setAttribute('data-theme','dark')"); pg.wait_for_timeout(200)
        cor = pg.evaluate("getComputedStyle(document.querySelector('#itcmdImportado h3, #itcmdImportar h2')).color")
        assert cor != 'rgb(99, 19, 37)', cor
        pg.evaluate("document.documentElement.setAttribute('data-theme','light')")
    passo('sem anexo só avisa; 400 px sem rolagem horizontal; tema escuro', sem_anexo_e_mobile)

    def artefato_sem_hub():
        pg2 = ctx.new_page()
        pg2.goto('file://' + os.path.abspath(os.path.join(AQUI, '..', '..', 'w', 'itcmd', 'piloto.html'))); pg2.wait_for_timeout(800)
        assert 'funciona dentro do Hub' in pg2.inner_text('#itcmdImportarMiolo') and pg2.locator('#btExtrairDossie').count() == 0
        pg2.close()
    passo('piloto fora do Hub: sem zona de anexos, nota explicativa', artefato_sem_hub)

    nav.close()

print('\n%d ok, %d falha(s); erros de console relevantes: %d' % (ok, len(falhas), len(erros)))
for e in erros[:5]: print('   console:', e[:200])
sys.exit(1 if falhas or erros else 0)
