/**
 * LeitorAcervo — Hub CN2O ← Acervo de Livros e Atos (Google Sheets) — v2 (Hub v1.33)
 * Cartório de Notas do 2º Ofício de Itabaiana/SE
 *
 * O QUE FAZ
 *   Entrega ao backend do Hub (Railway) o conteúdo das DUAS PLANILHAS do acervo — cópias
 *   do modelo "PAINEL DO ACERVO DE LIVROS", na conta tnitabaiana@gmail.com:
 *
 *     fonte "antigo1" → PLANILHA_1_ID → "Acervo 1º Ofício (Antigo ) - SÉRGIO"
 *                       (acervo antigo do 1º Ofício, incorporado ao acervo do CN2O)
 *     fonte "cn2o"    → PLANILHA_2_ID → "Acervo 2º Ofício (Antigo e Atual) - MILVO"
 *
 *   De cada planilha saem DUAS ABAS — e só elas:
 *     CADASTRO_LIVROS — os livros físicos: tipo, número, código, status, onde estão
 *                       guardados (sala/estante/prateleira/caixa), se estão digitalizados,
 *                       o link da pasta digital, pendências e observações.
 *     INDICE_ATOS     — os atos lavrados: livro, folhas, data, nº do ato, partes, CPF,
 *                       objeto, matrícula, valor, tributo, link do arquivo e observações.
 *   PAINEL, BUSCA, MOVIMENTACOES, MAPA_FISICO, LISTAS, CHECKLIST e AJUDA são ignoradas.
 *
 *   As abas são achadas pelo NOME; se a planilha tiver nomes diferentes, o script procura
 *   pelo CABEÇALHO: a aba cuja primeira linha tem "Nº DO LIVRO" e "TIPO DE LIVRO" é a dos
 *   livros; a que tem "PARTE 1" (ou "Nº DO ATO") é a dos atos.
 *
 *   Responde:
 *     { ok: true, fonte: "cn2o", planilha: "Acervo 2º Ofício (Antigo e Atual) - MILVO",
 *       atualizado_em: "2026-09-16T12:00:00.000Z",
 *       livros: { aba: "CADASTRO_LIVROS", colunas: [...], linhas: [[...]] },
 *       atos:   { aba: "INDICE_ATOS",     colunas: [...], linhas: [[...]] } }
 *
 *   A PRIMEIRA LINHA de cada aba é o cabeçalho e vai em `colunas`; as demais, em `linhas`.
 *   Linhas totalmente vazias são descartadas (a INDICE_ATOS, hoje só com o cabeçalho,
 *   responde `linhas: []` — o Hub mostra "nenhum ato indexado ainda"). O Hub descobre
 *   sozinho o papel de cada coluna pelo nome e guarda as que não conhece (CHAVE DE BUSCA,
 *   ALERTA, MATCH_BUSCA e qualquer coluna nova) para mostrar no "mais…". Dá para
 *   acrescentar colunas às planilhas sem mexer em nada aqui.
 *
 *   Datas saem como dd/mm/aaaa no fuso da planilha (nada de ISO com fuso trocado) e
 *   números formatados saem como aparecem na célula (R$ 250.000,00).
 *
 * =====================================================================================
 * IMPLANTAÇÃO — PASSO A PASSO (uma vez, na conta tnitabaiana@gmail.com)
 * =====================================================================================
 *  1. Abra script.google.com (logado como tnitabaiana@gmail.com) → "Novo projeto".
 *  2. Renomeie o projeto (canto superior esquerdo) para: LeitorAcervo — Hub CN2O
 *  3. Apague o conteúdo do arquivo Code.gs, cole ESTE arquivo inteiro e salve (Ctrl+S).
 *  4. Engrenagem "Configurações do projeto" (menu da esquerda) → role até "Propriedades
 *     do script" → "Adicionar propriedade do script" e crie TRÊS:
 *         HUB_ACERVO_SECRET  →  uma senha longa, inventada por você (ex.: 40 caracteres).
 *                               Guarde: ela vai igualzinha no Railway, no passo 8.
 *         PLANILHA_1_ID      →  1GZtzzB2FqfnQKR18gUJ2ZKfBalhPk8riC9PZNpRVpR8
 *         PLANILHA_2_ID      →  1ZM3sEt1cCqkfvZgLQfJf0q-Zx-AVUuwRMdMvEI5OErQ
 *     (Opcionais, só se as abas tiverem outro nome: ABA_LIVROS e ABA_ATOS.)
 *     Clique em "Salvar propriedades do script".
 *  5. Volte ao editor (ícone "<>"). Na barra de cima, no seletor de função, escolha
 *     testarLeitura e clique em "Executar".
 *  6. O Google vai pedir autorização: "Revisar permissões" → escolha a conta
 *     tnitabaiana@gmail.com → a tela avisa que o app não é verificado: clique em
 *     "Avançado" → "Acessar LeitorAcervo — Hub CN2O (não seguro)" → "Permitir".
 *     (É o seu próprio script lendo as suas próprias planilhas.)
 *  7. Veja o registro de execução (Ctrl+Enter). Deve aparecer, para cada planilha, o nome
 *     do arquivo, as abas encontradas, as colunas e quantas linhas foram lidas. Se disser
 *     "aba não encontrada", confira os nomes CADASTRO_LIVROS e INDICE_ATOS.
 *  8. "Implantar" (botão azul, canto superior direito) → "Nova implantação" →
 *     na engrenagem "Selecionar tipo", escolha "Aplicativo da Web" →
 *        Descrição: v1
 *        Executar como: Eu (tnitabaiana@gmail.com)
 *        Quem pode acessar: Qualquer pessoa
 *     → "Implantar" → copie a "URL do app da Web" (termina em /exec).
 *  9. Railway → projeto do Hub → serviço cn2o-hub-backend → aba "Variables" →
 *     "New Variable", duas vezes:
 *        HUB_ACERVO_WEBAPP_URL  →  a URL /exec do passo 8
 *        HUB_ACERVO_SECRET      →  a MESMA senha do passo 4
 *     (Opcional: HUB_ACERVO_CACHE_MIN = 10 — minutos de cache no servidor.)
 *     O Railway refaz o deploy sozinho; se não refizer, clique em "Deploy".
 * 10. No Hub, abra o quadro "10 · Pesquisa / Acervo": as duas abas do alto devem dizer
 *     "Índice vinculado", com a contagem de livros e de atos de cada planilha.
 *
 * SE PRECISAR MUDAR O CÓDIGO DEPOIS: cole a versão nova, salve e vá em
 * "Implantar" → "Gerenciar implantações" → lápis (editar) → Versão: "Nova versão" →
 * "Implantar". A URL continua a mesma (não mexa no Railway).
 * SE MUDAR SÓ A PLANILHA OU A ABA: troque a propriedade do passo 4 — não precisa
 * reimplantar nada.
 * =====================================================================================
 *
 * CONFERÊNCIA RÁPIDA
 *   Abra a URL /exec no navegador: deve responder { ok: true, servico: … } e NADA das
 *   planilhas — dado só sai com o segredo, e o segredo só viaja no corpo do POST.
 *
 * SEGURANÇA
 *   O web app é público por necessidade (o Railway não tem conta Google), mas só devolve
 *   as planilhas quando o pedido traz o segredo, que vai no CORPO do POST — nunca na URL,
 *   nunca em log, nunca nas respostas. O script só LÊ as duas planilhas configuradas; não
 *   escreve, não apaga e não toca em nenhum outro arquivo do Drive.
 */

var VERSAO = 'LeitorAcervo 2.0 — Hub CN2O v1.33';
var MAX_LINHAS = 20000;     // teto de linhas por aba (planilha grande não estoura a resposta)
var MAX_CELULA = 500;       // teto de caracteres por célula

// fonte → propriedade com o id da planilha
var FONTES = {
  antigo1: 'PLANILHA_1_ID',
  cn2o: 'PLANILHA_2_ID'
};
var FONTE_PADRAO = 'cn2o';

// Como achar cada aba: pelo nome e, se não houver, pelo cabeçalho.
var ABAS = {
  livros: {
    nomes: ['CADASTRO_LIVROS', 'CADASTRO LIVROS', 'LIVROS'],
    propriedade: 'ABA_LIVROS',
    exige: [['n do livro', 'no do livro', 'numero do livro'], ['tipo de livro']]
  },
  atos: {
    nomes: ['INDICE_ATOS', 'INDICE ATOS', 'ÍNDICE_ATOS', 'ATOS'],
    propriedade: 'ABA_ATOS',
    exige: [['parte 1 outorgante', 'parte 1', 'n do ato', 'no do ato', 'numero do ato']]
  }
};

function doGet() {
  return saida({ ok: true, servico: VERSAO });
}

function doPost(e) {
  var pedido;
  try {
    pedido = JSON.parse((e && e.postData && e.postData.contents) || '{}');
  } catch (err) {
    return saida({ ok: false, erro: 'corpo inválido (esperava JSON)' });
  }
  var props = PropertiesService.getScriptProperties();
  var segredo = props.getProperty('HUB_ACERVO_SECRET') || '';
  if (!segredo) return saida({ ok: false, erro: 'HUB_ACERVO_SECRET não configurado nas propriedades do script' });
  if (String(pedido.segredo || '') !== segredo) return saida({ ok: false, erro: 'segredo inválido' });

  try {
    // versao 1 (contrato antigo, planilha única) continua respondida: uma aba só,
    // em { colunas, linhas }. Serve aos testes e a qualquer versão antiga do backend.
    if (Number(pedido.versao) === 1) return saida(lerUmaAbaSo(props));
    return saida(lerFonte(props, escolherFonte(pedido.fonte)));
  } catch (err) {
    // A mensagem do erro do Apps Script pode citar a planilha, nunca o segredo.
    return saida({ ok: false, erro: String((err && err.message) || err).slice(0, 300) });
  }
}

function escolherFonte(v) {
  var k = String(v == null ? '' : v).trim().toLowerCase();
  return FONTES[k] ? k : FONTE_PADRAO;
}

// ------------------------------------------------------------------ leitura
function lerFonte(props, fonte) {
  var id = (props.getProperty(FONTES[fonte]) || '').trim();
  if (!id) throw new Error(FONTES[fonte] + ' não configurado nas propriedades do script');
  var planilha = SpreadsheetApp.openById(id);
  var livros = lerAba(props, planilha, 'livros');
  var atos = lerAba(props, planilha, 'atos');
  return {
    ok: true,
    fonte: fonte,
    planilha: planilha.getName(),
    atualizado_em: new Date().toISOString(),   // instante da LEITURA (é o que o Hub mostra)
    livros: livros,
    atos: atos
  };
}

// Contrato antigo: uma planilha, uma aba (a de atos, ou a primeira que houver).
function lerUmaAbaSo(props) {
  var id = (props.getProperty('PLANILHA_ID') || props.getProperty(FONTES[FONTE_PADRAO]) || '').trim();
  if (!id) throw new Error('PLANILHA_ID não configurado nas propriedades do script');
  var planilha = SpreadsheetApp.openById(id);
  var r = lerAba(props, planilha, 'atos');
  if (!r.colunas.length) r = conteudoDaAba(planilha.getSheets()[0]);
  return { ok: true, aba: r.aba, colunas: r.colunas, linhas: r.linhas,
    planilha: planilha.getName(), atualizado_em: new Date().toISOString() };
}

function lerAba(props, planilha, qual) {
  var cfg = ABAS[qual];
  var nome = (props.getProperty(cfg.propriedade) || '').trim();
  var aba = nome ? planilha.getSheetByName(nome) : null;
  if (!aba) {
    for (var i = 0; i < cfg.nomes.length && !aba; i++) aba = planilha.getSheetByName(cfg.nomes[i]);
  }
  if (!aba) aba = abaPeloCabecalho(planilha, cfg.exige);
  if (!aba) return { aba: '', colunas: [], linhas: [] };
  return conteudoDaAba(aba);
}

// Procura a aba cuja PRIMEIRA LINHA tem as colunas exigidas (uma de cada grupo).
function abaPeloCabecalho(planilha, exige) {
  var abas = planilha.getSheets();
  for (var i = 0; i < abas.length; i++) {
    var ultima = abas[i].getLastColumn();
    if (!ultima) continue;
    var cab = abas[i].getRange(1, 1, 1, ultima).getDisplayValues()[0].map(chave);
    var ok = true;
    for (var g = 0; g < exige.length && ok; g++) {
      var achou = false;
      for (var k = 0; k < exige[g].length && !achou; k++) if (cab.indexOf(exige[g][k]) !== -1) achou = true;
      ok = achou;
    }
    if (ok) return abas[i];
  }
  return null;
}

function conteudoDaAba(aba) {
  var faixa = aba.getDataRange();
  var valores = faixa.getValues();                 // valores de verdade (datas viram Date)
  if (!valores.length) return { aba: aba.getName(), colunas: [], linhas: [] };
  var exibidos = null;
  try { exibidos = faixa.getDisplayValues(); } catch (err) { exibidos = null; }   // só para números/moeda
  var fuso = aba.getParent().getSpreadsheetTimeZone() || Session.getScriptTimeZone() || 'America/Maceio';

  var texto = [];
  for (var i = 0; i < valores.length; i++) {
    var linha = [];
    for (var j = 0; j < valores[i].length; j++) {
      linha.push(celula(valores[i][j], exibidos && exibidos[i] ? exibidos[i][j] : '', fuso));
    }
    texto.push(linha);
  }
  aplicarLinks(faixa, texto);                      // texto clicável / =HYPERLINK → a URL

  var colunas = (texto[0] || []).map(function (c) { return recortar(c, 120); });
  var linhas = [];
  for (var k = 1; k < texto.length && linhas.length < MAX_LINHAS; k++) {
    var l = texto[k].map(function (c) { return recortar(c, MAX_CELULA); });
    if (l.join('').trim() === '') continue;        // linha em branco no meio ou no fim
    linhas.push(l);
  }
  return { aba: aba.getName(), colunas: colunas, linhas: linhas };
}

// Um valor de célula vira texto: data no fuso da planilha (dd/mm/aaaa), número/moeda como
// aparece na célula (R$ 250.000,00), caixa de seleção como Sim/Não, o resto como está.
function celula(valor, exibido, fuso) {
  if (valor === null || valor === undefined || valor === '') return '';
  if (Object.prototype.toString.call(valor) === '[object Date]') {
    return Utilities.formatDate(valor, fuso, 'dd/MM/yyyy');
  }
  if (typeof valor === 'boolean') return valor ? 'Sim' : 'Não';
  if (typeof valor === 'number') return String(exibido || valor);
  return String(valor);
}

// Onde a célula é um link clicável (ou um =HYPERLINK) e o texto visível não é a própria
// URL, devolve a URL: é dela que o Hub monta os botões "Pasta digital" e "Abrir no Drive".
// Tudo em blocos (uma chamada para a faixa inteira) e dentro de try — se a API não
// cooperar, ficam os textos visíveis e a pesquisa continua funcionando, só sem o botão.
function aplicarLinks(faixa, texto) {
  var ricos = null, formulas = null;
  try { ricos = faixa.getRichTextValues(); } catch (err) { ricos = null; }
  try { formulas = faixa.getFormulas(); } catch (err) { formulas = null; }
  for (var i = 0; i < texto.length; i++) {
    for (var j = 0; j < (texto[i] || []).length; j++) {
      var visivel = String(texto[i][j] == null ? '' : texto[i][j]);
      if (/^https?:\/\//i.test(visivel.replace(/^\s+/, ''))) continue;
      var url = '';
      if (ricos && ricos[i] && ricos[i][j]) {
        try { url = ricos[i][j].getLinkUrl() || ''; } catch (err) { url = ''; }
        if (!url) {
          try {
            var corridas = ricos[i][j].getRuns() || [];
            for (var k = 0; k < corridas.length && !url; k++) url = corridas[k].getLinkUrl() || '';
          } catch (err2) { url = ''; }
        }
      }
      if (!url && formulas && formulas[i] && formulas[i][j]) {
        var m = /=\s*HYPERLINK\s*\(\s*"([^"]+)"/i.exec(String(formulas[i][j]));
        if (m) url = m[1];
      }
      if (url && /^https?:\/\//i.test(url)) texto[i][j] = url;
    }
  }
}

// ------------------------------------------------------------------ auxiliares
function recortar(v, max) {
  return String(v == null ? '' : v).replace(/[\r\n\t]+/g, ' ').replace(/\s{2,}/g, ' ').trim().slice(0, max);
}
// "Nº DO LIVRO" → "n do livro" (sem acento, sem caixa, sem pontuação)
function chave(v) {
  return String(v == null ? '' : v)
    .normalize('NFD').replace(/[̀-ͯ]/g, '')
    .toLowerCase().replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim();
}
function saida(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

// ------------------------------------------------------------------ conferência
// Rode esta função no editor (Executar) para ver se as duas planilhas estão sendo lidas.
// Não expõe o segredo; imprime só nomes de arquivo, abas, colunas e contagens.
function testarLeitura() {
  var props = PropertiesService.getScriptProperties();
  Logger.log('segredo configurado: %s', props.getProperty('HUB_ACERVO_SECRET') ? 'sim' : 'NÃO');
  Object.keys(FONTES).forEach(function (fonte) {
    Logger.log('--------------------------------------------------');
    var id = (props.getProperty(FONTES[fonte]) || '').trim();
    if (!id) { Logger.log('%s (%s): NÃO configurado', fonte, FONTES[fonte]); return; }
    try {
      var r = lerFonte(props, fonte);
      Logger.log('%s → %s', fonte, r.planilha);
      Logger.log('  livros: aba "%s" · %s colunas · %s linhas', r.livros.aba, r.livros.colunas.length, r.livros.linhas.length);
      Logger.log('  colunas de livros: %s', r.livros.colunas.join(' | '));
      Logger.log('  atos:   aba "%s" · %s colunas · %s linhas', r.atos.aba, r.atos.colunas.length, r.atos.linhas.length);
      Logger.log('  colunas de atos:   %s', r.atos.colunas.join(' | '));
      if (r.livros.linhas.length) Logger.log('  1º livro: %s', r.livros.linhas[0].join(' | '));
      if (r.atos.linhas.length) Logger.log('  1º ato:   %s', r.atos.linhas[0].join(' | '));
    } catch (err) {
      Logger.log('%s → ERRO: %s', fonte, err.message);
    }
  });
}
