#!/bin/bash
# Sobe o server.js REAL (com hub.js) + o site de teste + o fake do Apps Script (Google
# Docs, v1.29) + o fake da planilha do acervo (v1.33). Mocks: gemini.js, ocr.js,
# trello.js, whats.js (em real/).
# RESET_DB=1 recria o banco "cn2o" do zero.
# A ponte do Google Docs fica LIGADA por padrão, apontando para o fake da porta 3997
# (docs-falso.js); EXTRA_ENV pode sobrepor qualquer variável (vem depois, e no `env`
# a última atribuição vence) — ex.: EXTRA_ENV="HUB_DOCS_WEBAPP_URL=" desliga a ponte.
#
# v1.33 — ACERVO: o fake das planilhas (acervo-falso.js, porta 3996) sobe sempre e a ponte
# do Acervo já vai LIGADA, apontando para ele — as duas fontes (antigo1 e cn2o) respondem
# como as planilhas do Tabelião. HUB_ACERVO_CACHE_MIN=0 desliga o cache de 10 min: cada
# pesquisa relê o fake, que é o que os testes esperam.
# Para ver a tela no estado "índice ainda não vinculado":
#   EXTRA_ENV="HUB_ACERVO_WEBAPP_URL=" ./reiniciar-real.sh
cd /home/claude/hub-definitivo/teste
ps -eo pid,args | awk '/node (server|site-teste|servidor-teste|docs-falso|acervo-falso)\.js/ && !/awk/ {print $1}' | xargs -r kill 2>/dev/null
for i in 1 2 3 4 5 6 7 8 9 10; do
  (ss -ltn 2>/dev/null | grep -qE ':(3999|8088|3997|3996) ') || break; sleep 0.3
done
if [ "$RESET_DB" = "1" ]; then
  psql -h 127.0.0.1 -p 54329 -U postgres -q -c "DROP DATABASE IF EXISTS cn2o WITH (FORCE);" -c "CREATE DATABASE cn2o;"
fi
rm -f /tmp/gemini-chamadas.json /tmp/trello-chamadas.json /tmp/whats-chamadas.json /tmp/docs-chamadas.json /tmp/acervo-chamadas.json
(cd real && exec env PORT=3999 DATABASE_URL=postgres://postgres@127.0.0.1:54329/cn2o GEMINI_API_KEY=${GEMINI_API_KEY-chave-de-teste} HUB_IA_ESPERA_MS=25 HUB_MODELO_MINUTAS=gemini-inexistente-teste GCP_VISION_KEY=AIza-chave-de-teste DOCAI_PROCESSOR=projects/teste/locations/us/processors/teste GCP_SA_JSON=e30= WHATS_TEMPLATE_RECIBO=recibo_protocolo_3 PROTOCOLO_INICIAL=1400 BOARD_00=quadro00 LISTA_ENTRADA=lista-entrada HUB_DOCS_WEBAPP_URL=http://127.0.0.1:3997/exec HUB_DOCS_SECRET=segredo-teste HUB_ACERVO_WEBAPP_URL=http://127.0.0.1:3996/exec HUB_ACERVO_SECRET=segredo-acervo HUB_ACERVO_CACHE_MIN=0 ${EXTRA_ENV} node server.js > /tmp/real.log 2>&1) &
(exec node site-teste.js > /tmp/site-teste.log 2>&1) &
(exec node docs-falso.js > /tmp/docs-falso.log 2>&1) &
(exec node acervo-falso.js > /tmp/acervo-falso.log 2>&1) &
sleep 2
cat /tmp/real.log /tmp/site-teste.log /tmp/docs-falso.log /tmp/acervo-falso.log
