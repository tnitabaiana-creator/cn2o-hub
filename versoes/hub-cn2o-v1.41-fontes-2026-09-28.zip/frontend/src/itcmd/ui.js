/* ============ Interface — Calculadora ITCMD/SE (Hub CN2O) ============ */
(function () {
  'use strict';
  const M = window.ITCMD;
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fmt = v => 'R$ ' + (Math.round((+v || 0) * 100) / 100).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const fmtN = (v, c = 2) => (+v || 0).toLocaleString('pt-BR', { minimumFractionDigits: c, maximumFractionDigits: c });
  const pct = v => (v * 100).toLocaleString('pt-BR', { maximumFractionDigits: 2 }) + '%';
  const parseMoeda = s => { if (typeof s === 'number') return s; s = String(s || '').trim(); if (!s) return 0; if (/,\d{1,2}$/.test(s) || (s.includes(',') && !s.includes('.'))) s = s.replace(/\./g, '').replace(',', '.'); else if (/^\d{1,3}(\.\d{3})+$/.test(s)) s = s.replace(/\./g, ''); const n = parseFloat(s.replace(/[^\d.-]/g, '')); return isNaN(n) ? 0 : n; };
  const hojeISO = () => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
  const dataBR = iso => iso && /^\d{4}-\d{2}-\d{2}$/.test(iso) ? iso.split('-').reverse().join('/') : '—';
  const TIPOS = [['imovel_urbano', 'Imóvel urbano'], ['imovel_rural', 'Imóvel rural'], ['veiculo', 'Veículo'], ['quotas', 'Quotas de sociedade'], ['dinheiro', 'Dinheiro / aplicações'], ['outros', 'Outros bens móveis']];
  const REGIMES = [['parcial', 'Comunhão parcial de bens'], ['universal', 'Comunhão universal de bens'], ['separacao_conv', 'Separação convencional de bens'], ['separacao_obrig', 'Separação obrigatória (legal) de bens'], ['aquestos', 'Participação final nos aquestos']];

  /* ---------- Estado ---------- */
  const uid = () => 'u' + Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-3);
  const pessoa = (o = {}) => ({ uid: uid(), ...o });
  const novoFalecido = (n = '', estadoCivil = 'casado') => ({ nome: n, obito: '', estadoCivil, regime: 'parcial', conjuge: { nome: '', separadoFato: false, sumula377: false }, filhosComuns: 'sim',
    descendentes: [pessoa({ nome: '', condicao: 'vivo', representantes: [] })], ascendentes: { paiVivo: false, pai: '', maeViva: false, mae: '', avosPaternos: 0, avosMaternos: 0 },
    colaterais: [], bens: [{ descricao: '', tipo: 'imovel_urbano', valor: 0, natureza: 'comum', fracao: 100 }], dividas: 0, multaAtraso: true, aliquotaManual: '', isencaoUnicoImovel: false, isentosVI: {} });
  const novaDoacao = () => ({ doadores: [{ nome: '' }], data: hojeISO(), reservaUsufruto: false, baseNuaPropriedade: '100', usufrutoAcessorio: true, donatarios: [pessoa({ nome: '', doacoesAnteriores: 0, impostoAnterior: 0 })], bens: [{ descricao: '', tipo: 'imovel_urbano', valor: 0, fracao: 100, destino: 'todos' }], aliquotaManual: '' });
  let S = estadoInicial();
  function estadoInicial() {
    const u = M.ufpVigente(hojeISO());
    return { modo: 'inventario', ufp: u.valor, ufpManual: false, hoje: hojeISO(), inv: [novoFalecido(), novoFalecido('', 'solteiro')], doa: novaDoacao(), emol: { inv2Acessorio: false }, orc: { honorarios: '', certidoes: '', registro: '', outros: '' } };
  }
  function exemplo() {
    const s = estadoInicial();
    s.modo = 'cumulativo';
    s.inv[0] = { ...novoFalecido('José da Silva'), obito: '2019-04-12', estadoCivil: 'casado', regime: 'parcial', conjuge: { nome: 'Maria da Silva', separadoFato: false, sumula377: false }, filhosComuns: 'sim',
      descendentes: [pessoa({ nome: 'Ana da Silva', condicao: 'vivo', representantes: [] }), pessoa({ nome: 'Carlos da Silva', condicao: 'vivo', representantes: [] }), pessoa({ nome: 'Pedro da Silva', condicao: 'premorto', representantes: [pessoa({ nome: 'Lucas da Silva (neto)' }), pessoa({ nome: 'Júlia da Silva (neta)' })] })],
      bens: [{ descricao: 'Casa na Rua Quintino Bocaiúva, 120 — matrícula 12.345', tipo: 'imovel_urbano', valor: 380000, natureza: 'comum', fracao: 100 }, { descricao: 'Sítio Boa Vista, 12 ha — matrícula 9.876', tipo: 'imovel_rural', valor: 260000, natureza: 'particular', fracao: 100 }, { descricao: 'Fiat Strada 2018', tipo: 'veiculo', valor: 62000, natureza: 'comum', fracao: 100 }], dividas: 0 };
    s.inv[1] = { ...novoFalecido('Maria da Silva'), obito: '2026-02-03', estadoCivil: 'solteiro', regime: 'parcial', conjuge: { nome: '', separadoFato: false, sumula377: false },
      descendentes: [pessoa({ nome: 'Ana da Silva', condicao: 'vivo', representantes: [] }), pessoa({ nome: 'Carlos da Silva', condicao: 'vivo', representantes: [] }), pessoa({ nome: 'Pedro da Silva', condicao: 'premorto', representantes: [pessoa({ nome: 'Lucas da Silva (neto)' }), pessoa({ nome: 'Júlia da Silva (neta)' })] })],
      bens: [{ descricao: 'Saldo em poupança Banese', tipo: 'dinheiro', valor: 18500, natureza: 'particular', fracao: 100 }] };
    s.doa = { ...novaDoacao(), doadores: [{ nome: 'Antônio Pereira' }, { nome: 'Rita Pereira' }], reservaUsufruto: true, donatarios: [pessoa({ nome: 'Bruno Pereira', doacoesAnteriores: 0, impostoAnterior: 0 }), pessoa({ nome: 'Carla Pereira', doacoesAnteriores: 0, impostoAnterior: 0 })],
      bens: [{ descricao: 'Apartamento na Av. Ivo de Carvalho — matrícula 4.321', tipo: 'imovel_urbano', valor: 420000, fracao: 100, destino: 'todos' }] };
    return s;
  }

  /* ---------- Acesso por caminho ---------- */
  function get(obj, path) { return path.split('.').reduce((o, k) => (o == null ? undefined : o[k]), obj); }
  function set(obj, path, val) { const ks = path.split('.'); let o = obj; for (let i = 0; i < ks.length - 1; i++) { if (o[ks[i]] == null) o[ks[i]] = /^\d+$/.test(ks[i + 1]) ? [] : {}; o = o[ks[i]]; } o[ks[ks.length - 1]] = val; }

  /* ---------- Blocos de formulário ---------- */
  const campo = (path, rotulo, tipo, extra = {}) => {
    const id = 'c_' + path.replace(/\W/g, '_');
    const v = get(S, path);
    let ctl;
    if (tipo === 'select') ctl = `<select id="${id}" data-path="${path}" data-tipo="select" ${extra.estrutural ? 'data-estrutural="1"' : ''}>${extra.opcoes.map(([k, t]) => `<option value="${k}" ${String(v) === String(k) ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select>`;
    else if (tipo === 'moeda') ctl = `<input type="text" id="${id}" class="moeda" inputmode="decimal" data-path="${path}" data-tipo="moeda" value="${v ? fmtN(v) : ''}" placeholder="0,00">`;
    else if (tipo === 'numero') ctl = `<input type="number" id="${id}" data-path="${path}" data-tipo="numero" value="${esc(v ?? '')}" ${extra.attrs || ''} ${extra.estrutural ? 'data-estrutural="1"' : ''}>`;
    else if (tipo === 'data') ctl = `<input type="date" id="${id}" data-path="${path}" data-tipo="texto" value="${esc(v || '')}">`;
    else ctl = `<input type="text" id="${id}" data-path="${path}" data-tipo="texto" value="${esc(v || '')}" placeholder="${esc(extra.ph || '')}" ${extra.estrutural ? 'data-estrutural="1"' : ''}>`;
    return `<div class="campo ${extra.classe || ''}"><label for="${id}">${rotulo}${extra.dica ? ` <span class="dica">${extra.dica}</span>` : ''}</label>${ctl}</div>`;
  };
  const marcar = (path, texto, estrutural = true) => { const id = 'c_' + path.replace(/\W/g, '_'); return `<label class="marcar" for="${id}"><input type="checkbox" id="${id}" data-path="${path}" data-tipo="bool" ${estrutural ? 'data-estrutural="1"' : ''} ${get(S, path) ? 'checked' : ''}><span>${texto}</span></label>`; };
  const opcoes = (path, lista) => `<div class="opcoes" role="group">${lista.map(([k, t]) => `<button type="button" data-opcao="${path}" data-valor="${k}" aria-pressed="${String(get(S, path)) === String(k)}">${esc(t)}</button>`).join('')}</div>`;

  function blocoRepresentantes(base, lista) {
    return `<div class="sub"><div class="rotulo">Representantes (filhos do premorto — herdam por estirpe, cada um com fato gerador próprio)</div>
      ${lista.map((r, j) => `<div class="linha" style="grid-template-columns:minmax(0,1fr) auto">${campo(`${base}.${j}.nome`, `Neto(a) ${j + 1}`, 'texto', { ph: 'Nome completo' })}<button type="button" class="btn mini remover" data-acao="remover" data-lista="${base}" data-i="${j}" aria-label="Remover representante">✕</button></div>`).join('')}
      <div><button type="button" class="btn mini suave" data-acao="adicionar" data-lista="${base}" data-modelo="rep">+ Representante</button></div></div>`;
  }

  function blocoFalecido(k, titulo) {
    const b = `inv.${k}`, f = S.inv[k];
    const temConj = f.estadoCivil !== 'solteiro';
    const rg = M.regras(f);
    const temNome = x => (x && (x.nome || '').trim() !== '');
    const temDesc = f.descendentes.some(d => temNome(d) || (d.condicao === 'premorto' && (d.representantes || []).some(temNome)));
    const cumul2 = S.modo === 'cumulativo' && k === 1;
    let h = `<section class="cartao" aria-labelledby="tf${k}"><h2 id="tf${k}"><span class="num">${cumul2 ? 3 : 2}</span>${titulo}</h2>`;
    if (cumul2) h += `<p class="lead">Normalmente é o cônjuge/companheiro sobrevivente do primeiro falecido. A meação e o quinhão que recebeu no 1º inventário entram automaticamente no patrimônio dele; abaixo, lance só os bens próprios que ele tinha além disso.</p>`;
    else h += `<p class="lead">Dados do óbito, do regime de bens e de quem herda. O cálculo segue o Código Civil (arts. 1.829 a 1.844).</p>`;
    h += `<div class="grade">${campo(`${b}.nome`, 'Nome do(a) falecido(a)', 'texto', { ph: 'Nome completo', classe: 'larga' })}${campo(`${b}.obito`, 'Data do óbito', 'data')}
      ${campo(`${b}.estadoCivil`, 'Estado civil ao falecer', 'select', { opcoes: [['casado', 'Casado(a)'], ['uniao', 'União estável'], ['solteiro', 'Solteiro(a), viúvo(a) ou divorciado(a)']], estrutural: true })}`;
    if (temConj) h += `${campo(`${b}.regime`, 'Regime de bens', 'select', { opcoes: REGIMES, estrutural: true })}${campo(`${b}.conjuge.nome`, f.estadoCivil === 'uniao' ? 'Companheiro(a) sobrevivente' : 'Cônjuge sobrevivente', 'texto', { ph: 'Nome completo' })}`;
    h += `</div>`;
    if (temConj) {
      h += `<div class="grade" style="margin-top:10px">`;
      h += `<div class="campo">${marcar(`${b}.conjuge.separadoFato`, 'Separados de fato há mais de 2 anos ou judicialmente (art. 1.830 CC): mantém a meação, mas não herda')}</div>`;
      if (f.regime === 'separacao_obrig') h += `<div class="campo">${marcar(`${b}.conjuge.sumula377`, 'Aplicar Súmula 377/STF: os bens adquiridos na constância (marcados como comuns) têm meação')}</div>`;
      h += `</div>`;
      if (rg.concorreDesc !== 'nada' && temDesc) h += `<div class="campo" style="margin-top:10px"><span class="rotulo">Todos os descendentes são também filhos do(a) sobrevivente? <span class="dica">define a reserva de 1/4 (art. 1.832 CC)</span></span>${opcoes(`${b}.filhosComuns`, [['sim', 'Sim, todos são comuns'], ['nao', 'Não (só do falecido ou filiação híbrida)']])}</div>`;
      if (f.regime === 'parcial') h += `<p class="notinha" style="margin-top:8px">Comunhão parcial: marque cada bem como <b>comum</b> (adquirido onerosamente na constância) ou <b>particular</b> (anterior ao casamento, herdado ou doado). O sobrevivente tem meação nos comuns e concorre com os descendentes só nos particulares.</p>`;
      if (f.regime === 'universal') h += `<p class="notinha" style="margin-top:8px">Comunhão universal: todos os bens são comuns (meação de 50%) e o sobrevivente não concorre com os descendentes. Marque "incomunicável" só para bens excluídos por cláusula (art. 1.668 CC).</p>`;
    }
    // Descendentes
    h += `<h3>Descendentes (filhos; netos por representação)</h3><div class="lista">`;
    f.descendentes.forEach((d, i) => {
      h += `<div class="item"><div class="linha">${campo(`${b}.descendentes.${i}.nome`, `Herdeiro ${i + 1}`, 'texto', { ph: 'Nome completo', classe: 'larga-mobile' })}
        ${campo(`${b}.descendentes.${i}.condicao`, 'Situação', 'select', { opcoes: [['vivo', 'Vivo(a) — herda'], ['premorto', 'Premorto(a) — netos representam'], ['renuncia', 'Renuncia à herança']], estrutural: true })}
        <button type="button" class="btn mini remover" data-acao="remover" data-lista="${b}.descendentes" data-i="${i}" aria-label="Remover herdeiro">✕</button></div>`;
      if (d.condicao === 'premorto') h += blocoRepresentantes(`${b}.descendentes.${i}.representantes`, d.representantes || []);
      h += `</div>`;
    });
    h += `</div><div class="acoes"><button type="button" class="btn suave" data-acao="adicionar" data-lista="${b}.descendentes" data-modelo="desc">+ Filho(a)</button></div>`;
    // Ascendentes
    const a = f.ascendentes;
    h += `<details style="margin-top:14px" ${!temDesc ? 'open' : ''}><summary>Ascendentes ${temDesc ? '<span class="dica">— ignorados: há descendentes</span>' : '<span class="dica">— herdam quando não há descendentes</span>'}</summary>
      <div class="grade" style="margin-top:10px"><div class="campo">${marcar(`${b}.ascendentes.paiVivo`, 'Pai vivo')}</div>${a.paiVivo ? campo(`${b}.ascendentes.pai`, 'Nome do pai', 'texto') : ''}<div class="campo">${marcar(`${b}.ascendentes.maeViva`, 'Mãe viva')}</div>${a.maeViva ? campo(`${b}.ascendentes.mae`, 'Nome da mãe', 'texto') : ''}</div>
      ${(!a.paiVivo && !a.maeViva) ? `<div class="grade" style="margin-top:10px">${campo(`${b}.ascendentes.avosPaternos`, 'Avós paternos vivos', 'numero', { attrs: 'min="0" max="2"', dica: '(0 a 2)' })}${campo(`${b}.ascendentes.avosMaternos`, 'Avós maternos vivos', 'numero', { attrs: 'min="0" max="2"', dica: '(0 a 2)' })}</div>` : '<p class="notinha" style="margin-top:8px">Com pai ou mãe vivo, os avós não herdam (art. 1.836, §1º CC).</p>'}</details>`;
    // Colaterais
    h += `<details style="margin-top:10px" ${(!temDesc && !temConj && !a.paiVivo && !a.maeViva && !(+a.avosPaternos) && !(+a.avosMaternos)) ? 'open' : ''}><summary>Colaterais <span class="dica">— só herdam sem descendentes, ascendentes e cônjuge</span></summary><div class="lista" style="margin-top:10px">`;
    f.colaterais.forEach((c, i) => {
      h += `<div class="item"><div class="linha colateral">${campo(`${b}.colaterais.${i}.nome`, `Colateral ${i + 1}`, 'texto', { ph: 'Nome completo' })}
        ${campo(`${b}.colaterais.${i}.grau`, 'Parentesco', 'select', { opcoes: [['irmao', 'Irmão/irmã'], ['sobrinho', 'Sobrinho(a) (por cabeça)'], ['tio', 'Tio(a)'], ['primo', 'Primo(a) / 4º grau']], estrutural: true })}
        ${c.grau === 'irmao' ? campo(`${b}.colaterais.${i}.tipo`, 'Vínculo', 'select', { opcoes: [['bilateral', 'Bilateral (mesmo pai e mãe)'], ['unilateral', 'Unilateral']] }) : '<div></div>'}
        <button type="button" class="btn mini remover" data-acao="remover" data-lista="${b}.colaterais" data-i="${i}" aria-label="Remover colateral">✕</button></div>
        ${c.grau === 'irmao' ? `<div class="linha" style="grid-template-columns:minmax(0,1fr)">${campo(`${b}.colaterais.${i}.condicao`, 'Situação', 'select', { opcoes: [['vivo', 'Vivo(a)'], ['premorto', 'Premorto(a) — sobrinhos representam'], ['renuncia', 'Renuncia']], estrutural: true })}</div>${c.condicao === 'premorto' ? blocoRepresentantes(`${b}.colaterais.${i}.representantes`, c.representantes || []) : ''}` : ''}</div>`;
    });
    h += `</div><div class="acoes"><button type="button" class="btn suave mini" data-acao="adicionar" data-lista="${b}.colaterais" data-modelo="col">+ Colateral</button></div></details>`;
    // Bens
    h += `<h3>${cumul2 ? 'Bens próprios do 2º falecido (além do que recebeu no 1º inventário)' : 'Bens do espólio'}</h3>`;
    h += `<p class="notinha">Valor = base de cálculo (valor venal/avaliação, nunca inferior ao do ITBI/IPTU, ITR ou IPVA — art. 10, §4º). "Fração do falecido/casal" serve para bens em condomínio com terceiros.</p><div class="lista" style="margin-top:8px">`;
    const mostraNat = temConj && (rg.meacaoSobre === 'comuns');
    f.bens.forEach((bm, i) => {
      h += `<div class="item"><div class="linha bem">${campo(`${b}.bens.${i}.descricao`, `Bem ${i + 1}`, 'texto', { ph: 'Descrição, matrícula…', classe: 'larga-mobile' })}
        ${campo(`${b}.bens.${i}.tipo`, 'Tipo', 'select', { opcoes: TIPOS })}${campo(`${b}.bens.${i}.valor`, 'Valor (R$)', 'moeda')}
        ${mostraNat ? campo(`${b}.bens.${i}.natureza`, 'Natureza', 'select', { opcoes: [['comum', 'Comum (do casal)'], ['particular', 'Particular (só do falecido)']] }) : (temConj && rg.meacaoSobre === 'todos' ? `<div class="campo"><span class="rotulo">&nbsp;</span>${marcar(`${b}.bens.${i}.incomunicavel`, 'Incomunicável', false)}</div>` : '<div></div>')}
        ${campo(`${b}.bens.${i}.fracao`, 'Fração (%)', 'numero', { attrs: 'min="0" max="100" step="0.01"' })}
        <button type="button" class="btn mini remover" data-acao="remover" data-lista="${b}.bens" data-i="${i}" aria-label="Remover bem">✕</button></div></div>`;
    });
    h += `</div><div class="acoes"><button type="button" class="btn suave" data-acao="adicionar" data-lista="${b}.bens" data-modelo="bem">+ Bem</button></div>`;
    h += `<div class="grade" style="margin-top:12px">${campo(`${b}.dividas`, 'Dívidas do espólio (R$)', 'moeda', { dica: 'abatem antes da meação' })}${campo(`${b}.aliquotaManual`, 'Alíquota manual (%)', 'numero', { attrs: 'min="0" max="10" step="0.5"', dica: 'deixe vazio para usar a lei vigente' })}</div>`;
    h += `<div class="grade" style="margin-top:10px"><div class="campo">${marcar(`${b}.multaAtraso`, 'Aplicar multa de 20% se o inventário não foi requerido em 120 dias do óbito (art. 27, I)', false)}</div>
      <div class="campo">${marcar(`${b}.isencaoUnicoImovel`, 'Único imóvel do espólio até 2.600 UFP: habilitar isenção do art. 8º, VI por sucessor (sem outro imóvel e renda ≤ 3 salários mínimos)')}</div></div>`;
    if (f.isencaoUnicoImovel) {
      const inv = M.inventario(f, { ufp: S.ufp, hoje: S.hoje });
      h += `<div class="aviso">Marque os sucessores que atendem aos requisitos (reconhecimento depende de pedido prévio à SEFAZ — Decreto, art. 9º):<div class="opcoes" style="margin-top:6px">${inv.suc.benef.map(x => marcar(`${b}.isentosVI.${x.id}`, esc(x.nome), false)).join('')}</div></div>`;
    }
    h += `</section>`;
    return h;
  }

  function blocoDoacao() {
    const d = S.doa;
    let h = `<section class="cartao" aria-labelledby="td"><h2 id="td"><span class="num">2</span>Doação</h2><p class="lead">Cada donatário é um fato gerador (art. 5º): isenção e alíquota são aferidas por donatário, somando as doações do mesmo exercício.</p>`;
    h += `<h3>Doador(es)</h3><div class="lista">${d.doadores.map((x, i) => `<div class="item"><div class="linha" style="grid-template-columns:minmax(0,1fr) auto">${campo(`doa.doadores.${i}.nome`, `Doador ${i + 1}`, 'texto', { ph: 'Nome completo' })}<button type="button" class="btn mini remover" data-acao="remover" data-lista="doa.doadores" data-i="${i}" aria-label="Remover doador">✕</button></div></div>`).join('')}</div>
      <div class="acoes"><button type="button" class="btn suave mini" data-acao="adicionar" data-lista="doa.doadores" data-modelo="doador">+ Doador (ex.: casal)</button></div>`;
    h += `<div class="grade" style="margin-top:12px">${campo('doa.data', 'Data prevista da escritura', 'data')}${campo('doa.aliquotaManual', 'Alíquota manual (%)', 'numero', { attrs: 'min="0" max="10" step="0.5"', dica: 'vazio = lei vigente' })}</div>`;
    h += `<div class="grade" style="margin-top:10px"><div class="campo">${marcar('doa.reservaUsufruto', 'Doação com reserva de usufruto em favor do(s) doador(es)')}</div>${d.reservaUsufruto ? campo('doa.baseNuaPropriedade', 'Base de cálculo da nua-propriedade', 'select', { opcoes: [['100', '100% do valor do bem (art. 2º, §5º)'], ['50', '50% do valor (art. 13, por analogia)']] }) : ''}</div>`;
    if (d.reservaUsufruto) h += `<div class="campo" style="margin-top:8px">${marcar('doa.usufrutoAcessorio', 'Emolumentos: cobrar a reserva de usufruto como ato acessório (metade da faixa)', false)}</div>`;
    h += `<h3>Donatários</h3><div class="lista">${d.donatarios.map((x, i) => `<div class="item"><div class="linha donatario">${campo(`doa.donatarios.${i}.nome`, `Donatário ${i + 1}`, 'texto', { ph: 'Nome completo' })}${campo(`doa.donatarios.${i}.doacoesAnteriores`, 'Doações anteriores no ano (R$)', 'moeda', { dica: 'do mesmo doador (art. 8º, §1º)' })}${campo(`doa.donatarios.${i}.impostoAnterior`, 'ITCMD já recolhido nelas (R$)', 'moeda', { dica: 'art. 10, §7º' })}<button type="button" class="btn mini remover" data-acao="remover" data-lista="doa.donatarios" data-i="${i}" aria-label="Remover donatário">✕</button></div></div>`).join('')}</div>
      <div class="acoes"><button type="button" class="btn suave" data-acao="adicionar" data-lista="doa.donatarios" data-modelo="donatario">+ Donatário</button></div>`;
    const dest = [['todos', 'Todos os donatários, em partes iguais'], ...d.donatarios.map((x, i) => [x.uid, x.nome || `Donatário ${i + 1}`])];
    d.bens.forEach(bm => { if (bm.destino && bm.destino !== 'todos' && !d.donatarios.some(x => x.uid === bm.destino)) bm.destino = 'todos'; });
    h += `<h3>Bens doados</h3><div class="lista">${d.bens.map((bm, i) => `<div class="item"><div class="linha bem bem-doacao">${campo(`doa.bens.${i}.descricao`, `Bem ${i + 1}`, 'texto', { ph: 'Descrição, matrícula…', classe: 'larga-mobile' })}${campo(`doa.bens.${i}.tipo`, 'Tipo', 'select', { opcoes: TIPOS })}${campo(`doa.bens.${i}.valor`, 'Valor (R$)', 'moeda')}${campo(`doa.bens.${i}.destino`, 'Para quem', 'select', { opcoes: dest })}${campo(`doa.bens.${i}.fracao`, 'Fração (%)', 'numero', { attrs: 'min="0" max="100" step="0.01"' })}<button type="button" class="btn mini remover" data-acao="remover" data-lista="doa.bens" data-i="${i}" aria-label="Remover bem">✕</button></div></div>`).join('')}</div>
      <div class="acoes"><button type="button" class="btn suave" data-acao="adicionar" data-lista="doa.bens" data-modelo="bemDoa">+ Bem</button></div>`;
    h += `</section>`;
    return h;
  }

  function renderForm() {
    const fi = $('#formInventarios'), fd = $('#formDoacao');
    $$('#segModo button').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.modo === S.modo)));
    if (S.modo === 'doacao') { fi.classList.add('oculto'); fd.classList.remove('oculto'); fd.innerHTML = blocoDoacao(); }
    else {
      fd.classList.add('oculto'); fi.classList.remove('oculto');
      fi.innerHTML = blocoFalecido(0, S.modo === 'cumulativo' ? '1º falecido e sua sucessão' : 'Falecido(a) e sucessão') + (S.modo === 'cumulativo' ? blocoFalecido(1, '2º falecido (inventário cumulativo)') : '');
    }
    $('#ufp').value = fmtN(S.ufp); $('#hoje').value = S.hoje;
    atualizarSelo();
  }
  function ufpDoCalculo() { return (S.modo === 'doacao' && !S.ufpManual && S.doa.data) ? M.ufpVigente(S.doa.data).valor : S.ufp; }
  function atualizarSelo() {
    const u = M.ufpVigente(S.hoje);
    $('#ufpDica').textContent = S.ufpManual ? 'valor informado manualmente' : `vigente em ${u.mes} (${u.fonte})`;
    $('#seloUfp').textContent = S.ufpManual ? `UFP/SE ${fmt(S.ufp)} · manual` : `UFP/SE ${fmt(S.ufp)} · ${u.mes}`;
  }

  /* ---------- Resultado ---------- */
  function tabelaHerdeiros(inv, tituloExtra) {
    const it = inv.itc;
    let h = `<div class="tabela-wrap"><table><thead><tr><th>Beneficiário</th><th>Título</th><th class="n">Fração</th><th class="n">Quinhão</th><th class="n">UFP</th><th>Situação</th><th class="n">ITCMD</th>${it.multaCabivel ? '<th class="n">Multa 20%</th>' : ''}</tr></thead><tbody>`;
    if (inv.pat.rg.temConjuge && inv.pat.meacao > 0) h += `<tr class="sub"><td>${esc(inv.falecido.conjuge.nome || 'Meeiro(a)')}</td><td>meação (não é herança)</td><td class="n fracao">${inv.pat.rg.meacaoSobre === 'todos' ? '1/2' : '1/2 dos comuns'}</td><td class="n">${fmt(inv.pat.meacao)}</td><td class="n">—</td><td><span class="pill sem">não incide</span></td><td class="n">—</td>${it.multaCabivel ? '<td class="n">—</td>' : ''}</tr>`;
    it.linhas.forEach(l => {
      let fr;
      if (inv.pat.herancaPart > 0 && inv.pat.herancaComum > 0 && l.frPart.txt() !== l.frComum.txt()) fr = [l.frPart.zero() ? '' : `${l.frPart.txt()} <span class="dica">da herança nos bens particulares</span>`, l.frComum.zero() ? '' : `${l.frComum.txt()} <span class="dica">da herança nos bens comuns</span>`].filter(Boolean).join('<br>');
      else fr = `${(inv.pat.herancaPart > 0 ? l.frPart : l.frComum).txt()} <span class="dica">da herança</span>`;
      h += `<tr><td>${esc(l.nome)}</td><td>${esc(l.papel)}</td><td class="n fracao" style="white-space:nowrap">${fr}</td><td class="n">${fmt(l.quinhao)}</td><td class="n">${fmtN(l.ufps, 1)}</td><td><span class="pill ${l.situacao === 'isento' ? 'isento' : l.situacao === 'tributado' ? 'tributado' : 'sem'}">${l.situacao === 'tributado' ? pct(l.aliq) : l.situacao}</span><div class="notinha">${esc(l.detalhe)}</div></td><td class="n">${fmt(l.imposto)}</td>${it.multaCabivel ? `<td class="n">${fmt(l.multa)}</td>` : ''}</tr>`;
    });
    h += `<tr class="total"><td colspan="3">Total ITCMD${tituloExtra || ''}</td><td class="n">${fmt(it.linhas.reduce((s, l) => s + l.quinhao, 0))}</td><td></td><td></td><td class="n">${fmt(it.total)}</td>${it.multaCabivel ? `<td class="n">${fmt(it.totalMulta)}</td>` : ''}</tr></tbody></table></div>`;
    return h;
  }
  function tabelaPartilha(inv) {
    let h = `<div class="tabela-wrap"><table><thead><tr><th>Bem</th><th>Quem recebe</th><th class="n">Fração do bem</th><th class="n">%</th><th class="n">Valor</th></tr></thead><tbody>`;
    inv.partilha.forEach(p => {
      p.linhas.forEach((l, j) => { h += `<tr>${j === 0 ? `<td rowspan="${p.linhas.length}"><b>${esc(p.bem.descricao)}</b><div class="notinha">${fmt(p.bem.valor)}${p.bem.fracao !== 100 ? ` (${fmtN(p.bem.fracao, 4)}% de ${fmt(p.bem.valorBem)})` : ''} · ${p.bem.comum ? 'comum' : 'particular'}</div></td>` : ''}<td>${esc(l.quem)}<div class="notinha">${esc(l.papel)}</div></td><td class="n fracao">${l.fr.txt()}</td><td class="n">${l.fr.pct(4)}</td><td class="n">${fmt(l.valor)}</td></tr>`; });
    });
    h += `</tbody></table></div>`;
    return h;
  }
  function resumoInventario(inv, rotulo) {
    const p = inv.pat, it = inv.itc;
    let h = `<h3>${esc(rotulo)}</h3><div class="kpis"><div class="kpi"><div class="r">Monte-mor</div><div class="v">${fmt(p.monteMor)}</div></div>${p.dividas ? `<div class="kpi"><div class="r">Dívidas</div><div class="v">− ${fmt(p.dividas)}</div></div>` : ''}${p.rg.temConjuge ? `<div class="kpi"><div class="r">Meação</div><div class="v">${fmt(p.meacao)}</div></div>` : ''}<div class="kpi"><div class="r">Herança (monte partível)</div><div class="v">${fmt(p.heranca)}</div></div><div class="kpi destaque"><div class="r">ITCMD${it.multaCabivel ? ' + multa' : ''}</div><div class="v">${fmt(it.totalGeral)}</div></div></div>`;
    if (it.dias !== null) h += `<p class="notinha">Óbito em ${dataBR(inv.falecido.obito)} — ${it.dias} dias até a data de referência.${it.multaCabivel ? ' Prazo de 120 dias ultrapassado: multa de 20% do imposto (art. 27, I), salvo se o inventário já foi requerido no prazo.' : it.dias > 120 ? ' Multa desativada.' : ''}</p>`;
    const avs = [...inv.suc.avisos, ...(inv.itc.avisos || [])];
    const graves = avs.filter(a => /sem o nome/.test(a)), demais = avs.filter(a => !/sem o nome/.test(a));
    if (graves.length) h += `<div class="aviso erro"><ul>${graves.map(a => `<li>${esc(a)}</li>`).join('')}</ul></div>`;
    if (demais.length) h += `<div class="aviso"><ul>${demais.map(a => `<li>${esc(a)}</li>`).join('')}</ul></div>`;
    if (inv.falecido.obito && inv.falecido.obito < '2024-01-01' && !inv.falecido.aliquotaManual) h += `<div class="aviso">Óbito anterior a 2024: a alíquota é a vigente na data do fato gerador. Esta versão aplica a tabela atual; confira na SEFAZ/SE e, se for o caso, informe a alíquota manual.</div>`;
    h += tabelaHerdeiros(inv);
    h += `<h3>Partilha ideal por bem (para a declaração)</h3>${p.dividas ? '<p class="notinha">Frações e valores brutos dos bens, antes do abatimento das dívidas.</p>' : ''}` + tabelaPartilha(inv);
    return h;
  }

  let ULT = null; // último cálculo (para o orçamento e a cópia)
  function calcular() {
    const opts = { ufp: S.ufp, hoje: S.hoje };
    atualizarSelo();
    const rc = $('#resCorpo'); let h = '';
    try {
      if (S.modo === 'doacao') {
        const d = M.doacao(S.doa, { ufp: ufpDoCalculo(), hoje: S.doa.data || S.hoje });
        ULT = { modo: 'doacao', d };
        if (!S.ufpManual && S.doa.data && M.ufpVigente(S.doa.data).valor !== S.ufp) h += `<div class="aviso">Escritura prevista para ${dataBR(S.doa.data)}: usada a UFP/SE de ${M.ufpVigente(S.doa.data).mes} (${fmt(d.ufp)}).</div>`;
        h += `<div class="kpis"><div class="kpi"><div class="r">Valor doado</div><div class="v">${fmt(d.valorTotal)}</div></div><div class="kpi"><div class="r">Donatários</div><div class="v">${d.linhas.length}</div></div><div class="kpi destaque"><div class="r">ITCMD</div><div class="v">${fmt(d.total)}</div></div></div>`;
        if (d.avisos.length) h += `<div class="aviso"><ul>${d.avisos.map(a => `<li>${esc(a)}</li>`).join('')}</ul></div>`;
        h += `<div class="tabela-wrap"><table><thead><tr><th>Donatário</th><th class="n">Imóveis</th><th class="n">Móveis</th><th class="n">Base (+ anteriores)</th><th class="n">UFP</th><th>Situação</th><th class="n">ITCMD</th></tr></thead><tbody>`;
        d.linhas.forEach(l => { h += `<tr><td>${esc(l.nome)}</td><td class="n">${fmt(l.imoveis)}</td><td class="n">${fmt(l.moveis)}</td><td class="n">${fmt(l.quinhao + l.anteriores)}</td><td class="n">${fmtN(l.ufps, 1)}</td><td><span class="pill ${l.situacao === 'isento' ? 'isento' : l.situacao === 'tributado' ? 'tributado' : 'sem'}">${l.situacao === 'tributado' ? pct(l.aliq) : l.situacao}</span><div class="notinha">${esc(l.detalhe)}</div></td><td class="n">${fmt(l.imposto)}</td></tr>`; });
        h += `<tr class="total"><td colspan="6">Total ITCMD</td><td class="n">${fmt(d.total)}</td></tr></tbody></table></div>`;
      } else if (S.modo === 'cumulativo') {
        const c = M.cumulativo(S.inv[0], S.inv[1], opts);
        ULT = { modo: 'cumulativo', c };
        h += resumoInventario(c.inv1, `1ª declaração — ${S.inv[0].nome || '1º falecido'}`);
        h += `<div class="aviso ok">O 2º falecido leva para o próprio inventário: meação ${fmt(c.inv1.pat.meacao)}${c.inv1.suc.benef.find(b => b.id === 'conj') ? ` + quinhão ${fmt(c.inv1.suc.benef.find(b => b.id === 'conj').valor)}` : ''} = ${fmt(c.inv2.pat.bens.filter(b => b.origem === 'inv1').reduce((s, b) => s + b.valor, 0))} (já lançado como bens particulares do 2º inventário).</div>`;
        h += resumoInventario(c.inv2, `2ª declaração — ${S.inv[1].nome || '2º falecido'}`);
      } else {
        const inv = M.inventario(S.inv[0], opts);
        ULT = { modo: 'inventario', inv };
        h += resumoInventario(inv, S.inv[0].nome ? `Espólio de ${S.inv[0].nome}` : 'Espólio');
      }
    } catch (e) { h = `<div class="aviso erro">Não foi possível calcular: ${esc(e.message)}</div>`; ULT = null; console.error(e); }
    rc.innerHTML = h;
    orcamento();
  }

  const ORC_EDITAVEIS = [['honorarios', 'Honorários advocatícios', 'a combinar com o cliente'], ['certidoes', 'Certidões e diligências', 'RI, negativas, avaliações'], ['registro', 'Registro/averbação no RI', 'tabela do Registro de Imóveis'], ['outros', 'Outros custos', '']];
  function montarOrcamentoFixo() { // campos editáveis são criados uma única vez (não perdem o foco nem o valor)
    const oc = $('#orcCorpo');
    oc.innerHTML = `<p class="notinha" id="orcTitulo"></p><div class="tabela-wrap"><table><thead><tr><th>Item</th><th class="n">Valor</th></tr></thead><tbody id="orcLinhas"></tbody><tbody id="orcEditaveis">${ORC_EDITAVEIS.map(([k, r, d]) => `<tr><td><label for="orc_${k}">${r}</label>${d ? `<div class="notinha">${d}</div>` : ''}</td><td class="n" style="min-width:150px"><input type="text" id="orc_${k}" class="moeda" inputmode="decimal" data-path="orc.${k}" data-tipo="moedatexto" placeholder="0,00" aria-label="${r}"></td></tr>`).join('')}</tbody><tbody><tr class="total grande"><td>Total estimado do ato</td><td class="n" id="orcTotal">—</td></tr></tbody></table></div><div id="orcOpcoes" class="nao-imprimir"></div>`;
  }
  function orcamento() {
    if (!$('#orcLinhas')) montarOrcamentoFixo();
    ORC_EDITAVEIS.forEach(([k]) => { const el = $('#orc_' + k); if (el && document.activeElement !== el) el.value = S.orc[k] || ''; });
    if (!ULT) { $('#orcLinhas').innerHTML = '<tr><td colspan="2" class="notinha">Preencha os dados para montar o orçamento.</td></tr>'; $('#orcTotal').textContent = '—'; return; }
    const linhas = []; // {rotulo, detalhe, valor}
    let titulo = '';
    if (ULT.modo === 'doacao') {
      const d = ULT.d; titulo = 'Escritura pública de doação';
      linhas.push({ rotulo: 'ITCMD — doação', detalhe: `${d.linhas.length} donatário(s)`, valor: d.total });
      const e = M.emolumentosEscritura(d.valorTotal, S.doa.doadores.length + S.doa.donatarios.length);
      linhas.push({ rotulo: 'Emolumentos da escritura', detalhe: `faixa ${fmt(d.valorTotal)} → ${fmt(e.emol)}${e.adicional ? ` + ${fmt(e.adicional)} adicionais` : ''} + FERD 20% ${fmt(e.ferd)}`, valor: e.total });
      if (S.doa.reservaUsufruto && S.doa.usufrutoAcessorio) { const ea = M.emolumentosEscritura(d.valorTotal, 0, { acessorio: true }); linhas.push({ rotulo: 'Reserva de usufruto (ato acessório)', detalhe: `metade da faixa ${fmt(ea.emol)} + FERD ${fmt(ea.ferd)}`, valor: ea.total }); }
    } else {
      const invs = ULT.modo === 'cumulativo' ? [ULT.c.inv1, ULT.c.inv2] : [ULT.inv];
      titulo = ULT.modo === 'cumulativo' ? 'Escritura pública de inventário cumulativo e partilha' : 'Escritura pública de inventário e partilha';
      invs.forEach((inv, k) => {
        const nome = inv.falecido.nome || (k ? '2º falecido' : 'falecido');
        linhas.push({ rotulo: `ITCMD causa mortis — ${nome}`, detalhe: `${inv.itc.linhas.filter(l => l.situacao === 'tributado').length} quinhão(ões) tributado(s), ${inv.itc.linhas.filter(l => l.situacao === 'isento').length} isento(s)`, valor: inv.itc.total });
        if (inv.itc.multaCabivel && inv.itc.totalMulta) linhas.push({ rotulo: `Multa 20% (art. 27, I) — ${nome}`, detalhe: 'inventário fora do prazo de 120 dias', valor: inv.itc.totalMulta });
      });
      invs.forEach((inv, k) => {
        const pessoas = inv.itc.linhas.length + (inv.pat.rg.temConjuge && inv.pat.meacao > 0 ? 1 : 0) + (inv.falecido.descendentes || []).filter(x => x.condicao === 'renuncia' && (x.nome || '').trim()).length;
        const acess = k === 1 && S.emol.inv2Acessorio;
        const e = M.emolumentosEscritura(inv.pat.monteMor, pessoas, { acessorio: acess });
        linhas.push({ rotulo: `Emolumentos — inventário de ${inv.falecido.nome || (k ? '2º falecido' : 'falecido')}${acess ? ' (ato acessório)' : ''}`, detalhe: `faixa ${fmt(inv.pat.monteMor)} → ${fmt(e.emol)}${e.adicional ? ` + ${fmt(e.adicional)} (${pessoas} pessoas)` : ''} + FERD 20% ${fmt(e.ferd)}`, valor: e.total });
      });
    }
    const fixos = linhas.reduce((s, l) => s + l.valor, 0);
    const edSoma = ORC_EDITAVEIS.reduce((s, [k]) => s + parseMoeda(S.orc[k]), 0);
    $('#orcTitulo').innerHTML = `<b>${esc(titulo)}</b>${ULT.modo !== 'doacao' ? ` · ${[...new Set((ULT.modo === 'cumulativo' ? [ULT.c.inv1, ULT.c.inv2] : [ULT.inv]).map(i => i.falecido.nome).filter(Boolean))].map(esc).join(' e ')}` : ''}`;
    let h = '';
    linhas.forEach(l => { h += `<tr><td>${esc(l.rotulo)}<div class="notinha">${esc(l.detalhe)}</div></td><td class="n">${fmt(l.valor)}</td></tr>`; });
    h += `<tr class="sub"><td>Subtotal — imposto e emolumentos</td><td class="n"><b id="orcSubtotal">${fmt(fixos)}</b></td></tr>`;
    $('#orcLinhas').innerHTML = h;
    $('#orcTotal').textContent = fmt(fixos + edSoma);
    const op = ULT.modo === 'cumulativo' ? `<div style="margin-top:8px">${marcar('emol.inv2Acessorio', 'Cobrar o 2º inventário como ato acessório (metade da faixa)', false)}</div>` : '';
    const opEl = $('#orcOpcoes'); if (opEl.dataset.modo !== ULT.modo || (op && !opEl.contains(document.activeElement) && opEl.innerHTML !== op)) { opEl.innerHTML = op; opEl.dataset.modo = ULT.modo; }
    const itcmdTot = linhas.filter(l => /^ITCMD|^Multa/.test(l.rotulo)).reduce((s, l) => s + l.valor, 0), emolTot = linhas.filter(l => /^Emolumentos|^Reserva/.test(l.rotulo)).reduce((s, l) => s + l.valor, 0);
    $('#bvItcmd').textContent = fmt(itcmdTot); $('#bvEmol').textContent = fmt(emolTot); $('#bvTotal').textContent = fmt(fixos + edSoma);
    $('#orcData').textContent = `Referência: ${dataBR(S.hoje)} · UFP/SE ${fmt(ULT.modo === 'doacao' ? ULT.d.ufp : S.ufp)}`;
  }

  function textoResumo() {
    if (!ULT) return '';
    const L = [];
    L.push(`ORÇAMENTO — ${ULT.modo === 'doacao' ? 'ESCRITURA DE DOAÇÃO' : ULT.modo === 'cumulativo' ? 'INVENTÁRIO CUMULATIVO' : 'INVENTÁRIO E PARTILHA'}`);
    L.push(`Cartório de Notas do 2º Ofício de Itabaiana/SE · referência ${dataBR(S.hoje)} · UFP/SE ${fmt(ULT.modo === 'doacao' ? ULT.d.ufp : S.ufp)}`); L.push('');
    const bloco = (inv, t) => { L.push(t); L.push(`Monte-mor ${fmt(inv.pat.monteMor)}${inv.pat.dividas ? ` − dívidas ${fmt(inv.pat.dividas)}` : ''}${inv.pat.rg.temConjuge ? ` − meação ${fmt(inv.pat.meacao)}` : ''} = herança ${fmt(inv.pat.heranca)}`); inv.itc.linhas.forEach(l => L.push(`  • ${l.nome} (${l.papel}): quinhão ${fmt(l.quinhao)} = ${fmtN(l.ufps, 1)} UFP → ${l.situacao === 'tributado' ? pct(l.aliq) + ' = ' + fmt(l.imposto) : l.situacao}${l.multa ? ` + multa ${fmt(l.multa)}` : ''}`)); L.push(`  ITCMD: ${fmt(inv.itc.totalGeral)}`); L.push(''); };
    if (ULT.modo === 'doacao') { L.push('Donatários:'); ULT.d.linhas.forEach(l => L.push(`  • ${l.nome}: base ${fmt(l.quinhao)} (${fmtN(l.ufps, 1)} UFP) → ${l.situacao === 'tributado' ? pct(l.aliq) + ' = ' + fmt(l.imposto) : l.situacao}`)); L.push(`  ITCMD: ${fmt(ULT.d.total)}`); L.push(''); }
    else if (ULT.modo === 'cumulativo') { bloco(ULT.c.inv1, `1ª declaração — ${S.inv[0].nome}`); bloco(ULT.c.inv2, `2ª declaração — ${S.inv[1].nome}`); }
    else bloco(ULT.inv, `Espólio de ${S.inv[0].nome}`);
    $$('#orcCorpo tbody tr').forEach(tr => { const td = tr.children; if (td.length < 2) return; const rot = td[0].querySelector('label') ? td[0].querySelector('label').textContent : td[0].childNodes[0].textContent; const inp = td[1].querySelector('input'); L.push(`${rot.trim()}: ${inp ? fmt(parseMoeda(inp.value)) : td[1].textContent.trim()}`); });
    return L.join('\n');
  }

  /* ---------- Eventos ---------- */
  function aplicarEntrada(el) {
    const p = el.dataset.path, t = el.dataset.tipo; if (!p) return;
    let v;
    if (t === 'bool') v = el.checked; else if (t === 'moeda') v = parseMoeda(el.value); else if (t === 'numero') v = el.value === '' ? '' : +el.value; else v = el.value;
    if (t === 'moedatexto') v = el.value;
    set(S, p, v);
    if (p === 'ufp') { if (!v) { set(S, p, M.ufpVigente(S.hoje).valor); S.ufpManual = false; } else S.ufpManual = Math.abs(v - M.ufpVigente(S.hoje).valor) > 0.001; }
  }
  // Dentro do Hub, a ferramenta vive em #itcmdRaiz: os ouvintes ficam presos a ela para não
  // reagir a botões de outras páginas (o Guia de ITBI também usa data-modo).
  const RAIZ = document.getElementById('itcmdRaiz') || document;
  RAIZ.addEventListener('input', e => {
    const el = e.target; if (!el.dataset || !el.dataset.path) return;
    if (el.dataset.estrutural) return; // trata no change
    aplicarEntrada(el); agendar();
  });
  RAIZ.addEventListener('change', e => {
    const el = e.target; if (!el.dataset || !el.dataset.path) return;
    aplicarEntrada(el);
    if (el.dataset.tipo === 'moeda') el.value = get(S, el.dataset.path) ? fmtN(get(S, el.dataset.path)) : '';
    if (el.dataset.path === 'hoje' || el.dataset.path === 'doa.data') { if (el.dataset.path === 'hoje' && !S.ufpManual) { S.ufp = M.ufpVigente(S.hoje).valor; } renderForm(); }
    if (el.dataset.estrutural) renderForm();
    calcular(); salvarAuto();
  });
  RAIZ.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.id === 'btVerOrcamento') { const o = $('#orcamento'); if (o) o.scrollIntoView({ behavior: 'smooth', block: 'start' }); return; }
    if (b.dataset.modo && ['inventario', 'cumulativo', 'doacao'].includes(b.dataset.modo)) { S.modo = b.dataset.modo; renderForm(); calcular(); salvarAuto(); return; }
    if (b.dataset.opcao) { set(S, b.dataset.opcao, b.dataset.valor); renderForm(); calcular(); salvarAuto(); return; }
    if (b.dataset.acao === 'adicionar') {
      const lista = get(S, b.dataset.lista) || []; const m = b.dataset.modelo;
      const novo = m === 'desc' ? pessoa({ nome: '', condicao: 'vivo', representantes: [] }) : m === 'rep' ? pessoa({ nome: '' }) : m === 'col' ? pessoa({ nome: '', grau: 'irmao', tipo: 'bilateral', condicao: 'vivo', representantes: [] }) : m === 'bem' ? { descricao: '', tipo: 'imovel_urbano', valor: 0, natureza: 'comum', fracao: 100 } : m === 'bemDoa' ? { descricao: '', tipo: 'imovel_urbano', valor: 0, fracao: 100, destino: 'todos' } : m === 'donatario' ? pessoa({ nome: '', doacoesAnteriores: 0, impostoAnterior: 0 }) : { nome: '' };
      lista.push(novo); set(S, b.dataset.lista, lista); renderForm(); calcular(); salvarAuto();
      const foco = $(`[data-path="${b.dataset.lista}.${lista.length - 1}.${m === 'bem' || m === 'bemDoa' ? 'descricao' : 'nome'}"]`); if (foco) foco.focus();
      return;
    }
    if (b.dataset.acao === 'remover') { const lista = get(S, b.dataset.lista); lista.splice(+b.dataset.i, 1); renderForm(); calcular(); salvarAuto(); return; }
  });
  let timer = null;
  function agendar() { clearTimeout(timer); timer = setTimeout(() => { calcular(); salvarAuto(); }, 250); }

  $('#btExemplo').addEventListener('click', () => { S = exemplo(); renderForm(); calcular(); salvarAuto(); toast('Exemplo carregado'); });
  $('#btLimpar').addEventListener('click', () => { S = estadoInicial(); renderForm(); calcular(); try { localStorage.removeItem('itcmd-rascunho'); } catch (e) { } toast('Formulário limpo'); });
  $('#btSalvar').addEventListener('click', () => { salvarAuto(true); });
  $('#btImprimir').addEventListener('click', imprimirOrcamento);
  function imprimirOrcamento() {
    if (!ULT) return;
    let quem = ''; try { quem = (typeof SESSAO !== 'undefined' && SESSAO && SESSAO.nome) ? String(SESSAO.nome) : ''; } catch (e) { }
    const css = `body{font-family:Arial,Helvetica,sans-serif;color:#000;font-size:12.5pt;margin:18mm 16mm;line-height:1.35}
      h1{font-size:18pt;margin:0 0 2px}h2{font-size:14pt;margin:18px 0 6px;border-bottom:1.5pt solid #631325;padding-bottom:3px}h3{font-size:12.5pt;margin:14px 0 4px;color:#631325}
      .cab{display:flex;justify-content:space-between;align-items:flex-end;border-bottom:2pt solid #631325;padding-bottom:6px;margin-bottom:10px}.cab small{color:#333}
      table{border-collapse:collapse;width:100%;font-size:11pt;margin-top:4px}th,td{border-bottom:.6pt solid #999;padding:4px 6px;text-align:left;vertical-align:top}th{font-size:9.5pt;text-transform:uppercase;letter-spacing:.04em;background:#f2eee6}
      td.n,th.n{text-align:right;white-space:nowrap}tr.total td{font-weight:bold;border-top:1.5pt solid #333}tr.grande td{font-size:14pt}.notinha{font-size:10pt;color:#333}.dica{font-size:9.5pt;color:#333}
      .pill{border:.6pt solid #666;border-radius:8px;padding:0 6px;font-size:10pt}.kpis{display:flex;flex-wrap:wrap;gap:8px;margin:6px 0}.kpi{border:.8pt solid #999;border-radius:6px;padding:6px 10px;min-width:140px}.kpi .r{font-size:9.5pt;text-transform:uppercase}.kpi .v{font-weight:bold;font-size:13pt}
      .aviso{border-left:3pt solid #b98a3e;padding:4px 8px;margin:6px 0;font-size:10.5pt}.aviso ul{margin:0;padding-left:16px}.fracao{font-weight:bold}.assinatura{margin-top:22px;font-size:10pt;color:#333;border-top:.6pt dashed #999;padding-top:8px}
      .nao-imprimir,button,input{display:none}details{display:block}summary{font-weight:bold;margin-top:14px}ol,ul{font-size:10.5pt}@page{size:A4;margin:12mm}`;
    // valores digitados no orçamento entram como texto (os inputs não imprimem)
    const orc = $('#orcCorpo').cloneNode(true);
    orc.querySelectorAll('input').forEach(i => { const s = document.createElement('span'); s.textContent = i.value ? fmt(parseMoeda(i.value)) : 'R$ 0,00'; i.replaceWith(s); });
    const html = `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"><title>Orçamento — ${esc($('#orcTitulo') ? $('#orcTitulo').textContent : 'ITCMD')}</title><style>${css}</style></head><body>
      <div class="cab"><div><h1>Cartório de Notas do 2º Ofício de Itabaiana/SE</h1><div>Orçamento de custos do ato — ITCMD, emolumentos e despesas</div></div><small>${esc($('#orcData').textContent)}</small></div>
      <h2>Orçamento do ato</h2>${orc.innerHTML}
      <p class="assinatura">${esc($('#orcamento .assinatura').textContent)}${quem ? '<br>Elaborado por ' + esc(quem) + '.' : ''}</p>
      <h2>Memória de cálculo</h2>${$('#resCorpo').innerHTML}
      <details open><summary>Premissas e base legal</summary>${$('#premissas ol').outerHTML}</details>
      </body></html>`;
    const w = window.open('', '_blank');
    if (!w) { toast('O navegador bloqueou a janela de impressão — libere pop-ups para o Hub.'); return; }
    w.document.open(); w.document.write(html); w.document.close();
    w.focus(); setTimeout(() => { try { w.print(); } catch (e) { } }, 350);
  }
  $('#btCopiar').addEventListener('click', () => {
    const t = textoResumo();
    const ok = () => toast('Resumo copiado');
    const fallback = () => { const ta = document.createElement('textarea'); ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); ok(); } catch (e) { toast('Selecione e copie manualmente'); } document.body.removeChild(ta); };
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(ok).catch(fallback); else fallback();
  });
  function migrar(r) {
    const base = estadoInicial(); const s = { ...base, ...r, orc: { ...base.orc, ...(r.orc || {}) }, emol: { ...base.emol, ...(r.emol || {}) } };
    s.inv = [0, 1].map(k => { const f = { ...novoFalecido('', k ? 'solteiro' : 'casado'), ...((r.inv || [])[k] || {}) }; f.conjuge = { nome: '', separadoFato: false, sumula377: false, ...(f.conjuge || {}) }; f.ascendentes = { ...base.inv[0].ascendentes, ...(f.ascendentes || {}) }; ['descendentes', 'colaterais', 'bens'].forEach(c => { if (!Array.isArray(f[c])) f[c] = []; }); f.descendentes.concat(f.colaterais).forEach(x => { if (!x.uid) x.uid = uid(); if (!Array.isArray(x.representantes)) x.representantes = []; x.representantes.forEach(y => { if (!y.uid) y.uid = uid(); }); }); if (!f.isentosVI) f.isentosVI = {}; return f; });
    s.doa = { ...novaDoacao(), ...(r.doa || {}) }; ['doadores', 'donatarios', 'bens'].forEach(c => { if (!Array.isArray(s.doa[c])) s.doa[c] = []; }); s.doa.donatarios.forEach(x => { if (!x.uid) x.uid = uid(); });
    return s;
  }
  $('#btRestaurar').addEventListener('click', () => { try { const r = JSON.parse(localStorage.getItem('itcmd-rascunho')); if (r && r.S) { S = migrar(r.S); renderForm(); calcular(); toast('Rascunho restaurado'); } } catch (e) { toast('Rascunho ilegível'); } $('#barraRascunho').classList.add('oculto'); });
  $('#btDescartar').addEventListener('click', () => { try { localStorage.removeItem('itcmd-rascunho'); } catch (e) { } $('#barraRascunho').classList.add('oculto'); });
  function salvarAuto(avisar) { try { localStorage.setItem('itcmd-rascunho', JSON.stringify({ S, em: Date.now() })); if (avisar) toast('Rascunho salvo neste navegador'); } catch (e) { if (avisar) toast('Não foi possível salvar aqui'); } }
  let toastTimer = null;
  function toast(m) { if (typeof window.toast === 'function') { try { window.toast(m); return; } catch (e) { } } const t = $('#itcToast'); if (!t) return; t.textContent = m; t.classList.add('ativo'); clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('ativo'), 2200); }

  /* ---------- Início ---------- */
  if (/claude\.ai|claudeusercontent|anthropic/.test(location.hostname)) $('#btImprimir').classList.add('oculto');
  let rascunho = null; try { rascunho = JSON.parse(localStorage.getItem('itcmd-rascunho')); } catch (e) { }
  if (rascunho && rascunho.S) { S = exemplo(); $('#barraRascunho').classList.remove('oculto'); } else S = exemplo();
  renderForm(); calcular();
  window.ITCMD_UI = { get estado() { return S; }, set estado(v) { S = v; renderForm(); calcular(); }, calcular, textoResumo, get ultimo() { return ULT; } };
})();
