// Servidor de TESTE: reproduz o que o server.js real faz de relevante para o hub
// (CORS, parser pequeno, /login, /definir-senha, /logout) e monta o hub.js de verdade.
'use strict';
process.env.DATABASE_URL = process.env.DATABASE_URL || 'postgres://postgres@127.0.0.1:54329/postgres';
process.env.GEMINI_API_KEY = process.env.GEMINI_API_KEY === undefined ? 'chave-de-teste' : process.env.GEMINI_API_KEY;
const express = require('express');
const crypto = require('crypto');
const db = require('./backend/db');
const gemini = require('./backend/gemini');
const app = express();
const jsonPequeno = express.json({ limit: '256kb' });
app.use((req, res, next) =>
  (req.path.startsWith('/agentes') || req.path.startsWith('/hub/')) ? next() : jsonPequeno(req, res, next));
app.use((req, res, next) => {
  res.set('Access-Control-Allow-Origin', '*');
  res.set('Access-Control-Allow-Headers', 'Content-Type, X-Hub-Key, X-Auth-Token, X-Admin-Key');
  res.set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});
const hash = s => crypto.createHash('sha256').update(s).digest('hex');
app.post('/login', async (req, res) => {
  const { login, senha } = req.body || {};
  const u = await db.buscarUsuario(login);
  if (!u) return res.status(401).json({ erro: 'usuário ou senha inválidos' });
  if (!u.senha_hash) return res.json({ primeiro_acesso: true });
  if (!senha || hash(senha) !== u.senha_hash) return res.status(401).json({ erro: 'usuário ou senha inválidos' });
  const token = crypto.randomBytes(24).toString('hex');
  await db.criarSessao(token, u.login);
  res.json({ token, nome: u.nome, cargo: u.cargo });
});
app.post('/definir-senha', async (req, res) => {
  const { login, senha } = req.body || {};
  const u = await db.buscarUsuario(login);
  if (!u) return res.status(401).json({ erro: 'usuário inválido' });
  if (u.senha_hash) return res.status(409).json({ erro: 'senha já definida — use o login normal' });
  if (!senha || senha.length < 8) return res.status(400).json({ erro: 'a senha deve ter no mínimo 8 caracteres' });
  await db.gravarSenha(u.login, hash(senha));
  const token = crypto.randomBytes(24).toString('hex');
  await db.criarSessao(token, u.login);
  res.json({ token, nome: u.nome, cargo: u.cargo });
});
app.post('/logout', async (req, res) => { const t = req.get('X-Auth-Token'); if (t) await db.encerrarSessao(t); res.json({ ok: true }); });
if (!process.env.SEM_HUB) app.use('/hub', require('./backend/hub'));
app.get('/saude', (_req, res) => res.json({ ok: true }));
// rotas só de teste
app.get('/__teste/chamadas', (req, res) => res.json(gemini._chamadas));
app.post('/__teste/derrubar-sessoes', (req, res) => { db._sessoes.clear(); res.json({ ok: true }); });
app.post('/__teste/senha', (req, res) => { const u = db._usuarios.get(req.body.login); u.senha_hash = hash(req.body.senha); res.json({ ok: true }); });
const porta = Number(process.env.PORTA || 3999);
app.listen(porta, () => console.log('servidor de teste em', porta));
