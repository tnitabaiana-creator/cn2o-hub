// MOCK do whats.js (teste local): não dispara WhatsApp.
'use strict';
const fs = require('fs');
async function dispararRecibos(p, numero) { let l = []; try { l = JSON.parse(fs.readFileSync('/tmp/whats-chamadas.json', 'utf8')); } catch (e) {} l.push({ numero, ato: p.ato, dest: p.recibo_destinatarios }); fs.writeFileSync('/tmp/whats-chamadas.json', JSON.stringify(l)); }
module.exports = { dispararRecibos, ATO_NOME: {} };
