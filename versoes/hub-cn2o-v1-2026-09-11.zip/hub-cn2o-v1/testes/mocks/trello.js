// MOCK do trello.js (teste local): mesmas exportações; grava as chamadas, não toca o Trello real.
'use strict';
const fs = require('fs');
const ARQ = '/tmp/trello-chamadas.json';
function reg(nome, args) { let l = []; try { l = JSON.parse(fs.readFileSync(ARQ, 'utf8')); } catch (e) {} l.push({ nome, args }); fs.writeFileSync(ARQ, JSON.stringify(l)); }
let seq = 0;
module.exports = {
  t: async () => { throw new Error('mock'); },
  camposDoQuadro: async () => ({}),
  labelsDoQuadro: async (b) => { reg('labelsDoQuadro', [b]); return { 'Urgente': 'lbl-urg', 'Doc. pendente': 'lbl-doc', 'Santa Mônica': 'lbl-sm', 'Construtor': 'lbl-con', 'Corretor': 'lbl-cor', 'Advogado': 'lbl-adv', 'Loteador/Incorporador': 'lbl-lot' }; },
  criarCartao: async (x) => { reg('criarCartao', [x]); seq++; return { id: 'card-teste-' + seq, shortUrl: 'https://trello.com/c/TESTE' + seq }; },
  aplicarCampos: async (...a) => { reg('aplicarCampos', a); },
  criarChecklistDossie: async (...a) => { reg('criarChecklistDossie', a); },
  temPendenciaDossie: async () => false,
  aplicarLabelsPorNome: async (...a) => { reg('aplicarLabelsPorNome', a); },
  aplicarCapa: async (...a) => { reg('aplicarCapa', a); },
  cartoesDaLista: async () => [],
  obterCartao: async () => ({})
};
