// MOCK do db.js real (só para testes): mesma interface usada pelo server.js e hub.js.
'use strict';
const usuarios = new Map([
  ['cesar.bravo', { login: 'cesar.bravo', nome: 'César Bravo', cargo: 'Tabelião', senha_hash: null }],
  ['josilene.santos', { login: 'josilene.santos', nome: 'Josilene Santos', cargo: 'Escrevente', senha_hash: null }],
  ['camily.lima', { login: 'camily.lima', nome: 'Camily Lima', cargo: 'Escrevente', senha_hash: null }]
]);
const sessoes = new Map();
module.exports = {
  _usuarios: usuarios, _sessoes: sessoes,
  async init() {},
  async buscarUsuario(login) { return usuarios.get(String(login || '').trim()) || null; },
  async gravarSenha(login, hash) { const u = usuarios.get(login); if (u) u.senha_hash = hash; },
  async criarSessao(token, login) { sessoes.set(token, { login, criada: Date.now() }); },
  async sessaoValida(token) {
    const s = sessoes.get(token); if (!s) return null;
    const u = usuarios.get(s.login); return u ? { login: u.login, nome: u.nome } : null;
  },
  async encerrarSessao(token) { sessoes.delete(token); }
};
