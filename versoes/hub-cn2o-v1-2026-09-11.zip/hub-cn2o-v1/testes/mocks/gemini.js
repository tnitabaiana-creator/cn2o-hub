// MOCK do gemini.js (teste local): mesmas exportações do real; executar() simulado.
'use strict';
const fs = require('fs');
const ARQ = process.env.GEMINI_LOG || '/tmp/gemini-chamadas.json';
const MODELO_REDACAO = 'gemini-3.8-flash', MODELO_EXTRACAO = 'gemini-3.5-flash-lite';
const PRECOS = { 'gemini-3.8-flash': [0.75, 3.75] };
function registrar(x) { let l = []; try { l = JSON.parse(fs.readFileSync(ARQ, 'utf8')); } catch (e) {} l.push(x); fs.writeFileSync(ARQ, JSON.stringify(l)); }
async function executar({ agente, arquivos = [], campos = {}, observacoes, modelo }) {
  if (!process.env.GEMINI_API_KEY) throw new Error('GEMINI_API_KEY não configurada nas variáveis do serviço');
  registrar({ prompt: agente.prompt_sistema, temperatura: agente.temperatura, usa_busca: agente.usa_busca,
    arquivos: arquivos.map(a => ({ mime: a.mime, tam: Buffer.from(a.base64, 'base64').length, cabeca: Buffer.from(a.base64, 'base64').slice(0, 5).toString('latin1') })),
    observacoes, modelo });
  await new Promise(r => setTimeout(r, Number(process.env.MOCK_ATRASO_MS || 1200)));
  if (/FORCAR_ERRO/.test(observacoes || '')) throw new Error('Gemini gemini-3.8-flash 500: {"error":{"message":"falha simulada"}}');
  const ehMatricula = /Analista de Matrículas/.test(agente.prompt_sistema || '');
  const texto = ehMatricula
    ? 'EXTRATO DA SITUAÇÃO JURÍDICA DO IMÓVEL — MATRÍCULA Nº 8.412\n\n1. IDENTIFICAÇÃO — Matrícula 8.412 (teste).\n2. TITULARIDADE ATUAL — JOSÉ RAIMUNDO SANTOS BISPO.\n10. CONCLUSÃO — APTO COM RESSALVAS (penhora vigente).\n\n===DESCRICAO_COPIAVEL===\nUma casa residencial situada na Rua Coronel Sebastião, nº 156, Bairro Centro, nesta cidade, com área total de 240,00m².\n===FIM_DESCRICAO==='
    : 'QUALIFICAÇÃO PRONTA\n\nMARÍLIA FONTES DE JESUS, brasileira, solteira, maior, farmacêutica, portadora da cédula de identidade RG nº 3.845.216 – SSP/SE, inscrita no CPF/MF sob o nº 054.318.276-90.\n\n⚠ CONFERIR\n- Nada a apontar nos textos fornecidos.';
  const uso = { texto, modelo: modelo || MODELO_REDACAO, tokens_entrada: 1234 + arquivos.length * 1000, tokens_saida: 321, custo_usd: 0.0021, finish: 'STOP' };
  return { texto, uso };
}
const naoUsado = async () => { throw new Error('mock: não usado nos testes do hub'); };
module.exports = { extrair: naoUsado, redigir: naoUsado, revisar: naoUsado, executar, listarModelos: naoUsado,
  custoUsd: () => 0, MODELO_EXTRACAO, MODELO_REDACAO, PRECOS };
