"""E2E do Hub dos Escreventes (Chromium headless) contra o servidor de teste.

Roda o fluxo completo: login e primeiro acesso, mural, modo do Tabelião com o
editor de texto rico, aniversariantes, metas, histórico, Extrator e Analista com
anexos (foto, PDF, print colado), erros, sessão expirada, ferramenta embutida.
"""
import json, os, sys, time, urllib.request
from playwright.sync_api import sync_playwright

SITE = os.environ.get('SITE', 'http://127.0.0.1:8088/')
API = os.environ.get('API', 'http://127.0.0.1:3999')
SHOTS = os.environ.get('SHOTS', '/tmp/claude-0/-home-claude/1420be19-29c6-5b17-b90b-a63024aaf784/scratchpad/shots')
ARQ = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'arquivos')
os.makedirs(SHOTS, exist_ok=True)
ok = falhas = 0
erros_console = []

PAGINA = {}
def passo(nome, fn):
    global ok, falhas
    try:
        fn(); ok += 1; print('  ✓', nome)
    except Exception as e:
        falhas += 1; print('  ✗', nome, '→', repr(e)[:400])
        pg = PAGINA.get('pg')
        if pg:
            try:
                pg.screenshot(path=SHOTS + '/falha-' + str(falhas) + '.png')
                pg.evaluate("document.querySelectorAll('.veu.aberto').forEach(v => v.classList.remove('aberto'))")
            except Exception:
                pass

def api(caminho, corpo=None, token=None):
    req = urllib.request.Request(API + caminho, method='POST' if corpo is not None else 'GET')
    if corpo is not None:
        req.add_header('Content-Type', 'application/json'); req.data = json.dumps(corpo).encode()
    if token: req.add_header('X-Auth-Token', token)
    try:
        with urllib.request.urlopen(req) as r: return r.status, json.loads(r.read() or b'null')
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b'null')

import subprocess
def sql(comando):
    return subprocess.run(['psql', '-h', '127.0.0.1', '-p', '54329', '-U', 'postgres', '-d', 'cn2o', '-At', '-c', comando], capture_output=True, text=True, check=True).stdout
def chamadas():
    with open('/tmp/gemini-chamadas.json', encoding='utf-8') as f: return json.load(f)
def garantir_senha(login, senha):
    st, r = api('/login', {'login': login, 'senha': senha})
    if st == 200 and r.get('primeiro_acesso'):
        st, r = api('/definir-senha', {'login': login, 'senha': senha})
    return st

def esperar(cond, seg=8, msg='condição'):
    fim = time.time() + seg
    while time.time() < fim:
        if cond(): return
        time.sleep(0.1)
    raise AssertionError('tempo esgotado: ' + msg)

with sync_playwright() as p:
    nav = p.chromium.launch()
    ctx = nav.new_context(viewport={'width': 1366, 'height': 900}, locale='pt-BR', reduced_motion='reduce')
    # o container não alcança o Google Fonts: corta na hora para não travar o carregamento
    ctx.route('**/*', lambda r: r.abort() if ('fonts.googleapis' in r.request.url or 'fonts.gstatic' in r.request.url) else r.continue_())
    ctx.grant_permissions(['clipboard-read', 'clipboard-write'], origin=SITE.rstrip('/'))
    pg = ctx.new_page()
    pg.set_default_timeout(15000)
    PAGINA['pg'] = pg
    pg.on('console', lambda m: erros_console.append(m.text) if m.type == 'error' else None)
    pg.on('pageerror', lambda e: erros_console.append('pageerror: ' + str(e)))

    print('E2E — login e primeiro acesso')
    pg.goto(SITE); pg.wait_for_selector('#telaLogin:not([hidden])')
    def login_errado():
        # a senha da Camily é criada pelo teste de API; aqui usamos um usuário que já tem senha
        garantir_senha('camily.jesus', 'senha-camily-1')
        pg.fill('#campoLogin', 'camily.jesus'); pg.fill('#campoSenha', 'errada'); pg.click('#btnEntrar')
        pg.wait_for_selector('#msgLogin:not([hidden])')
        assert 'não conferem' in pg.inner_text('#msgLogin')
    passo('senha errada → "Usuário ou senha não conferem"', login_errado)

    def primeiro_acesso():
        pg.fill('#campoLogin', 'Josi.Silva '); pg.fill('#campoSenha', ''); pg.click('#btnEntrar')
        pg.wait_for_selector('#formPrimeiro:not([hidden])')
        assert pg.inner_text('#nomePrimeiro') == 'josi.silva'
        pg.fill('#senhaNova', 'curta'); pg.fill('#senhaConf', 'curta'); pg.click('#btnCriarSenha')
        assert '8 caracteres' in pg.inner_text('#msgPrimeiro')
        pg.fill('#senhaNova', 'senha-josi-2026'); pg.fill('#senhaConf', 'senha-josi-2027'); pg.click('#btnCriarSenha')
        assert 'não são iguais' in pg.inner_text('#msgPrimeiro')
        pg.fill('#senhaConf', 'senha-josi-2026'); pg.click('#btnCriarSenha')
        pg.wait_for_selector('#app:not([hidden])')
        assert 'Josilene' in pg.inner_text('#saudacao')
        assert pg.is_hidden('#btnEditarMural')
    passo('primeiro acesso cria senha (valida tamanho e confirmação) e entra', primeiro_acesso)

    def mural_inicial():
        pg.wait_for_selector('#muralAvisos .aviso-row')
        assert 'Comunicado Geral' in pg.inner_text('#muralAvisos')
        assert pg.locator('#muralAvisos .aviso-row.novo').count() == 1, 'sem marca de novo'
        assert '1 novo' in pg.text_content('#pillAvisos'), pg.text_content('#pillAvisos')
        pg.click('#muralAvisos .aviso-row')
        pg.wait_for_selector('#veuMural.aberto .sub-texto.rico b')
        assert 'Bem-vindo' in pg.inner_text('.sub-texto.rico b')
        assert 'César Bravo' in pg.inner_text('.sub-assina')
        pg.screenshot(path=SHOTS + '/01-aviso-aberto.png')
        pg.keyboard.press('Escape')
        esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='fechar subpágina')
        assert pg.locator('#muralAvisos .aviso-row.novo').count() == 0, 'continua novo'
        assert 'Em destaque' in pg.text_content('#pillAvisos'), pg.text_content('#pillAvisos')
    passo('mural: aviso "novo", abre subpágina rica, some o "novo" depois de lido', mural_inicial)

    def sessao_persistida():
        pg.reload(); pg.wait_for_selector('#app:not([hidden])')
        assert 'Josilene' in pg.inner_text('#saudacao')
    passo('recarregar a página mantém a sessão', sessao_persistida)

    def sair_e_entrar_cesar():
        pg.click('#btnSair'); pg.wait_for_selector('#telaLogin:not([hidden])')
        garantir_senha('cesar.bravo', 'senha-cesar-123')
        pg.fill('#campoLogin', 'cesar.bravo'); pg.fill('#campoSenha', 'senha-cesar-123'); pg.click('#btnEntrar')
        pg.wait_for_selector('#app:not([hidden])')
        assert pg.is_visible('#btnEditarMural')
    passo('sair → entrar como Tabelião → botão "Editar mural" aparece', sair_e_entrar_cesar)

    print('E2E — modo do Tabelião e editor de texto rico')
    def novo_aviso_formatado():
        pg.click('#btnEditarMural'); pg.wait_for_selector('#veuMural.aberto .ed-abas')
        pg.click('#edNovoAviso'); pg.wait_for_selector('#edAvEditor .rico-area')
        pg.fill('#edAvTitulo', 'Plantão de sábado')
        pg.click('[data-estilo="importante"]'); pg.check('#edAvFixado')
        area = pg.locator('#edAvEditor .rico-area')
        area.click()
        pg.keyboard.type('Atenção equipe: plantão neste sábado das 8h às 12h.')
        # seleciona "plantão" e aplica negrito
        def selecionar(palavra):
            pg.evaluate('''(p) => { const a = document.querySelector('#edAvEditor .rico-area');
              const w = document.createTreeWalker(a, NodeFilter.SHOW_TEXT); let n;
              while ((n = w.nextNode())) { const i = n.nodeValue.indexOf(p);
                if (i >= 0) { const r = document.createRange(); r.setStart(n, i); r.setEnd(n, i + p.length);
                  const s = getSelection(); s.removeAllRanges(); s.addRange(r); a.dispatchEvent(new Event('mouseup')); return; } } }''', palavra)
        selecionar('plantão'); pg.click('#edAvEditor [data-cmd="bold"]')
        selecionar('8h às 12h'); pg.click('#edAvEditor [data-acao="marca"]')
        selecionar('Atenção equipe'); pg.click('#edAvEditor [data-acao="vinho"]')
        pg.keyboard.press('End'); pg.keyboard.press('Enter')
        pg.click('#edAvEditor [data-cmd="insertUnorderedList"]')
        pg.keyboard.type('Trazer crachá'); pg.keyboard.press('Enter'); pg.keyboard.type('Chegar 7h50')
        pg.click('#edAvEditor [data-acao="emoji"]'); pg.click('#edAvEditor [data-emoji="📌"]')
        pg.screenshot(path=SHOTS + '/02-editor-rico.png')
        pg.click('#edAvSalvar')
        pg.wait_for_selector('.ed-item.fixado')
        assert 'pendente' in pg.get_attribute('#edStatus', 'class')
        pg.click('#edPublicar')
        esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='publicar fecha o editor')
        pg.wait_for_selector('#toast:not([hidden])')
        assert 'publicado' in pg.inner_text('#toast')
    passo('cria aviso Importante + fixado com negrito, destaque, cor vinho, lista e emoji; publica', novo_aviso_formatado)

    def conferir_html_salvo():
        tok = pg.evaluate("localStorage.getItem('cn2o_token')")
        st, r = api('/hub/mural', token=tok)
        av = r['dados']['avisos'][0]
        h = av['html']
        assert av['titulo'] == 'Plantão de sábado' and av['estilo'] == 'importante' and av['fixado'] is True, av
        assert '<b>plantão</b>' in h, h
        assert '<mark>8h às 12h</mark>' in h, h
        assert 't-vinho' in h, h
        assert '<ul><li>Trazer crachá</li><li>Chegar 7h50📌</li></ul>' in h or ('<li>Trazer crachá</li>' in h and '📌' in h), h
        assert 'style=' not in h and 'font' not in h, h
        print('     html salvo:', h[:220])
    passo('HTML gravado no servidor: só tags/classes permitidas (b, mark, t-vinho, ul/li)', conferir_html_salvo)

    def mural_mostra_fixado():
        first = pg.locator('#muralAvisos .aviso-row').first
        assert 'Plantão de sábado' in first.inner_text()
        assert 'fixado' in first.get_attribute('class') and 'importante' in first.get_attribute('class')
        first.click(); pg.wait_for_selector('.sub-selo.importante')
        assert pg.locator('.sub-texto.rico mark').count() == 1
        assert pg.locator('.sub-texto.rico .t-vinho').count() >= 1
        pg.screenshot(path=SHOTS + '/03-aviso-formatado.png')
        pg.keyboard.press('Escape')
    passo('mural: aviso fixado vem primeiro, selo "Importante" e formatação renderizada', mural_mostra_fixado)

    def editar_aviso_existente():
        pg.click('#btnEditarMural'); pg.wait_for_selector('.ed-abas')
        pg.click('[data-edita="0"]'); pg.wait_for_selector('#edAvEditor .rico-area')
        assert pg.input_value('#edAvTitulo') == 'Plantão de sábado', pg.input_value('#edAvTitulo')
        nb = pg.locator('#edAvEditor .rico-area b').count()
        assert nb == 1, 'negritos no editor: %d · %s' % (nb, pg.inner_html('#edAvEditor .rico-area'))
        pg.fill('#edAvTitulo', 'Plantão de sábado (confirmado)')
        pg.click('#edAvSalvar'); pg.click('#edPublicar')
        esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='publicar')
        assert 'confirmado' in pg.text_content('#muralAvisos'), pg.text_content('#muralAvisos')
    passo('edita aviso existente mantendo a formatação e republica', editar_aviso_existente)

    def aniversariantes_lote():
        pg.click('#btnEditarMural'); pg.click('[data-aba="aniversariantes"]')
        hoje = time.localtime()
        pg.fill('#edAnLote', f'Josilene - {hoje.tm_mday:02d}/{hoje.tm_mon:02d}\nCamily – 28/{hoje.tm_mon:02d}\nLara: 05/{(hoje.tm_mon % 12) + 1:02d}\nlinha ruim')
        pg.click('#edAnLoteAdd')
        assert pg.locator('.ed-item').count() == 3
        pg.click('#edPublicar'); esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='publicar')
        assert pg.locator('#muralAniversariantes li.hoje').count() == 1
        assert 'Camily' in pg.inner_text('#muralAniversariantes')
        pg.click('[data-sub="aniversariantes"]'); pg.wait_for_selector('#veuMural.aberto')
        assert 'Lara' in pg.inner_text('#subConteudo')
        pg.keyboard.press('Escape')
    passo('aniversariantes colados em lote (linha ruim avisada); "hoje!" destacado; próximo mês na subpágina', aniversariantes_lote)

    def metas_ativas():
        pg.click('#btnEditarMural'); pg.click('[data-aba="metas"]')
        pg.fill('#edMtTitulo', '120 atos lavrados em setembro'); pg.fill('#edMtProg', '65'); pg.fill('#edMtPremio', 'Almoço da equipe')
        pg.click('#edMtAdd'); pg.uncheck('#edMtBreve')
        pg.click('#edPublicar'); esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='publicar')
        assert pg.locator('#muralMetas .meta-item').count() == 1
        assert '65%' in pg.inner_text('#muralMetas')
        w = pg.evaluate("document.querySelector('#muralMetas .meta-barra i').style.width")
        assert w == '65%', w
    passo('metas: cadastra meta com prêmio, tira o "EM BREVE" e a barra aparece no cartão', metas_ativas)

    def historico_e_conflito():
        pg.click('#btnEditarMural'); pg.click('[data-aba="historico"]')
        pg.wait_for_selector('[data-carrega]')
        n = pg.locator('[data-carrega]').count(); assert n >= 4, n
        # alguém publica "por fora" enquanto o editor está aberto → 409 tratado
        tok = pg.evaluate("localStorage.getItem('cn2o_token')")
        st, atual = api('/hub/mural', token=tok)
        st2, _ = api('/hub/mural', {'dados': atual['dados'], 'base': atual['atualizado_em']}, token=tok)
        assert st2 == 200
        pg.click('[data-aba="avisos"]'); pg.click('[data-fixa="0"]'); pg.click('#edPublicar')
        pg.wait_for_function("document.getElementById('edStatus') && /alterado em outro lugar/.test(document.getElementById('edStatus').textContent)")
        pg.keyboard.press('Escape')
        pg.keyboard.press('Escape')
    passo('histórico lista as publicações; conflito de edição avisado e mural recarregado', historico_e_conflito)

    def fechar_com_alteracao_pendente():
        pg.click('#btnEditarMural'); pg.click('[data-fixa="0"]')
        pg.click('#subConteudo [data-fechar-sub]')
        assert pg.locator('#veuMural.aberto').count() == 1
        assert 'descartar' in pg.inner_text('#edStatus')
        pg.click('#subConteudo [data-fechar-sub]')
        esperar(lambda: pg.locator('#veuMural.aberto').count() == 0, msg='descartar')
    passo('fechar o editor com alteração pendente pede um segundo clique', fechar_com_alteracao_pendente)

    def xss_nao_renderiza():
        tok = pg.evaluate("localStorage.getItem('cn2o_token')")
        st, atual = api('/hub/mural', token=tok)
        d = atual['dados']
        d['avisos'].insert(0, {'titulo': 'Teste de segurança', 'html': '<p>ok<img src="x"><table><tr><td>célula</td></tr></table><a href="http://exemplo.com">link</a><video src="x"></video><font face="Comic Sans">fonte</font></p>'})
        st2, r = api('/hub/mural', {'dados': d, 'base': atual['atualizado_em']}, token=tok)
        assert st2 == 200, r
        pg.reload(); pg.wait_for_selector('#muralAvisos .aviso-row')
        pg.click('#muralAvisos .aviso-row:has-text("Teste de segurança")')
        pg.wait_for_selector('#veuMural.aberto .sub-texto.rico')
        assert pg.locator('.sub-texto.rico img, .sub-texto.rico table, .sub-texto.rico video, .sub-texto.rico font').count() == 0
        assert 'célula' in pg.text_content('.sub-texto.rico')
        a = pg.locator('.sub-texto.rico a')
        assert a.get_attribute('target') == '_blank' and 'noopener' in a.get_attribute('rel')
        assert pg.is_visible('body')
        pg.keyboard.press('Escape')
    passo('HTML indesejado gravado por fora não é renderizado (img/style/object caem; link seguro)', xss_nao_renderiza)

    print('E2E — ferramentas de IA')
    def extrator_texto():
        pg.click('#cardExtrator'); pg.wait_for_selector('#paginaExtrator:not([hidden])')
        assert pg.evaluate('location.hash') == '#extrator'
        esperar(lambda: 'IA ativa' in (pg.text_content('#paginaExtrator [data-chip-ia]') or ''), msg='chip IA ativa')
        pg.click('#btnExemploExt'); pg.click('#btnGerar')
        pg.wait_for_selector('#saidaExtrator .giro')
        pg.wait_for_function("document.getElementById('saidaExtrator').textContent.startsWith('QUALIFICAÇÃO PRONTA')", timeout=15000)
        assert pg.is_visible('#btnCopiarExt')
        meta = pg.inner_text('#metaExt'); assert 'Gemini 3.8 Flash' in meta and 'César' in meta, meta
    passo('Extrator: exemplo → Gerar → resultado, assinatura com modelo e botão Copiar', extrator_texto)

    def extrator_foto_grande():
        pg.click('#btnLimparExt')
        pg.set_input_files('#paginaExtrator .zona-anexos input[type=file]', os.path.join(ARQ, 'foto-celular.jpg'))
        pg.wait_for_selector('#paginaExtrator .anexo-item')
        tam = pg.inner_text('#paginaExtrator .anexo-tam')
        assert 'MB' in tam or 'KB' in tam
        info = pg.inner_text('#paginaExtrator .cont-anexos'); print('     foto 11 MB comprimida para:', info)
        pg.click('#btnGerar')
        pg.wait_for_function("document.getElementById('saidaExtrator').textContent.startsWith('QUALIFICAÇÃO PRONTA')", timeout=20000)
        ult = chamadas()[-1]
        assert ult['arquivos'][0]['mime'] == 'image/jpeg' and ult['arquivos'][0]['tam'] < 6 * 1024 * 1024, ult['arquivos']
        assert ult['observacoes'].startswith('(Sem texto colado')
    passo('Extrator: foto de celular de 11 MB é reduzida (≤ 2400 px) e chega como JPEG ao modelo', extrator_foto_grande)

    def analista_pdf_foto_print():
        pg.locator('[data-voltar]:visible').first.click(); pg.click('#cardAnalisador'); pg.wait_for_selector('#paginaAnalisador:not([hidden])')
        pg.set_input_files('#paginaAnalisador .zona-anexos input[type=file]', [os.path.join(ARQ, 'certidao.pdf'), os.path.join(ARQ, 'certidao-p1.png')])
        esperar(lambda: pg.locator('#paginaAnalisador .anexo-item').count() == 2, msg='2 anexos')
        assert pg.locator('#paginaAnalisador .anexo-thumb.pdf').count() == 1
        # print colado (Ctrl+V) com imagem no clipboard
        pg.evaluate('''async () => {
          const c = document.createElement('canvas'); c.width = 300; c.height = 120;
          const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0,0,300,120); g.fillStyle = '#000'; g.fillText('R.4/8.412 PENHORA', 20, 60);
          const b = await new Promise(r => c.toBlob(r, 'image/png'));
          const dt = new DataTransfer(); dt.items.add(new File([b], 'image.png', { type: 'image/png' }));
          document.body.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
        }''')
        esperar(lambda: pg.locator('#paginaAnalisador .anexo-item').count() == 3, msg='print colado')
        assert 'print colado' in pg.inner_text('#paginaAnalisador .anexo-lista')
        pg.screenshot(path=SHOTS + '/04-analista-anexos.png')
        pg.click('#btnAnalisar')
        pg.wait_for_selector('#descBox:not([hidden])', timeout=20000)
        assert 'Rua Coronel Sebastião' in pg.inner_text('#descTexto')
        assert '===DESCRICAO' not in pg.inner_text('#saidaAnalisador')
        ult = chamadas()[-1]
        assert [a['mime'] for a in ult['arquivos']] == ['application/pdf', 'image/png', 'image/png'], ult['arquivos']
        assert ult['arquivos'][0]['cabeca'] == '%PDF-'
        pg.screenshot(path=SHOTS + '/05-analista-resultado.png')
    passo('Analista: PDF + foto + print colado → extrato e "Descrição do imóvel" destacada', analista_pdf_foto_print)

    def colar_texto_nao_vira_anexo():
        n = pg.locator('#paginaAnalisador .anexo-item').count()
        pg.click('#entradaAnalisador')
        pg.evaluate('''() => { const dt = new DataTransfer(); dt.setData('text/plain', 'MATRÍCULA 123 texto');
          const c = document.createElement('canvas'); c.width = 10; c.height = 10;
          document.getElementById('entradaAnalisador').dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true })); }''')
        time.sleep(0.4)
        assert pg.locator('#paginaAnalisador .anexo-item').count() == n
    passo('colar TEXTO no campo não cria anexo', colar_texto_nao_vira_anexo)

    def erro_do_modelo():
        pg.click('#btnLimparAna'); pg.fill('#entradaAnalisador', 'FORCAR_ERRO')
        pg.click('#btnAnalisar')
        pg.wait_for_function("/A IA não conseguiu concluir/.test(document.getElementById('saidaAnalisador').textContent)", timeout=15000)
        assert (pg.text_content('#btnAnalisar') or '').strip() == 'Analisar matrícula', pg.text_content('#btnAnalisar')
    passo('falha do modelo mostra mensagem clara e libera o botão', erro_do_modelo)

    def interromper():
        pg.fill('#entradaAnalisador', 'qualquer'); pg.click('#btnAnalisar')
        pg.wait_for_selector('#saidaAnalisador .giro'); pg.click('#btnAnalisar')
        pg.wait_for_function("document.getElementById('saidaAnalisador').textContent === 'Interrompido.'")
    passo('botão Interromper cancela a análise em andamento', interromper)

    print('E2E — ferramentas embutidas, rotas e sessão')
    def protocolo_embutido():
        pg.locator('[data-voltar]:visible').first.click(); pg.click('#cardProtocolo')
        pg.wait_for_selector('#paginaEmbutida:not([hidden]) iframe')
        fr = pg.frame_locator('#molduraEmbutida iframe:not([hidden])')
        txt = fr.locator('#sessaoInfo').inner_text(timeout=8000)
        assert 'César Bravo' in txt and 'Tabelião' in txt and 'Hub dos Escreventes' not in txt, txt
        assert pg.get_attribute('#embutidaNovaAba', 'href') == 'protocolo.html'
        assert pg.evaluate('location.hash') == '#protocolo'
        pg.screenshot(path=SHOTS + '/06-protocolo-embutido.png')
        pg.go_back(); pg.wait_for_selector('#paginaHub:not([hidden])')
    passo('Protocolo abre embutido com a MESMA sessão; Voltar do navegador retorna ao hub', protocolo_embutido)

    def protocolar_de_verdade():
        pg.locator('[data-voltar]:visible').first.click() if pg.locator('[data-voltar]:visible').count() else None
        pg.click('#cardProtocolo'); pg.wait_for_selector('#paginaEmbutida:not([hidden])')
        fr = pg.frame_locator('#molduraEmbutida iframe:not([hidden])')
        fr.locator('.chip[data-ato="CV-Urbano"]').click()
        fr.locator('#veuCheck.aberto').wait_for()
        itens = fr.locator('#checkLista .ck-it.tick')
        n = itens.count()
        for i in range(min(3, n)): itens.nth(i).click()
        fr.locator('#veuCheck .fechar').click()
        fr.locator('#apresNome').fill('Corretor Teste da Silva')
        fr.locator('#apresTel').fill('(79) 99999-0000')
        fr.locator('#parteNome').fill('Comprador Teste de Souza')
        fr.locator('#enotT .op', has_text='Não').click()
        fr.locator('#enotA .op', has_text='Não').click()
        btn = fr.locator('#btnProt')
        esperar(lambda: btn.is_enabled(), msg='botão Protocolizar habilitar')
        btn.click()
        fr.locator('#veu.aberto').wait_for(timeout=15000)
        recibo = fr.locator('#reciboTxt').inner_text()
        assert 'Nº do protocolo: 1400' in recibo, recibo
        pg.screenshot(path=SHOTS + '/08-protocolo-recibo.png')
        num = sql("SELECT numero || '|' || usuario || '|' || coalesce(card_id,'') FROM protocolos ORDER BY numero DESC LIMIT 1").strip()
        assert num.startswith('1400|cesar.bravo|card-teste-'), num
        with open('/tmp/trello-chamadas.json', encoding='utf-8') as f: tr = json.load(f)
        cartao = [c for c in tr if c['nome'] == 'criarCartao'][-1]['args'][0]
        assert cartao['name'] == 'Prot. (CV-Urbano) 1400 - COMPRADOR TESTE DE SOUZA', cartao['name']
        campos = [c for c in tr if c['nome'] == 'aplicarCampos'][-1]['args'][2]
        assert campos['Escrevente'] == 'César Bravo', campos
        print('     protocolo 1400 registrado; cartão:', cartao['name'], '· escrevente (da sessão):', campos['Escrevente'])
        fr.locator('#veu .fechar').click()
        pg.locator('[data-voltar]:visible').first.click()
    passo('PROTOCOLO de ponta a ponta dentro do Hub: CV-Urbano → nº 1400 no banco, cartão (simulado) e escrevente da sessão', protocolar_de_verdade)

    def calculadora_embutida():
        pg.click('#cardCalculadora')
        pg.wait_for_selector('#paginaEmbutida:not([hidden])')
        fr = pg.frame_locator('#molduraEmbutida iframe:not([hidden])')
        assert fr.locator('body').inner_text(timeout=8000).strip() != ''
        pg.click('#paginaEmbutida [data-voltar]')
    passo('Calculadora abre embutida', calculadora_embutida)

    def rota_direta():
        pg.goto(SITE + '#analista'); pg.wait_for_selector('#paginaAnalisador:not([hidden])')
        pg.goto(SITE + '#protocolo'); pg.wait_for_selector('#paginaEmbutida:not([hidden])')
        pg.goto(SITE)
        pg.wait_for_selector('#paginaHub:not([hidden])')
    passo('atalhos diretos (#analista, #protocolo) abrem a ferramenta certa', rota_direta)

    def clausulas():
        pg.click('#cardClausulas'); pg.wait_for_selector('#veuClausulas.aberto')
        pg.click('.tema-cab >> nth=0'); pg.click('.clausula >> nth=0')
        pg.wait_for_selector('#toast:not([hidden])'); assert 'copiada' in pg.inner_text('#toast')
        pg.keyboard.press('Escape')
    passo('Cláusulas do Guia: abre tema e copia', clausulas)

    def sessao_expirada():
        sql('DELETE FROM sessoes')
        pg.click('#cardExtrator'); pg.click('#btnExemploExt'); pg.click('#btnGerar')
        pg.wait_for_selector('#telaLogin:not([hidden])', timeout=10000)
        assert 'expirou' in pg.inner_text('#msgLogin')
        assert pg.evaluate("localStorage.getItem('cn2o_token')") is None
    passo('sessão derrubada no servidor → volta ao login com "Sua sessão expirou"', sessao_expirada)

    def celular():
        m = nav.new_context(viewport={'width': 400, 'height': 860}, locale='pt-BR')
        m.route('**/*', lambda r: r.abort() if 'fonts.g' in r.request.url else r.continue_())
        mp = m.new_page(); mp.goto(SITE); mp.wait_for_selector('#telaLogin:not([hidden])')
        mp.fill('#campoLogin', 'cesar.bravo'); mp.fill('#campoSenha', 'senha-cesar-123'); mp.click('#btnEntrar')
        mp.wait_for_selector('#app:not([hidden])'); mp.wait_for_selector('#muralAvisos .aviso-row')
        larg = mp.evaluate('document.documentElement.scrollWidth')
        assert larg <= 402, larg
        mp.screenshot(path=SHOTS + '/07-celular.png', full_page=True)
        m.close()
    passo('tela de celular (400 px) sem rolagem horizontal', celular)

    pg.goto(SITE); pg.wait_for_selector('#telaLogin:not([hidden])')
    pg.fill('#campoLogin', 'cesar.bravo'); pg.fill('#campoSenha', 'senha-cesar-123'); pg.click('#btnEntrar')
    pg.wait_for_selector('#muralAvisos .aviso-row')
    pg.screenshot(path=SHOTS + '/00-hub-desktop.png', full_page=True)
    nav.close()

relevantes = [e for e in erros_console if 'Failed to load resource' not in e and 'fonts.g' not in e]
print(f'\n{ok} ok, {falhas} falha(s); erros de console relevantes: {len(relevantes)}')
for e in relevantes[:10]: print('   console:', e[:200])
sys.exit(1 if falhas else 0)
