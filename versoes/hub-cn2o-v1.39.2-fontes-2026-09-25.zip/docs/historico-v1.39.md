# Histórico de versões — Hub CN2O

*Cartório de Notas do 2º Ofício de Itabaiana/SE · Time CN2O · uso interno*

**Regra da casa:** toda alteração da plataforma tem o pacote guardado e registrado aqui, da mais nova para a mais antiga. Edições anteriores deste histórico: subpasta "Substituídos". O arquivo-mestre dos pacotes é a pasta **versoes/** do repositório cn2o-hub — ver o **Anexo D-1 — Inventário do arquivo de versões**, nesta mesma pasta.

## Onde está no ar

  - **Hub CN2O:** <https://cn2o-hub.netlify.app> (repo tnitabaiana-creator/cn2o-hub → Netlify). O site também serve **protocolo.html**, **calculadora.html** e **anexo.html** (v1.36).
  - **Servidor:** <https://cn2o-hub-backend-production.up.railway.app> (repo cn2o-hub-backend → Railway, projeto zestful-embrace, serviço cn2o-hub-backend).
  - **IA:** Gemini, **no plano pago desde 12/09/2026**. Modelos por variável: **HUB\_MODELO\_EXTRATOR** e **HUB\_MODELO\_MINUTAS** (Gerador de Minuta) → gemini-pro-latest; **HUB\_MODELO\_TRANSPOR** (transposição de dados; sem ela, segue o Extrator) → gemini-pro-latest; **HUB\_MODELO\_ANALISTA** → gemini-3.8-flash (escolha aferida; ver v1.23); **HUB\_MODELO\_REDATOR** → flash por padrão. Esperas de retentativa: HUB\_IA\_ESPERA\_MS. Tempo máximo de uma chamada: GEMINI\_TIMEOUT\_MS (padrão 180 s).
  - **OCR dedicado:** **Cloud Vision**, ligado pela variável **GCP\_VISION\_KEY**. Teto de páginas: OCR\_MAX\_PAGINAS (padrão 15). Limiar de confiança: DOCAI\_CONFIANCA\_MIN (padrão 0,80).
  - **Minuta no Google Docs (v1.29; formatação 1.1 na v1.30 — entrelinha 0,00):** o servidor cria o documento pelo Apps Script **CriadorDeMinutas — Hub CN2O** (conta tnitabaiana@gmail.com; implantação em versão 2) quando as variáveis **HUB\_DOCS\_WEBAPP\_URL** e **HUB\_DOCS\_SECRET** existem na Railway; sem elas, a minuta continua saindo só na tela. Espera máxima: HUB\_DOCS\_TIMEOUT\_MS (padrão 40 s). Pasta de destino: "Minutas Geradas — Casos" (propriedade PASTA\_ID do script).
  - **Pesquisa / Acervo (v1.33; ligado na v1.34):** o servidor lê as duas planilhas do acervo pelo Apps Script **LeitorAcervo — Hub CN2O** (conta tnitabaiana@gmail.com; implantação em versão 3, código 2.1.1, **escopo somente-leitura** — lê pela API do Google Sheets, não pelo SpreadsheetApp) quando **HUB\_ACERVO\_WEBAPP\_URL** e **HUB\_ACERVO\_SECRET** existem na Railway; cache de 10 min por fonte (HUB\_ACERVO\_CACHE\_MIN), espera máxima HUB\_ACERVO\_TIMEOUT\_MS (20 s). Propriedades do script: PLANILHA\_1\_ID (1º Ofício — SÉRGIO), PLANILHA\_2\_ID (2º Ofício — MILVO), HUB\_ACERVO\_SECRET.
  - **Trilha de auditoria (v1.34):** tabela hub\_auditoria no Postgres da Railway; retenção **HUB\_AUDITORIA\_DIAS** (padrão 730). Só o Tabelião lê (aba Auditoria do editor; exportação CSV).
  - **Recibo de protocolo por WhatsApp:** Meta Cloud API, template definido por **WHATS\_TEMPLATE\_RECIBO**. O **recibo.js e o whats.js são do Tabelião** (reescritos por ele em 17 e 18/09/2026): recibo\_protocolo\_3 com cinco variáveis na ordem data e hora · ato · parte · apresentante · número; os testes do Hub seguem essa ordem.
  - **Frases do Dia:** planilha "Frases do Dia — Hub CN2O (edite aqui)" nesta pasta.
  - **Relatórios das escreventes (v1.38):** tabelas eventos\_trello, passagens, pendencias, conclusoes, pesos\_ato, escreventes e envios\_relatorio no Postgres da Railway. O acompanhamento só grava com **TRELLO\_SECRET**. O e-mail sai pelo Apps Script **EnviarRelatorio** (pasta apps-script/ do servidor) com **RELATORIO\_EMAIL\_WEBAPP\_URL** e **RELATORIO\_EMAIL\_SECRET**. Sem **RELATORIO\_EMAIL\_PARA**, fica em homologação (só sergiolagofula2@gmail.com). Instalação: **RELATORIOS.md** do servidor. No ar desde 24/09/2026 (merge do PR #5 do servidor e do PR #1 do site).
  - **Atendimentos do balcão (v1.39):** o servidor do Hub consulta a API do NextQS direto, **sem n8n**. Precisa de **NEXTQS\_TOKEN** (Next Manager → API) na Railway. Coleta de segunda a sexta às 17h. Os dias ficam nas tabelas atendimentos\_dia e atendimentos\_status do Postgres. O PDF do mês anterior sai por e-mail às 7h do 1º dia útil, aos destinatários de RELATORIO\_EMAIL\_PARA. Na tela: aba Relatórios → **Atendimentos do balcão**. Os PDFs antigos, feitos pelo n8n, continuam no Drive, em "Relatórios de Atendimento — NextQS".
  - **Governança:** subpasta "Governança e segurança — Hub CN2O". O prompt do Gerador de Minuta é composto, no servidor, pelo **Prompt-Mestre BV 4.0 do Tabelião** (íntegro) e pela **camada de integração do Hub** — os dois vivem no pacote, em **docs/**, e são a fonte da verdade do card 05. O prompt da transposição de dados é **docs/prompt-transposicao.txt**.

## v1.39.2 — 25/09/2026 · Segurança, pacote B: exposição

**Pacote:** versoes/hub-cn2o-v1.39.2-fontes-2026-09-25.zip.
- **Servidor:** repo cn2o-hub-backend, branch seguranca-b-exposicao, empilhado sobre o pacote A.
- **Site:** entram o `netlify.toml` e o `404.html`. O index.html não muda.

  - **Código-fonte fora do ar:** o site servia `versoes/*.zip` (backend, prompts, auditorias) para quem tivesse o endereço. O `netlify.toml` passa a responder 404 em `/versoes/*`, e os pacotes continuam no repositório.
  - **Cabeçalhos do site** (`netlify.toml`, em todas as páginas):
    - **CSP:** conexões só com a Railway e o Google Docs das Frases do Dia; imagens só do próprio site, data: e blob:; iframe só do próprio site e do Google Agenda; formulários só para o próprio site; `object-src 'none'`, `base-uri 'none'` e `frame-ancestors 'self'`.
    - **Mais cabeçalhos:** nosniff, X-Frame-Options SAMEORIGIN, Referrer-Policy e Permissions-Policy.
    - **Scripts internos:** continuam permitidos de propósito. O e-Protocolo é editado direto no repositório, e uma CSP com hash quebraria a página a cada edição.
    - **Conferido:** com a mesma CSP no servidor de teste, o Hub, as abas do editor, Relatórios/Atendimentos, o Google Agenda, o e-Protocolo embutido, a Calculadora e o anexo carregam sem nenhum bloqueio.
  - **Cabeçalhos do servidor** (protecao.js):
    - nosniff, X-Frame-Options DENY, Referrer-Policy no-referrer, HSTS e uma CSP para a página Hub de Agentes.
    - Sem X-Powered-By.
    - CORS só para `https://cn2o-hub.netlify.app`; antes era `*`. Outras origens entram por `CORS_ORIGENS`.
  - **Erros:**
    - Um tratador global responde genérico: "falha interna", "requisição inválida" ou "arquivo grande demais", sem pilha e sem detalhe.
    - `/protocolo`, as listas públicas, relatórios e atendimentos deixam de devolver a mensagem interna nas respostas 500. O detalhe vai só para o log.
  - **WhatsApp:**
    - `/whats/status` era público e devolvia os telefones dos últimos envios; agora exige sessão de administrador e mascara os telefones (só os 4 últimos dígitos).
    - `/whats/testar` exige o mesmo, aceita só os templates da casa e entra na trilha.
    - A **HUB_KEY não vale mais para nada** e pode ser apagada da Railway.
  - **Corpo depois do login:** as rotas do Hub liam até 24 MB **antes** de conferir a sessão. Em 16 rotas o login vem primeiro; nas de admin, o login e o admin vêm antes.
  - **Webhook do Trello:** a re-hidratação, que escreve no Trello, só roda com a assinatura válida. Sem `TRELLO_SECRET`, roda só nos quadros da própria serventia.
  - **Testes:** 7 novos em test/protecao.test.js (cabeçalhos, CORS, erros sem detalhe, máscara, webhook, ordem login→corpo e rotas antigas fechadas). São 71 no total.

## v1.39.1 — 25/09/2026 · Segurança, pacote A: contas e login

**Pacote:** versoes/hub-cn2o-v1.39.1-fontes-2026-09-25.zip. **Servidor e site mudaram.** O servidor está no repo cn2o-hub-backend, branch seguranca-a-contas.

Primeiro pacote da varredura de segurança de 25/09/2026, feita com os agentes security-auditor e penetration-tester (OWASP Top 10:2025). Os quatro pacotes (A a D) foram aprovados pelo Tabelião.

  - **Crítico corrigido: tomada de conta pelo primeiro acesso.**
    - Como era: o `/definir-senha` pedia só o login. Qualquer pessoa na internet criava a senha de uma conta ainda sem senha e entrava com ela, inclusive na do Tabelião.
    - Como ficou: o primeiro acesso exige um **código de uso único**, válido por 48 h, que o Tabelião gera na aba Equipe (ao cadastrar, em "Gerar código" ou em "Zerar senha") e entrega em mãos. No banco fica só o hash do código. A senha é gravada numa única operação (UPDATE … WHERE sem senha AND código válido). O código aparece uma vez só, num quadro de destaque.
  - **Rota removida:** `/admin/resetar-senha`, com a HUB_KEY (o código dos balcões), zerava a senha de qualquer pessoa. Quem zera senha agora é o Tabelião, na aba Equipe, e o "zerar" já gera o código novo.
  - **Força bruta:**
    - 5 falhas por login ou 20 por IP em 15 min bloqueiam por 15 min (resposta 429, limites.js).
    - As falhas, os bloqueios e os primeiros acessos entram na trilha de auditoria, com a ação "Acesso".
    - O IP gravado na trilha passa a ser o `req.ip` atrás do proxy (trust proxy 1). Antes era o primeiro valor da X-Forwarded-For, que o cliente forja.
  - **Resposta única:** o `/login` responde igual, e no mesmo tempo, para usuário inexistente, conta sem senha e senha errada. Ele não diz mais quem está "sem senha".
  - **Senhas:**
    - O cálculo passa a ser assíncrono; o scryptSync travava o servidor a cada login.
    - Os parâmetros agora são os da OWASP (N=2^14, r=8, p=5).
    - Os hashes antigos continuam valendo e migram no próximo login certo.
    - O primeiro acesso recusa senha com menos de 8 caracteres ou que contenha o nome do usuário.
  - **Sessões:**
    - No banco fica só o SHA-256 do token.
    - As sessões antigas caem uma vez no deploy, então todos entram de novo.
    - As sessões vencidas são apagadas a cada login.
    - Gerar código ou zerar senha derruba as sessões da pessoa.
    - Uma falha do banco ao conferir a sessão responde 500 em vez de derrubar o processo.
  - **Emergência:** se o próprio Tabelião ficar sem acesso, a variável `HUB_CODIGO_ADMIN` na Railway (16+ caracteres) vale como código só para os administradores. Apague a variável depois de usar.
  - **Telas:**
    - A tela de entrada do Hub ganha o botão "Primeiro acesso ou senha zerada? Tenho um código", com os campos usuário, código e nova senha.
    - A página antiga "Hub de Agentes" (raiz da Railway) ganha o mesmo fluxo.
  - **Testes:** 12 testes novos em test/acesso.test.js, com o ataque original, código errado, vencido e reutilizado, força bruta por login e por IP, resposta única, migração do hash, emergência e logout. São 64 no total; o de integração pede Postgres.
  - **Conferido no navegador,** com a API simulada: mensagem única, "Tenho um código", código errado e certo, aba Equipe (situações, botões, quadro do código).

## v1.39 — 25/09/2026 · Atendimentos do balcão (NextQS) na aba Relatórios, sem n8n

**Pacote:** versoes/hub-cn2o-v1.39-fontes-2026-09-25.zip. **Servidor e site mudaram.**
- **Servidor:** repo cn2o-hub-backend, branch atendimentos-nextqs, empilhado sobre relatorios-nomes-claros (v1.38.4).
- **Site:** index.html.

Pedido do Tabelião: levar para o Hub o painel "Atendimentos · CN2O", que era um artifact do claude.ai alimentado pelo n8n, e fazer isso sem depender do n8n.

  - **Servidor**
    - **nextqs.js:** cliente da API do NextQS: `GET /v1/organization/reports`, token Bearer, 500 senhas por página. O 404 do NextQS significa período sem senhas. Faz 3 tentativas em falha de rede, 429 ou 5xx.
    - **atendimentos.js:** a mesma regra do workflow do n8n. As senhas viram um registro por dia, agrupado por fila, atendente, guichê e unidade.
      - Não atendida é a senha ausente ou nunca chamada até o fim do dia.
      - Espera é da emissão até a primeira chamada; atendimento é do início ao fim no guichê.
      - Registros com mais de 12 h, esquecidos abertos, não entram nos tempos.
      - Guarda a coleta, a carga do histórico (em janelas de 90 dias), o PDF e o e-mail do mês.
    - **atendimentos-pdf.js:** o PDF de 2 folhas do n8n, agora gerado no servidor.
    - **agendador.js:** coleta de segunda a sexta às 17h e PDF mensal às 7h do 1º dia útil.
    - **relatorio-email.js:** o anexo binário (o PDF) passa a seguir intacto.
    - **Testes:** 52 passam; o de integração pede Postgres.
  - **Site**
    - **A chave:** a aba Relatórios ganha a chave **Escreventes | Atendimentos do balcão**, e a última escolha fica guardada.
    - **O painel:** os seis números do período, atendidas por dia, filas e serviços, equipe, dia da semana, mês a mês, dia do mês (com início, meio e fim), horário de pico e detalhamento com CSV.
    - **O PDF do mês:** baixar ou enviar por e-mail, com confirmação em dois toques.
    - **Carga do histórico:** fica recolhida, para uso do suporte.
    - **Filtros:** período, fila, atendente e "Juntar filas de mesmo nome".
    - **A situação:** em linguagem simples, como na v1.38.3: "Em dia" ou avisos com "Avise o suporte".
    - Gráficos em SVG desenhados à mão, sem biblioteca, com texto escuro sobre claro.
  - **Conferido:**
    - No navegador, com as senhas fictícias passando pelo código real do servidor: filtros, dicas nos gráficos, o PDF baixado, a confirmação do envio, a situação sem token, a troca de visão e o celular com 400 px.
    - O build gera o index.html publicado (sem o comentário de versão do fim), e o protocolo.html e o anexo.html seguem inalterados.
  - **Antecedente:** a v1.38.5 (25/09, 12h28) punha os atendimentos na aba lendo um webhook do n8n ("CN2O · NextQS → dados para o Hub CN2O"). Foi revertida em seguida, e esta versão a substitui sem n8n.

## v1.38.4 — 25/09/2026 · Relatórios com nomes fáceis de entender

**Pacote:** versoes/hub-cn2o-v1.38.4-fontes-2026-09-25.zip. **Só o servidor mudou** (backend/, repo cn2o-hub-backend, branch relatorios-nomes-claros); o site segue o da v1.38.3.

Pedido do Tabelião: os nomes do e-mail ("Mesa", "Mesa P75", "Custo pessoal"…) eram de estatística. Os **cálculos não mudam**, só os nomes:

| Antes | Agora |
|---|---|
| Mesa | Tempo total |
| Mesa P75 · P75 (por tipo) | Mais demorados |
| Custo pessoal | Tempo de trabalho |
| Índice (de custo) | Tempo vs. equipe |
| Retorno | Voltou p/ ajuste |
| Pend. | Pendências |
| Afinidade | Onde rende mais e menos |
| Referência | Tempo esperado |

  - Vale para as tabelas, os destaques do topo, o perfil de cada escrevente, a legenda "Como ler" (reescrita), o texto simples do e-mail, as frases automáticas de leitura ("Tempo de trabalho 15% menor que o da equipe", "Rende mais em CV-Urbano (1,25× a equipe)") e os cabeçalhos do CSV (mesma ordem de colunas; "Tempo total (h)", "Tempo de trabalho (h)"…). "Afinidade" virou "Onde rende mais **e menos**" porque a linha mostra também, em vinho, os tipos em que ela rende menos.
  - RELATORIOS.md traz o nome novo e o campo interno de cada número. Teste novo garante os nomes novos e a ausência dos antigos no HTML e no texto; 45 testes passam (o de integração pede um Postgres).
  - **Também entra neste pacote** a correção do servidor ea0cb94 (25/09, PR #6 do servidor, sem pacote próprio): horas_mesa em reaberturas e o reconhecimento do tipo de ato pelo título (rastreio.js, relatorios.js, relatorio-email.js, tipos-ato.js e testes).

## v1.38.3 — 25/09/2026 · Aba Relatórios sem informação técnica

**Pacote:** versoes/hub-cn2o-v1.38.3-fontes-2026-09-25.zip. **Só o site mudou** (index.html); o servidor segue o mesmo.

Pedido do Tabelião: tirar da aba Relatórios o que só interessa a quem instala e mantém o sistema (webhook assinado, webhooks ativos, último movimento de cartão, provedor do e-mail, destinatários).

  - **Situação:** saíram as linhas técnicas e o número "Movimentos recebidos". Ficam "Atos concluídos", o último relatório e **uma** linha: "Tudo em ordem: os relatórios saem sozinhos por e-mail." Quando algo precisa de atenção, entram avisos em linguagem simples, sem nome de variável nem comando: acompanhamento do Trello com defeito (assinatura, webhooks faltando ou em outro endereço) → "precisa de um ajuste técnico. Avise o suporte."; e-mail sem provedor **ou em modo arquivo** (que não envia de verdade) → "não estão saindo por e-mail"; homologação → "estão em teste e vão só para …"; atos sem tipo reconhecido no título (esse continua, porque se resolve no Trello, pela equipe).
  - **Carga do histórico** (ferramenta de instalação) ficou recolhida no fim da aba, em "Carga do histórico (uso do suporte)". Continua funcionando igual quando aberta.
  - O detalhe técnico continua no JSON de `GET /hub/relatorios/status` (webhooks, outras\_urls, provedor, destinatários) e no script de manutenção dos webhooks.
  - Conferido no navegador com API simulada, nos cenários "tudo certo", "com defeito" e "webhook antigo + homologação", nos temas claro e escuro. O build gera o index.html publicado (sem o comentário de versão do fim); protocolo.html e anexo.html inalterados.

## v1.38.2 — 25/09/2026 · Atalho "Relatórios" na barra lateral, só para o Tabelião

**Pacote:** versoes/hub-cn2o-v1.38.2-fontes-2026-09-25.zip. **Só o site mudou** (index.html); o servidor segue o mesmo.

Pedido do Tabelião: chegar aos relatórios das escreventes com um clique, sem passar por ✎ Editar mural → aba Relatórios.

  - **frontend/src/corpo.html:** item **Relatórios** (ícone de barras) na barra lateral, entre "Agenda do Tabelião" e "Documentos". Nasce com `hidden`: nenhuma escrevente o vê, nem por um instante, antes de a sessão ser conferida.
  - **frontend/src/app.js:** `mostrarApp` mostra o item só com `SESSAO.admin` (o mesmo critério do botão Editar mural); `limparSessao` o esconde de novo (sair e sessão expirada). O clique vai para o Início, marca "Relatórios" e abre o Modo do Tabelião direto na aba Relatórios (`abrirEditorMural` ganhou o parâmetro da aba inicial; o botão ✎ Editar mural passou a chamá-la sem argumento, senão o evento do clique viraria a "aba" e o editor abriria vazio). Ao fechar o editor, a barra volta para "Início" **só** se ele tinha sido aberto por esse atalho: o Esc também passa por `fecharSubMural`, e não pode desmarcar a "Agenda do Tabelião" nem os outros itens.
  - A proteção de verdade continua no servidor: `/hub/relatorios/*` responde 403 a quem não é administrador. Se **RELATORIOS\_ADMINS** estiver gravada na Railway e não incluir todos os HUB\_ADMINS, quem ficou de fora vê o atalho (como já via a aba) mas recebe o aviso de que só o Tabelião vê os relatórios.
  - Conferido: o build deste pacote gera o index.html publicado (sem o comentário de versão do fim), e o protocolo.html e o anexo.html seguem idênticos aos publicados.

## v1.38.1 — 24/09/2026 · Consolidação do arquivo de versões (nada muda no ar)

**Pacote:** versoes/hub-cn2o-v1.38.1-fontes-2026-09-24.zip. **Nada mudou no site nem no servidor.**

Por que existe: a v1.37.5 (e-Protocolo) e a v1.38 (relatórios) foram feitas ao mesmo tempo, em sessões separadas, cada uma a partir da v1.37.4. No site as duas convivem sem conflito: a v1.37.5 mexeu só no protocolo.html, e a v1.38 só no index.html. Mas cada pacote de fontes ficou sem a mudança do outro. Este pacote junta os dois: fontes da v1.38 e protocolo.html, testes e capturas da v1.37.5. Daqui em diante, partir **deste** pacote.

  - Conferido: o build deste pacote gera o index.html publicado (merge bdacd9b, sem o comentário de versão do fim), e o protocolo.html é idêntico ao publicado.

## v1.38 — 24/09/2026 · Relatórios das escreventes (acompanhamento do Trello + e-mail semanal e mensal)

**Pacote:** versoes/hub-cn2o-v1.38-fontes-2026-09-24.zip. **Servidor e site mudaram.**
- **Servidor** (repo cn2o-hub-backend, branch relatorios-escreventes):
  - módulos novos: rastreio.js, db-relatorios.js, horas-uteis.js, tipos-ato.js, reports.js, relatorios.js, relatorio-email.js, agendador.js, carga\_retroativa.js, previa.js e apps-script/EnviarRelatorio.gs;
  - server.js: webhook, rotas e boot;
  - hub.js: uma linha, que expõe a trilha de auditoria.
- **Site** (repo cn2o-hub, branch relatorios-escreventes): app.js e estilo-extra.css, com a aba Relatórios do editor.
- **Testes:**
  - servidor: **54**, sendo 43 unitários e 11 de integração, com Postgres real e Trello simulado;
  - site: **22 verificações no Chrome**, em computador, 400 px e tema escuro, e com uma escrevente sem acesso.

**O que faz.**
- **Acompanhamento:** o webhook do Trello que o hub já recebia (quadros 00, 01 e 02-\*) passa a gravar cada movimento de cartão. O servidor calcula quanto tempo o ato ficou em cada lista, em horas úteis: expediente 08–12 e 13–17, sem feriados.
- **Envio automático:**
  - toda segunda-feira às 8h sai o relatório semanal;
  - no 1º dia útil do mês às 8h, o mensal;
  - o e-mail é HTML na identidade do CN2O, com CSV anexo;
  - uma trava no banco impede envio em dobro;
  - às 7h, uma reconciliação recupera o que o webhook tenha perdido.

**Aba Relatórios (Modo do Tabelião).** Mostra:
- **Situação:**
  - atos concluídos e movimentos recebidos;
  - se o webhook chega assinado e se algum quadro está sem webhook;
  - se o e-mail está configurado e se está em homologação;
  - o último relatório enviado.
- **Relatório:** Semanal ou Mensal, e o período numa lista (16 semanas ou 12 meses, já com as datas).
  - **Ver prévia** mostra o próprio e-mail, num quadro isolado.
  - **Baixar CSV** baixa a planilha do período.
  - **Enviar agora** pede confirmação em dois toques.
- **Envios:** o histórico, automáticos e manuais (com quem enviou).
- **Carga do histórico:** busca no Trello os movimentos desde uma data e mostra o andamento.

Prévia, envio e carga entram na trilha de auditoria (ação Administração, ferramenta Relatórios).

**Acesso.**
- Só administradores: `HUB_ADMINS`, ou `RELATORIOS_ADMINS` quando definida.
- Uma escrevente recebe 403 e nem vê o botão do editor.
- Com o servidor ainda sem a v1.38, a aba avisa "falta publicar o backend v1.38" em vez de quebrar.

**Para ligar (Railway):**
1. `TRELLO_SECRET`: o Segredo da mesma chave `TRELLO_KEY`.
2. Publicar apps-script/EnviarRelatorio.gs e gravar `RELATORIO_EMAIL_WEBAPP_URL` e `RELATORIO_EMAIL_SECRET`.
3. Rodar a carga do histórico, pela aba ou com `npm run carga`.
4. Para sair da homologação, preencher `RELATORIO_EMAIL_PARA`.

**Fica como está, de propósito.**
- A re-hidratação dos campos continua aceitando entrega sem assinatura, como antes. A assinatura decide só o que entra nos relatórios, para que um segredo errado não pare os quadros.
- Se as tabelas novas falharem no boot, o hub sobe sem os relatórios.

## v1.37.5 — 24/09/2026 · e-Protocolo: pessoa física, jurídica ou múltiplos (inclusive misto) na identificação

**Pacote:** versoes/hub-cn2o-v1.37.5-fontes-2026-09-24.zip. **Só o site mudou** (protocolo.html). Testes: **71 de ponta a ponta** e o auditor de opções do protocolo (734 opções, 0 violações de pacto, 0 falhas de dossiê); auditoria independente em duas rodadas — aprovada.

**Pedidos do Tabelião.** (1) Na compra e venda e na cessão de direitos hereditários, um botão de múltiplos ao lado de vendedor e ao lado de comprador, **sem campos por pessoa** — "quando da automação da minuta, ele vai extrair os vendedores e compradores, os múltiplos, da própria guia de ITBI"; os únicos campos digitados continuam sendo vendedor, apresentante e comprador. (2) Em todos os atos com comprador ou cessionário, a identificação não dizia se a parte é **pessoa física ou jurídica** — e os múltiplos podem ser **mistos** (PF e PJ); resolver em botões.

**Como ficou.** Em **CV-Urbano, CV-Rural, CDP e CDH**, a identificação ganhou, para cada polo, os botões **Pessoa física · Pessoa jurídica · Múltiplos vendedores/compradores** (cedentes/cessionários na cessão). Em "Múltiplos" abrem **composição** (Só pessoas físicas · Só pessoas jurídicas · **Misto — pessoas físicas e jurídicas**) e **quantos?** (2 a 15), com o aviso de que nomes e qualificação saem da guia de ITBI na geração da minuta (no CDP: da guia, se houver, ou da documentação; no CDH, os cedentes saem da guia — espólio — e das certidões). Nenhum campo por pessoa: nos múltiplos, o campo de nome recebe "Um deles". Na CV os botões do vendedor ficam no próprio quadro do vendedor; no CDP e no CDH os cedentes têm uma linha só com os botões (não há nome de cedente a digitar). São as mesmas respostas da triagem de antes: escolher **Pessoa física** abre, na triagem, estado civil e regime; pessoa jurídica e as composições trazem ao dossiê os documentos certos (contrato social, representação e certidão da Junta de cada PJ; RG/CPF e certidões de estado civil de todas as PF). As perguntas da identificação são **obrigatórias** para protocolizar (inclusive composição e quantidade nos múltiplos) — um aviso lista o que falta. O payload leva, por polo, `partes.transmitentes` / `partes.adquirentes` = { tipo, composição, fonte dos nomes }, que vai ao bloco de dados do cartão lido pela automação da minuta. A pergunta "quantos?" de todos os atos passou de 2–6 para 2–15, como a guia de ITBI. Doação e os demais atos não mudaram.

  - **Auditoria.** Primeira rodada: aprovada com ressalvas — sem a resposta obrigatória, o estado civil do comprador deixava de ser perguntado; "Múltiplos" sem composição passava com quantidade 1; cedentes do CDH fora; avisos com orientação errada; documentos que não batiam com a composição; rótulos internos no checklist. Tudo corrigido; segunda rodada: aprovada.
  - **Para a automação da minuta:** as chaves mudaram — o estado civil do adquirente não tem mais a opção "Múltiplos adquirentes" (nos quatro atos) e o CDH não tem mais `a_multi`/`t_multi`; usar `partes.transmitentes` e `partes.adquirentes` (tipo e composição) e `partes.qtd_*`.
  - Capturas: docs/protocolo-partes-v1.37.5/.

## v1.37.4 — 24/09/2026 · Guia de ITBI com até 15 adquirentes e 15 transmitentes

**Pacote:** versoes/hub-cn2o-v1.37.4-fontes-2026-09-24.zip. **Só o site mudou** (index.html: itbi.js, corpo.html, estilo-extra.css). Testes: **71 de ponta a ponta** (passo novo 15+15); auditoria independente em duas rodadas — aprovada.

**Pedido do Tabelião.** "Revise o layout da guia de ITBI para incluir múltiplos compradores e vendedores; inclua campos para o máximo de 15 vendedores e 15 compradores, abrindo tantos campos do formulário quantos forem suficientes para lançar os dados" — com a tela do e-Protocolo como referência (botão "Múltiplos transmitentes" e a pergunta "quantos?").

**Formulário.** Em cada polo, **"Um adquirente" / "Múltiplos adquirentes"** (e o mesmo para transmitentes). Em "Múltiplos" abre a nota com filete vinho e a pergunta **"Adquirentes — quantos?"** com os botões **2 a 15** (começa em 2); o formulário mostra um bloco de campos por pessoa. A tela não pula ao escolher — a pergunta continua à vista, e o leitor de tela ouve "N blocos abertos". A partir da 2ª pessoa, o botão **"Repetir o endereço do adquirente anterior"** copia endereço, município e CEP (inclusive o "não consta"). O **nome é obrigatório em todo bloco aberto** (bloco sobrando não vai em branco para a guia). A conferência dos campos em branco mostra primeiro os do imóvel e depois **uma linha por pessoa**.

**PDF.** Ordem de escolha: (1) o leiaute do modelo da Prefeitura numa página, descendo o corpo até 8,5 pt; (2) um leiaute compacto (duas linhas por pessoa) numa página, também até 8,5 pt; (3) muitas partes: compacto em **9 pt, em quantas páginas precisar** — cada pessoa inteira numa página, a seção reaberta com "(continuação)", "Guia de ITBI · Página N de M" no pé, e documentação + assinatura + avaliação + observações sempre juntas. Títulos: "1 – ADQUIRENTE(S) (n)" e "2 – TRANSMITENTE(ES) (n)" quando há mais de um. Números e documentos (CPF, CNPJ, áreas) nunca se partem no meio: descem inteiros para a linha de baixo. Aferido: 1+1 e 2+1 em 1 página a 10 pt; 2+2 a 9 pt; 3+3 a 8,5 pt; 5+5 e 7+7 em 2 páginas; 10+10 e 15+15 em 3 páginas; 1+15 em 2 páginas.

  - **Auditoria.** Primeira rodada: aprovada com ressalvas — CNPJ e "120,00" partidos no leiaute compacto, a tela pulando para o bloco 2 ao escolher "Múltiplos", uma página só com as Observações, corpo pequeno demais quando havia opção maior, blocos sem nome indo em branco, conferência com 164 linhas, rodapé perto da borda, rótulo em 13,5 px e blocos sem nome acessível. Tudo corrigido; segunda rodada: aprovada.
  - **Fica como está, de propósito:** diminuir o número de pessoas só esconde os blocos — os dados digitados ficam guardados e voltam se o número subir de novo (não entram na guia).
  - Capturas e um PDF de exemplo: docs/itbi-15-v1.37.4/.

## v1.37.3 — 24/09/2026 · Links úteis viram grade de ícones (como a tela de um celular)

**Pacote:** versoes/hub-cn2o-v1.37.3-fontes-2026-09-24.zip. **Só o site mudou** (index.html). Testes: **70 de ponta a ponta**; auditoria independente aprovada com ressalvas, todas corrigidas antes da publicação.

**Pedido do Tabelião.** Reformatar os Links úteis "como se fossem ícones de um smartphone. Apenas o símbolozinho e o nome abreviado embaixo", para que, "conforme formos agregando novos links úteis, o espaço seja melhor organizado e visualizado pelos usuários, tornando intuitivo o acesso mais pelo símbolo do que pela identificação". Nomes fixados por ele: **Emolumentos** (TJSE — guia de emolumentos), **e-Notariado**, **RI Digital**, **Links CNJ**, **CND** (Receita Federal) e **ITCMD** (Sefaz/SE); a **Prefeitura de Itabaiana saiu** da seção.

**Como ficou.** A lista virou uma grade alinhada à esquerda: símbolo de 72 px com cantos arredondados (62 px no telefone) e o nome curto embaixo, em Montserrat marinho de 14,5 px (14 px no telefone). A 1366 px cabem até sete ícones por linha; no telefone, três ou quatro. Link novo = um item a mais, sem mexer no resto. Passar o mouse levanta o símbolo; o nome por extenso aparece como dica do mouse e o leitor de tela lê o nome curto seguido do nome completo e da descrição. A busca do topo continua achando pelo nome por extenso ("Receita" mostra CND). O endereço de cada link não mudou. A sobreposição **Links CNJ** continua em lista.

**Correções da auditoria.** Nomes que se encostavam no telefone de 360 px (a coluna agora é de 92 px e o nome pode quebrar entre palavras, nunca no meio); contorno de foco do teclado invisível no tema escuro (agora branco); e, na sobreposição Links CNJ, dois defeitos antigos do tema escuro — nota clara e seta branca sobre o painel branco — mais as letras abaixo de 14 px (agora 14–15 px, texto marinho).

  - Teste de ponta a ponta reescrito para a grade: seis nomes e ordem, símbolo acima do nome, fonte ≥ 14 px, uma linha a 1366 px, Prefeitura ausente, endereços, busca por "Receita", foco branco no tema escuro, nenhum nome transbordando a 360 px e nenhuma rolagem horizontal.
  - Capturas: docs/links-icones-v1.37.3/.

## v1.37.2 — 23/09/2026 · CERT: a lista do que o solicitante pede, fixada pelo Tabelião

**Pacote:** versoes/hub-cn2o-v1.37.2-fontes-2026-09-23.zip. **Só o site mudou** (protocolo.html). Testes: 70 de ponta a ponta e 115 de API.

**Pedido do Tabelião.** "No campo 'O que o solicitante pede' do tipo de ato CERT liste apenas: Certidão do Ato (inteiro teor) · Certidão em breve relato · Certidão em quesitos · Certidão negativa · Outros. Refaça excluindo tudo que consta diferente da lista acima." Feito: o campo passou a ter exatamente essas cinco opções, nessa ordem (saíram "Traslado (2ª via)" e "Certidão de procuração"). Para o cartão não ficar mudo, **"Outros" abre um campo "Qual?"** e o pedido vai ao cartão e ao recibo como "Outros — <o que a escrevente escreveu>".

## v1.37.1 — 23/09/2026 · recibo próprio do CERT e instalação pelo Tabelião (campo "Preço ajustado", etiquetas do quadro 04, template na Meta)

**Pacote:** versoes/hub-cn2o-v1.37.1-fontes-2026-09-23.zip. **Só o servidor mudou** (server.js, hub.js, novo **recibo-cert.js**, .env.example, INSTALAR.md). Site igual à v1.37. Testes: **115 de API, 34 do recibo, 12 de OCR e 70 de ponta a ponta**; auditoria independente aprovada.

**Pedidos do Tabelião.** "Resolva a pendência 1, faça um template próprio para a CERT" e "Preço em coluna própria no Trello, crie o campo personalizado 'Preço ajustado' como texto nos quadros 00 e 02".

**Recibo próprio do CERT.** O `recibo_protocolo_3` rotula a pessoa do ato como "Comprador(a)" — num pedido de certidão o cliente leria "Comprador(a): FULANO". Nasceu o **recibo-cert.js**: cinco variáveis na ordem **data e hora · Pedido (espécie) · Solicitante · Ato procurado em nome de · Nº do protocolo**, montadas com o mesmo `campo()` do recibo.js do Tabelião (que ficou intocado, assim como o whats.js). O `/protocolo` usa o template próprio quando a variável **WHATS\_TEMPLATE\_CERT** existe na Railway, e envia **só ao solicitante** (a pessoa do ato é terceiro); sem a variável, o CERT segue pelo recibo comum, como antes. O texto do template vive no código (`definicaoTemplateCert`) e sai pronto pela rota `GET /hub/admin/whats/template-cert`; com **WHATS\_WABA\_ID** na Railway, `POST` na mesma rota cadastra o template pela API da Meta (o token precisa da permissão whatsapp\_business\_management). O cadastro em si depende do Tabelião: o WhatsApp Manager não está logado no Chrome e credencial é passo dele — guia na pasta de Governança ("Guia — template recibo\_certidao\_1 (CERT)"). `/whats/testar` com `ato=CERT` testa o recibo novo.

**Instalação pelo Tabelião (rotas de administrador, idempotentes).** O Trello no Chrome não respondeu à automação e o MCP do Trello não cria campos; a saída foi pôr as duas tarefas no próprio Hub, com a chave do Trello que já mora na Railway: `POST /hub/admin/trello/campo-preco` criou o campo personalizado **"Preço ajustado" (texto)** nos **sete quadros** por onde o cartão viaja (00, 01 e os cinco 02 — o servidor re-hidrata os campos a cada mudança de quadro), e `POST /hub/admin/trello/etiquetas-cert` criou as etiquetas **"Urgente"** e **"Doc. pendente"** no quadro 04 (as seis etiquetas de fábrica não tinham nome). Executadas em 23/09 pelo Hub logado como Tabelião; os cartões do CERT passam a ser sinalizados e o preço aparece em coluna própria (o servidor guarda a lista de campos em memória — vale a partir do reinício seguinte, que o próprio deploy desta versão provocou).

**Correção de segurança achada pelo teste novo.** As rotas `/admin/resetar-senha` e `/whats/testar` comparavam a chave com `process.env.HUB_KEY` e, sem a variável, `undefined !== undefined` deixava qualquer um passar (fail-open). Agora `chaveAdminOk`: sem HUB\_KEY configurada ninguém passa; com ela, só quem manda a chave igual.

  - Testes novos: 401/403 nas rotas de instalação sem tocar no Trello; campo criado nos 7 quadros e "já existia" na segunda chamada; etiquetas do quadro 04; GET/POST do template (400 sem WABA, nome inválido); CERT sem a variável vai pelo recibo comum; `/whats/testar` com CERT; as cinco variáveis do recibo próprio, reservas, definição do template (não começa nem termina por variável, ≤ 1024 caracteres, exemplo com 5 valores); HUB\_KEY fail-closed. Mocks do harness: trello.js responde customFields/labels; whats.js exporta enviarTemplate.

## v1.37 — 23/09/2026 · o servidor do CERT entra no ar (v1.36.1) e o e-Protocolo ganha o campo "Preço ajustado"

**Pacote:** versoes/hub-cn2o-v1.37-fontes-2026-09-23.zip. **Servidor mudou** (server.js, hub.js, atos.js, .env.example — fundidos sobre o servidor que o Tabelião alterou sozinho em 17 e 18/09; **recibo.js e whats.js dele ficaram intocados**). **Site mudou** (protocolo.html, anexo.html e index.html — o T-Consulta). Testes ao fim: **107 de API, 12 de OCR, 29 do recibo e 70 de ponta a ponta**, todos passando; auditoria independente em três passadas (aprovada).

**O que estava acontecendo.** A tela do CERT foi publicada em 17/09 (v1.36), mas o servidor correspondente — as rotas do anexo e o desvio do cartão para o quadro 04 — ficou no pacote e **nunca subiu** para a Railway. Na prática, desde 17/09 um pedido de certidão com anexo falhava no envio, e um pedido sem anexo criaria o cartão no quadro 00, com prazo de escritura. Nenhum cartão "Prot. (CERT)" chegou a ser criado nesse intervalo. Esta versão fecha a lacuna.

**Servidor do CERT (v1.36.1).** Fusão de três vias sobre o servidor de produção (base v1.34 → mudanças do Tabelião → CERT), conferida pelo auditor: o diff da produção só traz acréscimos. Entraram: tabela **hub\_cert\_anexos** (o documento fica no banco da serventia, nunca no Trello); **POST /hub/cert/anexos** e **GET /hub/cert/anexo/:id** (só com sessão); vínculo do número aos anexos depois do protocolo; cartão na lista **Triagem Certidões/Traslado** do quadro **04. Certidões/Traslado** (variáveis BOARD\_04, LISTA\_TRIAGEM\_CERT, HUB\_SITE, HUB\_CERT\_ANEXO\_DIAS — os padrões já apontam para o quadro real); regra da filiação repetida no servidor (400 quando o pedido só traz o nome); prazo de **3 dias úteis**; 'CERT' em atos.js (recibo e T-Consulta). Correções da auditoria antes de subir: (1) os anexos passam a subir **um por requisição** — cinco arquivos de 8 MB em base64 numa requisição só passavam do limite de 24 MB do corpo e o balcão recebia um 413 com recado de "análise"; (2) o **expurgo** (órfão em 12 h; vinculado em HUB\_CERT\_ANEXO\_DIAS, padrão 180) só rodava ao reiniciar o servidor — agora tem trava por hora e roda a cada uso do CERT; (3) nome de arquivo com travessão, apóstrofo curvo ou emoji derrubava a resposta (cabeçalho HTTP só aceita latin-1) — vai um nome ASCII em `filename` e o nome real em `filename*` (RFC 5987, com `' ( ) *` codificados), e a página do anexo lê o nome de verdade porque o servidor agora expõe o cabeçalho ao Netlify (`Access-Control-Expose-Headers`); (4) **LGPD:** a "pessoa que participa do ato" é terceiro — o campo de telefone dela some no CERT e o servidor zera o telefone antes de gravar e de disparar, de modo que o whats.js do Tabelião só avisa o solicitante; (5) id do anexo por `crypto.randomBytes` (32 hex); `X-Content-Type-Options: nosniff`; 413 com recado próprio ("envie um arquivo de até 8 MB por vez"); (6) papel da parte no payload = "Pessoa que participa do ato"; texto dos pendentes no CERT = "conferir com o solicitante antes de expedir"; falha nas etiquetas do quadro 04 não derruba o protocolo; **campo personalizado recusado pelo Trello deixou de derrubar o protocolo em qualquer ato** (o cartão já existia e o número já tinha sido consumido); (7) na tela, os `alert()` do CERT viraram aviso na própria página (#certAviso), trava contra segundo clique durante o envio, e a **legibilidade** entrou na régua do Tabelião: instruções em 15 px (antes 11,5), rótulos e título do bloco em 15–15,5 px, dicas dos campos e o "não consta" travado com contraste ≥ 4,5:1 (antes 2,2:1). anexo.html: nome pelo `filename*`, `decodeURIComponent` protegido, fontes ≥ 14 px.

**Preço ajustado.** Pedido do Tabelião, em 23/09: "acredito que esquecemos de incluir um campo para lançar o valor/preço do negócio/ato. Revise todos os atos/negócios patrimoniais e certifique-se de incluir, antes de 'Momento do Pagamento do Preço', um campo com referência a 'Preço ajustado' para lançamento do valor declarado pelas partes quanto ao negócio jurídico. Faça isso em todos os tipos de atos que comportem tal informação." E, ao ver a tela: "retirar observação abaixo do preço, desnecessário". Feito: na triagem de **CV-Urbano, CV-Rural, CDP e CDH** entra **"Preço ajustado (valor declarado pelas partes)"** imediatamente antes de "Momento do pagamento do preço"; na **Doação**, "Valor atribuído ao bem doado (declarado pelas partes)"; na **Permuta**, o campo de valores existente virou "Preço ajustado — valores atribuídos: bem 1 / bem 2 / torna". O campo é **obrigatório** (Protocolizar só destrava com um valor válido), tem **máscara em reais** ao sair do campo (150000 → R$ 150.000,00; 1.234,5 → R$ 1.234,50) e recusa zero, lixo ("12abc34") e valores acima do trilhão. O valor vai no topo do payload (`preco`) e, no servidor, abre a descrição do cartão em negrito (**PREÇO AJUSTADO: R$ …**; na doação, **VALOR ATRIBUÍDO AO BEM DOADO**), vai ao campo personalizado "Preço ajustado" se o quadro o tiver (como **texto**), aparece no **extrato do T-Consulta** e na linha "Preço ajustado: …" dos **dados do protocolo que o Redator recebe**. Protocolos antigos continuam sem o campo (o extrato mostra nada). A Ata de usucapião já tinha "Valor atribuído ao imóvel" e passa a alimentar o mesmo caminho. **Não coberto de propósito** (decisão do Tabelião): inventário (monte-mor), divórcio/união estável com partilha desigual e rerratificação de valor.

**Para o Tabelião decidir ou fazer.** (a) O template recibo\_protocolo\_3 imprime a pessoa do ato como "Comprador(a)" — num CERT, o cliente lê "Comprador(a): FULANO" (que pode ser o testador ou o falecido); um template próprio para certidão resolve. (b) As seis etiquetas do quadro 04 **não têm nome**: "Urgente" e "Doc. pendente" só se aplicam ao CERT depois que ele as criar lá. (c) Se quiser o preço em coluna própria no Trello, criar o campo personalizado "Preço ajustado" como **texto** nos quadros 00 e 02. (d) Comportamento antigo, de todos os atos: se o Trello falhar depois de gravado o número, o número fica consumido e a tela diz "Nada foi criado".

  - Testes novos: anexos de 7,9 MB um a um (e 413 com três de uma vez), nomes com travessão/emoji, Expose-Headers e nosniff, id de 32 hex, telefone da parte nunca chega ao WhatsApp, filtro de recibo\_destinatarios, preço no cartão/extrato/Redator (CV, DOA, PER, ATA-U e protocolos antigos), campo personalizado recusado não derruba o protocolo; no e2e, campo de telefone some no CERT e volta nos outros atos, aviso na página ao anexar .txt, fontes e contrastes do bloco CERT, o preço antes do momento do pagamento, máscara, obrigatoriedade e ausência de aviso abaixo do campo.
  - Docs: docs/CERT-SPEC.md (§5 e §6 atualizados para a v1.36.1).

## v1.36 — 17/09/2026 · CERT: pedido de certidão ou traslado no e-Protocolo (tela)

**Pacote:** versoes/hub-cn2o-v1.36-fontes-2026-09-17.zip. **Site mudou** (protocolo.html: botão CERT e o bloco "Pedido de certidão"; anexo.html, nova). O servidor correspondente ficou no pacote e só entrou no ar na v1.37 — ver acima.

**Pedido do Tabelião.** "Inclua um botão … para permitir o protocolo de pedido de CERTIDÃO cuja sigla será CERT, abrindo campos para nome do solicitante, RG, dados do ato (Livro, folhas, data). Sempre inclua botão 'não consta' ao lado de cada campo de dados informados pelo solicitante. Caso o pedido venha apenas com o nome completo da pessoa que participa do ato, nesse caso exija filiação. Inclua campo para anexar PDF ou imagem com documentos a servir de base para pesquisa nos livros. O protocolo deve gerar cartão Trello na área de trabalho do Trello específica das escreventes que acessam as certidões."

**O que entrou na tela.** O 15º botão de ato, **CERT · Certidão/Traslado**; o bloco **"Pedido de certidão — dados informados pelo solicitante"** (RG do solicitante, o que se pede — breve relatório, inteiro teor, traslado, certidão de procuração, negativa —, natureza do ato, livro, folhas, data, filiação pai/mãe), cada dado com o botão **"não consta"** ao lado, que trava o campo e leva a palavra ao cartão ("não consta" é resposta do solicitante; campo em branco é dado sobre o qual ninguém perguntou); a regra da **filiação obrigatória** quando livro, folhas e data estão todos ausentes (aviso em destaque e Protocolizar travado); o anexo de **PDF ou foto** (até 8 MB cada, no máximo cinco), que o cartão recebe como **link para anexo.html** — uma página do próprio site que abre o documento com a sessão do Hub, para que o documento da parte não vire URL pública. Especificação: docs/CERT-SPEC.md.

## v1.35 — 17/09/2026 · o pano de fundo do dashboard: a escultura da home entra na área de trabalho

**Pacote:** versoes/hub-cn2o-v1.35-fontes-2026-09-17.zip. **Só o site mudou** (frontend/src/estilo-extra.css, corpo.html, build.py e o recorte novo frontend/src/nicho-galeria.jpg). Servidor, Apps Script e prompts iguais à v1.34.

**Pedido do Tabelião.** "Gostei muito da home e dos elementos que você criou. Tente com sua criatividade e expertise transpor os mesmos elementos para o pano de fundo da dashboard do hub, de modo a ficar tão elegante como ficou na home. Tem que harmonizar e dar um charme a mais. Monte duas sugestões antes de aplicar e me mostre primeiro." Foram montadas duas — **A "Galeria"** (o mármore da home na coluna e o recorte fotográfico da arte numa peça emoldurada) e **B "Escultura"** (os arcos, a barra e o cubo redesenhados em vetor, como marca d'água) —, mostradas em capturas (docs/sugestoes-fundo-v1.35, geradas por teste/mockup-fundo.py sem tocar no projeto). Ele escolheu: **"escolho a galeria"**.

**O que entrou.** O dashboard tem pouco espaço livre — o mural e os quadros cobrem quase toda a coluna —, então o fundo trabalha onde de fato aparece. (1) A **superfície de mármore marfim da home** passou a forrar a coluna de conteúdo inteira, com um véu claro de cima para baixo (de 0 % a 55 %) que garante o contraste de tudo o que fica fora dos cartões — a saudação, a faixa dos Links úteis e o rodapé. (2) A célula que **sobra na grade das sete ferramentas** (a oitava, em qualquer largura com mais de uma coluna) deixou de ser um vazio e virou uma **peça de galeria**: o recorte do **arco de mármore marinho com o cubo vinho**, na mesma moldura dos cartões, com a legenda "CN2O · Ambiente interno" em versalete. A peça é decorativa (`aria-hidden`, não é botão, não entra na ordem do Tab) e **some no telefone**, onde a grade tem uma coluna só. No **tema escuro** a coluna volta ao marinho do Hub e só a peça permanece.

**Arrumação de bordo.** O base64 do mármore entrava duas vezes no arquivo publicado (home e dashboard); agora entra **uma vez só**, na variável CSS `--marmore` — o site cresceu apenas os ~45 KB da foto nova. O recorte foi reenquadrado em retrato, na proporção da célula, para que o cubo vinho não ficasse cortado, e acima da legenda da arte original.

**Duas correções no caminho.** (1) A guarda de contraste do e2e conferia a cor exata do texto; agora **mede a luminância já mesclada com o fundo** — a saudação usa alfa 0,76 sobre o mármore — e ignora, de propósito, o rótulo branco sobre a tarja vinho (rótulo curto sobre fundo escuro, exceção já aceita). (2) Uma rodada do e2e saiu com a guia de ITBI trazendo a profissão **dentro** do nome ("…MOURACOMERCIANTE") e o campo PROFISSÃO em branco. Cinco reproduções isoladas da mesma guia deram certo (10 pt, profissão no lugar), o que aponta corrida de preenchimento do próprio teste e não defeito da tela; ainda assim o passo passou a **conferir campo a campo logo depois de digitar**, para que, se voltar a acontecer, falhe apontando o campo — e o teste do tamanho do corpo deixou de exigir exatamente 10 pt: exige **uma página e corpo legível (≥ 9 pt)**, porque o ajuste automático desce por degraus conforme o conteúdo, inclusive o nome e o cargo de quem assina.

  - Testes: **67 de ponta a ponta** (passo novo: peça de galeria na 8ª célula com a legenda, mármore na coluna, contraste do texto solto, regras no topo da folha, tema escuro e telefone), **83 de API**, **12 de OCR** e **15 do recibo**.
  - Capturas: docs/sugestoes-fundo-v1.35 (as duas sugestões, a comparação lado a lado e o detalhe do nicho).

## v1.34 — 16 e 17/09/2026 · numeração do e-Protocolo, acervo ligado, quadro único IA-Not, 14 logins e trilha de auditoria

**Pacote:** versoes/hub-cn2o-v1.34-fontes-2026-09-17.zip (inclui **docs/apps-script/LeitorAcervo.gs 2.1.1** e as capturas docs/auditoria-v1.34-ia e docs/auditoria-v1.34-aud). **Servidor mudou** (hub.js: rotas /hub/admin/numeracao, /hub/admin/equipe/editar, /hub/registro, /hub/admin/auditoria; tabelas hub\_numeracao\_log e hub\_auditoria; semeadura dos 14 logins). **Site mudou** (dashboard com 7 quadros, página IA-Not, abas Numeração e Auditoria no editor, botão Editar na Equipe, registro de uso). **Apps Script LeitorAcervo** em nova versão (3). Publicada em três partes ao longo da noite de 16/09, cada uma testada e no ar antes da seguinte.

**Numeração do e-Protocolo (parte 1).** Aviso do Tabelião: "desabilitei o zapier (número de protocolo do trello), o último foi o nº 1449. Ativar a nova automação pelo hub cn2o para gerar os protocolos a partir do número 1450". O contador do Hub estava em 1371 (a semente antiga; cinco protocolos de teste, 1366–1370, gravados ao longo dos ensaios) — os próximos protocolos repetiriam números que o Zapier já tinha dado. A variável PROTOCOLO\_INICIAL só vale na primeira criação do banco; por isso o corte virou **função do Tabelião**: no editor do mural, a aba **Numeração** mostra o **próximo protocolo** em destaque, o maior número já gravado pelo Hub e o formulário "Ajustar o próximo número" (dois cliques para confirmar, motivo opcional); o servidor só aceita número **maior que o maior protocolo gravado** (nenhum número se repete) e registra cada ajuste (quem, quando, de → para, motivo) em hub\_numeracao\_log, listado na própria aba. O corte 1371 → 1450 foi feito por essa aba ainda em 16/09; o próximo protocolo sai como 1450.

**Acervo ligado (parte 1).** O LeitorAcervo foi implantado na conta tnitabaiana@gmail.com como aplicativo da Web (executa como o Tabelião; acesso "qualquer pessoa", protegido pelo segredo no corpo do POST). Duas lições: (1) o **SpreadsheetApp.openById exige o escopo completo de edição** das planilhas — o Google recusou a leitura com o escopo somente-leitura; em vez de ampliar a permissão, o script passou a ler pela **API do Google Sheets** (serviço avançado "Sheets" v4), que aceita o escopo somente-leitura — menos permissão, mesmo resultado; (2) pedir a grade inteira de uma aba (1.000 × 26 células, quase todas vazias) para achar os links levava 30–50 s e estourava a espera do servidor; agora só as **colunas de link** e só as linhas usadas são pedidas — leitura em ~3 s. Resultado no ar: **Acervo 2º Ofício (Antigo e Atual) - MILVO → 1.417 livros**; **Acervo 1º Ofício (Antigo) - SÉRGIO → 390 livros**; INDICE\_ATOS ainda vazia nas duas. O segredo compartilhado foi **trocado** durante a implantação (o valor anterior apareceu numa saída de ferramenta) e gravado nas duas pontas sem passar pelo assistente.

**Quadro único IA-Not (parte 2).** Pedido: "considerando o elevado número de quadros, refaça o layout criando um único quadro e vinculando nele todas as ferramentas de IA com um nome curto e com significado, cujo clique faça abrir uma subpágina com mini quadros das ferramentas atualmente autônomas no quadro geral… deixe esse novo quadro de IA numa cor diferente dos demais… coloque o nome no quadro de IA-Not". O dashboard passou de 10 para **7 quadros**: 01 e-Protocolo · 02 Calculadora de Emolumentos · **03 IA-Not** (único em cor própria, marinho-pastel #e4eaf4; chip ✦ IA; "IA Notarial — os quatro assistentes de IA da serventia num só lugar") · 04 Cláusulas CN2O · 05 T-Consulta · 06 Guia de ITBI · 07 Pesquisa / Acervo. O IA-Not abre a página dos assistentes (atalho #ia) com quatro mini-quadros — **3.1 Extrator, 3.2 e-Analista, 3.3 Gerador de Minuta (ainda EM BREVE, aberto só ao Tabelião) e 3.4 Redator CN2O** —, mesmos ids e comportamentos de antes; o "← Voltar" de um assistente aberto por ali volta para a página IA-Not ("← Voltar aos assistentes"), e pelos atalhos #extrator, #analista, #minutas e #redator volta ao hub, como sempre. Os cabeçalhos das ferramentas foram renumerados (3.1–3.4; 05, 06, 07).

**14 logins e trilha de auditoria (parte 3).** Pedido: "a lista de logins que preciso que vc implemente no hub, cada qual com acesso individual de login, bem como implementar trilha de auditoria pelo log no acesso das funcionalidades do hub". Os 14 usuários (lara.silva, hellen.lima, laila.carvalho, iara.costa, josi.silva, romenia.oliveira, geovana.menezes, camily.oliveira, milvo.neto, sergio.oliveira, gessica.bueno, josi.contini, jessica.santos, jonas.aragao) existem no servidor; quem já existia ficou como estava (josi.silva "Substituta do Tabelião", milvo.neto "Chefe do Setor de Protocolo"; camily.jesus foi mantida — o Tabelião decide); os novos entraram como "Escrevente" e **cada pessoa cria a própria senha no primeiro acesso**. A aba **Equipe** ganhou o botão **Editar** (nome de exibição e cargo — o Redator assina com o cargo). A **trilha de auditoria** registra o **uso, nunca o trabalho**: quem, quando, de onde (IP) e qual ferramenta — entrar e sair, abrir cada ferramenta, cada análise de IA (modelo, tempo, tokens, custo, quantos arquivos — nunca o que foi enviado nem a resposta), consulta pelo protocolo (só o número), pesquisa no acervo (os filtros usados; espaçada em 30 s), agenda e notas (só o fato de usar, espaçado em 10 min), guia de ITBI gerada, publicação do mural, minuta guardada (só id e tamanho) e toda ação administrativa (cadastro, edição, senha zerada, corte de numeração). A aba **Auditoria** do editor filtra por pessoa, ação e período, mostra 50 por página e **exporta CSV** para o Excel em português (BOM UTF-8, ';'; célula começada por =, +, - ou @ recebe apóstrofo — contra injeção de fórmula). Retenção de 730 dias (HUB\_AUDITORIA\_DIAS). Ficam fora, por ora: tentativas de login erradas (moram no server.js) e os 403 de administração.

**Aferição.** Quadro único, auditoria e logins feitos por dois agentes em cópias do projeto, integrados por diferença e revisados antes da publicação (um achado corrigido: a variante escura da aba Numeração pintava claro sobre a folha branca do editor — removida; outro, no CSV: proteção contra fórmulas). Harness: o script reiniciar-real.sh passou a rodar relativo ao próprio diretório (funciona em cópias).

  - Testes: **66 de ponta a ponta** (novos: aba Numeração com corte em dois cliques; 7 quadros e a página IA-Not com os mini-quadros 3.1–3.4, cor própria e a volta pela página IA; aba Auditoria com filtros e CSV; Editar na Equipe), **83 de API** (novos: numeração — 400/409, corte vale no próximo protocolo e fica no registro; 14 logins; editar equipe; auditoria — registros por rota, espaçamento, filtros, paginação, CSV, 401/403, nada de conteúdo), **12 de OCR** e **15 do recibo**.
  - Capturas para o Tabelião: docs/auditoria-v1.34-ia (dashboard com 7 quadros, página IA-Not, telefone, tema escuro) e docs/auditoria-v1.34-aud (aba Auditoria, aba Equipe com os 14 logins, tema escuro).

## v1.33 — 16/09/2026 · agenda por dia, Bloco de Notas, Guia de ITBI e Pesquisa / Acervo

**Pacote:** versoes/hub-cn2o-v1.33-fontes-2026-09-16.zip (inclui **docs/AUDITORIA-v1.33-frontend.md** — auditoria independente da versão integrada —, **docs/GUIA-ITBI-SPEC.md**, **docs/PESQUISA-ACERVO-SPEC.md**, **docs/apps-script/LeitorAcervo.gs** e capturas selecionadas). **Servidor mudou** (hub.js: tabela hub\_notas e rotas /hub/notas; rotas /hub/acervo; novo **acervo.js**). **Site mudou** (mural, subpáginas, dois cartões novos, **itbi.js** e **pdf-mini.js** no build). Apps Script CriadorDeMinutas e prompts iguais. Feita em quatro frentes por agentes paralelos (agenda, notas, ITBI, acervo) e auditada como um todo antes da publicação.

**Correção da manhã (v1.32.1).** O Tabelião abriu a agenda e a grade veio sem estilo: uma chave `}` a menos deixava as regras da subpágina presas dentro de um bloco `@container`; o Chrome 152 as ignorava, o Chromium dos testes as aplicava. Corrigido em minutos e o e2e ganhou uma guarda permanente: confere que as regras novas estão no topo da folha de estilo.

**Pedidos do Tabelião (cinco, ao longo do dia).** (1) "A página interna da agenda não está nada intuitiva… a partir do clique na data a subpágina traga apenas o dia específico; crie ainda uma função para permitir agendar compromisso em data futura fora dos dias da semana atual." (2) O recorte "Agenda Cn2o" em cor diferente, "um amarelo palha (claro) por exemplo". (3) "Ainda na Agenda, refaça o layout para particioná-la ladeando com um 'Bloco de Notas' (cor diferente) para anotações de modelos de mensagens ou comandos de texto de uso cotidiano." (4) Um quadro **gerador de guias de ITBI** da Prefeitura de Itabaiana: transformar o formulário anexo em página de campos, com profissão das partes, número de pessoas por polo, "não declarado" no valor e "não consta" nos demais campos, e um PDF pronto para imprimir e assinar, numa página só. (5) Um quadro **"Pesquisa / Acervo"** que abre uma subpágina com campos de pesquisa (livro, partes, data, folhas), ligada às duas planilhas do Google Sheets do acervo — "Acervo 1º Ofício (Antigo) - SÉRGIO" e "Acervo 2º Ofício (Antigo e Atual) - MILVO" — como dois submódulos.

**Minha Agenda, agora por dia.** Clicar numa coluna do quadro abre **só aquele dia**: a data por extenso, o selo "hoje", e as treze faixas uma embaixo da outra ("Dia inteiro / prazos", 07h … 18h), cada uma um campo de 16 px que cresce com o texto e salva sozinho (0,8 s depois de parar de digitar, ao sair do campo, ao fechar). No alto, "← Dia anterior · Hoje · Dia seguinte →", **"Outra data…"** (calendário para qualquer dia, futuro ou passado, inclusive fim de semana) e "Ver a semana" (a grade de antes virou vista secundária); uma faixa com os cinco dias da semana (número e quantidade de notas) troca de dia num clique. No fim da subpágina, **"Próximos"**: tudo o que está marcado nos 60 dias seguintes, agrupado por data, clicável. E o quadro do mural ganhou a linha **"Depois desta semana:"** com os três próximos compromissos fora da semana (e "+ N na agenda" quando há mais). A leitura passou a ser uma só chamada de 62 dias; o refresh periódico continua sem tocar em célula em edição.

**Bloco de Notas.** O quadro Minha Agenda foi dividido em dois painéis: à esquerda a agenda (em quadros estreitos os cinco dias viram cinco linhas), à direita o **Bloco de Notas** em verde-sálvia claro (#edf3ec): os textos que a escrevente repete todo dia — mensagens de WhatsApp, e-mails, trechos padrão — com título, as duas primeiras linhas e o botão **Copiar** (feedback "Copiado ✓"). "+ Nova nota" e "Abrir o bloco →" levam à subpágina, onde cada nota é um cartão com título e texto editáveis, salvamento automático igual ao da agenda e "Apagar" com segundo clique. Pessoal por login (tabela hub\_notas; até 60 notas de 4.000 caracteres). O recorte **"Agenda Cn2o"** (aniversariantes) dentro do quadro Avisos ficou em amarelo-palha (#fbf5dd), como pedido.

**09 · Guia de ITBI.** O formulário da Prefeitura (papel Ofício) virou uma página de campos por seção — 1 Adquirente(s), 2 Transmitente(s), 3 Imóvel, 4 Operação, 5 Documentação, 6 Observações — com **1 a 4 pessoas por polo** (nome, CPF/CNPJ, RG/CNH, **profissão**, endereço, município, CEP), chips para situação do terreno, tipo de construção e natureza da operação, **valor com máscara e o botão "Não declarado"**, e o botão **"não consta"** ao lado de cada campo (menos os nomes e as observações): ligado, o campo trava e a guia imprime "NÃO CONSTA"; vazio sem marcação sai em branco, como no modelo. Ao gerar, uma conferência lista os campos em branco ("Gerar assim mesmo" / "Voltar e completar"); só falta de nome de adquirente ou de transmitente impede. O PDF é feito **no próprio navegador**, por um escritor de PDF sem dependência (pdf-mini.js: Helvetica/Helvetica-Bold, WinAnsi, tabelas de largura dos AFM da Adobe), em **A4, uma página**, reproduzindo o layout oficial: brasão, cabeçalho da Prefeitura, faixas cinza das seções, "CPF/CNPJ | RG/CNH | PROFISSÃO", o atesto, a data, a linha de assinatura com **o nome e o cargo de quem está logado**, o quadro do Cartório e a seção de avaliação para uso da Prefeitura. Se o conteúdo não cabe (muitas pessoas, endereços longos), a fonte desce por degraus até 7,5 pt e só então vai a uma segunda página. Nada é guardado no servidor; "Baixar" salva "Guia-ITBI-<nome>-<data>.pdf".

**10 · Pesquisa / Acervo.** Dois submódulos no alto — **Acervo Antigo · 1º Ofício (incorporado)** e **Acervo · 2º Ofício (antigo e atual)** —, cada um ligado a uma planilha. As planilhas são cópias do mesmo modelo "Painel do Acervo de Livros", e a pesquisa lê duas abas de cada: **CADASTRO\_LIVROS** (o livro físico: tipo, número, código, status, sala/estante/prateleira/caixa, digitalizado, pasta digital, pendência, observações) e **INDICE\_ATOS** (o ato: tipo, data, livro, folhas, nº do ato, outorgante × outorgado, objeto, matrícula, valor, tributo, link — hoje só com o cabeçalho, vai sendo preenchida). Campos: nº do livro, tipo de livro (chips com os onze tipos da planilha), folhas (faixas cruzam), nome das partes (sem acento, em qualquer ordem, vários nomes por vírgula), data (de/até ou só o ano), tipo de ato e "qualquer palavra"; resultado em dois grupos, **Livros** e **Atos**, com contagem, "Mostrar mais 50", "mais…" para o resto das colunas, "Pasta digital" quando há link e os trechos casados em destaque. A planilha é privada (compartilhada por conta, nunca por link): quem a lê é o servidor, pelo Apps Script **LeitorAcervo** na conta do Tabelião, com segredo compartilhado no corpo do POST, cache por fonte (10 min) e leitura forçada só pelo administrador — mesmo caminho da ponte do Google Docs. Sem as variáveis HUB\_ACERVO\_WEBAPP\_URL/HUB\_ACERVO\_SECRET a tela diz "índice ainda não vinculado" e continua navegável.

**Auditoria independente (docs/AUDITORIA-v1.33-frontend.md, 83 evidências).** Veredito "aprovada com ressalvas", sem bloqueante: um contraste abaixo do mínimo (a linha vazia do recorte Agenda Cn2o) e rótulos em 13 px — tudo corrigido antes da publicação. Confirmado: CSS íntegro (1.528 regras de topo, nenhuma at-rule aberta), campos 100 % em 16 px, tema escuro sem texto claro sobre escuro, XSS bloqueado em nota, célula, ITBI (inclusive no PDF) e linha da planilha, robustez a falhas do servidor (retentativas, "Tentar de novo", nada se perde), backend com login sempre da sessão e limites exatos, segredo do acervo nunca em log, 400 px sem rolagem horizontal, foco visível e nomes acessíveis.

  - Testes: **62 de ponta a ponta** (novos: agenda por dia com "Outra data" e "Próximos", Bloco de Notas, Guia de ITBI com PDF conferido por pdfinfo/pdftotext, Pesquisa / Acervo com fake das duas planilhas; guarda das regras CSS no topo; cartões 01–10), **69 de API** (novos: notas; acervo — mapeamento tolerante, filtros, duas fontes, atos vazios, sessão obrigatória), **12 de OCR** e **15 do recibo**.
  - Para ligar o acervo: implantar docs/apps-script/LeitorAcervo.gs na conta tnitabaiana@gmail.com (passo a passo no cabeçalho do arquivo) e gravar as duas variáveis na Railway.

## v1.32 — 16/09/2026 · a página inicial em dois quadros: "Avisos" e "Minha Agenda"

**Pacote:** versoes/hub-cn2o-v1.32-fontes-2026-09-16.zip (inclui **docs/AUDITORIA-v1.32-frontend.md** com 33 capturas). **Servidor mudou** (hub.js: tabela hub\_agenda e as rotas GET/POST /hub/agenda). **Site mudou** (mural, menu lateral e a subpágina da agenda). Apps Script e prompts iguais à v1.30.

**Pedido do Tabelião.** Refazer a página inicial do Hub com **apenas dois quadros no mural**: um de **"Avisos"**, na mesma grafia da palavra "Mural", incorporando os avisos do Tabelião e a Agenda Cn2o; e outro chamado **"Minha Agenda"** (também estilizado), uma agenda pessoal do escrevente para as atividades do cartório — observações, prazos, providências pendentes —, funcional, intuitiva e de lançamento fácil: na visualização inicial a **agenda da semana em 5 colunas, com destaque colorido para os compromissos do dia atual**; com um clique abre uma subpágina onde, clicando no dia e na faixa de horário, a escrevente escreve o compromisso, **com salvamento automático**. Os dois quadros em cores diferentes (tons pastel), só para distingui-los com sutileza.

**O mural agora.** O quadro de Metas saiu do mural (o cadastro continua guardado no servidor e editável na aba Metas do editor do Tabelião — nada foi apagado). Ficaram dois papéis presos por alfinete, ligeiramente inclinados como antes: à esquerda **"Avisos"** (título manuscrito em Caveat, como o "Mural"; legenda "do Tabelião"), com os três avisos mais recentes, "Ver todos os avisos" e, separado por um tracejado, o bloco **"Agenda Cn2o"** com os aniversariantes do mês e o seu "Ver mais"; à direita, maior, **"Minha Agenda"**, com a legenda da semana ("semana de 14 a 18 de setembro"), o selo de resumo ("Só sua" quando vazia; "3 esta semana · 2 hoje" quando há lançamentos) e a **semana em cinco colunas, segunda a sexta**: número do dia, nome do dia e, dentro, as anotações com a hora (⚑ para as de dia inteiro); **o dia de hoje vem em vinho** — moldura, número e as anotações realçadas. Tons: rosé (vinho a 2–11 % sobre branco) no Avisos e azul-acinzentado (marinho) na Minha Agenda; o ícone e o traço do título acompanham a cor. Aos sábados e domingos o quadro já mostra a semana seguinte. Em quadros estreitos (telefone, janela apertada) os cinco dias viram cinco linhas, uma por dia, com a prévia legível em 16 px.

**A agenda pessoal.** Clicar em qualquer dia, em "Abrir minha agenda" ou no item **Minha Agenda** do menu lateral (que substituiu "Metas") abre a subpágina com a **grade da semana**: cinco colunas (o dia de hoje marcado; o dia clicado ganha um contorno tracejado quando não é hoje) por treze faixas — **"Dia inteiro / prazos"** para o que não tem hora e as horas cheias **07h a 18h**. Cada célula é um campo de texto (16 px, cresce com o conteúdo, até 2.000 caracteres): **clicou, escreveu, está salvo** — 0,8 s depois de parar de digitar a anotação vai ao servidor, e também ao sair da célula, ao fechar a subpágina, ao trocar de semana e ao fechar a aba. O status no alto diz "Salvando…" e "✓ Salvo às 14h35"; a célula fica tracejada enquanto espera e ganha o tom vinho quando tem texto. Texto apagado apaga a célula no servidor. **← Semana anterior · Hoje · Semana seguinte →** trocam a grade; Escape fecha. Se o servidor falhar no meio, a tela avisa, tenta de novo sozinha (seis vezes, em intervalos crescentes) e oferece "Tentar de novo"; se a sessão expirar durante um salvamento, a anotação fica guardada na memória e é enviada assim que a mesma pessoa entra de novo (outra pessoa entrando no mesmo navegador não herda nada). A atualização periódica do mural nunca sobrescreve uma célula que esteja sendo editada.

**Servidor.** Tabela **hub\_agenda** (login, dia, faixa, texto, atualizado\_em; chave login+dia+faixa). **GET /hub/agenda?de&ate** devolve as células do período (até 62 dias) **da pessoa da sessão, e só dela** — o login nunca vem do formulário; **POST /hub/agenda** grava ou atualiza a célula (upsert; texto vazio apaga). Validações: dia real em aaaa-mm-dd, faixa 0–23, até 2.000 caracteres, caracteres de controle removidos; o texto é guardado como texto e mostrado como texto (nada vira HTML — conferido com `<img onerror>` na auditoria). A gravação é por POST porque o CORS do servidor só libera GET e POST — nenhuma mudança no server.js foi necessária.

**Auditoria (agente, com Playwright; relatório docs/AUDITORIA-v1.32-frontend.md, 33 capturas).** Veredito inicial "aprovada com ressalvas"; tudo o que apontou foi corrigido antes da publicação: (bloqueante) as anotações de mais de uma linha abriam cortadas porque a auto-altura rodava com o véu ainda escondido — a ordem foi invertida; a sessão expirada no meio do salvamento perdia a anotação — agora fica na memória e é salva ao entrar de novo; prévias do quadro em 14 px e palavras partidas ao meio — 16 px, hifenização e colunas mais largas (o quadro da agenda ficou com 2/3 da largura); oito rótulos abaixo de 13,5 px — todos ≥ 13 px (os chips) e ≥ 13,5 px (os rótulos); `role="grid"` incompleto — retirado; contrastes de "livre", "+ N mais" e da ajuda (agora 16 px) elevados. Confirmado pela auditoria: paleta só vinho/marinho/branco; nada de texto claro sobre escuro dentro dos quadros; tema escuro mantém os papéis claros; 400 px sem rolagem horizontal; a coluna das horas fica presa à esquerda quando a grade rola no telefone; Tab passa de célula em célula; todas as regressões (avisos, Ver todos, Agenda Cn2o, Editar mural, sino, busca, cartão 05 "Em breve", Agenda do Tabelião embutida) intactas.

  - Testes: **59 de ponta a ponta** (passo novo: semana seg–sex com hoje em destaque, grade 13×5, salvamento automático com status, navegação de semana, persistência no servidor, apagar limpa, agenda pessoal vazia para outra pessoa, dois tons pastel, títulos em Caveat sem caixa alta, 400 px), **62 de API** (novo: POST grava/atualiza a célula, GET só do período e só do dono, texto vazio apaga, validações 400, 401 sem sessão, caracteres de controle fora), **12 de OCR** e **15 do recibo**.
  - Capturas para o Tabelião: docs/auditoria-v1.32/ e as telas em v1.32-telas (mural, subpágina preenchida, telefone, tema escuro).

## v1.31 — 15/09/2026 · o Gerador de Minuta fica "Em breve" para a equipe

**Pacote:** versoes/hub-cn2o-v1.31-fontes-2026-09-15.zip. **Só o site mudou** (cartão 05 e as rotas do Gerador). Servidor, Apps Script e prompt iguais à v1.30.

**Decisão do Tabelião.** O Hub entra em uso com a equipe na reunião de 16/09, mas a **inauguração do Gerador de Minuta fica adiada**: ele ainda vai fazer a curadoria das variáveis de união estável e de divórcio antes de liberar. Ordem dada: deixar tudo como está no código e apenas **inutilizar o botão** — sombreado, com "Em breve" —, sem dar acesso às funcionalidades.

**O que foi feito.** Nada do que foi construído saiu do código. Só a entrada foi fechada: o cartão **05 · Gerador de Minuta** aparece sombreado e hachurado de leve, com o selo **EM BREVE** e o rodapé "Em curadoria pelo Tabelião"; o clique só avisa ("Gerador de Minuta: em breve — o Tabelião está concluindo a curadoria das minutas") e os atalhos diretos **#minutas** e **#minuta=ID** (links permanentes de minutas guardadas) voltam ao hub com o mesmo aviso. **O Tabelião continua entrando** (conta administradora): para ele o cartão traz o selo e o rodapé "Aberto só ao Tabelião →", para testar e curar. A liberação à equipe é uma linha no código (`GERADOR_LIBERADO = true`) e uma publicação. Ajuste de bordo aproveitado: o foco que a validação do Gerador dá ao campo que falta é cancelado se a escrevente navegar antes.

  - Testes: **58 de ponta a ponta** (passo novo: cartão sombreado com selo para a equipe, clique só avisa, #minutas volta ao hub; cartão aberto ao Tabelião), **61 de API**, **12 de OCR** e **15 do recibo**.

## v1.30 — 15/09/2026 · o Gerador em fases: quadros lado a lado, linha do tempo e conferência

**Pacote:** versoes/hub-cn2o-v1.30-fontes-2026-09-15.zip (inclui **docs/AUDITORIA-v1.30-frontend.md** com as capturas, a spec §10 e o **docs/apps-script/CriadorDeMinutas.gs** 1.1). **Site mudou** (card 05 inteiro). **Servidor mudou só no prompt** (hub-prompts.js: nota do padrão gráfico, item 6.0 da camada). **Apps Script mudou** (CriadorDeMinutas 1.1 — nova versão da mesma implantação; a URL do web app é a mesma).

**Pedido do Tabelião (cinco, no mesmo dia).** (1) Conforto de leitura na página do Gerador: "está tudo muito claro" — um tom acima, pastel ou sombra, para distinguir um quadro de informações de outro. (2) Reorganizar a página: os quadros da entrevista **dispostos lateralmente, como fases de uma linha cronológica** — a escrevente caminha para a direita, confere cada quadro (faltou a profissão? lança ali) e chega ao botão Gerar sem rolar a página para baixo. (3) O botão "Abrir no Google Docs" nas **cores do Google Drive**, para chamar a atenção. (4) **Espaçamento entre linhas zero (0,00) em todo o corpo do texto** das minutas, sem mexer no resto da formatação. (5) **Retirar o termo de ciência do escrevente** da tela (a ciência passa a ser colhida por termo escrito e arquivada em pasta), **botões dos atos maiores, com o nome em fonte maior**, e uma **tela de espera** mais bonita (um emoji elegante girando ou uma barrinha).

**O Gerador em fases.** A entrevista deixou de ser uma página longa. Depois do cabeçalho vem a **linha do tempo** (presa no topo enquanto a fase rola): um passo por fase, numerado, com o nome e uma bolinha com o **número de respostas em aberto** daquela fase; a fase atual em vinho, as percorridas em marinho; qualquer passo é clicável. Abaixo, o **trilho**: os quadros ficam lado a lado e só o da fase atual fica à vista (rolagem horizontal com encaixe; a altura do trilho acompanha a fase, para a página não crescer com o que está fora da vista). Cada quadro tem número e título, um texto de uma linha dizendo o que se faz ali, as **caixas brancas** com os grupos de campos sobre o **fundo pastel** do quadro (vinho a 7 % sobre branco — a regra da paleta continua: só vinho, marinho e branco com transparências) e, no pé, **← Fase anterior · Fase N de M · Próxima fase →**. Atalhos: Alt+← e Alt+→ (fora de campos de texto); Tab num campo de outra fase leva a fase junto; ao trocar de ato a linha do tempo se refaz. As fases: **1 · O ato** (os cinco botões, forma do ato e particularidades) e **2 · Documentos** (a zona de anexos e a transposição) valem para os cinco atos; depois vêm as do ato — PROC: Finalidade · Outorgantes · Outorgados · Objeto e poderes · Condições; UE: Conviventes (um quadro por pessoa, lado a lado) · A união · Nome e registro; DISS_UE: Conviventes · A união e os bens · Filhos e alimentos · Nome e advogado; DIV: Cônjuges (com o nome antes do casamento) · O casamento · Bens · Filhos e pensão · Nome e advogado; EMANC: O emancipando · Os pais · Outorga e guarda — e a última, comum, **Conferir e gerar**: as Observações, a **Conferência** (uma linha por fase com o que ficou sem resposta — chips sem escolha e campos obrigatórios vazios, "nenhum documento anexado" na fase 2 — cada uma com o atalho "ir à fase"; quando não falta nada, "✓ Nenhum campo obrigatório em aberto") e o botão **GERAR MINUTA**. O aviso de validação (nome que falta, finalidade sem escolha) **leva a escrevente à fase do campo** e o foca. O resultado continua no painel logo abaixo do trilho, que entra na vista quando a geração começa e quando a minuta chega; **Limpar** volta à fase 1. Nada mudou na ficha: todos os ids, chips e chaves da v1.29 foram preservados — só a distribuição na tela é outra.

**O que saiu e o que cresceu.** O termo de ciência (duas caixas que travavam o botão) saiu da tela por decisão do Tabelião; o botão Gerar nasce liberado e só trava enquanto a transposição roda. Os botões dos atos passaram a 82 px de altura, ícone maior, **nome em 18 px** e descrição em 14 px. O botão **"Abrir no Google Docs"** é branco com o texto escuro (conforto de leitura), uma moldura tricolor azul-verde-amarelo, um trio de barras nas mesmas cores e um pulso de atenção nos primeiros segundos (três vezes; desligado para quem pede menos movimento); a caixa do Docs ganhou a faixa verde à esquerda. A **espera da IA** — no Gerador, na transposição, no Extrator, no Analista e no Redator — mostra um relógio (emoji) que dá a volta a cada 12 segundos, a mensagem da etapa, uma **barra em movimento** (indeterminada: nunca uma porcentagem inventada) e o tempo decorrido em 16 px.

**Entrelinha 0,00 (formatação da minuta).** Quem formata o Doc é o CriadorDeMinutas (o modelo devolve texto puro); o ajuste entrou lá, em `estiloBase`, para **todos os parágrafos** (cabeçalho, PRIMEIRO TRASLADO, ementa, corpo, a linha em branco, alertas e origem): entrelinha simples (1,0) e 0 pt antes e depois — nada mais mudou. Publicado como **versão 2 da mesma implantação** (doGet responde "CriadorDeMinutas 1.1 — Hub CN2O v1.30"). A camada de integração registra a regra no padrão gráfico (item 6.0), sem mexer no texto do Tabelião.

**Auditoria (agente, com Playwright; relatório docs/AUDITORIA-v1.30-frontend.md, 30 capturas).** 34 verificações; nada bloqueava; 6 itens "deve corrigir", todos corrigidos antes da publicação: a linha do tempo no tema escuro não distinguia os estados; "Próxima fase" no pé de uma fase alta deixava a seguinte pelo meio (agora o topo do trilho fica sempre logo abaixo da linha do tempo); resto de rolagem vertical do trilho depois de Shift+Tab; a página saltava ao fim quando a minuta chegava (âncora de rolagem do Chrome — desligada, e o resultado entra na vista de novo); rótulos da linha do tempo e da posição abaixo do piso (13,5 px); contraste das notas soltas sobre o pastel (agora ≥ 4,5:1). Cosméticos atendidos: Alt+setas ignoradas dentro de campos de texto; sem classe residual na fase escondida; a espera não anuncia a cada segundo ao leitor de tela; CSS morto do termo removido.

  - Testes: **57 de ponta a ponta** (passo novo: fases por ato 6/8/7/8/6, navegação, linha do tempo, conferência com "ir à fase", validação que leva ao campo, Alt+→, Limpar, botões dos atos em 18 px, espera com relógio e barra), **61 de API**, **12 de OCR** e **15 do recibo**.
  - Capturas de tela para o Tabelião: docs/auditoria-v1.30/ (fase 1, partes, conferência, tema escuro, 400 px).

## v1.29 — 15/09/2026 · os documentos preenchem a ficha; a minuta nasce no Google Docs

**Pacote:** versoes/hub-cn2o-v1.29-fontes-2026-09-15.zip (inclui **docs/prompt-transposicao.txt**, **docs/apps-script/CriadorDeMinutas.gs**, as auditorias **docs/AUDITORIA-v1.29-backend.md** e **docs/AUDITORIA-v1.29-frontend.md**, e a spec §9). **Servidor mudou** (hub.js, hub-prompts.js e o novo docs.js). **Site mudou** (card 05).

**Pedido do Tabelião (dois).** (1) Trazer para dentro da página do Gerador o mesmo poder de leitura do Extrator: um botão e uma área para anexar RG, CNH, certidões e comprovantes, que extraia os dados das pessoas e os **transponha direto para os campos** da entrevista — convivente 1 e 2, cônjuges, outorgantes e outorgados, emancipando e pais, com a referência da certidão — para que a minuta já saia completa. (2) A minuta não ficar num campo de copiar e colar: **nascer como Google Doc na pasta do Gerador de Minutas** (a base do Claude no Drive), com a formatação já definida na casa, e o Hub apontar o link para a escrevente abrir, ajustar e lançar no Extra Digital.

**Transposição de dados (card 05).** A zona **"Documentos das partes"** passou para logo depois da escolha do ato, com o botão **"Extrair e transpor dados"**. O servidor ganhou a ferramenta **transpor** (POST /hub/ia/transpor): só os documentos vão ao modelo (nunca a ficha), com o OCR dedicado como segunda leitura; o prompt manda transcrever — nunca inventar, "" quando não consta, divergências aos alertas, **estado civil só quando um documento o prova** (certidão de casamento, escritura de união, óbito do cônjuge; RG, CNH e certidão de nascimento não provam), uma pessoa por objeto, pais só como filiação. O servidor faz o parse do JSON e devolve um objeto de forma fixa; resposta sem JSON vira "tente de novo". A tela preenche os campos por ato (nome, CPF, profissão, nascimento, estado civil por chip só quando comprovado, e a nova **"Qualificação (dos documentos)"** de cada pessoa — parágrafo no padrão da casa, editável), no DIV também a certidão de casamento (data, serventia, matrícula, emissão, regime, nomes de solteiro) e no EMANC a **certidão de nascimento do menor e o nome dos pais** pela filiação. O painel **"Dados transpostos"** mostra cada pessoa e o destino (trocável), com **Reaplicar**, **Desfazer**, a marca "substituído" e os alertas do modelo. A ficha ganhou as chaves QUALIFICACAO\_\*, CERTIDAO\_NASCIMENTO, PAI e MAE; a camada de integração (itens 2.1 e 2.6) as trata como transcrição documental quando o documento está anexado e como declaração quando não está — nunca como autorização de nada.

**Minuta no Google Docs.** O Apps Script **CriadorDeMinutas** (web app na conta do Tabelião, protegido por segredo compartilhado) recebe do servidor a minuta PRONTA ou PRELIMINAR e grava um Doc na pasta **"Minutas Geradas — Casos"** com a formatação levantada das minutas da base: A4, Arial 11, cabeçalho Livro/Folha, PRIMEIRO TRASLADO, ementa recuada 7 cm com o ato e os nomes em negrito, corpo em **texto corrido** justificado, SAIBAM e rótulos das partes em negrito, nomes em caixa alta em negrito, **título de cada cláusula em negrito e sublinhado**, marcadores e valores em negrito, placeholders \[LAVRATURA: …\] e \[FALTA: …\] em vermelho; ao fim, a **"SEÇÃO ALERTAS — NÃO INTEGRA O CORPO LAVRÁVEL"** com a decisão do roteador, as pendências, o ⚠ CONFERIR e a linha de origem (quem gerou, quando, modelo) — para a escrevente conferir e apagar antes do lançamento. Título do Doc: "MINUTA — Hub — &lt;partes&gt; — dd/mm/aaaa HH:mm" (com " — PRELIMINAR" quando for o caso). O Hub mostra o botão **"Abrir no Google Docs"** no alto do resultado e guarda a URL no link permanente (#minuta=…); o Copiar continua como via alternativa. A falha do Docs nunca derruba a minuta: sai um aviso e a minuta segue na tela. Estados fechados (BLOQUEADA, DECISÃO DO TABELIÃO, FORA DO ESCOPO) não criam documento.

**Aferição com o Gemini real (15/09, pelo Chrome do Tabelião, documentos simulados).** UE com RG + certidão de casamento: **51 s, US$ 0,0175**, duas pessoas, dez campos preenchidos, qualificações no padrão da casa, casamento (data, serventia, matrícula, regime, nome de solteira) transposto — único desvio: a qualificação da esposa dizia "casada" e o campo próprio veio vazio (o prompt ganhou a regra de coerência interna no mesmo dia). EMANC com certidão de nascimento + RG de terceira: **46 s, US$ 0,0177**, emancipando, data, certidão (serventia · matrícula · emissão) e PAI/MAE pela filiação preenchidos; a terceira pessoa ficou fora dos destinos, como devia.

**Auditorias.** Backend: rota transpor (limites: 12 pessoas, 2.000 caracteres por campo, caracteres de controle fora), ponte docs.js (fetch com redirecionamento, text/plain de propósito, segredo nunca em log, timeout), coluna doc\_url só com URL de documento do Google Docs; fake do Apps Script no harness (POST → 302 → GET, como o Google faz). Tela: fichas anteriores idênticas, só com as linhas novas intercaladas; Gerar travado durante a transposição e vice-versa; Limpar zera o painel; tema escuro e 520 px.

  - Testes: **56 de ponta a ponta**, **61 de API**, **12 de OCR** e **15 do recibo**. Custo da transposição: ≈ US$ 0,02 por chamada.
  - **Docs ligado em produção em 15/09, 17h40 (Maceió),** com a autorização expressa do Tabelião: web app publicado (versão 1, executa como tnitabaiana@gmail.com, acesso "qualquer pessoa"), variáveis gravadas na Railway. Primeiro Doc real: "MINUTA — Hub — TESTE v1.29 — UE — … — PRELIMINAR", na pasta "Minutas Geradas — Casos", com a formatação conferida (A4, Arial 11, cabeçalho Livro/Folha, ementa recuada, corpo corrido, títulos de cláusula em negrito e sublinhado, placeholders em vermelho, seção de alertas ao fim). O segredo compartilhado pode ser trocado a qualquer momento nas duas pontas (propriedade do script e variável da Railway).

## v1.28 — 14/09/2026 · o Gerador de Minuta passa a rodar sobre o Prompt-Mestre BV 4.0

**Pacote:** versoes/hub-cn2o-v1.28-fontes-2026-09-14.zip (inclui **docs/prompt-mestre-bv-4.0.txt** — o documento do Tabelião, byte a byte —, **docs/hub-camada-integracao.txt**, **docs/GERADOR-MINUTA-SPEC.md** e **docs/RED-TEAM-v1.28.md**). **Servidor mudou** (hub.js e hub-prompts.js). **Site mudou** (card 05).

**Como nasceu.** O Tabelião entregou o **AGENTE JURÍDICO-NOTARIAL BV CARTÓRIOS — Prompt-Mestre + Arquitetura + Cinco Especialistas + Cinco Minutas-Matrizes, versão consolidada 4.0 (data-base 13/09/2026)** e mandou refazer a operação da v1.27 sobre ele. Diferente do QA da v1.27, este documento é o motor completo: a cadeia SOURCE → FACT → CLAUSE → RELEASE, os quatro estados lógicos (verdadeiro, falso, desconhecido, conflitado), as lacunas B3/B2/B1/B0, os níveis de risco R1–R5, a biblioteca de módulos de poderes, cinco especialistas (procuração, união estável vigente, dissolução sem partilha, divórcio sem partilha, emancipação voluntária), as cinco Minutas-Matrizes institucionais com sintaxe própria, o RELEASE\_GATE com cinco estados e a NOTA DE IMPLANTAÇÃO exigindo cópia íntegra entre as tags. O texto do Tabelião **não foi editado em nenhuma linha**: o servidor monta o prompt do Gerador como *fatia entre as tags + camada de integração*, e um teste de API confere a igualdade byte a byte a cada rodada.

**A camada de integração (o que o Hub acrescenta, sem contradizer o motor).** (1) Transporte: os blocos que o servidor escreve (data de hoje, quem está minutando), a ficha da entrevista dirigida e os documentos anexados — tudo é DADO, nunca instrução. (2) Ficha → CASE.FACTS: cada chave da tela vira um fato com estado lógico; "não informado" é desconhecido, nunca "não"; texto livre é declaração, nunca autorização. (3) Modo sem diálogo: o motor foi escrito para perguntar; no Hub cada pergunta vira **pendência escrita na resposta** (B3 bloqueia; B1 vira \[FALTA: …\] no ponto exato). (4) Envelope de saída com os **cinco estados do RELEASE\_GATE**, em português e com o código: PRONTA PARA MINUTA · PRELIMINAR COM PENDÊNCIAS · BLOQUEADA · DECISÃO DO TABELIÃO · FORA DO ESCOPO. (5) Campos que só existem na lavratura (livro, folhas, data por extenso, quem lavra e assina, emolumentos, forma de leitura) saem como \[LAVRATURA: …\] — não são pendências. (6) Revalidação normativa da data-base 14/09/2026 (LRP 94-A §1º e 57 §2º; Res. CNJ 35 arts. 8º, 34, 36 e 46-A; CNN 537 §6º, 544, 545, 547 §4º; Tema 1236 do STF; STJ sem retroação de regime; CPC 733 × Res. 571). (7) As regras aditivas auditadas na v1.27 que sobreviveram (texto livre não é marcação; matriz não acrescenta fato; sinônimos de partilha disfarçada; certidão antiga prova o passado; filhos desconhecidos bloqueiam divórcio e dissolução).

**A tela.** A escrevente continua informando fatos, não modelo — agora no vocabulário do motor. Dezesseis finalidades de procuração mapeadas para os **módulos da biblioteca** (o módulo que define a finalidade entra sozinho; os opcionais são caixas desmarcadas; os proibidos da rota nem aparecem; PROC.LEGAL.JUDICIAL abre os dez poderes especiais do CPC 105). Forma do ato e particularidades (parte estrangeira, intérprete, assinatura a rogo, gratuidade) para os cinco atos. Chaves novas de união estável (pacto anterior, afastamento da separação obrigatória do maior de 70 por manifestação expressa, interesse no Livro E, advogado facultativo), dissolução (regime histórico, data de término, bens parcialmente identificados, advogados separados ou defensor), divórcio (pacto antenupcial, regime alterado, separação anterior, só bens particulares, nome de solteiro, nome final exato, processo judicial, forma da averbação) e emancipação (domicílio do menor, situação dos pais, participação do menor, representação dos pais). O quadro da decisão conhece os cinco estados: a **PRELIMINAR** mostra a minuta com a faixa "não apta à assinatura" e a lista de PENDÊNCIAS, e o botão Copiar fica disponível; BLOQUEADA, DECISÃO DO TABELIÃO e FORA DO ESCOPO não trazem minuta.

**Auditorias (uma por etapa, seis agentes).** Backend: 8 defeitos corrigidos (o gerador do prompt não tolerava BOM nem tag repetida; cabeçalhos reservados recuados ou em minúsculas escapavam do filtro; nome da sessão podia injetar linha). Tela: 4 defeitos (texto livre com separador Unicode virava chave; leitura da resposta engolia seções; AUTOCONTRATO e PREÇO fora das finalidades certas). **Red-team do prompt composto: 65 achados** (11 altos, 23 médios, 25 baixos) — entre eles, a camada mandava emitir seções que o OUTPUT CONTRACT não pede; o motor exige verificação normativa que o modelo não pode fazer sem busca (agora o snapshot é o item 6 da camada, e normas locais ficam marcadas "conferir na data do ato"); cinco frases que a camada mandava o modelo escrever por conta própria viraram \[FALTA\] (o motor proíbe redação fora da matriz); sete módulos da biblioteca não têm cláusula pronta na MATRIX 01 e passam a ir ao Tabelião em vez de serem improvisados. Todas as correções entraram na camada; o texto do Tabelião ficou intacto.

**Aferição com o Gemini real.** Logo após a publicação: procuração para regularizar veículo, sem documentos anexados — resposta em **34 s, US$ 0,06**, envelope íntegro, estado PRELIMINAR COM PENDÊNCIAS (3 pendências), minuta na forma exata da MATRIX 01, módulo de transferência corretamente descartado; o modelo omitiu o rodapé de rascunho e o servidor passou a garanti-lo. Na noite de 14/09, **as 15 fichas dos poison cases** do §24.3 do Prompt-Mestre: **14 de 15 no estado esperado**, a décima quinta (PROC-P01) mais conservadora do que o esperado (BLOQUEADA, coerente com a camada); nenhuma minuta com conteúdo proibido; US$ 0,89 no total, 14–74 s por chamada (relatório na pasta de Governança).

**O que mudou de decisão em relação à v1.27.** Emancipação de menor sob tutela é **fora do escopo** (emancipação judicial), não mais bloqueio; substabelecimento não informado deixa de sair "vedado" e vira pendência; gravidez em dissolução de união estável vai à decisão do Tabelião (tensão CPC 733 × CNN 537 §6º), em divórcio bloqueia.

**Lacunas do Prompt-Mestre levadas ao Tabelião (spec §8 e RED-TEAM, "Decisões reservadas").** A MATRIX 01 não tem módulo para **comprar imóvel**, **casamento por procuração** e **procuração para divórcio/dissolução** (propostos PROC.REAL\_ESTATE.BUY, PROC.MARRIAGE com 90 dias e PROC.DIVORCE\_REPRESENTATION com 30 dias) nem cláusula para irrevogabilidade, mandato em causa própria, renúncia genérica e consentimento médico; a MATRIX 03 não tem variante "sem conhecimento de gravidez". Até a extensão, essas hipóteses saem como DECISÃO DO TABELIÃO — seguro, não perigoso.

  - Testes: **51 de ponta a ponta**, **48 de API**, **12 de OCR** e **15 do recibo**. Custo por minuta: da ordem de US$ 0,06 a 0,12 (prompt de ~200 mil caracteres).

## v1.27 — 14/09/2026 · o Gerador de Minuta: a escrevente informa fatos, o roteador decide

**Pacote:** versoes/hub-cn2o-v1.27-fontes-2026-09-14.zip. **Servidor e site mudaram.** O Tabelião entregou o QUALITY\_ASSURANCE\_ENGINE (Arquitetura 1.0) — a camada de testes de um gerador de minutas — e pediu que o card 05 virasse **"Gerador de Minuta"**: a escrevente informa o ato, a finalidade em linguagem de balcão e os fatos com consequência jurídica (sempre com "não informado" à vista); o roteador decide a variante, bloqueia o que não pode ser lavrado e devolve a qualificação ao Tabelião. Poderes de alto risco só entram marcados. Dezenove âncoras normativas conferidas em fonte primária (art. 46-A da Res. 35; LRP 94-A §1º; LRP 91 p.ú.; Tema 1236; STJ sem retroação de regime; CPC 733 × Res. 571). Auditorias: red-team do prompt (26 casos; 12 brechas e 5 contradições corrigidas), backend e tela (16 fichas por Playwright; texto livre com quebra de linha virava chave — corrigido). Superada pela v1.28, que trocou o prompt próprio pelo Prompt-Mestre do Tabelião.

## v1.26 — 13/09/2026 · o Redator CN2O: as comunicações da serventia

**Pacote:** versoes/hub-cn2o-v1.26-fontes-2026-09-13.zip. Ferramenta **08 · Redator CN2O**: sete tipos, sete formalidades — e-mail, resposta a e-mail, WhatsApp, ofício, resposta a ofício, aviso de pendência documental, comunicado interno. O servidor acrescenta sozinho a data de hoje, quem assina (ofício pelo Tabelião, o resto pela escrevente) e, com o nº do protocolo, o ato, as partes e as pendências do dossiê. Vocabulário da casa como regra; pronome de tratamento por autoridade; ofício com número em branco; "Refazer com esse ajuste".

## v1.25 — 13/09/2026 · o recibo do WhatsApp passa a dizer o que o cliente precisa saber

**Pacote:** versoes/hub-cn2o-v1.25-fontes-2026-09-13.zip. O texto aprovado dizia "autuada no **processo** 1369" e levava só o número. Novo template recibo\_protocolo\_3: protocolo em negrito, ato por extenso, apresentante, parte/comprador(a), vendedor(a). **atos.js** e **recibo.js**; a quantidade de variáveis segue o nome do template — a virada é uma linha na Railway. Falta o Tabelião criar o template no WhatsApp Manager.

## v1.24 — 12/09/2026 · o cônjuge por regime e o acento como dado

**Pacote:** versoes/hub-cn2o-v1.24-fontes-2026-09-12.zip. Comunhão universal: cônjuge coproprietário, TRANSMITENTE (arts. 1.667 e 1.668). Comunhão parcial: VÊNIA (art. 1.659, I, c/c 1.647, I). "ANDRÉA" não vira "ANDREA".

## v1.23 — 12/09/2026 · o que o primeiro teste com documento ruim ensinou

**Pacote:** versoes/hub-cn2o-v1.23-fontes-2026-09-12.zip. Aferição com a matrícula 33.765: Extrator acertou 45 de ~46 informações e os 21 campos numéricos; e-Analista pegou o fechamento de 99,98% das frações. **Pro no e-Analista reprovado** — voltou ao flash. Conferência aritmética (1 ha = 10.000 m²), cruzamento de campos repetidos, ⚠ CONFERIR só com o que tem consequência, georreferenciamento por faixa (Dec. 12.689/2025).

## v1.22 · v1.21 — 12/09/2026

v1.22: OCR migra para o **Cloud Vision por chave de API**; chave nunca aparece em log. v1.21: 503 do provedor — retentativa, troca de modelo nos dois sentidos e recado humano em português.

## v1.20 … v1 — 11 e 12/09/2026

v1.20: carregamento verde no upload. v1.19: Extrator só por documento. v1.18: Extrator vira botões. v1.17: dupla leitura. v1.16: Extrator volta à vida. v1.15: Atkinson Hyperlegible 18 px. v1.14: T-Consulta. v1.13: auditoria do pacto antenupcial (594 opções, 0 violações). v1.12–v1: lançamento, leitura confortável, aba Equipe, Agenda, home da escultura, links úteis, dashboard marfim, atalho 3D do Trello, avatar, mural com alfinetes, Frase do Dia pela planilha, Calculadora servida pelo Hub.

## Governança

  - **Dossiê Técnico rev. 2**, **Política de Segurança da Informação**, **Aferição de eficácia**, **Aferição do Gerador — 15 poison cases (v1.28)**, **Guia — template recibo\_protocolo\_3**, **Portaria + Termo de Ciência** (reunião 16/09, vigência 17/09), **Raio-X** de 12/09, **Guia do OCR pelo Cloud Vision**, **Anexo D-1 — Inventário do arquivo de versões**.
  - **No pacote (docs/):** o Prompt-Mestre BV 4.0 íntegro, a camada de integração, a especificação da ficha (com a tabela finalidade → módulos, a proposta de extensão da MATRIX 01 e, desde a v1.29, o §9 da transposição), o relatório do red-team com as decisões reservadas ao Tabelião, o prompt da transposição e o Apps Script CriadorDeMinutas com o passo a passo de implantação no cabeçalho.

## Pendências

  - **Segurança (varredura de 25/09/2026):**
    - Pacotes C e D a publicar.
    - Depois do pacote B: apagar a variável HUB_KEY da Railway, que não tem mais uso.
    - Tornar **privados** os repositórios cn2o-hub e cn2o-hub-backend no GitHub.
    - Gravar `NODE_ENV=production` na Railway.
    - **Trocar o token e o secret do Trello**, que foram expostos numa conversa.
    - Confirmar o faturamento e criar um alerta de orçamento no Google Cloud (Gemini e Vision).
    - Ligar o backup do Postgres na Railway.
    - Gerar código de acesso para quem ainda está "sem senha" na aba Equipe.
  - **Atendimentos (v1.39):**
    - Gravar NEXTQS\_TOKEN na Railway e rodar a carga do histórico uma vez.
    - Deixar o n8n e o Hub coletando em paralelo por alguns dias e comparar os números.
    - Depois, desativar no n8n "CN2O · NextQS → Painel de Atendimentos", "CN2O · NextQS → Relatório mensal (PDF)" e "CN2O · NextQS → dados para o Hub CN2O". Este último sobrou da v1.38.5 revertida.
    - Antes de 01/10/2026, escolher quem manda o PDF de setembro: o n8n (no Drive) ou o Hub (por e-mail). Os dois juntos geram o PDF em dobro.
    - Quando o n8n for desligado, o painel do claude.ai deixa de receber dados novos.

  - **Google Docs (v1.29):** compartilhar a pasta "Minutas Geradas — Casos" com as contas das escreventes (por conta, como é a regra da casa) para que o botão "Abrir no Google Docs" abra sem pedir acesso; e apagar ou renomear o Doc de teste "MINUTA — Hub — TESTE v1.29 …" quando quiser.
  - **Gerador de Minuta — decisões do Tabelião** (RED-TEAM-v1.28.md, "Decisões reservadas"; spec §8): extensão da MATRIX 01 (comprar imóvel; casamento por procuração; procuração para divórcio/dissolução; cláusulas de irrevogabilidade, causa própria, renúncia e consentimento médico); variante "sem conhecimento de gravidez" na MATRIX 03; filhos incapazes com decisão judicial integral (liberar × devolver); padrão de qualificação das partes; prazo de 90 dias das certidões; septuagenário com união anterior aos 70; suspensão do poder familiar.
  - **Gerador de Minuta — aferição ampliada:** os 22 ataques de transporte do RED-TEAM-v1.28.md no Gemini real; a transposição com documentos reais (foto de balcão, verso de RG, certidão antiga manuscrita); e conferência humana de toda minuta na primeira fase (a ferramenta é de rascunho assistido).
  - **Portaria (art. 3º):** o card 05 mudou de escopo (cinco atos, cinco estados, transposição e Docs) e o card 08 nasceu depois da minuta — ajustar os incisos antes de 17/09 ou tratar como facultativos na primeira fase.
  - **Atualizar o Dossiê Técnico** com as ferramentas 05 (novo escopo, transposição, ponte com o Google Docs) e 08 (art. 4º, §6º do Prov. 213).
  - **Recibo do CERT (v1.37.1):** cadastrar o template `recibo_certidao_1` na Meta (pelo WhatsApp Manager, com o texto do guia, ou gravando WHATS\_WABA\_ID na Railway e chamando `POST /hub/admin/whats/template-cert`) e, aprovado, gravar `WHATS_TEMPLATE_CERT=recibo_certidao_1`. Até lá o CERT sai pelo recibo comum. Campo "Preço ajustado" e etiquetas do quadro 04: feitos em 23/09.
  - **Numerar a Portaria** e imprimir o Termo para as assinaturas na reunião de 16/09.
  - **Liberar o Gerador de Minuta à equipe (v1.31):** depois da curadoria das variáveis de união estável e divórcio — `GERADOR_LIBERADO = true` em frontend/src/app.js e publicar.
  - **Termo de ciência do Gerador por escrito (v1.30):** as duas caixas saíram da tela por decisão do Tabelião; a ciência de que o Gerador serve só aos cinco atos e de que toda minuta é rascunho passa a ser colhida no termo escrito e arquivada em pasta — conferir se o Termo da reunião de 16/09 já traz essas duas declarações.
  - **Minha Agenda e Bloco de Notas (v1.32/1.33):** pessoais — só a própria pessoa lê; se o Tabelião quiser um dia enxergar a agenda das escreventes (para distribuir tarefas), é uma decisão a tomar e uma rota nova. Faixas fixas 07h–18h (lista MA\_FAIXAS no código).
  - **Pesquisa / Acervo (ligado na v1.34):** a aba INDICE\_ATOS das duas planilhas ainda só tem o cabeçalho — a pesquisa por partes/folhas/data só devolve resultados quando a equipe começar a indexar os atos. Os tipos de livro da planilha do 1º Ofício podem não coincidir com os chips (conferir com o Sérgio).
  - **Guia de ITBI (v1.33):** conferir com a Prefeitura se a guia em A4 (o modelo é Ofício) é aceita — e, desde a v1.37.4, se aceita a guia em mais de uma página quando há muitas partes; o nº da guia sai em branco para a Prefeitura preencher.
  - **Equipe (v1.34):** ajustar nome de exibição e cargo dos novos logins pela aba Equipe → Editar (entraram como "Escrevente"); decidir o que fazer com camily.jesus (mantida ao lado de camily.oliveira); tentativa de login errada e 403 ainda não entram na trilha (exige mexer no server.js).
  - **Protocolos de teste 1366–1370** gravados pelo Hub durante os ensaios (e os cartões correspondentes no Trello): decidir se ficam como registro ou se são marcados como teste.
  - **Metas (v1.32):** o quadro saiu do mural por pedido do Tabelião; o cadastro segue na aba Metas do editor, sem lugar na tela — decidir se volta um dia (como subpágina) ou se a aba sai do editor.
  - **Espelho dos pacotes no Drive** parado na v1.6: o arquivo-mestre no GitHub está completo, v1 a v1.39.2.
  - **Adequação ao Prov. 213/2026** (MFA, logs, PCN/PRD, backup 3-2-1, criptografia documentada; classe com a contadoria) e **lapidações do raio-X** (limite de tentativas no login, sessão em /vendedores e /corretores, CORS, cabeçalhos, expurgo de minutas, backup do Postgres).
  - **Acompanhar o custo** da IA na aba de consumo na primeira semana de uso real — o Gerador ficou mais caro por chamada (prompt de 200 mil caracteres); a transposição custa ≈ US$ 0,02.
  - Eventos na "Agenda Cn2o"; fotos reais; frases na planilha; cadastrar colaboradores; atalhos nas máquinas; compartilhar a pasta 09 por conta.
